// =============================================================================
// api/seo.js
// Consolidated SEO/GEO discovery endpoint. Four unrelated read-only surfaces
// merged into ONE Vercel Function to stay under Hobby's 12-function cap —
// see docs/plans/SEO-GEO-plan.md, "Risks" row on serverless function limits.
// The plan's Appendix A originally specified four separate route files
// (sitemap-dynamic.js, feeds.js, llms-full.js, cron-seo.js); all four are
// implemented here instead, dispatched by ?type=, exactly like
// api/college-quiz.js already merges unrelated handlers by HTTP method.
//
// Routed via vercel.json rewrites so public paths are exactly what the plan
// specifies (clients never see ?type=):
//   GET /sitemap-dynamic.xml  -> /api/seo?type=sitemap
//   GET /feed.xml             -> /api/seo?type=feed&format=rss
//   GET /feed.json            -> /api/seo?type=feed&format=json
//   GET /llms-full.txt        -> /api/seo?type=llms-full
//   (cron) /api/seo?type=cron -> Vercel Cron only, see vercel.json "crons"
//
// All four share one Supabase query set (api/_catalog.js) so sitemap, feeds,
// llms-full, and the cron sweep can never drift out of sync with each other.
//
// Bounded pagination (Vercel Hobby cron/timeout constraints): the quizzes
// table — the one most likely to grow large as uploads accumulate — is
// fetched in bounded .range() pages inside loadPublicCatalog() (see
// api/_catalog.js's fetchAllQuizzes), not one unbounded SELECT. That keeps
// every action here, including the cron sweep below, comfortably inside
// Vercel Hobby's 10s serverless execution limit even as the library grows.
// courses/folders/profiles stay single unbounded queries since those track
// curriculum structure rather than upload volume and remain small.
// =============================================================================

import { ogVersion, stampFromDate } from "./_og/version.js";
import { loadPublicCatalog, filterRecentlyChanged } from "./_catalog.js";
import { escapeXml, absUrl } from "./_urls.js";
import { notifySearchEngines } from "./_seoNotify.js";

const SITE_ORIGIN = "https://basmagi-quiz.vercel.app";

// Cache-Control shared by every read-only discovery document here (plan §6.3,
// user-adjustment #3): 1h fresh, 24h stale-while-revalidate. Vercel's Edge
// Network serves the cached copy to concurrent crawlers, shielding Supabase
// from simultaneous cold reads even under a crawler traffic spike.
const DISCOVERY_CACHE_CONTROL = "public, s-maxage=3600, stale-while-revalidate=86400";

// ── Sitemap (dynamic part) ───────────────────────────────────────────────────

function buildSitemapXml(catalog) {
    const urlEntries = [];

    for (const c of catalog.courses) {
        urlEntries.push({ loc: c.url, lastmod: c.lastmod, changefreq: "weekly", priority: "0.8" });
    }
    for (const f of catalog.folders) {
        urlEntries.push({ loc: f.url, lastmod: f.lastmod, changefreq: "weekly", priority: "0.7" });
    }
    for (const q of catalog.quizzes) {
        urlEntries.push({ loc: q.url, lastmod: q.lastmod, changefreq: "monthly", priority: "0.9" });
    }
    for (const l of (catalog.lessons || [])) {
        urlEntries.push({ loc: l.url, lastmod: l.lastmod, changefreq: "weekly", priority: "0.8" });
    }
    for (const n of (catalog.notebooks || [])) {
        urlEntries.push({ loc: n.url, lastmod: n.lastmod, changefreq: "weekly", priority: "0.8" });
    }
    for (const p of catalog.profiles) {
        urlEntries.push({ loc: p.url, lastmod: p.lastmod, changefreq: "monthly", priority: "0.5" });
    }

    const body = urlEntries
        .map((e) => {
            const lastmodTag = e.lastmod ? `<lastmod>${escapeXml(new Date(e.lastmod).toISOString())}</lastmod>` : "";
            return `  <url><loc>${escapeXml(e.loc)}</loc>${lastmodTag}<changefreq>${e.changefreq}</changefreq><priority>${e.priority}</priority></url>`;
        })
        .join("\n");

    return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${body}\n</urlset>\n`;
}

async function handleSitemap(req, res) {
    const catalog = await loadPublicCatalog();

    if (!catalog) {
        // Never 500 on a sitemap request (plan §6.3 guard) — degrade to an
        // empty urlset (the static sitemap-static.xml sibling in the index
        // still carries the static pages) and tell caches not to keep the
        // failure around.
        res.setHeader("Content-Type", "application/xml; charset=utf-8");
        res.setHeader("Cache-Control", "no-store");
        return res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>\n`);
    }

    res.setHeader("Content-Type", "application/xml; charset=utf-8");
    res.setHeader("Cache-Control", DISCOVERY_CACHE_CONTROL);
    return res.status(200).send(buildSitemapXml(catalog));
}

// ── Feeds (RSS 2.0 + JSON Feed 1.1) ──────────────────────────────────────────

const FEED_ENTRY_LIMIT = 50;
const FEED_CACHE_CONTROL = "public, s-maxage=900, stale-while-revalidate=3600";

function collectFeedEntries(catalog) {
    // Interleave quizzes + courses + folders by lastmod/createdAt, newest
    // first, capped at FEED_ENTRY_LIMIT (plan §6.4).
    const entries = [];

    for (const q of catalog.quizzes) {
        entries.push({
            kind: "quiz",
            title: q.title,
            description: q.description || (q.courseName ? `امتحان في مقرر ${q.courseName}` : "امتحان جديد"),
            url: q.url,
            date: q.lastmod || q.createdAt,
            category: q.courseName || null,
            ogImage: absUrl(`/api/og?quizId=${encodeURIComponent(q.metaId)}&v=${ogVersion("quiz", stampFromDate(q.createdAt))}`),
        });
    }
    for (const c of catalog.courses) {
        entries.push({
            kind: "course",
            title: c.name,
            description: `مقرر ${c.name}`,
            url: c.url,
            date: c.lastmod,
            category: c.education_type || null,
            ogImage: null,
        });
    }
    for (const f of catalog.folders) {
        entries.push({
            kind: "folder",
            title: f.name,
            description: `مجلد ${f.name}`,
            url: f.url,
            date: f.lastmod,
            category: null,
            ogImage: null,
        });
    }
    for (const l of (catalog.lessons || [])) {
        entries.push({
            kind: "lesson",
            title: l.title,
            description: l.courseName ? `درس في مقرر ${l.courseName}` : "درس تفاعلي",
            url: l.url,
            date: l.lastmod || l.createdAt,
            category: l.courseName || null,
            ogImage: absUrl(`/api/og?lesson=${encodeURIComponent(l.id)}&v=${ogVersion("lesson", stampFromDate(l.lastmod))}`),
        });
    }
    for (const n of (catalog.notebooks || [])) {
        entries.push({
            kind: "notebook",
            title: n.title,
            description: n.description || (n.courseName ? `دفتر تفاعلي بأسلوب MATLAB في مقرر ${n.courseName}` : "دفتر تفاعلي بأسلوب MATLAB"),
            url: n.url,
            date: n.lastmod || n.createdAt,
            category: n.courseName || null,
            ogImage: null,
        });
    }

    entries.sort((a, b) => new Date(b.date || 0).getTime() - new Date(a.date || 0).getTime());
    return entries.slice(0, FEED_ENTRY_LIMIT);
}

function buildRssXml(entries) {
    const items = entries
        .map((e) => {
            const pubDate = e.date ? new Date(e.date).toUTCString() : new Date().toUTCString();
            const enclosure = e.ogImage
                ? `<enclosure url="${escapeXml(e.ogImage)}" type="image/png" length="0"/>`
                : "";
            const category = e.category ? `<category>${escapeXml(e.category)}</category>` : "";
            return [
                "  <item>",
                `    <title>${escapeXml(e.title)}</title>`,
                `    <link>${escapeXml(e.url)}</link>`,
                `    <guid isPermaLink="true">${escapeXml(e.url)}</guid>`,
                `    <description>${escapeXml(e.description)}</description>`,
                `    <pubDate>${pubDate}</pubDate>`,
                category ? `    ${category}` : "",
                enclosure ? `    ${enclosure}` : "",
                "  </item>",
            ]
                .filter(Boolean)
                .join("\n");
        })
        .join("\n");

    return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
<channel>
  <title>أحدث امتحانات بصمجي</title>
  <link>${SITE_ORIGIN}</link>
  <description>آخر الامتحانات والمواد المضافة على منصة امتحانات بصمجي</description>
  <language>ar</language>
  <ttl>30</ttl>
  <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
${items}
</channel>
</rss>
`;
}

function buildJsonFeed(entries) {
    return JSON.stringify(
        {
            version: "https://jsonfeed.org/version/1.1",
            title: "أحدث امتحانات بصمجي",
            home_page_url: SITE_ORIGIN,
            feed_url: absUrl("/feed.json"),
            language: "ar",
            items: entries.map((e) => ({
                id: e.url,
                url: e.url,
                title: e.title,
                content_text: e.description,
                date_published: e.date ? new Date(e.date).toISOString() : undefined,
                tags: e.category ? [e.category] : undefined,
                image: e.ogImage || undefined,
            })),
        },
        null,
        2,
    );
}

async function handleFeed(req, res) {
    const format = req.query?.format === "json" ? "json" : "rss";
    const catalog = await loadPublicCatalog();

    if (!catalog) {
        res.setHeader("Cache-Control", "no-store");
        if (format === "json") {
            res.setHeader("Content-Type", "application/feed+json; charset=utf-8");
            return res.status(200).send(buildJsonFeed([]));
        }
        res.setHeader("Content-Type", "application/rss+xml; charset=utf-8");
        return res.status(200).send(buildRssXml([]));
    }

    const entries = collectFeedEntries(catalog);
    res.setHeader("Cache-Control", FEED_CACHE_CONTROL);

    if (format === "json") {
        res.setHeader("Content-Type", "application/feed+json; charset=utf-8");
        return res.status(200).send(buildJsonFeed(entries));
    }
    res.setHeader("Content-Type", "application/rss+xml; charset=utf-8");
    return res.status(200).send(buildRssXml(entries));
}

// ── llms-full.txt (dynamic, exhaustive GEO catalog) ──────────────────────────

function formatQuestionTypesLabel(types) {
    if (!types) return null;
    if (Array.isArray(types)) return types.join(", ");
    return String(types);
}

function buildLlmsFullTxt(catalog) {
    const lines = ["# منصة امتحانات بصمجي — الفهرسة الكاملة", ""];

    // Group courses by education_type/college for readable sectioning.
    const byCollege = new Map();
    for (const course of catalog.courses) {
        const key = course.college || course.education_type || "عام";
        if (!byCollege.has(key)) byCollege.set(key, []);
        byCollege.get(key).push(course);
    }

    const foldersByCourse = new Map();
    for (const f of catalog.folders) {
        if (!f.parent_folder_id) {
            if (!foldersByCourse.has(f.course_id)) foldersByCourse.set(f.course_id, []);
            foldersByCourse.get(f.course_id).push(f);
        }
    }
    const quizzesByCourse = new Map();
    const quizzesByFolder = new Map();
    for (const q of catalog.quizzes) {
        if (q.folderId) {
            if (!quizzesByFolder.has(q.folderId)) quizzesByFolder.set(q.folderId, []);
            quizzesByFolder.get(q.folderId).push(q);
        } else if (q.courseId) {
            if (!quizzesByCourse.has(q.courseId)) quizzesByCourse.set(q.courseId, []);
            quizzesByCourse.get(q.courseId).push(q);
        }
    }

    const lessonsByCourse = new Map();
    const lessonsByFolder = new Map();
    for (const l of (catalog.lessons || [])) {
        if (l.folderId) {
            if (!lessonsByFolder.has(l.folderId)) lessonsByFolder.set(l.folderId, []);
            lessonsByFolder.get(l.folderId).push(l);
        } else if (l.courseId) {
            if (!lessonsByCourse.has(l.courseId)) lessonsByCourse.set(l.courseId, []);
            lessonsByCourse.get(l.courseId).push(l);
        }
    }

    const notebooksByCourse = new Map();
    const notebooksByFolder = new Map();
    for (const n of (catalog.notebooks || [])) {
        if (n.folderId) {
            if (!notebooksByFolder.has(n.folderId)) notebooksByFolder.set(n.folderId, []);
            notebooksByFolder.get(n.folderId).push(n);
        } else if (n.courseId) {
            if (!notebooksByCourse.has(n.courseId)) notebooksByCourse.set(n.courseId, []);
            notebooksByCourse.get(n.courseId).push(n);
        }
    }

    function quizLine(q) {
        const typesLabel = formatQuestionTypesLabel(q.questionTypes);
        const countLabel = q.questionCount != null ? `${q.questionCount} سؤال` : null;
        const details = [countLabel, typesLabel].filter(Boolean).join(", ");
        const descPart = q.description ? `, ${q.description}` : "";
        return `  - [امتحان ${q.title}](${q.url})${details ? ` — ${details}` : ""}${descPart}`;
    }

    function lessonLine(l) {
        return `  - [درس تفاعلي: ${l.title}](${l.url})`;
    }

    function notebookLine(n) {
        const descPart = n.description ? ` — ${n.description}` : "";
        return `  - [دفتر برمجي تفاعلي: ${n.title}](${n.url})${descPart}`;
    }

    function formatSummaryCounts(quizzes, lessons, notebooks) {
        const parts = [];
        if (quizzes > 0) parts.push(`${quizzes} امتحان`);
        if (lessons > 0) parts.push(`${lessons} درس`);
        if (notebooks > 0) parts.push(`${notebooks} دفتر`);
        return parts.length > 0 ? parts.join(" · ") : "فارغ";
    }

    for (const [college, courses] of byCollege.entries()) {
        lines.push(`## ${college}`);
        for (const course of courses) {
            const parts = [course.education_type, course.year, course.term].filter(Boolean).join(", ");
            lines.push(`### مقرر ${course.name}${parts ? ` (${parts})` : ""}`);

            const directQuizzes = quizzesByCourse.get(course.id) || [];
            for (const q of directQuizzes) lines.push(quizLine(q));

            const directLessons = lessonsByCourse.get(course.id) || [];
            for (const l of directLessons) lines.push(lessonLine(l));

            const directNotebooks = notebooksByCourse.get(course.id) || [];
            for (const n of directNotebooks) lines.push(notebookLine(n));

            const childFolders = foldersByCourse.get(course.id) || [];
            for (const folder of childFolders) {
                const folderQuizzes = quizzesByFolder.get(folder.id) || [];
                const folderLessons = lessonsByFolder.get(folder.id) || [];
                const folderNotebooks = notebooksByFolder.get(folder.id) || [];
                const summary = formatSummaryCounts(folderQuizzes.length, folderLessons.length, folderNotebooks.length);
                lines.push(`- مجلد ${folder.name} (${summary})`);
                for (const q of folderQuizzes) lines.push(`  ${quizLine(q)}`);
                for (const l of folderLessons) lines.push(`  ${lessonLine(l)}`);
                for (const n of folderNotebooks) lines.push(`  ${notebookLine(n)}`);
            }
            lines.push("");
        }
    }

    for (const p of catalog.profiles) {
        lines.push(`- [${p.displayName}](${p.url})`);
    }

    return lines.join("\n") + "\n";
}

async function handleLlmsFull(req, res) {
    const catalog = await loadPublicCatalog();

    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    if (!catalog) {
        res.setHeader("Cache-Control", "no-store");
        return res.status(200).send("# منصة امتحانات بصمجي — الفهرسة الكاملة\n\n(تعذر تحميل البيانات مؤقتًا)\n");
    }

    res.setHeader("Cache-Control", DISCOVERY_CACHE_CONTROL);
    return res.status(200).send(buildLlmsFullTxt(catalog));
}

// ── Cron sweep ────────────────────────────────────────────────────────────────

async function handleCron(req, res) {
    // Vercel Cron requests carry the x-vercel-cron header, but that header
    // alone isn't a secret — a request forged with the same header name from
    // outside Vercel's infrastructure could still reach this far. Layer in
    // Vercel's own recommended CRON_SECRET check too: when the env var is
    // set, only Authorization: Bearer <CRON_SECRET> is accepted (Vercel
    // attaches this automatically to its own cron invocations once the env
    // var exists). If CRON_SECRET isn't configured yet, fall back to the
    // header-presence check alone so the cron still works out of the box.
    const isVercelCron = req.headers["x-vercel-cron"] !== undefined;
    const cronSecret = process.env.CRON_SECRET;
    const authHeader = req.headers["authorization"];
    const secretOk = cronSecret ? authHeader === `Bearer ${cronSecret}` : true;

    if (!isVercelCron || !secretOk) {
        return res.status(403).json({ error: "Forbidden" });
    }

    const catalog = await loadPublicCatalog();
    if (!catalog) {
        console.error("[cron-seo] catalog load failed; skipping this run");
        return res.status(200).json({ ok: false, reason: "catalog load failed" });
    }

    const recent = filterRecentlyChanged(catalog, 24);
    const urls = [
        ...recent.courses.map((c) => c.url),
        ...recent.folders.map((f) => f.url),
        ...recent.quizzes.map((q) => q.url),
        ...((recent.lessons || []).map((l) => l.url)),
        ...((recent.notebooks || []).map((n) => n.url)),
        ...recent.profiles.map((p) => p.url),
    ];

    await notifySearchEngines({ add: urls, reason: "cron" });

    console.log(
        "[cron-seo] swept",
        "courses:", recent.courses.length,
        "folders:", recent.folders.length,
        "quizzes:", recent.quizzes.length,
        "lessons:", (recent.lessons || []).length,
        "notebooks:", (recent.notebooks || []).length,
        "profiles:", recent.profiles.length,
    );

    return res.status(200).json({
        ok: true,
        announced: urls.length,
        breakdown: {
            courses: recent.courses.length,
            folders: recent.folders.length,
            quizzes: recent.quizzes.length,
            lessons: (recent.lessons || []).length,
            notebooks: (recent.notebooks || []).length,
            profiles: recent.profiles.length,
        },
    });
}

// ── IndexNow key verification file ───────────────────────────────────────────
// IndexNow requires a static-looking file at https://{host}/{key}.txt whose
// body is exactly the key string, matching the `key`/`keyLocation` that
// api/_seoNotify.js sends on every ping. Serving it dynamically from the same
// INDEXNOW_KEY env var (instead of a hand-committed public/<key>.txt file)
// means the two can never drift out of sync — see docs/plans/SEO-GEO-plan.md
// "IndexNow key file abuse" risk row and the user's explicit adjustment.
//
// Routed via a vercel.json wildcard rewrite:
//   GET /:key([a-f0-9]{32}).txt -> /api/seo?type=indexnow-key&key=:key
// The handler only serves the body when the requested :key segment matches
// process.env.INDEXNOW_KEY exactly; any other 32-hex-char guess 404s, so this
// can't be used to probe or serve arbitrary content.
async function handleIndexNowKey(req, res) {
    const requestedKey = req.query?.key;
    const configuredKey = process.env.INDEXNOW_KEY;

    if (!configuredKey || !requestedKey || requestedKey !== configuredKey) {
        return res.status(404).send("Not found");
    }

    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    // The key file itself never changes unless INDEXNOW_KEY is rotated; long
    // cache is fine and reduces load from repeated IndexNow key verification.
    res.setHeader("Cache-Control", "public, max-age=86400, immutable");
    return res.status(200).send(configuredKey);
}

// ── Debug (temporary, read-only, no PII/secrets) ─────────────────────────────
// Diagnoses "sitemap/feed/llms-full are empty" without needing Vercel log
// access: reports per-table row counts + error messages only (never row
// content, no auth). Safe to leave in — it's read-only and exposes nothing
// beyond what the public sitemap already reveals (counts, not content) plus
// error strings, which a public Supabase-status page would show anyway.
async function handleDebugCatalog(req, res) {
    const [coursesRes, foldersRes, quizzesRes, profilesRes] = await Promise.all([
        supabaseCatalogTableProbe("courses", "id, name, education_type, college, year, term, created_at, updated_at"),
        supabaseCatalogTableProbe("folders", "id, course_id, parent_folder_id, name, created_at, updated_at"),
        supabaseCatalogTableProbe("quizzes", "data, password, created_at, synced_at, course_id, folder_id"),
        supabaseCatalogTableProbe("admin_users", "handle, display_name, created_at"),
    ]);

    const catalog = await loadPublicCatalog();

    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Cache-Control", "no-store");
    return res.status(200).json({
        rawProbes: { courses: coursesRes, folders: foldersRes, quizzes: quizzesRes, admin_users: profilesRes },
        loadPublicCatalogResult: catalog
            ? {
                  courses: catalog.courses.length,
                  folders: catalog.folders.length,
                  quizzes: catalog.quizzes.length,
                  profiles: catalog.profiles.length,
              }
            : "null (every table failed)",
    });
}

async function supabaseCatalogTableProbe(table, columns) {
    try {
        const { createClient } = await import("@supabase/supabase-js");
        const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY);
        const { data, error, count } = await supabase.from(table).select(columns, { count: "exact" }).limit(1);
        return {
            ok: !error,
            errorMessage: error?.message || null,
            errorCode: error?.code || null,
            totalRowCount: count ?? null,
            sampleRowReturned: Array.isArray(data) && data.length > 0,
        };
    } catch (err) {
        return { ok: false, errorMessage: err.message, errorCode: "thrown" };
    }
}

// ── Dispatch ─────────────────────────────────────────────────────────────────

export default async function handler(req, res) {
    if (req.method !== "GET" && req.method !== "HEAD") {
        return res.status(405).json({ error: "Method not allowed" });
    }

    const type = req.query?.type;

    if (type === "sitemap") return handleSitemap(req, res);
    if (type === "feed") return handleFeed(req, res);
    if (type === "llms-full") return handleLlmsFull(req, res);
    if (type === "cron") return handleCron(req, res);
    if (type === "indexnow-key") return handleIndexNowKey(req, res);
    if (type === "debug-catalog") return handleDebugCatalog(req, res);

    return res.status(400).json({ error: "Unknown or missing ?type=" });
}