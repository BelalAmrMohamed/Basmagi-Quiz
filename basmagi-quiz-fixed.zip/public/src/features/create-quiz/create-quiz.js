// public/src/features/create-quiz/create-quiz.js

import {
  showNotification,
  _confirm,
  _prompt
} from "../../components/notifications/notifications.js";

import {
  processQuizJsonFile,
  parseQuizJson,
  buildJsonQuizExport,
} from "../../shared/quiz-json.js";
import { showDownloadModal } from "../../components/download-quiz-modal/download-quiz-modal.js";
import { renderMarkdown } from "../../shared/markdown.js";
import { readEditorDrafts, upsertEditorDraft, removeEditorDraft, migrateWorkspaceDrafts } from "../../shared/editor-drafts.js";
import { isAdminAuthenticated, getToken } from "../../shared/adminAuth.js";
import { ensureSharedSupabaseClient } from "../../shared/supabaseClientRegistry.js";
import { loadFullQuizData, checkQuizHasPassword } from "../home/quiz-data-loader.js";
import { createAIAgentFab } from "../../components/ai-agent/ai-agent.js";
import { CREATE_QUIZ_PAGE_SYSTEM_PROMPT } from "../../components/ai-agent/ai-agent-default-prompts.js";
import { CREATE_QUIZ_PAGE_SUGGESTED_PROMPTS } from "../../components/ai-agent/ai-agent-suggested-prompts.js";
import { isMultiSelectQuestion } from "../../shared/rate-answers.js";
import { hasSameLevelCollision } from "../home/user-quizzes-folders.js";
import { renderCreateQuestionNavigator, initCreateQuestionNavigator } from "./question-navigator.js";
import { setupGlobalMarkdownToolbar } from "../../shared/global-markdown-toolbar.js";
import { applyMarkdownToolbarAction } from "../../shared/markdown-toolbar-actions.js";

// ============================================================================
// STATE MANAGEMENT
// ============================================================================

let quizData = {
  title: "",
  description: "",
  source: "",
  questions: [],
};

// Internal-only marker used for a question's `answer` field so every
// isEssay check (a truthy test on `question.answer`) reliably identifies
// essay questions even while the actual model-answer text (`options[0]`)
// is still blank. Never shown to the user or exported — buildQuizPayload/
// exportQuiz derive the real exported `answer` from `options[0]` for any
// question whose `options` array has exactly one entry.
const ESSAY_MARKER = "__essay__";

let questionIdCounter = 0;
let autosaveTimeout = null;
let bulkModeActive = false;
let selectedQuestions = new Set();
let isTemplatesPanelOpen = false;
let editingQuizId = null;
let reorderModeActive = false;
// Timestamp of the last programmatic menu/dropdown open (menu bar or the
// LaTeX/heading gmd toolbar) — used to ignore a scroll event that's a side
// effect of that same open (e.g. the browser auto-scrolling a trigger into
// view when it's tapped near the edge of a horizontally-scrolling bar on
// phones) rather than the user actually scrolling to dismiss the menu. See
// setupMenuBarListeners / setupGlobalMdBar.
let _lastMenuOpenAt = 0;
function _armMenuOpenGuard() {
  _lastMenuOpenAt = Date.now();
}
const _menuKeyboardCleanup = new WeakMap();
function _cleanupMenuKeyboard(dropdown) {
  _menuKeyboardCleanup.get(dropdown)?.();
}
// ID of the current draft entry in user_quizzes (meta.type = "draft").
// null when editing an already-published quiz via ?edit=<id>.
let currentDraftId = null;

// Set when the page was opened via ?id=<dbId>&mode=edit (editing a shared/
// admin, Supabase-backed quiz) — distinct from editingQuizId, which always
// means a *local* user_quizzes row (?edit=<id>). The two flows are mutually
// exclusive: sharedEditDbId being non-null means saveLocally()'s usual
// local-storage branch is bypassed entirely in favor of posting to
// POST /api/admin?action=update-quiz. See saveSharedQuizEdit() below and
// docs/plans/Admin actions and deletion flow for quizzes.md §7/step 9.
let sharedEditDbId = null;

// Whether the shared quiz currently being edited (sharedEditDbId) actually
// has a password set, per checkQuizHasPassword() — loadFullQuizData() never
// exposes the hash itself (see that function's header comment), so this is
// populated separately by loadSharedQuizForEdit() and consulted by
// updateSaveMenuOptionForSharedEdit() before revealing the "remove
// password" row. Stays false for the local-edit/new-quiz flows, where it's
// simply unused.
let sharedEditHasPassword = false;

// ── Admin detection ──────────────────────────────────────────────────────────
// Set once on DOMContentLoaded; controls whether media-upload tabs are shown.
let isAdmin = false;

// ============================================================================
// LATEX / KATEX RENDERING
// ============================================================================

/**
 * Scan a container for LaTeX delimiters ($...$ inline, $$...$$ block) and
 * render them in place with KaTeX. Safe to call even if KaTeX or the
 * auto-render extension haven't loaded yet (e.g. slow CDN) — it just no-ops.
 * Call this AFTER any innerHTML update that may contain raw markdown/LaTeX
 * source, so the DOM nodes actually exist for KaTeX to walk and replace.
 */
// ============================================================================
// WRITE / PREVIEW EDITOR SYSTEM (GitHub-style)
// ============================================================================
//
// Each text field (question text, options, explanation, essay answer) is a
// single bordered container with a Write / Preview tab pair and a small
// markdown formatting toolbar, mirroring GitHub's comment/release editor.
// Only one pane (textarea or rendered preview) is visible at a time — no
// stacked "edit box + live preview beneath it" like the old system.

// Per-field markdown toolbars were removed. Formatting is centralized in
// ../../shared/global-markdown-toolbar.js + markdown-toolbar-actions.js.

/** Focus a .md-source field and place the cursor at the end of its text.
 * Formerly also switched a per-card Write/Preview tab (switchMdTab); that
 * markup was removed along with the per-card .wp-bar in favor of the global
 * #globalMdBar toolbar, so this now only handles focusing the field. */
window.activateMdEditor = function (e, id) {
  if (typeof e === "string" && !id) {
    id = e;
  }
  const source = document.getElementById(id);
  if (source) {
    source.focus();
    source.setSelectionRange(source.value.length, source.value.length);
  }
};

/** HTML for one markdown field (.md-source textarea + its on-demand preview
 * pane). `id` must be unique on the page. Shared markup/classes with
 * create-lesson.js's mdEditorHtml so the one global Markdown toolbar, the
 * write/preview toggle, and the drag/drop/paste media embedding all work
 * identically on both pages — see .wp-field/.wp-pane-wrap/.wp-preview-pane
 * in create-quiz.css. */
function mdEditorHtml(id, value, placeholder, rows = 2) {
  const escaped = String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
  return `
    <div class="wp-field" id="wrap-${id}">
      <div class="wp-pane-wrap">
        <textarea class="md-source wp-textarea" dir="auto" id="${id}" rows="${rows}" placeholder="${escapeHtml(placeholder)}">${escaped}</textarea>
        <div class="wp-preview-pane ltr md-content" id="preview-${id}" style="display:none;"></div>
      </div>
    </div>`;
}

/**
 * AI-chat-style growing textarea: starts small enough for one line, grows
 * with content up to a max height, then stops growing and scrolls instead.
 * `minPx` lets compact fields (like option inputs) start smaller than the
 * default single question-text line.
 */
function autoResizeMdSource(ta, minPx = 40, maxPx = 240) {
  ta.style.height = "auto";
  const next = Math.min(Math.max(ta.scrollHeight, minPx), maxPx);
  ta.style.height = next + "px";
  ta.style.overflowY = ta.scrollHeight > maxPx ? "auto" : "hidden";
}

/**
 * Replace the range [start, end) of a textarea's value with `text`, without
 * breaking the browser's native undo/redo (Ctrl+Z) history.
 *
 * Setting `ta.value` directly wipes the textarea's undo stack in every
 * browser — that's why Ctrl+Z used to stop working the moment any toolbar
 * button was used. `document.execCommand('insertText', ...)` goes through
 * the same input pipeline a real keystroke would, so it's recorded as a
 * normal undoable edit. execCommand is deprecated for rich-text editing in
 * general, but for plain <textarea>/<input> "insertText" it is still
 * implemented and recommended by all major browsers specifically because
 * there is no replacement API yet for preserving undo history this way.
 * Falls back to a direct value swap (old behavior) only if execCommand is
 * unavailable, so nothing breaks in that rare case.
 */
function replaceTextareaRange(ta, start, end, text) {
  ta.focus();
  ta.setSelectionRange(start, end);
  const ok =
    typeof document.execCommand === "function" &&
    document.execCommand("insertText", false, text);
  if (!ok) {
    // Fallback: no native undo support, but the edit still applies.
    const value = ta.value;
    ta.value = value.slice(0, start) + text + value.slice(end);
    ta.setSelectionRange(start + text.length, start + text.length);
  }
}

/** Wire up a Write/Preview field: auto-resize + onChange. Preview renders on-demand (tab switch).
 * Option fields (id starts with "option-text-") are compact, like a chat
 * reply box; everything else (question text, explanation, description)
 * gets the taller prompt-box sizing.
 * Also wires GitHub-style drag-and-drop/paste media embedding (see
 * setupMarkdownMediaDropzone) — every field that goes through this
 * function gets it for free: question text, options, explanation, and the
 * essay/formal-answer editor. */
function setupMdEditor(id, onChange) {
  const source = document.getElementById(id);
  if (!source) return;

  const isOption = id.startsWith("option-text-");
  const minPx = isOption ? 36 : 40;
  const maxPx = isOption ? 140 : 240;

  autoResizeMdSource(source, minPx, maxPx);

  source.addEventListener("input", () => {
    autoResizeMdSource(source, minPx, maxPx);
    if (onChange) onChange(source.value);
  });

  // Remembered so the global Markdown toolbar's image/audio/video buttons
  // (see setupGlobalMdBar's onMedia -> triggerMediaInsertForActiveField)
  // can replay this exact field's onChange after a picked file uploads,
  // without every call site having to thread onChange through the DOM.
  mdFieldOnChangeByTextarea.set(source, onChange);

  setupMarkdownMediaDropzone(source, onChange);
}

// textarea -> onChange, populated by setupMdEditor for every markdown field
// (question text, options, explanation). Used by triggerMediaInsertForActiveField.
const mdFieldOnChangeByTextarea = new WeakMap();

/**
 * Opens a native file picker restricted to the given media type and, once a
 * file is chosen, routes it through the exact same upload/insert pipeline as
 * drag-and-drop or paste (handleMarkdownMediaFile) on the field that was
 * focused when the global Markdown toolbar's image/audio/video button was
 * clicked. Mirrors create-lesson.js's implementation of the same helper.
 * @param {"image"|"audio"|"video"} mediaType
 * @param {HTMLTextAreaElement|null} textarea
 */
function triggerMediaInsertForActiveField(mediaType, textarea) {
  if (!textarea || !document.body.contains(textarea)) {
    showNotification("لا يوجد حقل نشط", "اضغط داخل حقل النص أولاً، ثم أعد المحاولة.", "error");
    return;
  }
  const accept = [...(MEDIA_MIME_MAP[mediaType] || [])].join(",");
  const input = document.createElement("input");
  input.type = "file";
  input.accept = accept;
  input.style.display = "none";
  document.body.appendChild(input);
  const onChange = mdFieldOnChangeByTextarea.get(textarea) || null;
  input.addEventListener("change", () => {
    const file = input.files?.[0];
    if (file) handleMarkdownMediaFile(textarea, file, onChange);
    input.remove();
  });
  // If the user dismisses the OS picker without choosing a file, the
  // "change" event never fires — clean up the detached input either way.
  input.addEventListener(
    "cancel",
    () => input.remove(),
  );
  input.click();
}

// =============================================================================
// SHARED GLOBAL MARKDOWN + LATEX BAR
// =============================================================================

function setupGlobalMdBar() {
  return setupGlobalMarkdownToolbar({
    barId: "globalMdBar",
    onAction: (payload) => applyMarkdownToolbarAction(payload),
    onMedia: (mediaType, textarea) => triggerMediaInsertForActiveField(mediaType, textarea),
  });
}


// ============================================================================
// UNDO / REDO
// ============================================================================
//
// Whole-quiz-snapshot history. #undoBtn/#redoBtn in create-quiz.html already
// call performUndo()/performRedo() and expect updateUndoRedoButtons() to
// toggle their disabled state — this block is what actually backs them.
//
// Deliberately scoped to STRUCTURAL edits only (add/remove/duplicate/move/
// reorder/convert/bulk-delete/import/template-insert/AI edits) — i.e. every
// call site that already calls autosave() from outside a per-keystroke
// input handler. Per-keystroke text edits (question/option/title/description
// text) are intentionally excluded and continue to rely on the textarea's
// own native undo (see the "why not just set ta.value" comment above
// replaceTextareaRange) — pushing a snapshot on every keystroke would both
// explode the stack and fight the native undo the user already expects
// inside a text field.
//
// Snapshots are plain deep clones of `quizData` (JSON-safe: title,
// description, source, questions — no DOM/live references), so restoring
// one is just `quizData = clone; rerenderAllQuestions(); ...`.

const UNDO_STACK_LIMIT = 50;
let undoStack = [];
let redoStack = [];
// Set while performUndo/performRedo is actively restoring a snapshot, so
// pushHistorySnapshot() calls triggered by that restore's own re-render
// (e.g. autosave() inside rerenderAllQuestions callbacks) don't re-enter
// the stack and corrupt it.
let isRestoringHistory = false;

function cloneQuizData() {
  return JSON.parse(JSON.stringify(quizData));
}

/**
 * Record the CURRENT quizData as an undo point, then clear the redo stack
 * (a fresh structural edit invalidates whatever was ahead). Call this
 * BEFORE mutating quizData for a structural operation — that way the
 * snapshot captures the pre-edit state to return to.
 */
function pushHistorySnapshot() {
  if (isRestoringHistory) return;
  undoStack.push(cloneQuizData());
  if (undoStack.length > UNDO_STACK_LIMIT) undoStack.shift();
  redoStack = [];
  updateUndoRedoButtons();
}

// Text-level history: the browser keeps a native undo stack per text field
// (toolbar formatting goes through execCommand, so it is in that stack too).
// The header buttons drive that stack for the last focused field and fall back
// to the structural stack when the field has nothing to undo.
let lastTextField = null;

function isHistoryTextField(el) {
  return el instanceof HTMLTextAreaElement ||
    (el instanceof HTMLInputElement && /^(text|search|url|)$/.test(el.type));
}

function textHistoryAvailable(kind) {
  if (!lastTextField || !document.body.contains(lastTextField)) return false;
  try {
    if (document.activeElement !== lastTextField) lastTextField.focus({ preventScroll: true });
    return document.queryCommandEnabled(kind);
  } catch (_) {
    return false;
  }
}

function updateUndoRedoButtons() {
  const undoBtn = document.getElementById("undoBtn");
  const redoBtn = document.getElementById("redoBtn");
  if (undoBtn) undoBtn.disabled = undoStack.length === 0 && !textHistoryAvailable("undo");
  if (redoBtn) redoBtn.disabled = redoStack.length === 0 && !textHistoryAvailable("redo");
}

document.addEventListener("focusin", (e) => {
  if (isHistoryTextField(e.target)) lastTextField = e.target;
  updateUndoRedoButtons();
});
document.addEventListener("input", (e) => {
  if (isHistoryTextField(e.target)) { lastTextField = e.target; updateUndoRedoButtons(); }
});
// Keep focus in the field when a history button is pressed so execCommand
// targets it.
document.addEventListener("mousedown", (e) => {
  if (e.target.closest?.("#undoBtn, #redoBtn")) e.preventDefault();
});

/** Fully re-render the editor from the current quizData after a snapshot
 * restore — mirrors what every structural mutator already does after
 * changing quizData, so undo/redo looks identical to a normal edit. */
function refreshEditorAfterHistoryChange() {
  rerenderAllQuestions();
  updateEmptyState();
  updateProgress();
  updateStatistics();
  updateAppTitleBar();

  const titleInput = document.getElementById("quizTitle");
  const descInput = document.getElementById("quizDescription");
  const sourceInput = document.getElementById("quizSource");
  if (titleInput) titleInput.value = quizData.title || "";
  if (descInput) {
    descInput.value = quizData.description || "";
    autoResizeMdSource(descInput);
  }
  if (sourceInput) sourceInput.value = quizData.source || "";

  // Bulk/reorder mode reference DOM nodes (checkboxes, drag handles) that
  // no longer exist after the container was rebuilt — leaving the mode
  // "on" would show a stale toolbar over cards with no handles/checkboxes.
  if (bulkModeActive) window.toggleBulkMode();
  if (reorderModeActive) window.toggleReorderMode();
}

window.performUndo = function () {
  if (textHistoryAvailable("undo")) {
    lastTextField.focus({ preventScroll: true });
    document.execCommand("undo");
    updateUndoRedoButtons();
    return;
  }
  if (undoStack.length === 0) return;
  const previous = undoStack.pop();
  redoStack.push(cloneQuizData());
  if (redoStack.length > UNDO_STACK_LIMIT) redoStack.shift();

  isRestoringHistory = true;
  quizData = previous;
  refreshEditorAfterHistoryChange();
  isRestoringHistory = false;

  updateUndoRedoButtons();
  autosave();
};

window.performRedo = function () {
  if (textHistoryAvailable("redo")) {
    lastTextField.focus({ preventScroll: true });
    document.execCommand("redo");
    updateUndoRedoButtons();
    return;
  }
  if (redoStack.length === 0) return;
  const next = redoStack.pop();
  undoStack.push(cloneQuizData());
  if (undoStack.length > UNDO_STACK_LIMIT) undoStack.shift();

  isRestoringHistory = true;
  quizData = next;
  refreshEditorAfterHistoryChange();
  isRestoringHistory = false;

  updateUndoRedoButtons();
  autosave();
};

/** Reset the history stacks — call whenever quizData is replaced wholesale
 * from outside the undo system itself (loading a draft, importing a quiz,
 * resetting the page), since old snapshots would otherwise point back to
 * a completely unrelated quiz. */
function resetHistory() {
  undoStack = [];
  redoStack = [];
  updateUndoRedoButtons();
}

// ============================================================================
// INITIALIZATION
// ============================================================================

document.addEventListener("DOMContentLoaded", () => {
  migrateWorkspaceDrafts();
  // Detect admin role — controls upload-tab visibility
  isAdmin = isAdminAuthenticated();

  const urlParams = new URLSearchParams(window.location.search);
  const editId = urlParams.get("edit");
  const sharedId = urlParams.get("id");
  const sharedMode = urlParams.get("mode");
  if (sharedId && sharedMode === "edit") {
    // Deep-linked shared-quiz edit (?id=<dbId>&mode=edit), reached from the
    // admin "تعديل" dropdown action (exam-card.js). Distinct query param
    // from the pre-existing local ?edit=<id> so both keep working
    // unchanged — see sharedEditDbId's declaration above for why.
    sharedEditDbId = sharedId;
    // Defensive: clear any stray quiz_draft key left over from a previous
    // *local* published-quiz edit-in-progress in this browser (?edit=<id>
    // autosaves into this same key — see autosave()'s header comment on its
    // currentDraftId-less branch). Without this, an old local edit sitting
    // here from before this shared-edit session could get surfaced on the
    // entry screen later and look like it belongs to this quiz.
    try {
      localStorage.removeItem("quiz_draft");
    } catch (e) { /* ignore storage errors */ }
    showQuizForm();
    loadSharedQuizForEdit(sharedId);
  } else if (editId) {
    // Deep-linked edit (?edit=<id>) always bypasses the entry screen and
    // opens straight into the form, same as before this feature existed.
    editingQuizId = editId;
    showQuizForm();
    loadQuizFromLocalStorage(editId);
  } else {
    showEntryScreen();
  }

  setupEventListeners();
  setupKeyboardShortcuts();
  setupMenuBarListeners();
  setupEntryItemMenuListeners();
  setupQuestionMenuListeners();
  setupGlobalMdBar();
  mountAIHelper();
  updateUndoRedoButtons();
  setupReorderHandles();
  initCreateQuestionNavigator();
  renderCreateQuestionNavigator(quizData.questions);
  syncActionsMenuConvertSingleButton();

  document.dispatchEvent(new Event("app:ready"));
});

// ============================================================================
// ENTRY SCREEN
// ============================================================================

/**
 * Build the Google-Docs-style "recent items" grid: a "Blank quiz" tile plus
 * one tile per saved item (the current draft, if any, and every quiz in
 * user_quizzes), newest first. Replaces the old three-fixed-cards layout.
 */
function showEntryScreen() {
  const entryScreen = document.getElementById("entryScreen");
  const form = document.getElementById("quizCreatorForm");
  const appTitleBar = document.getElementById("appTitleBar");
  const globalMdBar = document.getElementById("globalMdBar");
  if (!entryScreen || !form) {
    // Defensive fallback: if the entry screen markup is missing for any
    // reason, don't strand the user on a blank page — go straight in.
    loadDraftFromLocalStorage();
    finishFormInit();
    return;
  }

  form.style.display = "none";
  // Hide the unified top bar (now contains both title + menu nav)
  if (appTitleBar) appTitleBar.style.display = "none";
  // Hide the global markdown/LaTeX toolbar
  if (globalMdBar) globalMdBar.style.display = "none";
  entryScreen.style.display = "block";
  document.body.classList.remove("quiz-form-active");

  // Strip any ?edit=/?id=&mode=edit params left over from a deep-linked
  // edit session — now that saving returns here in-page (instead of
  // navigating to "/"), the address bar would otherwise keep pointing at
  // a quiz that's no longer open for editing.
  if (window.location.search) {
    const url = new URL(window.location.href);
    if (url.searchParams.has("edit") || url.searchParams.has("id") || url.searchParams.has("mode")) {
      url.searchParams.delete("edit");
      url.searchParams.delete("id");
      url.searchParams.delete("mode");
      history.replaceState(null, "", url.pathname + url.search);
    }
  }

  renderEntryItemsGrid();
}

/** Read the draft + saved quizzes and render them as one recent-items grid. */
function renderEntryItemsGrid() {
  const grid = document.getElementById("entryItemsGrid");
  if (!grid) return;

  // Migrate legacy single-key draft to a proper draft entry, then clean up
  try {
    const legacyDraft = localStorage.getItem("quiz_draft");
    if (legacyDraft) {
      const d = JSON.parse(legacyDraft);
      const hasContent = d && (d.meta?.title || d.title || d.questions?.length);
      if (hasContent) {
        const id = "draft-" + Date.now();
        const entry = {
          id,
          meta: {
            type: "draft",
            title: d.meta?.title || d.title || "مسودة غير مُعنونة",
            description: d.meta?.description || d.description || "",
            source: d.meta?.source || d.source || "",
            updatedAt: d.lastModified || new Date().toISOString(),
          },
          questions: d.questions || [],
        };
        upsertEditorDraft(entry);
      }
      localStorage.removeItem("quiz_draft");
    }
  } catch (e) { /* ignore migration errors */ }

  let userQuizzes = _readUserQuizzes();

  // ── Helper: render a single tile ──────────────────────────────────────────
  function makeTile(item) {
    const title = escapeHtml(item.title);
    const countLabel = `${item.count} ${item.count === 1 ? "سؤال" : "أسئلة"}`;
    const dateLabel = formatEntryItemDate(item.updatedAt);
    const meta = [countLabel, dateLabel].filter(Boolean).join(" · ");
    const clickHandler = `chooseUserQuizToEdit('${item.id}')`;
    const moreMenu =
      item.kind === "mine" || item.kind === "draft"
        ? `
        <div class="entry-item-more-wrap">
          <button type="button" class="entry-item-more-btn" onclick="toggleEntryItemMenu(event, '${item.id}')"
            aria-label="خيارات إضافية" title="خيارات إضافية">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
              stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="1" />
              <circle cx="19" cy="12" r="1" />
              <circle cx="5" cy="12" r="1" />
            </svg>
          </button>
          <div class="entry-item-menu" id="entryItemMenu-${item.id}">
            <button type="button" class="entry-item-menu-option" onclick="renameEntryItem(event, '${item.id}')">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
              </svg>
              <span>إعادة تسمية</span>
            </button>
            <button type="button" class="entry-item-menu-option entry-item-menu-option-danger"
              onclick="deleteEntryItem(event, '${item.id}')">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 6h18" />
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
              </svg>
              <span>حذف</span>
            </button>
          </div>
        </div>`
        : "";
    return `
      <div class="entry-item-wrap">
        <button type="button" class="entry-item${item.kind === "draft" ? " entry-item-draft" : ""}" onclick="${clickHandler}">
          <span class="entry-item-thumb">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
              stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
              <rect width="8" height="4" x="8" y="2" rx="1" ry="1" />
              <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
              <path d="M12 11h4" />
              <path d="M12 16h4" />
              <path d="M8 11h.01" />
              <path d="M8 16h.01" />
            </svg>
          </span>
          <span class="entry-item-title">${title}</span>
          <span class="entry-item-meta">${meta}</span>
        </button>
        ${moreMenu}
      </div>`;
  }

  // ── Drafts section ────────────────────────────────────────────────────────
  const draftItems = readEditorDrafts()
    .filter((q) => q.meta?.type === "draft")
    .map((q) => ({
      kind: "draft",
      id: q.id,
      title: q.meta?.title || q.title || "مسودة غير مُعنونة",
      count: q.questions?.length || 0,
      updatedAt: q.meta?.updatedAt || null,
    }))
    .sort((a, b) => {
      if (!a.updatedAt && !b.updatedAt) return 0;
      if (!a.updatedAt) return 1;
      if (!b.updatedAt) return -1;
      return new Date(b.updatedAt) - new Date(a.updatedAt);
    });

  // ── Saved quizzes section ─────────────────────────────────────────────────
  const savedItems = userQuizzes
    .filter((quiz) => {
      const t = quiz.meta?.type;
      return t !== "folder" && t !== "course" && t !== "draft" && t !== "lesson" && t !== "draft-lesson";
    })
    .map((quiz) => ({
      kind: "mine",
      id: quiz.id,
      title: quiz.meta?.title || quiz.title || "بدون عنوان",
      count: quiz.stats?.questionCount ?? quiz.questions?.length ?? 0,
      updatedAt: quiz.meta?.updatedAt || null,
    }))
    .sort((a, b) => {
      if (!a.updatedAt && !b.updatedAt) return 0;
      if (!a.updatedAt) return 1;
      if (!b.updatedAt) return -1;
      return new Date(b.updatedAt) - new Date(a.updatedAt);
    });

  // ── Assemble sections ─────────────────────────────────────────────────────
  const draftTiles = draftItems.map((item) => makeTile(item)).join("");
  const savedTiles = savedItems.map(makeTile).join("");

  // The "new quiz" tile lives in static HTML now (see #entryScreen in
  // create-quiz.html) — it needs nothing from localStorage/DB, so it no
  // longer needs to be generated here or wait on this render.
  let html = "";
  if (draftTiles) {
    html += `
    <div class="entry-section">
      <h2 class="entry-screen-heading">المسودات</h2>
      <div class="entry-items-grid">${draftTiles}</div>
    </div>`;
  }

  if (savedTiles) {
    html += `
    <div class="entry-section">
      <h2 class="entry-screen-heading">الامتحانات المحفوظة</h2>
      <div class="entry-items-grid">${savedTiles}</div>
    </div>`;
  }

  grid.innerHTML = html;

  // First real render: swap the static skeleton out for the actual grid.
  const skeleton = document.getElementById("entrySkeleton");
  if (skeleton) skeleton.style.display = "none";
  grid.style.display = "";
}



/** "منذ ٣ أيام"-style relative label, falling back to a short date. */
function formatEntryItemDate(isoString) {
  if (!isoString) return "";
  const date = new Date(isoString);
  if (isNaN(date.getTime())) return "";

  const diffMs = Date.now() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return "الآن";
  if (diffMin < 60) return `منذ ${diffMin} دقيقة`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `منذ ${diffHr} ساعة`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 30) return `منذ ${diffDay} يوم`;
  return date.toLocaleDateString("ar-EG", { year: "numeric", month: "short", day: "numeric" });
}

/** Hide the entry screen and reveal the quiz-creator form + unified bar. */
function showQuizForm() {
  const entryScreen = document.getElementById("entryScreen");
  const form = document.getElementById("quizCreatorForm");
  const appTitleBar = document.getElementById("appTitleBar");
  const globalMdBar = document.getElementById("globalMdBar");
  if (entryScreen) entryScreen.style.display = "none";
  if (form) form.style.display = "flex";
  // Show the unified top bar (merged title + menu nav)
  if (appTitleBar) appTitleBar.style.display = "flex";
  // Show the global markdown/LaTeX toolbar below the top bar
  if (globalMdBar) globalMdBar.style.display = "flex";
  document.body.classList.add("quiz-form-active");
  updateAppTitleBar();
}

/** Keep the compact app-bar title in sync with the quiz's own title field. */
function updateAppTitleBar() {
  const titleEl = document.getElementById("appTitleText");
  if (titleEl && titleEl.getAttribute("contenteditable") !== "true") {
    titleEl.textContent = quizData.title?.trim() || "امتحان بدون عنوان";
  }
}

// ============================================================================
// APP-BAR TITLE — click-to-rename (Docs-style)
// The app-bar title is a *display mirror* of the real #quizTitle input in
// the metadata card, not a second source of truth — editing it here writes
// straight into #quizTitle and fires the same "input" event that field
// already listens for, so quizData.title, the char counter, and autosave
// all stay driven by the one existing code path.
// ============================================================================

/** Turn the app-bar title into an editable field, focused with all text selected. */
window.startTitleEdit = function () {
  const titleEl = document.getElementById("appTitleText");
  if (!titleEl) return;

  titleEl.setAttribute("contenteditable", "true");
  titleEl.textContent = quizData.title || "";
  titleEl.classList.add("editing");
  titleEl.focus();

  const range = document.createRange();
  range.selectNodeContents(titleEl);
  const selection = window.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
};

/** Commit the edited app-bar title back into #quizTitle (the real field). */
window.commitTitleEdit = function () {
  const titleEl = document.getElementById("appTitleText");
  if (!titleEl || titleEl.getAttribute("contenteditable") !== "true") return;

  titleEl.setAttribute("contenteditable", "false");
  titleEl.classList.remove("editing");

  const newTitle = titleEl.textContent.trim();
  const titleInput = document.getElementById("quizTitle");
  if (titleInput && titleInput.value !== newTitle) {
    titleInput.value = newTitle;
    // Reuse the exact same path typing in the metadata field already
    // takes: updates quizData.title, the char counter, the app-bar text,
    // and triggers autosave — no duplicated logic here.
    titleInput.dispatchEvent(new Event("input", { bubbles: true }));
  } else {
    updateAppTitleBar();
  }
};

/** Enter commits, Escape cancels without saving. */
window.handleTitleEditKeydown = function (event) {
  if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("appTitleText")?.blur();
  } else if (event.key === "Escape") {
    event.preventDefault();
    const titleEl = document.getElementById("appTitleText");
    if (titleEl) {
      titleEl.setAttribute("contenteditable", "false");
      titleEl.classList.remove("editing");
      updateAppTitleBar();
      titleEl.blur();
    }
  }
};

/** Run the same init steps the form previously did unconditionally on load. */
function finishFormInit() {
  showQuizForm();
  updateEmptyState();
  updateProgress();
  updateStatistics();
}

// ============================================================================
// SHARED LOCALSTORAGE HELPERS
// ============================================================================

/** Safe read of user_quizzes from localStorage. Always returns an array. */
function _readUserQuizzes() {
  try {
    return JSON.parse(localStorage.getItem("user_quizzes") || "[]");
  } catch (e) {
    return [];
  }
}

/** Safe write of user_quizzes to localStorage. */
function _writeUserQuizzes(quizzes) {
  localStorage.setItem("user_quizzes", JSON.stringify(quizzes));
}

/** Generate a simple unique ID (timestamp + random suffix). */
function _generateId(prefix = "draft") {
  return prefix + "-" + Date.now() + "-" + Math.random().toString(36).slice(2, 7);
}



/** Handles taps on entry-screen tiles ("new" | "exit"). */
window.chooseEntryAction = function (action) {
  if (action === "new") {
    resetPageData();    // clears quizData, generates a new currentDraftId
    finishFormInit();
    return;
  }

  if (action === "exit") {
    // The app-bar "هوم" button: go back to the entry screen without
    // discarding anything — autosave already persisted the current draft.
    showEntryScreen();
  }
};

/** User picked a specific saved quiz OR draft tile from the entry screen. */
window.chooseUserQuizToEdit = function (quizId) {
  const quizzes = _readUserQuizzes();
  const quiz = readEditorDrafts().find((q) => q.id === quizId && q.meta?.type === "draft") || quizzes.find((q) => q.id === quizId);
  if (!quiz) return;

  if (quiz.meta?.type === "draft") {
    // Opening a draft: track it as currentDraftId so autosave updates it
    currentDraftId = quizId;
    editingQuizId = null;
  } else {
    // Opening a published quiz for editing: no draft tracking
    editingQuizId = quizId;
    currentDraftId = null;
  }
  finishFormInit();
  loadQuizFromLocalStorage(quizId);
};

// ============================================================================
// ENTRY SCREEN — per-tile "more" (⋮) menu: rename / delete
// A lightweight, purpose-built implementation rather than reusing
// user-quizzes-folders.js's renameItem()/deleteFolder() — those re-render
// the home page's own views (renderRootCategories/renderUserQuizzesView),
// which don't exist on this page. This follows the same storage contract
// (user_quizzes in localStorage, item.meta.title) but re-renders the entry
// grid instead.
// ============================================================================

/** Open/close the ⋮ dropdown for one tile, closing any other open one first. */
window.toggleEntryItemMenu = function (event, quizId) {
  event.stopPropagation();
  const menu = document.getElementById(`entryItemMenu-${quizId}`);
  if (!menu) return;
  const isOpen = menu.classList.contains("open");
  closeAllEntryItemMenus();
  if (!isOpen) menu.classList.add("open");
};

function closeAllEntryItemMenus() {
  document
    .querySelectorAll(".entry-item-menu.open")
    .forEach((menu) => menu.classList.remove("open"));
}

/** Open/close the ⋮ "more" dropdown for one question card, closing any
 * other open one first. Same pattern as toggleEntryItemMenu. */
window.toggleQuestionMenu = function (event, questionId) {
  event.stopPropagation();
  const menu = document.getElementById(`questionMenu-${questionId}`);
  if (!menu) return;
  const isOpen = menu.classList.contains("open");
  closeAllQuestionMenus();
  if (!isOpen) menu.classList.add("open");
};

window.closeAllQuestionMenus = function () {
  document
    .querySelectorAll(".question-more-menu.open")
    .forEach((menu) => menu.classList.remove("open"));
};

/* Rename a saved quiz directly in user_quizzes, then refresh the grid. */
window.renameEntryItem = async function (event, quizId) {
  event.stopPropagation();
  closeAllEntryItemMenus();

  let userQuizzes = [];
  try {
    userQuizzes = JSON.parse(localStorage.getItem("user_quizzes") || "[]");
  } catch (e) {
    userQuizzes = [];
  }

  const quiz = userQuizzes.find((q) => q.id === quizId);
  if (!quiz) return;

  const currentTitle = quiz.meta?.title || quiz.title || "";
  const newTitle = await _prompt("أدخل الاسم الجديد:", currentTitle);
  if (!newTitle || !newTitle.trim()) return;
  const trimmedTitle = newTitle.trim();

  const parentId = quiz.meta?.parentId || null;
  if (
    hasSameLevelCollision(userQuizzes, {
      type: quiz.meta?.type || "quiz",
      title: trimmedTitle,
      parentId,
      excludeId: quizId,
    })
  ) {
    showNotification(
      "الاسم مستخدم",
      "يوجد عنصر بنفس الاسم والنوع في هذا المستوى. اختر اسماً مختلفاً.",
      "warning",
    );
    return;
  }

  if (quiz.meta) {
    quiz.meta.title = trimmedTitle;
  } else {
    quiz.title = trimmedTitle;
  }
  localStorage.setItem("user_quizzes", JSON.stringify(userQuizzes));
  renderEntryItemsGrid();
};

/** Delete a saved quiz directly from user_quizzes, then refresh the grid. */
window.deleteEntryItem = async function (event, quizId) {
  event.stopPropagation();
  closeAllEntryItemMenus();

  if (!(await _confirm("هل أنت متأكد من حذف هذا الامتحان؟"))) return;

  let userQuizzes = [];
  try {
    userQuizzes = JSON.parse(localStorage.getItem("user_quizzes") || "[]");
  } catch (e) {
    userQuizzes = [];
  }

  const newQuizzes = userQuizzes.filter((q) => q.id !== quizId);
  localStorage.setItem("user_quizzes", JSON.stringify(newQuizzes));
  renderEntryItemsGrid();
};

// ============================================================================
// MENU BAR (Docs-style dropdowns)
// ============================================================================

/**
 * Position a .menu-dropdown (position: fixed) directly beneath its trigger,
 * using the trigger's live bounding rect, then clamp to the viewport.
 * Mirrors positionGmdDropdown() above — needed because .app-title-bar
 * scrolls horizontally on phones, so a plain position:absolute dropdown
 * could render partly or fully off-screen depending on scroll position.
 */
function positionMenuDropdown(trigger, dropdown) {
  const rect = trigger.getBoundingClientRect();
  // Measure first with visibility hidden so offsetWidth/Height are correct
  // before the final visible placement.
  dropdown.style.visibility = "hidden";
  dropdown.style.display = "block";
  dropdown.style.top = `${rect.bottom + 4}px`;
  dropdown.style.left = "0px";

  const menuWidth = dropdown.offsetWidth;
  let left = rect.right - menuWidth; // align dropdown's right edge to trigger's right edge (RTL)
  left = Math.max(8, Math.min(left, window.innerWidth - menuWidth - 8));

  let top = rect.bottom + 4;
  const menuHeight = dropdown.offsetHeight;
  if (top + menuHeight > window.innerHeight - 8) {
    // Not enough room below — flip to open above the trigger instead.
    top = Math.max(8, rect.top - menuHeight - 4);
  }

  dropdown.style.left = `${left}px`;
  dropdown.style.top = `${top}px`;
  dropdown.style.display = "";
  dropdown.style.visibility = "";
}

/**
 * Position a .menu-submenu-dropdown beside its trigger row (to the left in
 * this RTL layout), clamped to the viewport the same way as top-level menus.
 */
function positionSubmenuDropdown(trigger, dropdown) {
  const rect = trigger.getBoundingClientRect();
  dropdown.style.visibility = "hidden";
  dropdown.style.display = "block";
  dropdown.style.top = "0px";
  dropdown.style.left = "0px";

  const menuWidth = dropdown.offsetWidth;
  const menuHeight = dropdown.offsetHeight;

  // Prefer popping out to the left of the trigger row (RTL: away from the
  // sidebar). If there isn't room on the left, fall back to the right.
  let left = rect.left - menuWidth - 2;
  if (left < 8) left = Math.min(rect.right + 2, window.innerWidth - menuWidth - 8);
  left = Math.max(8, left);

  let top = rect.top - 6;
  top = Math.max(8, Math.min(top, window.innerHeight - menuHeight - 8));

  dropdown.style.left = `${left}px`;
  dropdown.style.top = `${top}px`;
  dropdown.style.display = "";
  dropdown.style.visibility = "";
}

/**
 * One-time ARIA wiring for the Docs-style menu bar. The dropdowns already
 * carry role="menu" in the markup, but the pieces that make them a real
 * menu for assistive tech were missing: triggers need aria-haspopup +
 * aria-expanded (so a screen reader announces "button, has popup,
 * collapsed/expanded" instead of a plain button), and every row inside a
 * role="menu" container needs role="menuitem" or it's read as generic
 * clickable content rather than a menu choice. Done once here in JS,
 * rather than hand-adding these attributes to every .menu-option/.menu-
 * trigger in the HTML, so newly added menu rows automatically pick up the
 * same wiring without anyone having to remember the attributes by hand.
 * aria-expanded is kept in sync afterward by _setMenuExpanded() at every
 * open/close site (toggleMenu, toggleSubmenu, closeAllMenus).
 */
function _wireMenuBarAria() {
  document.querySelectorAll("#menuBar .menu-bar-item").forEach((item) => {
    const isSubmenuItem = item.classList.contains("menu-item-submenu");
    const trigger = item.querySelector(
      isSubmenuItem ? ":scope > .menu-option" : ":scope > .menu-trigger"
    );
    const dropdown = item.querySelector(
      ":scope > .menu-dropdown, :scope > .menu-submenu-dropdown"
    );
    if (trigger && dropdown) {
      trigger.setAttribute("aria-haspopup", "true");
      trigger.setAttribute("aria-expanded", "false");
      if (dropdown.id) trigger.setAttribute("aria-controls", dropdown.id);
      dropdown.setAttribute("role", "menu");
      dropdown.setAttribute("aria-hidden", "true");
    }
  });
  document
    .querySelectorAll("#menuBar .menu-dropdown .menu-option, #menuBar .menu-dropdown .menu-separator")
    .forEach((el) => {
      // Separators get role="separator" so they aren't announced as
      // choices; every real row (including submenu trigger rows, which
      // are both a menuitem AND a popup trigger — aria-haspopup above
      // still applies to the same element) gets role="menuitem".
      el.setAttribute(
        "role",
        el.classList.contains("menu-separator") ? "separator" : "menuitem"
      );
    });
}

/** Reflect a menu-bar-item's open/closed state in aria-expanded on its
 * trigger, so screen readers announce the change (the visual state is
 * already carried by the menu-item-open class). */
function _setMenuExpanded(item, expanded) {
  if (!item) return;
  const isSubmenuItem = item.classList.contains("menu-item-submenu");
  const trigger = item.querySelector(
    isSubmenuItem ? ":scope > .menu-option" : ":scope > .menu-trigger"
  );
  trigger?.setAttribute("aria-expanded", expanded ? "true" : "false");
}

/** Open the named dropdown, closing any other open one first. */
window.toggleMenu = function (name) {
  const dropdown = document.getElementById(`menu-${name}`);
  const item = dropdown?.closest(".menu-bar-item");
  const trigger = item?.querySelector(":scope > .menu-trigger");
  if (!dropdown || !item || !trigger) return;

  const isOpen = item.classList.contains("menu-item-open");
  closeAllMenus();
  if (!isOpen) {
    item.classList.add("menu-item-open");
    _setMenuExpanded(item, true);
    dropdown.setAttribute("aria-hidden", "false");
    positionMenuDropdown(trigger, dropdown);
    activateMenuKeyboardNav(dropdown, () => {
      closeAllMenus();
      trigger.focus();
    });
    // See _armMenuOpenGuard below: tapping a trigger near the scroll edge
    // of the horizontally-scrolling .app-title-bar (phones) can make the
    // browser auto-scroll the trigger into view as a side effect of the
    // tap/focus itself. That scroll event was reaching the "scroll closes
    // menus" listener and immediately closing the menu this same tap just
    // opened — on a second trigger, the net effect looked like "first tap
    // closes the previous menu, second tap opens nothing" even though a
    // menu genuinely did open for a frame. Suppress scroll-triggered
    // closes for a brief window right after opening.
    _armMenuOpenGuard();
  }
};


/** Close every open menu dropdown. Safe to call even if none are open. */
window.closeAllMenus = function () {
  document.querySelectorAll(".menu-bar-item.menu-item-open").forEach((item) => {
    const dropdown = item.querySelector(":scope > .menu-dropdown");
    _cleanupMenuKeyboard(dropdown);
    if (dropdown) dropdown.setAttribute("aria-hidden", "true");
    item.classList.remove("menu-item-open");
    _setMenuExpanded(item, false);
  });
  document.querySelectorAll(".menu-item-submenu.menu-item-open").forEach((item) => {
    const dropdown = item.querySelector(":scope > .menu-submenu-dropdown");
    _cleanupMenuKeyboard(dropdown);
    if (dropdown) dropdown.setAttribute("aria-hidden", "true");
    item.classList.remove("menu-item-open");
    _setMenuExpanded(item, false);
  });
};

/**
 * Arrow-key navigation inside one open menu dropdown (ArrowDown/ArrowUp move
 * focus between menuitems, Home/End jump to the first/last, Escape closes
 * via the supplied callback). Attached fresh each time a dropdown opens and
 * torn down automatically once it closes, so stale listeners never pile up
 * across repeated open/close cycles of the same #menuBar dropdown.
 * @param {HTMLElement} dropdown - the open .menu-dropdown/.menu-submenu-dropdown
 * @param {() => void} onClose - called on Escape; expected to close the menu and restore focus to its trigger
 */
function activateMenuKeyboardNav(dropdown, onClose, { focusFirst = true } = {}) {
  if (!dropdown) return;
  _cleanupMenuKeyboard(dropdown);
  const items = () => [
    ...dropdown.querySelectorAll(':scope > .menu-option:not([disabled]), :scope > [role="menuitem"]:not([disabled])'),
  ];
  const focusAt = (index, list) => {
    if (!list.length) return;
    const next = ((index % list.length) + list.length) % list.length;
    list[next].focus({ preventScroll: true });
  };
  const onKeydown = (e) => {
    const list = items();
    const currentIndex = list.indexOf(document.activeElement);
    if (e.key === "ArrowDown" || e.key === "ArrowRight") {
      e.preventDefault();
      focusAt(currentIndex < 0 ? 0 : currentIndex + 1, list);
    } else if (e.key === "ArrowUp" || e.key === "ArrowLeft") {
      e.preventDefault();
      focusAt(currentIndex < 0 ? list.length - 1 : currentIndex - 1, list);
    } else if (e.key === "Home") {
      e.preventDefault();
      focusAt(0, list);
    } else if (e.key === "End") {
      e.preventDefault();
      focusAt(list.length - 1, list);
    } else if (e.key === "Escape" || e.key === "Tab") {
      e.preventDefault();
      e.stopPropagation();
      cleanup();
      if (typeof onClose === "function") onClose();
    }
  };
  function cleanup() {
    dropdown.removeEventListener("keydown", onKeydown);
    if (_menuKeyboardCleanup.get(dropdown) === cleanup) _menuKeyboardCleanup.delete(dropdown);
  }
  dropdown.addEventListener("keydown", onKeydown);
  _menuKeyboardCleanup.set(dropdown, cleanup);
  if (focusFirst) focusAt(0, items());
}

/**
 * Toggle a nested submenu inside an already-open parent dropdown./**
 * Toggle a nested submenu inside an already-open parent dropdown.
 * Stops event propagation so the parent dropdown doesn't close.
 * Now click-driven (not hover) since the submenu is position:fixed and
 * placed by JS on open — there's no continuous CSS box to hover across
 * once the dropdown can float anywhere in the viewport.
 */
window.toggleSubmenu = function (event, submenuId) {
  event.stopPropagation();
  const submenuItem = event.currentTarget.closest("[data-menu='" + submenuId + "']");
  const trigger = event.currentTarget;
  const dropdown = submenuItem?.querySelector(":scope > .menu-submenu-dropdown");
  if (!submenuItem || !dropdown) return;
  const isOpen = submenuItem.classList.contains("menu-item-open");
  // Close any other open submenus at this level first
  submenuItem
    .closest(".menu-dropdown")
    ?.querySelectorAll(".menu-item-submenu.menu-item-open")
    .forEach((s) => {
      s.classList.remove("menu-item-open");
      _setMenuExpanded(s, false);
    });
  if (!isOpen) {
    submenuItem.classList.add("menu-item-open");
    _setMenuExpanded(submenuItem, true);
    dropdown.setAttribute("aria-hidden", "false");
    positionSubmenuDropdown(trigger, dropdown);
    activateMenuKeyboardNav(dropdown, () => {
      submenuItem.classList.remove("menu-item-open");
      _setMenuExpanded(submenuItem, false);
      trigger.focus();
    });
    _armMenuOpenGuard();
  } else {
    _cleanupMenuKeyboard(dropdown);
    dropdown.setAttribute("aria-hidden", "true");
    submenuItem.classList.remove("menu-item-open");
    _setMenuExpanded(submenuItem, false);
  }
};

/**
 * Open the Insert (إدراج) menu and pre-expand the templates submenu,
 * so the empty-state "استخدام قالب" button takes users straight there.
 */
window.openTemplatesMenu = function () {
  // Open the Insert top-level menu
  const insertItem = document.querySelector(".menu-bar-item[data-menu='insert']");
  if (!insertItem) return;
  closeAllMenus();
  const insertTrigger = insertItem.querySelector(":scope > .menu-trigger");
  const insertDropdown = insertItem.querySelector(":scope > .menu-dropdown");
  insertItem.classList.add("menu-item-open");
  _setMenuExpanded(insertItem, true);
  insertDropdown?.setAttribute("aria-hidden", "false");
  if (insertTrigger && insertDropdown) positionMenuDropdown(insertTrigger, insertDropdown);
  // Pre-expand the templates submenu inside it
  const templatesItem = insertItem.querySelector(".menu-item-submenu[data-menu='insert-templates']");
  const templatesTrigger = templatesItem?.querySelector(":scope > .menu-option");
  const templatesDropdown = templatesItem?.querySelector(":scope > .menu-submenu-dropdown");
  if (templatesItem) {
    templatesItem.classList.add("menu-item-open");
    _setMenuExpanded(templatesItem, true);
    templatesDropdown?.setAttribute("aria-hidden", "false");
    if (templatesTrigger && templatesDropdown) positionSubmenuDropdown(templatesTrigger, templatesDropdown);
  }
};

// ============================================================================
// STATISTICS MODAL
// ============================================================================

/** Open the stats modal (updating numbers first so they're always fresh). */
window.openStatsModal = function () {
  updateStatistics();
  const modal = document.getElementById("statsModal");
  if (modal) modal.style.display = "flex";
};

/** Close the stats modal. */
window.closeStatsModal = function () {
  const modal = document.getElementById("statsModal");
  if (modal) modal.style.display = "none";
};

/** Click-outside and Escape-to-close wiring for the menu bar, plus
 * hover-to-switch between top-level menus once one is already open.
 * NOTE: The menu bar is now embedded as .app-bar-menu inside #appTitleBar.
 * We attach the close listener to #appTitleBar so that clicks anywhere
 * INSIDE it (including submenu items) do NOT close the dropdown prematurely.
 * Submenus are now click-driven (see toggleSubmenu) since dropdowns are
 * position:fixed and placed by JS rather than pure CSS :hover. */
function setupMenuBarListeners() {
  // Reference the unified top bar (which contains the embedded menu nav)
  const appTitleBar = document.getElementById("appTitleBar");
  if (!appTitleBar) return;

  _wireMenuBarAria();

  appTitleBar.querySelectorAll("#menuBar .menu-trigger").forEach((trigger) => {
    if (trigger.dataset.menuArrowNavBound === "1") return;
    trigger.dataset.menuArrowNavBound = "1";
    trigger.addEventListener("keydown", (e) => {
      if (e.key !== "ArrowDown") return;
      e.preventDefault();
      const name = trigger.closest(".menu-bar-item")?.dataset.menu;
      if (!name) return;
      toggleMenu(name);
    });
  });

  // Click outside the entire top bar AND outside any open dropdown → close.
  // Dropdowns are position:fixed now, so they're no longer DOM-nested
  // inside appTitleBar's visible box in a way .contains() would still
  // reliably reflect for outside-click purposes — check both.
  document.addEventListener("click", (e) => {
    if (!appTitleBar.contains(e.target) && !e.target.closest(".menu-dropdown")) {
      closeAllMenus();
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAllMenus();
  });

  // Re-close (rather than leave a dropdown stranded mid-air) if the bar
  // scrolls or the window resizes — its fixed position was computed for
  // the trigger's rect at open-time only. Skip closes that land in the
  // brief window right after this same tap opened a menu (see
  // _armMenuOpenGuard) — those are the tap's own focus-scroll side effect,
  // not the user scrolling to dismiss the menu.
  appTitleBar.addEventListener("scroll", () => {
    if (Date.now() - _lastMenuOpenAt < 350) return;
    closeAllMenus();
  });
  window.addEventListener("resize", closeAllMenus);

  // Hover-to-switch: once any top-level menu is open, hovering another
  // .menu-bar-item (that has its own data-menu trigger) switches to it.
  // We scope to .menu-bar-inner to avoid triggering on submenu rows.
  //
  // Desktop-only (matchMedia gate below): touch browsers — WebKit/iOS in
  // particular — synthesize a hover/"mouseenter" pass on the FIRST tap of
  // any element that has a mouseenter/mouseover listener, and only dispatch
  // the real `click` on a SECOND tap on that same element. With this
  // listener attached unconditionally, tapping a second .menu-trigger while
  // another menu was open used to eat that first tap as a hover simulation
  // (closing nothing, opening nothing) and only actually call
  // toggleMenu()'s click handler on the tap after — i.e. exactly the
  // "closes the open menu, then a second tap is needed to open the next
  // one" bug. Desktop mouse users still get the hover-switch via the
  // (hover: hover) and (pointer: fine) checks; touch users fall back to
  // toggleMenu's own click-driven close-then-open, which already switches
  // menus correctly in a single tap.
  const menuBarInner = appTitleBar.querySelector(".menu-bar-inner");
  if (!menuBarInner) return;
  const supportsHover =
    window.matchMedia &&
    window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  if (!supportsHover) return;
  menuBarInner.querySelectorAll(":scope > .menu-bar-item").forEach((item) => {
    item.addEventListener("mouseenter", () => {
      const anyOpen = menuBarInner.querySelector(".menu-item-open");
      if (anyOpen && anyOpen !== item) {
        const oldDropdown = anyOpen.querySelector(":scope > .menu-dropdown");
        _cleanupMenuKeyboard(oldDropdown);
        oldDropdown?.setAttribute("aria-hidden", "true");
        _setMenuExpanded(anyOpen, false);
        anyOpen.classList.remove("menu-item-open");
        item.classList.add("menu-item-open");
        const trigger = item.querySelector(":scope > .menu-trigger");
        const dropdown = item.querySelector(":scope > .menu-dropdown");
        if (trigger && dropdown) {
          _setMenuExpanded(item, true);
          dropdown.setAttribute("aria-hidden", "false");
          positionMenuDropdown(trigger, dropdown);
          activateMenuKeyboardNav(dropdown, () => { closeAllMenus(); trigger.focus({ preventScroll: true }); }, { focusFirst: false });
        }
      }
    });
  });
}

/** Outside-click/Escape closing for entry-item "more" (⋮) dropdowns.
 * Delegated to document once at init — safe across renderEntryItemsGrid()
 * re-renders since it doesn't hold references to the (re-created) menu
 * elements themselves. */
function setupEntryItemMenuListeners() {
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".entry-item-more-wrap")) {
      closeAllEntryItemMenus();
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAllEntryItemMenus();
  });
}

/** Outside-click/Escape closing for question-card "more" (⋮) dropdowns.
 * Same delegated pattern as setupEntryItemMenuListeners — question cards
 * are re-rendered/reordered often (add/move/duplicate/remove), so this is
 * attached once at init rather than per-card. */
function setupQuestionMenuListeners() {
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".question-more-wrap")) {
      closeAllQuestionMenus();
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAllQuestionMenus();
  });
}

function setupEventListeners() {
  // Close modals on background click
  document.addEventListener("click", (e) => {
    // Modal Overlays
    if (e.target.classList.contains("modal-overlay")) {
      if (
        e.target.id === "previewModal" &&
        typeof window.closePreview === "function"
      ) {
        window.closePreview();
      } else if (
        e.target.id === "importModal" &&
        typeof window.closeImportModal === "function"
      ) {
        window.closeImportModal();
      } else if (e.target.id === "statsModal") {
        window.closeStatsModal();
      } else {
        e.target.style.display = "none";
      }
    }

    // Shortcuts Panel
    const shortcutsPanel = document.getElementById("shortcutsPanel");
    if (shortcutsPanel && shortcutsPanel.style.display === "block") {
      // Allow clicking either toggle button (help-panel close btn, or the
      // "مساعدة" menu item) without immediately re-closing what it just opened.
      if (
        !shortcutsPanel.contains(e.target) &&
        !e.target.closest('button[onclick^="toggleShortcuts()"]') &&
        !e.target.closest('button[onclick^="toggleShortcuts();"]')
      ) {
        toggleShortcuts();
      }
    }
  });

  // Metadata event listeners
  const titleInput = document.getElementById("quizTitle");
  const descInput = document.getElementById("quizDescription");
  const sourceInput = document.getElementById("quizSource");

  titleInput.addEventListener("input", (e) => {
    quizData.title = e.target.value;
    updateCharCount("titleCharCount", e.target.value.length, 100);
    updateAppTitleBar();
    autosave();
  });

  autoResizeMdSource(descInput);
  descInput.addEventListener("input", (e) => {
    quizData.description = e.target.value;
    updateCharCount("descCharCount", e.target.value.length, 500);
    autoResizeMdSource(e.target);
    autosave();
  });

  if (sourceInput) {
    sourceInput.addEventListener("input", (e) => {
      quizData.source = e.target.value.trim();
      autosave();
    });
  }

  // Search functionality with debounce
  const searchInput = document.getElementById("questionSearch");
  if (searchInput) {
    searchInput.addEventListener("input", debounce(handleSearch, 300));
    // Escape while the field itself has focus closes the pinned (title-bar
    // Actions menu) search bar outright, matching the affordance the
    // fixed-position close button gives — scoped to the input's own
    // keydown (not a document-level listener) so it doesn't interfere
    // with every other Escape handler in the app (menus, modals, etc.)
    // and only fires when the search field is actually what's focused.
    searchInput.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        closeQuestionSearch();
      }
    });
    searchInput.addEventListener("input", (e) => {
      const clearBtn = document.getElementById("clearSearch");
      if (clearBtn) {
        clearBtn.style.display = e.target.value ? "flex" : "none";
      }
    });
  }

  // Note: the FAB and its scroll-driven show/hide were removed when the
  // "add question" action moved into the persistent top action bar.
}

// ============================================================================
// CHARACTER COUNT
// ============================================================================

function updateCharCount(elementId, current, max) {
  const element = document.getElementById(elementId);
  if (element) {
    element.textContent = `${current}/${max}`;
    element.classList.remove("warning", "error");
    if (current > max * 0.9) {
      element.classList.add("warning");
    }
    if (current >= max) {
      element.classList.add("error");
    }
  }
}

// ============================================================================
// KEYBOARD SHORTCUTS
// ============================================================================

/** True if `el` is something the user can type into directly — an
 * INPUT/TEXTAREA (covers every .md-source field: question/option/
 * explanation text) or a contentEditable node. Used to keep global
 * single-key/Ctrl shortcuts from hijacking keystrokes meant for the
 * field itself (native undo, text entry, etc.). */
function isTextEditableElement(el) {
  if (!el) return false;
  const tag = el.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || el.isContentEditable;
}

function setupKeyboardShortcuts() {
  document.addEventListener("keydown", (e) => {
    // Alt+N: Add new question.
    // Checked via e.code ("KeyN", the physical key) rather than e.key: this
    // is an Arabic-locale app, and on Arabic keyboard layouts e.key for the
    // N key reports the Arabic letter printed on that key, not "n" — so
    // e.key.toLowerCase() === "n" silently never matched for exactly the
    // users this app is built for. e.code identifies the physical key
    // regardless of the active layout.
    if (e.altKey && e.code === "KeyN") {
      e.preventDefault();
      addQuestion();
    }

    // Ctrl+S: Save quiz
    if ((e.ctrlKey || e.metaKey) && e.key === "s") {
      e.preventDefault();
      saveLocally();
    }

    // Ctrl+Z: Undo. Ctrl+Y or Ctrl+Shift+Z: Redo (both are common
    // conventions — Ctrl+Y matches the shortcut already printed on
    // #redoBtn's title attribute in create-quiz.html).
    //
    // Both are skipped while focus is inside a text-editable field (any
    // .md-source textarea — question/option/explanation text — or any
    // other input/textarea/contentEditable). Structural undo/redo has no
    // text-level granularity (see the UNDO/REDO section's header comment:
    // per-keystroke text edits are deliberately excluded from the
    // snapshot stack), so previously this handler's unconditional
    // e.preventDefault() blocked the browser's own native undo for that
    // field — which normally handles text edits — before it could ever
    // run, then fired the structural undo instead, which had nothing
    // relevant to restore. Leaving Ctrl+Z/Y alone here lets the field's
    // native undo take over, exactly as intended.
    const isTextEditTarget = isTextEditableElement(e.target);
    if (!isTextEditTarget && (e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === "z") {
      e.preventDefault();
      performUndo();
    }
    if (
      !isTextEditTarget &&
      (e.ctrlKey || e.metaKey) &&
      (e.key.toLowerCase() === "y" ||
        (e.shiftKey && e.key.toLowerCase() === "z"))
    ) {
      e.preventDefault();
      performRedo();
    }

    // Ctrl+P: Preview quiz
    if ((e.ctrlKey || e.metaKey) && e.key === "p") {
      e.preventDefault();
      previewQuiz();
    }

    // Ctrl+E: Export quiz
    if ((e.ctrlKey || e.metaKey) && e.key === "e") {
      e.preventDefault();
      exportQuiz();
    }

    // Escape: close any open modal
    if (e.key === "Escape") {
      const statsModal = document.getElementById("statsModal");
      if (statsModal && statsModal.style.display !== "none") {
        window.closeStatsModal();
      }
    }

    // ?: Show shortcuts
    if (e.key === "?" && !e.ctrlKey && !e.metaKey && !isTextEditableElement(e.target)) {
      e.preventDefault();
      toggleShortcuts();
    }
  });
}

/**
 * Show/hide the quiz password's plaintext, like a normal password field's
 * reveal button — toggles the input's type between "password" and "text"
 * and swaps the eye / eye-off icon + label to match the resulting state.
 */
window.toggleQuizPasswordVisibility = function () {
  const input = document.getElementById("quizPassword");
  const btn = document.getElementById("quizPasswordToggle");
  if (!input || !btn) return;

  const revealing = input.type === "password";
  input.type = revealing ? "text" : "password";

  const eyeIcon = btn.querySelector(".icon-eye");
  const eyeOffIcon = btn.querySelector(".icon-eye-off");
  if (eyeIcon) eyeIcon.style.display = revealing ? "none" : "";
  if (eyeOffIcon) eyeOffIcon.style.display = revealing ? "" : "none";

  const label = revealing ? "إخفاء كلمة المرور" : "إظهار كلمة المرور";
  btn.title = label;
  btn.setAttribute("aria-label", label);
  btn.setAttribute("aria-pressed", String(revealing));
};

/**
 * Copy the quiz password to the clipboard, independent of whether it's
 * currently masked or revealed (reads input.value directly either way).
 * Swaps the button's copy icon for a checkmark briefly as confirmation,
 * matching the pattern already used for the copy-question action, and
 * falls back to a hidden-textarea + execCommand copy for browsers/contexts
 * where navigator.clipboard is unavailable (e.g. non-HTTPS/local dev).
 */
window.copyQuizPassword = async function () {
  const input = document.getElementById("quizPassword");
  const btn = document.getElementById("quizPasswordCopy");
  if (!input || !btn) return;

  const value = input.value;
  if (!value) {
    showNotification("لا توجد كلمة مرور", "أدخل كلمة مرور أولاً لنسخها", "error");
    return;
  }

  let copied = false;
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
      copied = true;
    }
  } catch (err) {
    // Fall through to the execCommand fallback below.
  }

  if (!copied) {
    try {
      const temp = document.createElement("textarea");
      temp.value = value;
      temp.style.position = "fixed";
      temp.style.opacity = "0";
      document.body.appendChild(temp);
      temp.focus();
      temp.select();
      copied = document.execCommand("copy");
      document.body.removeChild(temp);
    } catch (err) {
      copied = false;
    }
  }

  if (!copied) {
    showNotification("تعذر النسخ", "لم يتمكن المتصفح من نسخ كلمة المرور", "error");
    return;
  }

  const copyIcon = btn.querySelector(".icon-copy");
  const checkIcon = btn.querySelector(".icon-check");
  if (copyIcon) copyIcon.style.display = "none";
  if (checkIcon) checkIcon.style.display = "";
  btn.classList.add("copied");
  btn.title = "تم النسخ";
  btn.setAttribute("aria-label", "تم نسخ كلمة المرور");

  clearTimeout(btn._copyResetTimer);
  btn._copyResetTimer = setTimeout(() => {
    if (copyIcon) copyIcon.style.display = "";
    if (checkIcon) checkIcon.style.display = "none";
    btn.classList.remove("copied");
    btn.title = "نسخ كلمة المرور";
    btn.setAttribute("aria-label", "نسخ كلمة المرور");
  }, 1500);
};

window.toggleShortcuts = function () {
  const panel = document.getElementById("shortcutsPanel");
  if (panel.style.display === "none") {
    panel.style.display = "block";
  } else {
    panel.style.display = "none";
  }
};

// ============================================================================
// PROGRESS TRACKING
// ============================================================================

function updateProgress() {
  const totalQuestions = quizData.questions.length;
  const progressText = document.getElementById("progressText");
  const progressBar = document.getElementById("progressBar");

  if (progressText) {
    progressText.textContent = `${totalQuestions} ${totalQuestions === 1 ? "سؤال" : "أسئلة"}`;
  }

  if (progressBar) {
    const progress = Math.min((totalQuestions / 10) * 100, 100);
    progressBar.style.width = `${progress}%`;
  }
}

// ============================================================================
// STATISTICS
// ============================================================================

function updateStatistics() {
  // Stats now live inside #statsModal rather than an inline card — just
  // keep the numbers up-to-date; the modal itself is shown on demand.
  const totalQuestions = quizData.questions.length;

  // Media is embedded inline in the question body as raw HTML tags now
  // (<img src="...">, <video>, <audio>) rather than a dedicated `image`
  // field or bracket-syntax markdown, so detect an inline <img> tag
  // directly in `q.q` instead. <video>/<audio> are excluded since this
  // stat is specifically "images". Also matches the older bracket-syntax
  // form (![alt](url), excluding ![audio]/![video]) for quizzes saved
  // before this change.
  const IMAGE_TAG_RE = /<img\b[^>]*\bsrc=/i;
  const LEGACY_IMAGE_BRACKET_RE = /!\[(?!audio\]|video\])[^\]]*\]\([^\s)]+\)/i;
  const questionsWithImages = quizData.questions.filter(
    (q) => q.q && (IMAGE_TAG_RE.test(q.q) || LEGACY_IMAGE_BRACKET_RE.test(q.q)),
  ).length;
  const questionsWithExplanations = quizData.questions.filter(
    (q) => q.explanation && q.explanation.trim(),
  ).length;
  const totalOptions = quizData.questions.reduce(
    (sum, q) => sum + (Array.isArray(q.options) ? q.options.length : 1),
    0,
  );
  const avgOptions =
    totalQuestions > 0 ? (totalOptions / totalQuestions).toFixed(1) : "0";

  const statQ = document.getElementById("statQuestions");
  const statI = document.getElementById("statImages");
  const statE = document.getElementById("statExplanations");
  const statA = document.getElementById("statAvgOptions");
  if (statQ) statQ.textContent = totalQuestions;
  if (statI) statI.textContent = questionsWithImages;
  if (statE) statE.textContent = questionsWithExplanations;
  if (statA) statA.textContent = avgOptions;
}

// ============================================================================
// QUESTION MANAGEMENT
// ============================================================================

window.addQuestion = function () {
  pushHistorySnapshot();
  const questionId = ++questionIdCounter;

  const question = {
    id: questionId,
    q: "",
    options: ["", ""],
    correct: [],
    multiSelect: false,
    explanation: "",
  };

  quizData.questions.push(question);
  renderQuestion(question);
  updateEmptyState();
  updateProgress();
  updateStatistics();
  autosave();

  setTimeout(() => {
    const questionCard = document.getElementById(`question-${questionId}`);
    if (questionCard) {
      questionCard.scrollIntoView({ behavior: "smooth", block: "center" });
      // Activate the question text md editor so user can type immediately
      const questionTextId = `question-text-${questionId}`;
      activateMdEditor(questionTextId);
    }
  }, 100);
};

window.removeQuestion = async function (questionId) {
  if (!(await _confirm("هل أنت متأكد من حذف هذا السؤال؟"))) {
    return;
  }

  const index = quizData.questions.findIndex((q) => q.id === questionId);
  if (index !== -1) {
    pushHistorySnapshot();
    quizData.questions.splice(index, 1);

    const questionCard = document.getElementById(`question-${questionId}`);
    if (questionCard) {
      questionCard.style.animation = "slideOut 0.3s ease";
      setTimeout(() => {
        questionCard.remove();
        updateQuestionNumbers();
        updateEmptyState();
        updateProgress();
        updateStatistics();
        showNotification("تم الحذف", "تم حذف السؤال بنجاح", "success");
      }, 300);
    }

    autosave();
  }
};

window.duplicateQuestion = function (questionId) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (!question) return;

  pushHistorySnapshot();
  const newId = ++questionIdCounter;
  const duplicatedQuestion = {
    ...question,
    id: newId,
    q: question.q,
  };

  const index = quizData.questions.findIndex((q) => q.id === questionId);
  quizData.questions.splice(index + 1, 0, duplicatedQuestion);

  renderQuestion(duplicatedQuestion, index + 1);
  updateQuestionNumbers();
  updateProgress();
  updateStatistics();
  autosave();

  showNotification("تم النسخ", "تم نسخ السؤال بنجاح", "success");

  setTimeout(() => {
    const newCard = document.getElementById(`question-${newId}`);
    if (newCard) {
      newCard.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, 100);
};

function renderQuestion(question, insertAtIndex = null) {
  const container = document.getElementById("questionsContainer");
  const questionNumber =
    quizData.questions.findIndex((q) => q.id === question.id) + 1;

  const questionCard = document.createElement("div");
  questionCard.className = "question-card";
  questionCard.id = `question-${question.id}`;
  questionCard.dataset.questionId = question.id;

  // ── Detect question type and tag the card ──────────────────────────────────
  const isEssay = question.answer;
  if (isEssay) questionCard.classList.add("question-card--essay");

  if (!isEssay) normalizeCorrectField(question);

  // Check if question is incomplete
  const isIncomplete =
    !question.q ||
    question.q.trim() === "" ||
    question.options.some((opt) => !opt || opt.trim() === "") ||
    (!isEssay &&
      (!Array.isArray(question.correct) || question.correct.length === 0));
  if (isIncomplete) {
    questionCard.classList.add("incomplete");
  }

  questionCard.innerHTML = `
        <div class="question-header">
            ${reorderModeActive
      ? `<button type="button" class="question-drag-handle" aria-label="اسحب لإعادة ترتيب السؤال ${questionNumber}" title="اسحب لإعادة الترتيب">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="9" cy="6" r="1.2" /><circle cx="15" cy="6" r="1.2" />
                        <circle cx="9" cy="12" r="1.2" /><circle cx="15" cy="12" r="1.2" />
                        <circle cx="9" cy="18" r="1.2" /><circle cx="15" cy="18" r="1.2" />
                    </svg>
                </button>`
      : ""
    }
            <span class="question-number" id="qnum-${question.id}">
                ${bulkModeActive ? `<input type="checkbox" class="question-select-checkbox" onchange="handleQuestionSelect(event, ${question.id})" onclick="event.stopPropagation()">` : ""}
                <span class="q-label">سؤال ${questionNumber}</span>
                <span class="q-preview ltr" id="qpreview-${question.id}"></span>
            </span>
            <div class="question-actions" onclick="event.stopPropagation()">
                <div class="question-more-wrap">
                    <button type="button" class="question-more-btn" onclick="toggleQuestionMenu(event, ${question.id})"
                        aria-label="خيارات إضافية" title="خيارات إضافية">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                            stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="1" />
                            <circle cx="19" cy="12" r="1" />
                            <circle cx="5" cy="12" r="1" />
                        </svg>
                    </button>
                    <div class="question-more-menu" id="questionMenu-${question.id}" role="menu" aria-label="خيارات السؤال">
                        <button type="button" class="question-menu-option" role="menuitem" onclick="previewSingleQuestion(${question.id}); closeAllQuestionMenus();">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/></svg>
                            <span>معاينة</span>
                        </button>
                        <div class="menu-separator"></div>
                        <button type="button" class="question-menu-option" role="menuitem" onclick="moveQuestion(${question.id}, 'top'); closeAllQuestionMenus();">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 11l-5-5-5 5"/><path d="M17 18l-5-5-5 5"/></svg>
                            <span>نقل لأعلى السؤال</span>
                        </button>
                        <button type="button" class="question-menu-option" role="menuitem" onclick="moveQuestion(${question.id}, 'up'); closeAllQuestionMenus();">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>
                            <span>نقل للأعلى</span>
                        </button>
                        <button type="button" class="question-menu-option" role="menuitem" onclick="moveQuestion(${question.id}, 'down'); closeAllQuestionMenus();">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                            <span>نقل للأسفل</span>
                        </button>
                        <button type="button" class="question-menu-option" role="menuitem" onclick="moveQuestion(${question.id}, 'bottom'); closeAllQuestionMenus();">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 13l-5 5-5-5"/><path d="M17 6l-5 5-5-5"/></svg>
                            <span>نقل لأسفل السؤال</span>
                        </button>
                        <div class="menu-separator"></div>
                        <button type="button" class="question-menu-option" role="menuitem" onclick="toggleQuestionCollapse(${question.id}); closeAllQuestionMenus();">
                            <svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24"
                              fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                              stroke-linejoin="round">
                              <path d="m7 20 5-5 5 5" />
                              <path d="m7 4 5 5 5-5" />
                             </svg>
                            <span>طي/توسيع السؤال</span>
                        </button>
                        ${!isEssay
      ? `<button type="button" id="multiSelectToggle-${question.id}" class="question-menu-option" role="menuitem" onclick="setMultiSelect(${question.id}, ${!isMultiSelectQuestion(question)}); closeAllQuestionMenus();">
                            <svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><path d="M8 20v-4a4 4 0 0 1 8 0v4"/></svg>
                            <span>${isMultiSelectQuestion(question) ? "تحويل إلى إجابة واحدة فقط" : "اختر إجابة واحدة أو أكثر"}</span>
                        </button>`
      : ""
    }
                        <button type="button" class="question-menu-option" role="menuitem" onclick="duplicateQuestion(${question.id}); closeAllQuestionMenus();">
                            <svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
                            <span>مضاعفة السؤال</span>
                        </button>
                        <div class="menu-separator"></div>
                        <button type="button" class="question-menu-option question-menu-option-danger" role="menuitem" onclick="closeAllQuestionMenus(); removeQuestion(${question.id});">
                            <svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 11v6"/><path d="M14 11v6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                            <span>حذف السؤال</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="question-body">
            <div class="form-group">
                <label>نصّ السؤال *</label>
                ${mdEditorHtml(`question-text-${question.id}`, question.q, "أدخل سؤالك هنا...", 1)}
            </div>
            
            <div class="form-group">
                <label class="options-label">${isEssay ? "الإجابة المرجعية" : "الإختيارات"}</label>
                <div id="options-container-${question.id}" class="options-list">
                    ${renderOptions(question)}
                </div>
                <div id="option-btn-${question.id}">
                  ${isEssay
      ? `<button class="add-option-btn add-option-btn--convert" onclick="convertEssayToMcq(${question.id})">
                         <svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg> تحويل إلى اختيار متعدد
                       </button>`
      : `<button class="add-option-btn" onclick="addOption(${question.id})">
                         <svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-plus-icon lucide-plus"><path d="M5 12h14"/><path d="M12 5v14"/></svg> إضافة خيار
                       </button>
                       <button class="add-option-btn add-option-btn--convert" onclick="convertMcqToEssay(${question.id})">
                         <svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z"/></svg> تحويل إلى سؤال مقالي
                       </button>`
    }
                </div>
            </div>
            
            <div class="form-group">
                <label><svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-lightbulb-icon lucide-lightbulb"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg> الشرح (اختياري)</label>
                ${mdEditorHtml(`question-explanation-${question.id}`, question.explanation || "", "قدم تفسيرًا للإجابة الصحيحة", 1)}
            </div>
        </div>
    `;

  if (insertAtIndex !== null) {
    const existingCards = container.children;
    if (insertAtIndex < existingCards.length) {
      container.insertBefore(questionCard, existingCards[insertAtIndex]);
    } else {
      container.appendChild(questionCard);
    }
  } else {
    container.appendChild(questionCard);
  }

  setupQuestionEventListeners(question.id);
}

// Click on header area (but not buttons/drag) collapses the card
window.handleHeaderClick = function (e, questionId) {
  // Only collapse if clicking directly on header/label, not child interactive elements
  if (
    e.target.closest(".question-actions") ||
    e.target.closest(".question-more-wrap") ||
    e.target.closest(".question-select-checkbox") ||
    e.target.tagName === "BUTTON" ||
    e.target.tagName === "INPUT"
  )
    return;
  toggleQuestionCollapse(questionId);
};

window.toggleQuestionCollapse = function (questionId) {
  const card = document.getElementById(`question-${questionId}`);
  if (!card) return;
  card.classList.toggle("collapsed");

  const isCollapsed = card.classList.contains("collapsed");
  const qPreview = document.getElementById(`qpreview-${questionId}`);

  if (isCollapsed && qPreview) {
    // Get question text from state or fallback to textarea
    const question = quizData.questions.find((q) => q.id === questionId);
    const textarea = document.getElementById(`question-text-${questionId}`);
    const rawText =
      (question && question.q) || (textarea && textarea.value) || "";
    const preview = rawText
      .replace(/\n/g, " ")
      .replace(/```[\s\S]*?```/g, "[كود]")
      .replace(/`/g, "")
      .trim();
    qPreview.textContent = preview
      ? preview.slice(0, 20) + (preview.length > 20 ? "…" : "")
      : "";
  } else if (qPreview) {
    qPreview.textContent = "";
  }
};

function setupQuestionEventListeners(questionId) {
  // Question text: inline md editor
  setupMdEditor(`question-text-${questionId}`, (val) =>
    updateQuestionData(questionId, "q", val),
  );

  // Explanation: inline md editor
  setupMdEditor(`question-explanation-${questionId}`, (val) =>
    updateQuestionData(questionId, "explanation", val),
  );

  // Option md editors are set up after rerenderOptions via setupOptionMdEditors
  setupOptionMdEditors(questionId);
}

// ============================================================================
// COMBINED MEDIA DROPZONE (image / audio / video, auto-detected)
// ============================================================================
//
// One dropzone + one link input per question, instead of three separate
// always-visible sections. Admins can drop/select any file or paste any
// link; the type (image / audio / video) is auto-detected from the file's
// MIME type or the URL's extension/host (e.g. YouTube), then inserted into
// the question body as a raw HTML media tag (see buildMediaHtmlTag below)
// — there is no dedicated question.image/question.audio/question.video
// field to write into anymore. Non-admin users get the link input only
// (no upload).

const MEDIA_MIME_MAP = {
  image: new Set([
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
    "image/svg+xml",
  ]),
  audio: new Set([
    "audio/mpeg",
    "audio/ogg",
    "audio/wav",
    "audio/webm",
    "audio/aac",
    "audio/x-m4a",
    "audio/mp4",
  ]),
  video: new Set(["video/mp4", "video/webm", "video/ogg"]),
};
const MEDIA_MAX_SIZE = {
  image: 5 * 1024 * 1024,
  audio: 10 * 1024 * 1024,
  video: 50 * 1024 * 1024,
};
const MEDIA_EXT_MAP = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/gif": "gif",
  "image/webp": "webp",
  "image/svg+xml": "svg",
  "audio/mpeg": "mp3",
  "audio/ogg": "ogg",
  "audio/wav": "wav",
  "audio/webm": "webm",
  "audio/aac": "aac",
  "audio/x-m4a": "m4a",
  "audio/mp4": "m4a",
  "video/mp4": "mp4",
  "video/webm": "webm",
  "video/ogg": "ogv",
};

/**
 * Compress an image File in-browser using <canvas> before upload.
 * Downscales to a max dimension and re-encodes as JPEG at a given quality.
 * Returns the smaller of {compressed, original} — never makes things worse.
 * Skips SVG (vector) and GIF (animation would be flattened to one frame).
 */
async function compressImageFile(
  file,
  { maxDim = 1600, quality = 0.82, qualityFloor = 0.6 } = {},
) {
  if (!file || !file.type) return file;
  if (file.type === "image/svg+xml" || file.type === "image/gif") {
    return file;
  }

  let bitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch (err) {
    console.warn("[compressImageFile] decode failed, using original", err);
    return file;
  }

  try {
    const scale = Math.min(1, maxDim / Math.max(bitmap.width, bitmap.height));
    const w = Math.max(1, Math.round(bitmap.width * scale));
    const h = Math.max(1, Math.round(bitmap.height * scale));

    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(bitmap, 0, 0, w, h);

    const blob = await new Promise((resolve) => {
      canvas.toBlob((b) => resolve(b), "image/jpeg", Math.max(quality, qualityFloor));
    });

    if (!blob) return file;

    // Only use the compressed version if it's actually smaller.
    if (blob.size >= file.size) return file;

    const ext = "jpg";
    const baseName = file.name ? file.name.replace(/\.[^.]+$/, "") : "image";
    return new File([blob], `${baseName}.${ext}`, {
      type: "image/jpeg",
      lastModified: Date.now(),
    });
  } catch (err) {
    console.warn("[compressImageFile] compression failed, using original", err);
    return file;
  } finally {
    bitmap.close?.();
  }
}

/** Detect media type ("image"|"audio"|"video"|null) from a File's MIME type. */
function detectMediaTypeFromFile(file) {
  if (!file || !file.type) return null;
  for (const type of ["image", "audio", "video"]) {
    if (MEDIA_MIME_MAP[type].has(file.type)) return type;
  }
  return null;
}

/** Detect media type ("image"|"audio"|"video"|null) from a URL string. */
function detectMediaTypeFromUrl(url) {
  if (!url) return null;
  const clean = url.split("?")[0].split("#")[0].trim().toLowerCase();
  if (/youtube\.com\/watch\?v=|youtu\.be\//i.test(url)) return "video";
  if (/\.(jpe?g|png|gif|webp|svg)$/.test(clean)) return "image";
  if (/\.(mp3|ogg|wav|webm|aac|m4a)$/.test(clean)) return "audio";
  if (/\.(mp4|ogv|mov)$/.test(clean)) return "video";
  return null;
}

// Kept: still used by the insert-at-cursor upload path's error/success
// notifications (uploadMediaFileForMarkdown, handleMarkdownMediaFile).
const MEDIA_TYPE_LABELS = { image: "صورة", audio: "ملف صوتي", video: "فيديو" };

function updateQuestionData(questionId, field, value) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (question) {
    question[field] = value;
    if (field === "explanation" || field === "image") {
      updateStatistics();
    }
    autosave();
  }
}

function updateQuestionNumbers() {
  quizData.questions.forEach((question, index) => {
    const qLabel = document
      .getElementById(`question-${question.id}`)
      ?.querySelector(".q-label");
    if (qLabel) {
      qLabel.textContent = `سؤال ${index + 1}`;
    }
  });
}

renderCreateQuestionNavigator(quizData.questions);
syncActionsMenuConvertSingleButton();

// ============================================================================
// GITHUB-STYLE MEDIA EMBEDDING: drag-and-drop / paste into markdown fields
// ============================================================================
//
// Mirrors GitHub's issue/release editor: dropping or pasting media into any
// .md-source textarea (question text, options, explanation, essay/formal
// answer — every field wired through setupMdEditor()) immediately inserts
// an `![Uploading filename…]()` placeholder at the cursor so the author can
// keep typing, uploads the file in the background using the exact same
// Supabase Storage path already used by the legacy image/audio/video
// dropzone (uploadMediaFileForMarkdown), then swaps the placeholder text for
// the final raw HTML media tag (`<img src="...">` / `<audio src="...">` /
// `<video src="...">`, built by buildMediaHtmlTag) once the upload finishes.
// markdown.js's renderMarkdown() renders these tags directly (see "Step -1:
// Raw HTML media tags" in _renderMarkdownCore) — width/height/alt
// attributes on <img> are preserved through to the rendered element.
//
// NOTE: pasting a YouTube / image / video / audio URL (instead of a file)
// is wrapped in the matching raw HTML tag immediately (see the "paste"
// listener in setupMarkdownMediaDropzone below); pasting an already-complete
// <img>/<video>/<audio> HTML snippet (e.g. copied from a browser's "copy
// image" action) is inserted as-is, since markdown.js understands it
// natively.

/**
 * Builds the raw HTML media tag markdown.js's renderMarkdown() now renders
 * directly (see the "Step -1: Raw HTML media tags" block in markdown.js's
 * _renderMarkdownCore) — an `<img>` tag for images, `<video>`/`<audio>`
 * for everything else. YouTube links are inserted as an ordinary
 * `<video src="youtube-url">` tag too; markdown.js detects the YouTube URL
 * itself and swaps in an iframe embed at render time, so no special case
 * is needed here.
 * @param {"image"|"audio"|"video"} mediaType
 * @param {string} url
 * @param {{width?: number, height?: number, alt?: string}} [opts]
 */
function buildMediaHtmlTag(mediaType, url, opts = {}) {
  const esc = (v) => String(v ?? "").replace(/"/g, "&quot;");
  if (mediaType === "image") {
    const dims =
      (opts.width ? ` width="${opts.width}"` : "") +
      (opts.height ? ` height="${opts.height}"` : "");
    // alt text intentionally fixed (not the raw filename), matching the
    // alt text already used by migrated legacy image tags ("صورة توضيحية
    // للسؤال" — "illustrative image for the question") for consistency
    // across old and new content.
    const alt = opts.alt ?? "صورة توضيحية للسؤال";
    return `<img${dims} alt="${esc(alt)}" src="${esc(url)}" />`;
  }
  return `<${mediaType} src="${esc(url)}"></${mediaType}>`;
}

/**
 * Uploads a File to Supabase Storage using the same "quiz-media" bucket,
 * per-user path convention, and compression step as the legacy combined
 * media dropzone this replaces, but returns the public URL
 * instead of writing into a question.image/audio/video field. Throws with
 * a user-facing Arabic message on any failure — callers should catch and
 * surface it via showNotification.
 */
async function uploadMediaFileForMarkdown(file, mediaType) {
  let workingFile = file;
  let dims = null;
  if (mediaType === "image") {
    workingFile = await compressImageFile(workingFile);
    try {
      const bitmap = await createImageBitmap(workingFile);
      dims = { width: bitmap.width, height: bitmap.height };
      bitmap.close?.();
    } catch {
      dims = null; // dimensions are cosmetic (width/height attrs) — fine to omit
    }
  }

  if (workingFile.size > MEDIA_MAX_SIZE[mediaType]) {
    const maxMb = MEDIA_MAX_SIZE[mediaType] / (1024 * 1024);
    throw new Error(
      `الحد الأقصى لـ ${MEDIA_TYPE_LABELS[mediaType]} هو ${maxMb} ميجابايت.`,
    );
  }
  if (workingFile.size === 0) {
    throw new Error("الملف المحدد فارغ.");
  }

  const client = await ensureSharedSupabaseClient();
  if (!client) {
    throw new Error("تعذّر الاتصال بـ Supabase. حاول تسجيل الخروج والدخول مجدداً.");
  }
  const { data: sessionData } = await client.auth.getSession();
  if (!sessionData?.session) {
    throw new Error("جلسة Supabase منتهية. أعد تسجيل الدخول.");
  }

  const uid = sessionData.session.user.id;
  const ext = MEDIA_EXT_MAP[workingFile.type] || "bin";
  const random = Math.random().toString(36).slice(2, 9);
  const storagePath = `${mediaType}s/${uid}/${Date.now()}-${random}.${ext}`;

  const { error: uploadError } = await client.storage
    .from("quiz-media")
    .upload(storagePath, workingFile, {
      contentType: workingFile.type,
      upsert: false,
    });
  if (uploadError) throw new Error(uploadError.message);

  const { data: urlData } = client.storage
    .from("quiz-media")
    .getPublicUrl(storagePath);
  if (!urlData?.publicUrl) throw new Error("تم الرفع لكن فشل توليد الرابط.");

  return { url: urlData.publicUrl, dims };
}

/**
 * Core GitHub-style upload flow for one File dropped/pasted into a
 * .md-source textarea:
 *   1. Insert `![Uploading filename…]()` at the cursor (undo-safe) so the
 *      author can keep typing immediately.
 *   2. Upload in the background.
 *   3. Replace that exact placeholder text with the final media tag,
 *      wherever it now sits in the textarea (the author may have moved
 *      the cursor or typed more text around it in the meantime).
 * Multiple concurrent uploads in the same field are supported since each
 * one tracks its own unique placeholder string.
 */
async function handleMarkdownMediaFile(textarea, file, onChange) {
  // Uploading to the shared "quiz-media" Supabase bucket is an admin-only
  // action (non-admins can still paste a link — see Case 2/3 in
  // setupMarkdownMediaDropzone's paste handler — they just can't push new
  // binaries into shared storage). Drag-and-drop and clipboard file-paste
  // are the only two entry points that reach this function, so gating here
  // covers both without duplicating the check at each call site.
  if (!isAdmin) {
    showNotification(
      "غير مسموح",
      "رفع الملفات متاح للمشرفين فقط. الصقوا رابط الملف مباشرة بدلاً من ذلك.",
      "error",
    );
    return;
  }
  const mediaType = detectMediaTypeFromFile(file);
  if (!mediaType) {
    showNotification(
      "نوع غير مدعوم",
      `نوع الملف (${file.type || "غير معروف"}) غير مدعوم. الأنواع المدعومة: صور، صوت، فيديو.`,
      "error",
    );
    return;
  }

  // Unique per-upload placeholder — lets several uploads run at once in the
  // same field (e.g. two images dropped back-to-back) without colliding.
  const uploadTag = `${file.name}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const placeholder = `![Uploading ${uploadTag}…]()`;

  const start = textarea.selectionStart ?? textarea.value.length;
  const end = textarea.selectionEnd ?? textarea.value.length;
  replaceTextareaRange(textarea, start, end, placeholder);
  autoResizeMdSource(
    textarea,
    textarea.id.startsWith("option-text-") ? 36 : 40,
    textarea.id.startsWith("option-text-") ? 140 : 240,
  );
  if (onChange) onChange(textarea.value);

  const replacePlaceholder = (replacementText) => {
    const idx = textarea.value.indexOf(placeholder);
    if (idx === -1) {
      // The placeholder text is gone (author deleted it, or the field was
      // rebuilt) — nothing sane to patch. The upload still completed
      // successfully; the author just won't see it auto-inserted.
      return;
    }
    replaceTextareaRange(textarea, idx, idx + placeholder.length, replacementText);
    autoResizeMdSource(
      textarea,
      textarea.id.startsWith("option-text-") ? 36 : 40,
      textarea.id.startsWith("option-text-") ? 140 : 240,
    );
    if (onChange) onChange(textarea.value);
  };

  try {
    const { url: publicUrl, dims } = await uploadMediaFileForMarkdown(file, mediaType);
    const tag = buildMediaHtmlTag(mediaType, publicUrl, {
      width: dims?.width,
      height: dims?.height,
      alt: file.name,
    });
    replacePlaceholder(tag);
  } catch (err) {
    console.error("[handleMarkdownMediaFile]", err);
    replacePlaceholder(""); // remove the placeholder — the upload failed
    showNotification(
      "خطأ في الرفع",
      err.message || "حدث خطأ أثناء رفع الملف.",
      "error",
    );
  }
}

/**
 * Wires drag-and-drop and clipboard-paste media handling onto one
 * .md-source textarea. Called once per field from setupMdEditor(), so
 * every markdown field in the editor (question text, options, explanation,
 * essay/formal answer) gets this for free.
 */
function setupMarkdownMediaDropzone(textarea, onChange) {
  let dragDepth = 0;

  textarea.addEventListener("dragenter", (e) => {
    if (!e.dataTransfer?.types?.includes("Files")) return;
    e.preventDefault();
    dragDepth++;
    textarea.classList.add("md-source--drag-active");
  });
  textarea.addEventListener("dragover", (e) => {
    if (!e.dataTransfer?.types?.includes("Files")) return;
    e.preventDefault();
  });
  textarea.addEventListener("dragleave", () => {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) textarea.classList.remove("md-source--drag-active");
  });
  textarea.addEventListener("drop", (e) => {
    const files = e.dataTransfer?.files;
    if (!files || !files.length) return;
    e.preventDefault();
    dragDepth = 0;
    textarea.classList.remove("md-source--drag-active");
    Array.from(files).forEach((file) =>
      handleMarkdownMediaFile(textarea, file, onChange),
    );
  });

  textarea.addEventListener("paste", (e) => {
    // Case 1: an actual image/file sitting on the clipboard (e.g. a
    // screenshot copied from the OS, or an image copied from a browser).
    const fileItems = Array.from(e.clipboardData?.items || []).filter(
      (item) => item.kind === "file",
    );
    if (fileItems.length) {
      e.preventDefault();
      fileItems.forEach((item) => {
        const file = item.getAsFile();
        if (file) handleMarkdownMediaFile(textarea, file, onChange);
      });
      return;
    }

    // Case 2: plain-text paste that happens to BE a media URL (YouTube
    // link, direct image/video/audio link). Wrap the pasted URL in the
    // matching raw HTML media tag immediately — markdown.js's
    // renderMarkdown() renders real <img>/<video>/<audio> tags directly
    // (see "Step -1: Raw HTML media tags" in markdown.js's
    // _renderMarkdownCore) and detects YouTube URLs itself to swap in an
    // iframe embed, so a plain `<video src="youtube-url">` is enough here
    // — instead of inserting the bare URL as plain text, which would
    // otherwise just sit there as inert text, never becoming embedded media.
    const text = e.clipboardData?.getData("text/plain");
    if (text) {
      const trimmed = text.trim();
      const mediaType = detectMediaTypeFromUrl(trimmed);
      if (mediaType) {
        e.preventDefault();
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const tag = buildMediaHtmlTag(mediaType, trimmed);
        replaceTextareaRange(textarea, start, end, tag);
        autoResizeMdSource(
          textarea,
          textarea.id.startsWith("option-text-") ? 36 : 40,
          textarea.id.startsWith("option-text-") ? 140 : 240,
        );
        if (onChange) onChange(textarea.value);
        return;
      }

      // Case 3: a raw <img>/<video>/<audio> HTML snippet (not a bare URL).
      // This is what many browsers/OSes put on the clipboard for "copy
      // image" (e.g. right-click → copy image, or dragging an <img> out of
      // a web page) — a full tag like
      // `<img width="400" height="400" alt="x.jpg" src="https://...">`,
      // not a plain link. markdown.js now renders raw <img>/<video>/<audio>
      // tags directly, so the pasted snippet can be inserted as-is with no
      // rebuilding — the only work here is recognizing that it IS one of
      // these tags (so we intercept the default paste and use our own
      // insert-at-cursor logic instead of the browser's, which would just
      // dump the raw text in verbatim in the same way, but without the
      // auto-resize/onChange bookkeeping the other cases get).
      const isMediaTag = /^<(img|video|audio|source)\b[^>]*\bsrc=["'][^"']*["'][^>]*>/i.test(
        trimmed,
      );
      if (isMediaTag) {
        e.preventDefault();
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        replaceTextareaRange(textarea, start, end, trimmed);
        autoResizeMdSource(
          textarea,
          textarea.id.startsWith("option-text-") ? 36 : 40,
          textarea.id.startsWith("option-text-") ? 140 : 240,
        );
        if (onChange) onChange(textarea.value);
        return;
      }
    }
    // Anything else (plain text, non-media links): fall through to the
    // browser's default paste behavior.
  });
}


//
// Previously implemented with native HTML5 drag-and-drop, armed from a
// `.drag-handle` mousedown. That approach broke on touch devices: touchstart
// set `draggable = true`, but native HTML5 DnD is mouse-only, so no matching
// `dragstart` ever fired — leaving the element in a stuck intermediate drag
// state that froze the page with no console error. Replaced with explicit
// move-up/move-down buttons: deterministic, keyboard-accessible, no native
// drag gesture involved at all.

window.moveQuestion = function (questionId, direction) {
  const index = quizData.questions.findIndex((q) => q.id === questionId);
  if (index === -1) return;

  let targetIndex;
  if (direction === "up") targetIndex = index - 1;
  else if (direction === "down") targetIndex = index + 1;
  else if (direction === "top") targetIndex = 0;
  else if (direction === "bottom") targetIndex = quizData.questions.length - 1;
  else return;

  if (targetIndex < 0 || targetIndex >= quizData.questions.length) return;
  if (targetIndex === index) return;

  pushHistorySnapshot();
  const [moved] = quizData.questions.splice(index, 1);
  quizData.questions.splice(targetIndex, 0, moved);

  const container = document.getElementById("questionsContainer");
  const card = document.getElementById(`question-${questionId}`);

  if (card) {
    if (direction === "up") {
      const sibling = card.previousElementSibling;
      if (sibling) container.insertBefore(card, sibling);
    } else if (direction === "down") {
      const sibling = card.nextElementSibling;
      if (sibling) container.insertBefore(sibling, card);
    } else if (direction === "top") {
      container.insertBefore(card, container.firstElementChild);
    } else if (direction === "bottom") {
      container.appendChild(card);
    }
  }

  updateQuestionNumbers();
  autosave();
};

function rerenderAllQuestions() {
  const container = document.getElementById("questionsContainer");
  container.innerHTML = "";
  quizData.questions.forEach((question) => {
    renderQuestion(question);
  });
  updateQuestionNumbers();
}

// ============================================================================
// REORDER MODE (drag handle, Pointer Events)
// ============================================================================
//
// A dedicated toggleable mode rather than an always-on handle, per the same
// touch-safety lesson as the old HTML5 DnD removal above: this uses Pointer
// Events (pointerdown/pointermove/pointerup), which — unlike HTML5
// draggable/dragstart — fire consistently for mouse, touch, and pen alike,
// so there's no touch-only failure mode to repeat here. The handle only
// exists in the DOM while reorderModeActive (see renderQuestion), so it
// can't be grabbed by accident during normal editing.

let reorderDrag = null; // { card, placeholder, pointerId, startY, offsetY }

/**
 * Reflect a toggle-mode's on/off state onto every button instance that
 * represents it — e.g. both the .section-actions button above the
 * questions list AND its mirror in the title bar's "إجراءات" (Actions)
 * menu (see #reorderModeBtn / #actionsMenuReorderBtn and the bulk-mode
 * equivalents). Previously each toggle* function only ever touched one
 * hardcoded button id, so a second trigger for the same mode had no way
 * to show whether that mode was currently on. `ariaAttr` is "aria-pressed"
 * for the two real toggle buttons or null for the collapse/expand item,
 * which has no persistent on/off state of its own to reflect.
 */
function _syncModeButtons(ids, active, ariaAttr = "aria-pressed") {
  ids.forEach((id) => {
    const btn = document.getElementById(id);
    if (!btn) return;
    btn.classList.toggle("active", active);
    if (ariaAttr) btn.setAttribute(ariaAttr, String(active));
  });
}

window.toggleReorderMode = function () {
  reorderModeActive = !reorderModeActive;

  // Reorder and bulk-select are mutually exclusive — both repurpose the
  // question header (drag handle vs. checkbox) and both reorder/renumber
  // the list, so having both active at once would be visually cluttered
  // and semantically confusing (what does "select" mean while dragging?).
  if (reorderModeActive && bulkModeActive) {
    window.toggleBulkMode();
  }

  _syncModeButtons(["reorderModeBtn", "actionsMenuReorderBtn"], reorderModeActive);
  document.body.classList.toggle("reorder-mode-active", reorderModeActive);

  // Re-render so every card picks up (or drops) its drag handle — simplest
  // way to keep this in sync with bulkModeActive's own checkbox toggling.
  // Collapse state lives only as a DOM class (see renderQuestion), so a
  // full rebuild would otherwise silently expand every card, same bug
  // toggleBulkMode avoids by mutating in place instead of re-rendering.
  // Capture and restore it around the rebuild here.
  const collapsedIds = new Set(
    Array.from(document.querySelectorAll(".question-card.collapsed")).map(
      (card) => card.dataset.questionId,
    ),
  );
  rerenderAllQuestions();
  collapsedIds.forEach((id) => {
    const card = document.querySelector(
      `.question-card[data-question-id="${id}"]`,
    );
    if (!card) return;
    card.classList.add("collapsed");
    // Also restore the collapsed-state preview snippet (see
    // toggleQuestionCollapse), which a fresh render leaves empty.
    const qPreview = document.getElementById(`qpreview-${id}`);
    const question = quizData.questions.find((q) => String(q.id) === id);
    if (qPreview && question) {
      const preview = (question.q || "")
        .replace(/\n/g, " ")
        .replace(/```[\s\S]*?```/g, "[كود]")
        .replace(/`/g, "")
        .trim();
      qPreview.textContent = preview
        ? preview.slice(0, 20) + (preview.length > 20 ? "…" : "")
        : "";
    }
  });
};

function setupReorderHandles() {
  const container = document.getElementById("questionsContainer");
  if (!container || container.dataset.reorderReady) return;
  container.dataset.reorderReady = "1";

  container.addEventListener("pointerdown", (e) => {
    if (!reorderModeActive) return;
    const handle = e.target.closest(".question-drag-handle");
    if (!handle) return;
    const card = handle.closest(".question-card");
    if (!card) return;

    e.preventDefault();

    const rect = card.getBoundingClientRect();
    const placeholder = document.createElement("div");
    placeholder.className = "question-drag-placeholder";
    placeholder.style.height = `${rect.height}px`;
    card.after(placeholder);

    card.classList.add("dragging");
    card.style.width = `${rect.width}px`;
    card.style.position = "fixed";
    card.style.top = `${rect.top}px`;
    card.style.left = `${rect.left}px`;
    card.style.zIndex = "500";
    card.style.pointerEvents = "none";

    reorderDrag = {
      card,
      placeholder,
      pointerId: e.pointerId,
      startY: e.clientY,
      cardTop: rect.top,
    };

    handle.setPointerCapture(e.pointerId);
  });

  container.addEventListener("pointermove", (e) => {
    if (!reorderDrag || e.pointerId !== reorderDrag.pointerId) return;
    e.preventDefault();

    const dy = e.clientY - reorderDrag.startY;
    reorderDrag.card.style.top = `${reorderDrag.cardTop + dy}px`;

    // Find which sibling the pointer is currently over and move the
    // placeholder there — the dragged card itself stays position:fixed
    // and is ignored by elementsFromPoint via pointer-events:none.
    const target = document
      .elementsFromPoint(e.clientX, e.clientY)
      .find((el) => el.classList?.contains("question-card") && el !== reorderDrag.card);
    if (!target) return;

    const targetRect = target.getBoundingClientRect();
    const isAfter = e.clientY > targetRect.top + targetRect.height / 2;
    if (isAfter) {
      target.after(reorderDrag.placeholder);
    } else {
      target.before(reorderDrag.placeholder);
    }
  });

  const endDrag = (e) => {
    if (!reorderDrag || e.pointerId !== reorderDrag.pointerId) return;
    const { card, placeholder } = reorderDrag;

    // Commit: move the card to the placeholder's position, then discard
    // the placeholder and reset the card's temporary drag styles.
    placeholder.replaceWith(card);
    card.classList.remove("dragging");
    card.style.position = "";
    card.style.top = "";
    card.style.left = "";
    card.style.width = "";
    card.style.zIndex = "";
    card.style.pointerEvents = "";

    reorderDrag = null;
    commitReorderFromDom();
  };

  container.addEventListener("pointerup", endDrag);
  container.addEventListener("pointercancel", endDrag);
}

/** After a drag settles, read the new DOM order back into quizData.questions
 * (single source of truth), snapshot for undo, renumber, and autosave —
 * mirrors what moveQuestion() does for the button-based reorder path. */
function commitReorderFromDom() {
  const container = document.getElementById("questionsContainer");
  if (!container) return;

  const domIds = Array.from(container.querySelectorAll(".question-card")).map(
    (card) => Number(card.dataset.questionId),
  );

  const currentIds = quizData.questions.map((q) => q.id);
  const unchanged =
    domIds.length === currentIds.length &&
    domIds.every((id, i) => id === currentIds[i]);
  if (unchanged) return;

  pushHistorySnapshot();
  const byId = new Map(quizData.questions.map((q) => [q.id, q]));
  quizData.questions = domIds.map((id) => byId.get(id)).filter(Boolean);

  updateQuestionNumbers();
  autosave();
}

// ============================================================================
// OPTIONS MANAGEMENT
// ============================================================================

/**
 * Normalize a question's `correct` field to always be an array of indices.
 * Older/imported data may still use a single number — this coerces it in
 * place so every render/export path can assume an array.
 *
 * Does NOT set `multiSelect` — its absence is meaningful (it signals a
 * pre-multiSelect question for isMultiSelectQuestion()'s backward-compat
 * fallback in rate-answers.js). Only setMultiSelect()/newly-created
 * questions set it explicitly.
 */
function normalizeCorrectField(question) {
  if (!question) return;
  if (Array.isArray(question.correct)) return;
  if (typeof question.correct === "number" && !Number.isNaN(question.correct)) {
    question.correct = [question.correct];
  } else {
    question.correct = [];
  }
}

/**
 * Explicitly sets a question's `multiSelect` flag (true = checkboxes /
 * multiple correct answers allowed, false = radio buttons / exactly one
 * correct answer), independent of how many options are currently marked
 * correct. This is what the per-question "اختر إجابة واحدة أو أكثر" menu
 * toggle calls.
 *
 * Turning multiSelect OFF on a question that currently has more than one
 * correct answer marked keeps only the first (lowest-index) one, since a
 * single-select question can only have exactly one correct answer — the
 * creator is told this via a confirmation before it happens (see the
 * onclick wiring in renderQuestion()).
 */
window.setMultiSelect = async function (questionId, multiSelect) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (!question) return;

  normalizeCorrectField(question);
  const nextMultiSelect = Boolean(multiSelect);

  if (!nextMultiSelect && question.correct.length > 1) {
    if (
      !(await _confirm(
        "هذا السؤال يحتوي على أكثر من إجابة صحيحة. تحويله إلى «اختيار واحد» سيُبقي أول إجابة صحيحة فقط. هل تريد المتابعة؟",
      ))
    ) {
      return;
    }
  }

  pushHistorySnapshot();
  question.multiSelect = nextMultiSelect;

  if (!question.multiSelect && question.correct.length > 1) {
    question.correct = [question.correct[0]];
  }

  rerenderOptions(questionId);
  updateIncompleteState(questionId);
  updateQuestionNumbers();
  autosave();
  syncActionsMenuConvertSingleButton();
};

/**
 * Keep the bulk action's label and next action aligned with the per-question
 * multi-select toggle. If any multi-select MCQ has exactly one answer, the
 * next action is to make those questions single-select; otherwise the action
 * turns current single-select MCQs into multi-select questions.
 */
function getSingleCorrectMultiSelectQuestions() {
  return quizData.questions.filter(
    (question) =>
      !question.answer &&
      isMultiSelectQuestion(question) &&
      Array.isArray(question.correct) &&
      question.correct.length === 1,
  );
}

function syncActionsMenuConvertSingleButton() {
  const button = document.getElementById("actionsMenuConvertSingleBtn");
  if (!button) return;

  const convertsToSingle = getSingleCorrectMultiSelectQuestions().length > 0;
  button.setAttribute("aria-pressed", String(convertsToSingle));
  const label = button.querySelector("span");
  if (label) {
    label.textContent = convertsToSingle
      ? "تحويل الأسئلة ذات الإجابة الواحدة إلى اختيار واحد"
      : "تحويل أسئلة الاختيار الواحد إلى إجابة واحدة أو أكثر";
  }
}

window.toggleSingleCorrectMcqsSelectMode = async function () {
  const candidates = getSingleCorrectMultiSelectQuestions();

  if (candidates.length > 0) {
    if (
      !(await _confirm(
        `سيتم تحويل ${candidates.length} سؤال إلى «اختيار واحد» مع الإبقاء على الإجابة الصحيحة الحالية. هل تريد المتابعة؟`,
      ))
    ) {
      return;
    }

    pushHistorySnapshot();
    candidates.forEach((question) => {
      question.multiSelect = false;
      rerenderOptions(question.id);
      updateIncompleteState(question.id);
    });

    autosave();
    renderCreateQuestionNavigator(quizData.questions);
    syncActionsMenuConvertSingleButton();
    showNotification(
      "تم التحويل",
      `تم تحويل ${candidates.length} سؤال إلى «اختيار واحد».`,
      "success",
    );
    return;
  }

  const singleSelectQuestions = quizData.questions.filter(
    (question) => !question.answer && !isMultiSelectQuestion(question),
  );

  if (singleSelectQuestions.length === 0) {
    showNotification(
      "لا توجد أسئلة مطابقة",
      "لا توجد أسئلة اختيار من متعدد يمكن تحويلها.",
      "info",
    );
    return;
  }

  if (
    !(await _confirm(
      `سيتم تحويل ${singleSelectQuestions.length} سؤال إلى «إجابة واحدة أو أكثر». هل تريد المتابعة؟`,
    ))
  ) {
    return;
  }

  pushHistorySnapshot();

  singleSelectQuestions.forEach((question) => {
    question.multiSelect = true;
    rerenderOptions(question.id);
    updateIncompleteState(question.id);
  });

  autosave();
  renderCreateQuestionNavigator(quizData.questions);
  syncActionsMenuConvertSingleButton();

  showNotification(
    "تم التحويل",
    `تم تحويل ${singleSelectQuestions.length} سؤال إلى «إجابة واحدة أو أكثر».`,
    "success",
  );
};

// Compatibility for callers that used the old one-way action name.
window.convertSingleCorrectMcqsToSingleSelect = window.toggleSingleCorrectMcqsSelectMode;

function renderOptions(question) {
  if (question.answer) {
    const optId = `option-text-${question.id}-0`;
    return `
      <div class="essay-answer-container" id="option-${question.id}-0">
        <div class="essay-answer-label">
          <span class="essay-badge">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z"/></svg>
            سؤال مقالي
          </span>
          نموذج الإجابة ${question.options?.[0]?.trim()
        ? `<span class="essay-answer-note">(يُستخدم لتصحيح إجابات الطلاب تلقائيًا وتقييمها من 5)</span>`
        : `<span class="essay-answer-missing">(مطلوب — بدونه لن يمكن تصحيح إجابات الطلاب تلقائيًا)</span>`
      }
        </div>
        <div class="essay-answer-editor">
          ${mdEditorHtml(optId, question.options[0], "اكتب نموذج إجابة هنا...", 5)}
        </div>
      </div>
    `;
  }

  normalizeCorrectField(question);
  const isMultiple = isMultiSelectQuestion(question);

  // ── MCQ / True-False: checkboxes when multiSelect, radio buttons when not ──
  return question.options
    .map((option, index) => {
      const optId = `option-text-${question.id}-${index}`;
      const isCorrect = question.correct.includes(index);
      const inputType = isMultiple ? "checkbox" : "radio";
      const inputName = isMultiple
        ? undefined
        : `correct-answer-${question.id}`;
      return `
        <div class="option-item ${isCorrect ? "correct" : ""}" id="option-${question.id}-${index}">
            <input 
                type="${inputType}" 
                class="option-checkbox"
                ${inputName ? `name="${inputName}"` : ""}
                ${isCorrect ? "checked" : ""}
                onchange="toggleCorrectAnswer(${question.id}, ${index})"
                title="تحديد كإجابة صحيحة"
                aria-label="تحديد الخيار ${index + 1} كإجابة صحيحة"
            />
            <div class="option-md-wrap">
                ${mdEditorHtml(optId, option, `إختيار ${index + 1}`, 1)}
            </div>
            ${question.options.length > 2
          ? `<button class="option-delete" onclick="removeOption(${question.id}, ${index})" title="حذف الخيار" aria-label="حذف الخيار ${index + 1}"><svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x-icon lucide-x"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button>`
          : ""
        }
        </div>
      `;
    })
    .join("");
}

function setupOptionMdEditors(questionId) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (!question) return;
  question.options.forEach((_, index) => {
    const optId = `option-text-${questionId}-${index}`;
    setupMdEditor(optId, (val) => {
      const q = quizData.questions.find((q) => q.id === questionId);
      if (q) {
        q.options[index] = val;
        autosave();
      }
    });
  });
}

window.updateOption = function (questionId, optionIndex, value) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (question) {
    question.options[optionIndex] = value;
    autosave();
  }
};

/** Toggle whether an option is one of the correct answers (multi-select) */
/** Toggle whether an option is one of the correct answers.
 * When question.multiSelect is true, behaves as multi-select (any number of
 * options can be marked). When false (or unset on a new question), behaves
 * as single-select: marking one option replaces `correct` entirely with
 * just that option, so exactly one answer is ever marked correct — matching
 * the radio-button UI rendered for these questions in renderOptions().
 */
window.toggleCorrectAnswer = function (questionId, optionIndex) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (question) {
    pushHistorySnapshot();
    normalizeCorrectField(question);
    if (isMultiSelectQuestion(question)) {
      const pos = question.correct.indexOf(optionIndex);
      if (pos === -1) {
        question.correct.push(optionIndex);
      } else {
        question.correct.splice(pos, 1);
      }
      question.correct.sort((a, b) => a - b);
    } else {
      // Single-select: this option becomes the one and only correct answer
      // (a radio button can't be "unchecked" by clicking it again, matching
      // native radio semantics — exactly one option must be selected).
      question.correct = [optionIndex];
    }
    rerenderOptions(questionId);
    updateIncompleteState(questionId);
    autosave();
  }
};

function rerenderOptions(questionId) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (!question) return;

  const container = document.getElementById(`options-container-${questionId}`);
  if (container) {
    container.innerHTML = renderOptions(question);
    setupOptionMdEditors(questionId);
  }

  // ── Keep the "multiSelect" menu toggle's label/action in sync ──────────────
  // renderOptions() above already reflects the current multiSelect state in
  // the option inputs themselves; this keeps the "⋮" dropdown's toggle entry
  // (which lives outside options-container, in the question header) matching
  // too, without needing a full question-card re-render.
  const multiSelectBtn = document.getElementById(
    `multiSelectToggle-${questionId}`,
  );
  if (multiSelectBtn) {
    const nowMultiple = isMultiSelectQuestion(question);
    multiSelectBtn.setAttribute(
      "onclick",
      `setMultiSelect(${questionId}, ${!nowMultiple}); closeAllQuestionMenus();`,
    );
    const label = multiSelectBtn.querySelector("span");
    if (label) {
      label.textContent = nowMultiple
        ? "تحويل إلى إجابة واحدة فقط"
        : "اختر إجابة واحدة أو أكثر";
    }
  }
  syncActionsMenuConvertSingleButton();

  // ── Keep card class, label, and button in sync with question type ──────────
  // Truthy check (not `=== 1`) to match renderQuestion()/renderOptions()/
  // updateIncompleteState() — `answer` is a non-empty string for essay
  // questions, so the old strict-equality check here always evaluated to
  // false. That silently mis-rendered the "add option"/"convert" button for
  // *every* essay question the moment anything triggered a rerenderOptions
  // (toggling a correct answer, removing an option, etc.) — swapping in
  // "إضافة خيار" (which calls addOption -> options.push("")) instead of the
  // essay's actual "تحويل إلى اختيار متعدد" button, corrupting the
  // single-slot essay `options` array instead of doing anything visible as
  // "add a question".
  const isEssay = Boolean(question.answer);
  const card = document.getElementById(`question-${questionId}`);
  if (card) {
    card.classList.toggle("question-card--essay", isEssay);
  }

  const label = document.querySelector(
    `#question-${questionId} .options-label`,
  );
  if (label) {
    label.textContent = isEssay
      ? "الإجابة المرجعية"
      : "الإختيارات";
  }

  const btnDiv = document.getElementById(`option-btn-${questionId}`);
  if (btnDiv) {
    if (isEssay) {
      btnDiv.innerHTML = `<button class="add-option-btn add-option-btn--convert" onclick="convertEssayToMcq(${questionId})">
        <svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg> تحويل إلى اختيار متعدد
      </button>`;
    } else {
      btnDiv.innerHTML = `<button class="add-option-btn" onclick="addOption(${questionId})">
        <svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg> إضافة خيار
      </button>
      <button class="add-option-btn add-option-btn--convert" onclick="convertMcqToEssay(${questionId})">
        <svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z"/></svg> تحويل إلى سؤال مقالي
      </button>`;
    }
  }
}

window.addOption = function (questionId) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (question) {
    pushHistorySnapshot();
    question.options.push("");
    rerenderOptions(questionId);
    updateStatistics();
    autosave();
  }
};

window.removeOption = function (questionId, optionIndex) {
  const question = quizData.questions.find((q) => q.id === questionId);
  // MCQs must keep at least 2 options — only remove when there are more
  // than 2 to begin with, so the last removal always leaves exactly 2.
  if (question && question.options.length > 2) {
    pushHistorySnapshot();
    normalizeCorrectField(question);
    question.options.splice(optionIndex, 1);
    // Drop the removed index from `correct` and shift indices above it down.
    question.correct = question.correct
      .filter((i) => i !== optionIndex)
      .map((i) => (i > optionIndex ? i - 1 : i));
    rerenderOptions(questionId);
    updateStatistics();
    updateIncompleteState(questionId);
    autosave();
  }
};

/** Convert a single-option (essay) question into a 4-option MCQ */
window.convertEssayToMcq = function (questionId) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (!question) return;
  pushHistorySnapshot();
  // Keep the model-answer text as the first option
  while (question.options.length < 4) question.options.push("");
  question.correct = [0];
  question.multiSelect = false;
  // Clear the essay marker/text — every isEssay check in this file is a
  // truthy test on `answer`, so leaving it set (even to the old essay
  // answer text) would keep this question rendering as an essay question
  // everywhere except the one button this function itself just redrew,
  // reverting back to the essay UI the next time the card re-renders
  // (e.g. reopening the page, or any other rerenderOptions call).
  question.answer = "";
  rerenderOptions(questionId);
  updateStatistics();
  updateIncompleteState(questionId);
  autosave();
  showNotification("تم التحويل", "تم تحويل السؤال إلى اختيار متعدد", "success");
};

/**
 * Convert a multiple-choice/true-false question into a single-option essay
 * question. The counterpart to convertEssayToMcq above — previously
 * missing entirely, which is why there was no way to go MCQ → Essay in the
 * editor (only the reverse direction had a button).
 *
 * Destructive to the existing options list (a 4-option MCQ can't keep all
 * 4 texts once collapsed to a single essay-answer slot), so this asks for
 * confirmation first via the app's own _confirm() dialog — consistent with
 * removeQuestion's use of the same helper elsewhere in this file — rather
 * than silently discarding the user's option text.
 */
window.convertMcqToEssay = async function (questionId) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (!question) return;

  if (!(await _confirm(
    "تحويل هذا السؤال إلى سؤال مقالي سيحذف كل الخيارات الحالية باستثناء نص أول خيار (سيُستخدم كبداية لنموذج الإجابة). هل تريد المتابعة؟",
  ))) {
    return;
  }

  pushHistorySnapshot();
  // Keep the first option's text as a starting draft for the model answer
  // rather than discarding it outright — the user may already have typed
  // the correct answer's wording into option 1.
  const draftAnswer = question.options?.[0] || "";
  question.options = [draftAnswer];
  question.answer = draftAnswer || ESSAY_MARKER;
  question.correct = [];

  rerenderOptions(questionId);
  updateStatistics();
  updateIncompleteState(questionId);
  autosave();
  showNotification("تم التحويل", "تم تحويل السؤال إلى سؤال مقالي", "success");
};

/** Recompute the "incomplete" badge on a card (e.g. after toggling correct answers) */
function updateIncompleteState(questionId) {
  const question = quizData.questions.find((q) => q.id === questionId);
  const card = document.getElementById(`question-${questionId}`);
  if (!question || !card) return;

  const isIncomplete =
    !question.q ||
    question.q.trim() === "" ||
    question.options.some((opt) => !opt || opt.trim() === "") ||
    (!question.answer &&
      (!Array.isArray(question.correct) || question.correct.length === 0));

  card.classList.toggle("incomplete", isIncomplete);
}

// ============================================================================
// COLLAPSIBLE SECTIONS
// ============================================================================

// ============================================================================
// SEARCH AND FILTER - ENHANCED
// ============================================================================

function handleSearch(e) {
  const searchTerm = e.target.value.toLowerCase();
  const questionCards = document.querySelectorAll(".question-card");
  const clearBtn = document.getElementById("clearSearch");

  if (clearBtn) {
    clearBtn.style.display = searchTerm ? "flex" : "none";
  }

  let visibleCount = 0;
  questionCards.forEach((card) => {
    // Read from the md-source textarea (the raw text field)
    const sourceTextarea = card.querySelector(".md-source");
    const questionText = (
      sourceTextarea ? sourceTextarea.value : ""
    ).toLowerCase();
    const matches = questionText.includes(searchTerm);
    card.style.display = matches ? "block" : "none";
    if (matches) visibleCount++;
  });

  if (visibleCount === 0 && searchTerm) {
    showNotification(
      "لا توجد نتائج",
      `لم يتم العثور على أسئلة تحتوي على "${searchTerm}"`,
      "info",
    );
  }
}

window.clearSearch = function () {
  const searchInput = document.getElementById("questionSearch");
  const clearBtn = document.getElementById("clearSearch");

  if (searchInput) {
    searchInput.value = "";
    clearBtn.style.display = "none";

    // Show all questions
    document.querySelectorAll(".question-card").forEach((card) => {
      card.style.display = "block";
    });
  }
};

window.toggleExpand = function () {
  const cards = document.querySelectorAll(".question-card");
  if (cards.length === 0) return;

  const allCollapsed = Array.from(cards).every((card) =>
    card.classList.contains("collapsed"),
  );

  if (allCollapsed) {
    window.expandAll();
  } else {
    window.collapseAll();
  }
};

window.expandAll = function () {
  document.querySelectorAll(".question-card.collapsed").forEach((card) => {
    const id = parseInt(card.dataset.questionId);
    if (!Number.isNaN(id)) {
      window.toggleQuestionCollapse(id);
    }
  });
};

window.collapseAll = function () {
  document.querySelectorAll(".question-card").forEach((card) => {
    if (!card.classList.contains("collapsed")) {
      const id = parseInt(card.dataset.questionId);
      if (!Number.isNaN(id)) {
        window.toggleQuestionCollapse(id);
      }
    }
  });
};

// ============================================================================
// BULK MODE
// ============================================================================

window.toggleBulkMode = function () {
  bulkModeActive = !bulkModeActive;
  const bulkActionsBar = document.getElementById("bulkActionsBar");

  // Mutually exclusive with reorder mode — see the matching check in
  // toggleReorderMode() for why (both repurpose the question header).
  if (bulkModeActive && reorderModeActive) {
    window.toggleReorderMode();
  }

  // Was inline-style toggling (bulkBtn.style.background/color) targeting
  // only #bulkModeBtn — switched to the same .active class + _syncModeButtons
  // helper toggleReorderMode uses, so the title bar's Actions-menu mirror
  // (#actionsMenuSelectBtn) reflects the mode too instead of only the
  // original section-actions button.
  _syncModeButtons(["bulkModeBtn", "actionsMenuSelectBtn"], bulkModeActive);

  if (bulkModeActive) {
    bulkActionsBar.style.display = "flex";

    // Add checkboxes to all questions
    document.querySelectorAll(".question-card").forEach((card) => {
      if (!card.querySelector(".question-select-checkbox")) {
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.className = "question-select-checkbox";
        checkbox.onclick = (e) => e.stopPropagation();
        checkbox.onchange = (e) =>
          handleQuestionSelect(e, parseInt(card.dataset.questionId));

        const numberSpan = card.querySelector(".question-number");
        numberSpan.insertBefore(checkbox, numberSpan.firstChild);
      }
    });
  } else {
    bulkActionsBar.style.display = "none";
    selectedQuestions.clear();

    // Remove checkboxes
    document
      .querySelectorAll(".question-select-checkbox")
      .forEach((cb) => cb.remove());
    document.querySelectorAll(".question-card").forEach((card) => {
      card.classList.remove("selected");
    });
    updateSelectedCount();
  }
};

window.handleQuestionSelect = function (e, questionId) {
  const card = document.getElementById(`question-${questionId}`);

  if (e.target.checked) {
    selectedQuestions.add(questionId);
    card.classList.add("selected");
  } else {
    selectedQuestions.delete(questionId);
    card.classList.remove("selected");
  }

  updateSelectedCount();
};

function updateSelectedCount() {
  const countSpan = document.getElementById("selectedCount");
  if (countSpan) {
    countSpan.textContent = selectedQuestions.size;
  }
}

window.selectAllQuestions = function () {
  document.querySelectorAll(".question-select-checkbox").forEach((cb) => {
    cb.checked = true;
    const card = cb.closest(".question-card");
    if (card) {
      const questionId = parseInt(card.dataset.questionId);
      selectedQuestions.add(questionId);
      card.classList.add("selected");
    }
  });
  updateSelectedCount();
  showNotification(
    "تم التحديد",
    `تم تحديد ${selectedQuestions.size} سؤال`,
    "info",
  );
};

window.deselectAllQuestions = function () {
  document.querySelectorAll(".question-select-checkbox").forEach((cb) => {
    cb.checked = false;
  });
  document.querySelectorAll(".question-card").forEach((card) => {
    card.classList.remove("selected");
  });
  selectedQuestions.clear();
  updateSelectedCount();
};

window.deleteSelectedQuestions = async function () {
  if (selectedQuestions.size === 0) {
    showNotification("تنبيه", "لم يتم تحديد أي أسئلة", "error");
    return;
  }

  if (
    !(await _confirm(`هل أنت متأكد من حذف ${selectedQuestions.size} سؤال؟`))
  ) {
    return;
  }

  pushHistorySnapshot();
  const idsToDelete = Array.from(selectedQuestions);

  idsToDelete.forEach((id) => {
    const index = quizData.questions.findIndex((q) => q.id === id);
    if (index !== -1) {
      quizData.questions.splice(index, 1);
    }

    const card = document.getElementById(`question-${id}`);
    if (card) {
      card.remove();
    }
  });

  selectedQuestions.clear();
  updateQuestionNumbers();
  updateEmptyState();
  updateProgress();
  updateStatistics();
  updateSelectedCount();
  autosave();

  showNotification("تم الحذف", `تم حذف ${idsToDelete.length} سؤال`, "success");
};

/** Duplicate every currently-selected question, inserting each copy
 * directly after its original — same per-question behavior as
 * duplicateQuestion(), just applied to the whole selection at once. */
window.duplicateSelectedQuestions = function () {
  if (selectedQuestions.size === 0) {
    showNotification("تنبيه", "لم يتم تحديد أي أسئلة", "error");
    return;
  }

  pushHistorySnapshot();

  // Snapshot the ids in on-page order (not Set insertion order) so
  // duplicates land in a predictable top-to-bottom sequence even if the
  // user selected questions out of order.
  const idsToDuplicate = quizData.questions
    .map((q) => q.id)
    .filter((id) => selectedQuestions.has(id));

  let duplicatedCount = 0;
  idsToDuplicate.forEach((id) => {
    const index = quizData.questions.findIndex((q) => q.id === id);
    if (index === -1) return;
    const original = quizData.questions[index];
    const newId = ++questionIdCounter;
    const copy = { ...original, id: newId };
    quizData.questions.splice(index + 1, 0, copy);
    renderQuestion(copy, index + 1);
    duplicatedCount++;
  });

  updateQuestionNumbers();
  updateEmptyState();
  updateProgress();
  updateStatistics();
  autosave();

  showNotification(
    "تم النسخ",
    `تم نسخ ${duplicatedCount} سؤال`,
    "success",
  );
};

// ============================================================================
// VALIDATION
// ============================================================================

function validateQuiz() {
  const errors = [];

  if (!quizData.title || quizData.title.trim() === "") {
    errors.push("عنوان الامتحان مطلوب");
  }

  if (quizData.questions.length === 0) {
    errors.push("يجب إضافة سؤال واحد على الأقل");
  }

  quizData.questions.forEach((q, index) => {
    const questionNum = index + 1;

    if (!q.q || q.q.trim() === "") {
      errors.push(`السؤال ${questionNum}: نص السؤال مطلوب`);
    }

    if (q.options.length > 1) {
      const emptyOptions = q.options.filter((opt) => !opt || opt.trim() === "");
      if (emptyOptions.length > 0) {
        errors.push(`السؤال ${questionNum}: جميع الخيارات يجب أن تحتوي على نص`);
      }

      if (!Array.isArray(q.correct) || q.correct.length === 0) {
        errors.push(
          `السؤال ${questionNum}: يجب تحديد إجابة صحيحة واحدة على الأقل`,
        );
      }
    }

  });

  return errors;
}

// ============================================================================
// EMPTY STATE
// ============================================================================

function updateEmptyState() {
  const emptyState = document.getElementById("emptyState");
  const questionControls = document.getElementById("questionControls");
  const addQuestionBottom = document.getElementById("addQuestionBottom");
  const questionBadge = document.getElementById("questionBadge");

  if (quizData.questions.length === 0) {
    emptyState.classList.remove("hidden");
    if (questionControls) questionControls.style.display = "none";
    if (addQuestionBottom) addQuestionBottom.style.display = "none";
  } else {
    emptyState.classList.add("hidden");
    if (questionControls) questionControls.style.display = "block";
    if (addQuestionBottom) addQuestionBottom.style.display = "flex";
  }

  if (questionBadge) {
    questionBadge.textContent = quizData.questions.length;
  }

  // Keep the live editor navigator synchronized with every path that changes
  // the question collection (add/import/load/reset/delete), not just the
  // explicit reorder path.
  renderCreateQuestionNavigator(quizData.questions);
}

// ============================================================================
// TEMPLATES SYSTEM
// ============================================================================

window.toggleTemplates = function () {
  const panel = document.getElementById("templatesPanel");
  isTemplatesPanelOpen = !isTemplatesPanelOpen;

  if (isTemplatesPanelOpen) {
    panel.style.display = "block";
  } else {
    panel.style.display = "none";
  }
};

window.addQuestionFromTemplate = function (templateType) {
  const templates = {
    mcq: {
      q: "",
      options: ["", "", "", ""],
      correct: [0],
      multiSelect: false,
      image: "",
      audio: "",
      video: "",
      explanation: "",
    },
    truefalse: {
      q: "",
      options: ["True", "False"],
      correct: [0],
      multiSelect: false,
      image: "",
      audio: "",
      video: "",
      explanation: "",
    },
    essay: {
      q: "",
      // Every isEssay check in this file (renderQuestion, renderOptions,
      // rerenderOptions, updateIncompleteState) branches on `answer` being
      // *truthy* — this template previously omitted the field entirely, so
      // picking "essay" from the templates panel silently produced a
      // single-empty-option MCQ instead of an essay question. `options[0]`
      // (not this field) is what the essay-answer editor actually reads
      // and writes as the user types, so this is only an internal marker
      // — it must stay non-empty (unlike options[0], which starts blank)
      // purely so the truthy checks correctly identify this as an essay
      // question from the moment it's created.
      answer: ESSAY_MARKER,
      options: [""],
      correct: [],
      image: "",
      audio: "",
      video: "",
      explanation: "",
    },
  };

  const template = templates[templateType];
  if (!template) return;

  pushHistorySnapshot();
  const questionId = ++questionIdCounter;
  const question = {
    id: questionId,
    ...template,
  };

  quizData.questions.push(question);
  renderQuestion(question);
  updateEmptyState();
  updateProgress();
  updateStatistics();
  autosave();

  // Close templates panel after selection
  toggleTemplates();

  setTimeout(() => {
    const questionCard = document.getElementById(`question-${questionId}`);
    if (questionCard) {
      questionCard.scrollIntoView({ behavior: "smooth", block: "center" });

      // Image section is always visible now — focus it directly for image
      // templates, otherwise focus the question text field.
      if (templateType === "image") {
        const imageInput = document.getElementById(
          `question-image-${questionId}`,
        );
        if (imageInput) {
          imageInput.focus();
        } else {
          activateMdEditor(`question-text-${questionId}`);
        }
      } else {
        activateMdEditor(`question-text-${questionId}`);
      }
    }
  }, 100);

  showNotification(
    "تم الإضافة!",
    `تم إضافة سؤال من قالب ${getTemplateName(templateType)}`,
    "success",
  );
};

function getTemplateName(type) {
  const names = {
    mcq: "اختيار متعدد",
    truefalse: "صح أم خطأ",
    essay: "مقالي",
    image: "مع صورة",
  };
  return names[type] || "افتراضي";
}

// ============================================================================
// AUTOSAVE
// ============================================================================

function autosave() {
  clearTimeout(autosaveTimeout);

  updateAutosaveIndicator("saving");

  autosaveTimeout = setTimeout(() => {
    try {
      // Editing a shared/admin quiz (?id=<dbId>&mode=edit) — the server is
      // the source of truth here (saveLocally() posts straight to
      // POST /api/admin?action=update-quiz for this mode; see its header
      // comment), so there's no local draft to keep in sync. Skipping local
      // persistence entirely also avoids the bug this branch used to cause:
      // falling through to the quiz_draft key below (the same key the
      // *local* published-quiz edit path uses) meant every keystroke here
      // got written under that single shared key, which the entry screen's
      // legacy-draft migration (renderEntryItemsGrid()) then surfaced as a
      // bogus recoverable draft for an entirely different, unrelated quiz.
      if (sharedEditDbId) {
        updateAutosaveIndicator("saved");
        return;
      }

      // If we have a currentDraftId, upsert into user_quizzes as a draft entry.
      // If editing a published quiz (?edit=<id>), fall back to the old single-key
      // quiz_draft behaviour so the editor's state is preserved across refreshes.
      if (currentDraftId) {
        const entry = {
          id: currentDraftId,
          meta: {
            type: "draft",
            title: quizData.title?.trim() || "",
            description: quizData.description?.trim() || "",
            source: quizData.source?.trim() || "",
            updatedAt: new Date().toISOString(),
          },
          questions: quizData.questions,
        };
        upsertEditorDraft(entry);
      } else {
        // Editing a published quiz — keep a local recovery copy under quiz_draft
        const dataToSave = {
          title: quizData.title,
          description: quizData.description,
          source: quizData.source,
          questions: quizData.questions,
          lastModified: new Date().toISOString(),
        };
        localStorage.setItem("quiz_draft", JSON.stringify(dataToSave));
      }
      updateAutosaveIndicator("saved");
    } catch (error) {
      console.error("Autosave error:", error);
      updateAutosaveIndicator("error");
    }
  }, 1000);
}

function updateAutosaveIndicator(status) {
  const indicator = document.getElementById("autosaveIndicator");
  if (!indicator) return;

  indicator.classList.remove("saving", "error");

  if (status === "saving") {
    indicator.classList.add("saving");
    indicator.querySelector(".save-text").textContent = "يُحفظ..";
  } else if (status === "saved") {
    indicator.querySelector(".save-text").textContent = "محفوظ";
  } else if (status === "error") {
    indicator.classList.add("error");
    indicator.querySelector(".save-text").textContent = "خطأ في الحفظ";
  }
}

/**
 * Convert a question from the saved (exported) format back to the editor's
 * internal format.  Essay questions are stored as { q, answer } in
 * user_quizzes but the editor always uses { q, options: [answer] }.
 */
function normalizeQuestionForEditor(q) {
  if (!Array.isArray(q.options)) {
    // Essay: answer field present, no options array. `answer` here becomes
    // the editor's isEssay marker (see ESSAY_MARKER) — it must stay
    // non-empty even when the real answer text (q.answer) is blank, since
    // every isEssay check in this file is a truthy test on `answer`, not a
    // check for the field's mere presence.
    return {
      ...q,
      answer: q.answer || ESSAY_MARKER,
      options: [q.answer ?? ""],
      correct: [],
    };
  }
  // Ensure options is never empty
  if (q.options.length === 0) {
    return { ...q, options: [""], correct: [] };
  }
  // MCQ/True-False question with a real options array. Every isEssay check
  // in this file (renderQuestion, rerenderOptions, updateIncompleteState,
  // etc.) is a plain truthy test on `question.answer` — it assumes `answer`
  // is only ever present on essay questions. The AI tool schema documents
  // that contract too (_tools.js: "Omit `correct` (and `options`) entirely
  // for essay/free-text questions and use `answer` instead"), but models
  // don't always honor it — some providers still tack on a redundant
  // `answer` field to an MCQ question (e.g. restating "the answer is B").
  // Left in place, that stray field flips every isEssay check to true and
  // the question silently loses its options/correct entirely. Since
  // `options` is the authoritative signal for "this is MCQ" here, drop any
  // `answer` field whenever real options are present, so the rest of the
  // editor sees an unambiguous MCQ/TF question.
  const { answer, ...withoutAnswer } = q;
  q = withoutAnswer;
  // Normalize a legacy single-index `correct` (old saved quizzes) into an
  // array so every render/export path downstream can assume an array.
  if (!Array.isArray(q.correct)) {
    return {
      ...q,
      correct:
        typeof q.correct === "number" && !Number.isNaN(q.correct)
          ? [q.correct]
          : [],
    };
  }
  return q;
}

// Ensure all loaded questions have stable numeric IDs before rendering
function normalizeQuestionsWithIds(questions) {
  let maxId = 0;
  const normalized = questions.map((q) => {
    let idNum = Number(q.id);
    if (!Number.isInteger(idNum) || idNum <= 0) {
      idNum = maxId + 1;
    }
    if (idNum > maxId) {
      maxId = idNum;
    }
    return normalizeQuestionForEditor({
      ...q,
      id: idNum,
    });
  });

  // Fallback for legacy data with no IDs at all
  if (maxId === 0 && normalized.length > 0) {
    normalized.forEach((q, index) => {
      q.id = index + 1;
    });
    maxId = normalized.length;
  }

  return { questions: normalized, maxId };
}

function loadDraftFromLocalStorage() {
  try {
    const saved = localStorage.getItem("quiz_draft");
    if (saved) {
      const data = JSON.parse(saved);

      // Support both old flat schema and new (meta.title)
      const title = data.meta?.title || data.title;
      const description = data.meta?.description || data.description;
      const source = data.meta?.source || data.source || "";

      if (title) {
        quizData.title = title;
        document.getElementById("quizTitle").value = title;
        updateCharCount("titleCharCount", title.length, 100);
      }

      if (description) {
        quizData.description = description;
        const descEl = document.getElementById("quizDescription");
        descEl.value = description;
        updateCharCount("descCharCount", description.length, 500);
        autoResizeMdSource(descEl);
      }

      if (source) {
        quizData.source = source;
        const srcEl = document.getElementById("quizSource");
        if (srcEl) srcEl.value = source;
      }

      // Restore Phase 2 fields
      if (data.meta) {
        if (data.meta.password) {
          const passEl = document.getElementById("quizPassword");
          if (passEl) passEl.value = data.meta.password;
        }

        const viewValue =
          data.meta.view && data.meta.view !== "empty"
            ? data.meta.view
            : "empty";
        const viewRadio = document.querySelector(
          `input[name="quizView"][value="${viewValue}"]`,
        );
        if (viewRadio) {
          viewRadio.checked = true;
          if (typeof updateOptionCards === "function")
            updateOptionCards(viewRadio);
        }

        const modeValue =
          data.meta.mode && data.meta.mode !== "empty"
            ? data.meta.mode
            : "empty";
        const modeRadio = document.querySelector(
          `input[name="quizMode"][value="${modeValue}"]`,
        );
        if (modeRadio) {
          modeRadio.checked = true;
          if (typeof updateOptionCards === "function")
            updateOptionCards(modeRadio);
        }
      }

      if (data.questions && data.questions.length > 0) {
        const { questions, maxId } = normalizeQuestionsWithIds(data.questions);
        quizData.questions = questions;
        questionIdCounter = maxId;

        const container = document.getElementById("questionsContainer");
        container.innerHTML = "";

        questions.forEach((question) => {
          renderQuestion(question);
        });

        updateEmptyState();
        updateProgress();
        updateStatistics();
        showNotification("تم التحميل", "تم تحميل المسودة المحفوظة", "success");
      }
      // Sync the app-bar title now that quizData.title is populated
      updateAppTitleBar();
    }
    // Loading a draft replaces quizData wholesale — old undo/redo snapshots
    // (if any existed at this point) would no longer point back to anything
    // related to what's now on screen.
    resetHistory();
  } catch (error) {
    console.error("Error loading from localStorage:", error);
  }
}

function loadQuizFromLocalStorage(quizId) {
  try {
    const userQuizzes = JSON.parse(
      localStorage.getItem("user_quizzes") || "[]",
    );
    const quiz = userQuizzes.find((q) => q.id === quizId);

    if (quiz) {
      const headerTitle = document.querySelector(".header h1");
      if (headerTitle) headerTitle.textContent = "تعديل الامتحان";
      document.title = "تعديل الامتحان - منصة بصمجي";

      // Support both old flat schema and new (meta.title)
      quizData.title = quiz.meta?.title || quiz.title || "";
      const qTitleEl = document.getElementById("quizTitle");
      if (qTitleEl) {
        qTitleEl.value = quizData.title;
        updateCharCount("titleCharCount", quizData.title.length, 100);
      }

      quizData.description = quiz.meta?.description || quiz.description || "";
      const quizDescEl = document.getElementById("quizDescription");
      quizDescEl.value = quizData.description;
      updateCharCount("descCharCount", quizData.description.length, 500);
      autoResizeMdSource(quizDescEl);

      quizData.source = quiz.meta?.source || quiz.source || "";
      document.getElementById("quizSource").value = quizData.source;
      updateCharCount("sourceCharCount", quizData.source.length, 500);

      // Restore Phase 2 fields
      if (quiz.meta) {
        // Restore password
        if (quiz.meta.password) {
          const passEl = document.getElementById("quizPassword");
          if (passEl) passEl.value = quiz.meta.password;
        }

        const viewValue =
          quiz.meta.view && quiz.meta.view !== "empty"
            ? quiz.meta.view
            : "empty";
        const viewRadio = document.querySelector(
          `input[name="quizView"][value="${viewValue}"]`,
        );
        if (viewRadio) {
          viewRadio.checked = true;
          if (typeof updateOptionCards === "function")
            updateOptionCards(viewRadio);
        }

        const modeValue =
          quiz.meta.mode && quiz.meta.mode !== "empty"
            ? quiz.meta.mode
            : "empty";
        const modeRadio = document.querySelector(
          `input[name="quizMode"][value="${modeValue}"]`,
        );
        if (modeRadio) {
          modeRadio.checked = true;
          if (typeof updateOptionCards === "function")
            updateOptionCards(modeRadio);
        }
      }

      if (quiz.questions && quiz.questions.length > 0) {
        const { questions, maxId } = normalizeQuestionsWithIds(quiz.questions);
        quizData.questions = questions;
        questionIdCounter = maxId;
      }

      // Always clear and re-render everything
      const container = document.getElementById("questionsContainer");
      if (container) container.innerHTML = "";
      quizData.questions.forEach((question) => {
        renderQuestion(question);
      });

      showNotification("أهلاً بك", "تم تحميل الامتحان للتعديل", "success");
      // Sync the app-bar title now that quizData.title is populated
      updateAppTitleBar();
      // Questions were just rendered above — refresh the empty-state
      // visibility (it's shown by default / left over from an earlier,
      // still-empty call to finishFormInit()) along with progress/stats,
      // which also depend on quizData.questions now being populated.
      updateEmptyState();
      updateProgress();
      updateStatistics();
      // Freshly loaded quiz — nothing to undo back into yet.
      resetHistory();
    } else {
      showNotification("خطأ", "لم يتم العثور على الامتحان", "error");
      setTimeout(() => (window.location.href = "/"), 1500);
    }
  } catch (error) {
    console.error("Error loading quiz for edit:", error);
    showNotification("خطأ", "حدث خطأ أثناء تحميل الامتحان", "error");
  }
}

/**
 * Fetch a shared/admin (Supabase-backed) quiz by its DB row id and prefill
 * the editor form from it — the shared-quiz counterpart to
 * loadQuizFromLocalStorage() above. Reuses loadFullQuizData() (already
 * used by the download/copy/AI-attach paths) rather than a new fetch, since
 * it already returns exactly the {meta, stats, questions} shape this form
 * needs and public reads on `quizzes` already allow it (no auth token
 * needed just to populate the form — the real authorization check happens
 * server-side when the save actually posts to action=update-quiz).
 *
 * Note meta.password is never present here (see the header comment on
 * handleUpdateQuiz in api/admin.js for why) — the password field simply
 * starts blank, same as it would look to a public visitor.
 */
async function loadSharedQuizForEdit(dbId) {
  try {
    const full = await loadFullQuizData({ dbId });
    const meta = full.meta || {};

    // See sharedEditHasPassword's declaration above — fetched alongside the
    // quiz itself so updateSaveMenuOptionForSharedEdit() (called at the end
    // of this function) knows whether to reveal the "remove password" row.
    // Best-effort: if the check itself fails, fall back to not showing the
    // row rather than blocking the rest of the load over it.
    try {
      sharedEditHasPassword = await checkQuizHasPassword(dbId);
    } catch (pwError) {
      console.error("Error checking quiz password state:", pwError);
      sharedEditHasPassword = false;
    }

    const headerTitle = document.querySelector(".header h1");
    if (headerTitle) headerTitle.textContent = "تعديل الامتحان";
    document.title = "تعديل الامتحان - منصة بصمجي";

    quizData.title = meta.title || "";
    const qTitleEl = document.getElementById("quizTitle");
    if (qTitleEl) {
      qTitleEl.value = quizData.title;
      updateCharCount("titleCharCount", quizData.title.length, 100);
    }

    quizData.description = meta.description || "";
    const quizDescEl = document.getElementById("quizDescription");
    if (quizDescEl) {
      quizDescEl.value = quizData.description;
      updateCharCount("descCharCount", quizData.description.length, 500);
      autoResizeMdSource(quizDescEl);
    }

    quizData.source = meta.source || "";
    const quizSourceEl = document.getElementById("quizSource");
    if (quizSourceEl) {
      quizSourceEl.value = quizData.source;
      updateCharCount("sourceCharCount", quizData.source.length, 500);
    }

    // Password intentionally left blank — see function header comment.
    // The view/mode radios are the only other meta fields the create form
    // exposes, same as the local-edit path above.
    const viewValue = meta.view && meta.view !== "empty" ? meta.view : "empty";
    const viewRadio = document.querySelector(
      `input[name="quizView"][value="${viewValue}"]`,
    );
    if (viewRadio) {
      viewRadio.checked = true;
      if (typeof updateOptionCards === "function") updateOptionCards(viewRadio);
    }

    const modeValue = meta.mode && meta.mode !== "empty" ? meta.mode : "empty";
    const modeRadio = document.querySelector(
      `input[name="quizMode"][value="${modeValue}"]`,
    );
    if (modeRadio) {
      modeRadio.checked = true;
      if (typeof updateOptionCards === "function") updateOptionCards(modeRadio);
    }

    if (Array.isArray(full.questions) && full.questions.length > 0) {
      const { questions, maxId } = normalizeQuestionsWithIds(full.questions);
      quizData.questions = questions;
      questionIdCounter = maxId;
    }

    const container = document.getElementById("questionsContainer");
    if (container) container.innerHTML = "";
    quizData.questions.forEach((question) => renderQuestion(question));

    showNotification("أهلاً بك", "تم تحميل الامتحان للتعديل", "success");
    updateAppTitleBar();
    updateEmptyState();
    updateProgress();
    updateStatistics();
    resetHistory();
    updateSaveMenuOptionForSharedEdit();
  } catch (error) {
    console.error("Error loading shared quiz for edit:", error);
    showNotification(
      "خطأ",
      "تعذّر تحميل الامتحان للتعديل. تأكد أنه ما يزال موجودًا.",
      "error",
    );
    setTimeout(() => (window.location.href = "/"), 1500);
  }
}

/**
 * Swap the "حفظ محليًا" / Ctrl+S menu entry's label to "حفظ التعديلات" while
 * editing a shared quiz, so its wording doesn't misleadingly claim a
 * server-backed save is only local. Purely cosmetic — saveLocally() itself
 * (called by both the click handler and the Ctrl+S shortcut, unchanged)
 * already branches on sharedEditDbId to actually post to the server; see
 * its header comment.
 */
function updateSaveMenuOptionForSharedEdit() {
  if (!sharedEditDbId) return;
  const label = document.querySelector(
    '.menu-option[onclick*="saveLocally"] span:not(.menu-option-shortcut)',
  );
  if (label) label.textContent = "حفظ التعديلات";

  // Also reveal the "remove password" checkbox (create-quiz.html) — see
  // saveSharedQuizEdit()'s header comment for why plain-blank isn't enough
  // to mean "remove it" in this mode. Only shown when the loaded quiz
  // actually has a password set (sharedEditHasPassword, populated by
  // loadSharedQuizForEdit() via checkQuizHasPassword()) — otherwise there's
  // nothing to clear and the row was showing unconditionally. Also make
  // sure it's hidden (and its checkbox unticked) in the no-password case,
  // in case this ever runs more than once for the same page load.
  const clearRow = document.getElementById("quizPasswordClearRow");
  if (clearRow) {
    clearRow.style.display = sharedEditHasPassword ? "" : "none";
    if (!sharedEditHasPassword) {
      const clearCheckbox = document.getElementById("quizPasswordClear");
      if (clearCheckbox) clearCheckbox.checked = false;
    }
  }
}

// ============================================================================
// SAVE TO USER QUIZZES
// ============================================================================

function buildQuizPayload(quizToSave, quizId, existingCreatedAt) {
  // Media lives inline inside `q.q` as raw HTML tags (<img>/<video>/
  // <audio>) — there are no dedicated image/audio/video fields to carry
  // over anymore.
  const questions = (quizToSave.questions || []).map((q) => {
    const out = { q: q.q };
    // Normalize essay: old 1-option → new answer field
    if (Array.isArray(q.options) && q.options.length === 1) {
      out.answer = q.options[0] ?? "";
    } else if (!Array.isArray(q.options) && q.answer !== undefined) {
      out.answer = q.answer;
    } else if (Array.isArray(q.options)) {
      out.options = q.options;
      if (q.correct !== undefined && q.correct !== null) {
        out.correct = Array.isArray(q.correct)
          ? q.correct
          : typeof q.correct === "number"
            ? [q.correct]
            : [];
      }
      // Persist the explicit multiSelect flag (see rate-answers.js /
      // setMultiSelect above) so the checkbox-vs-radio choice survives a
      // save — omitting it here would silently lose it on every save,
      // falling back to the legacy Array.isArray(correct) heuristic on
      // next load (which is now always true, since `correct` is always
      // an array — that would make every saved question look multi-select).
      if (q.multiSelect !== undefined) out.multiSelect = Boolean(q.multiSelect);
    }
    if (q.explanation?.trim()) out.explanation = q.explanation;
    return out;
  });

  const types = new Set();
  questions.forEach((q) => {
    if (!Array.isArray(q.options) || q.options.length === 0) types.add("Essay");
    else if (q.options.length === 2) types.add("True/False");
    else types.add("MCQ");
  });

  const meta = {
    title: quizToSave.title?.trim() || "Untitled",
    createdAt: existingCreatedAt || new Date().toLocaleString("en-US"),
    // ISO timestamp, distinct from the legacy locale-string createdAt above
    // (which other pages parse/display and I don't want to risk changing).
    // Used only by the entry screen's "recent items" sort/relative-date label.
    updatedAt: new Date().toISOString(),
  };
  if (quizToSave.description?.trim())
    meta.description = quizToSave.description.trim();
  if (quizToSave.source?.trim()) meta.source = quizToSave.source.trim();

  // Read Phase 2 fields
  const pwd = document.getElementById("quizPassword")?.value?.trim();
  if (pwd) {
    meta.password = pwd;
  } else {
    delete meta.password;
  }
  delete meta.privacy;
  delete meta.lang;
  const viewVal = document.querySelector(
    'input[name="quizView"]:checked',
  )?.value;
  if (viewVal && viewVal !== "empty") meta.view = viewVal;

  const modeVal = document.querySelector(
    'input[name="quizMode"]:checked',
  )?.value;
  if (modeVal && modeVal !== "empty") meta.mode = modeVal;

  return {
    meta,
    stats: {
      questionCount: questions.length,
      questionTypes: Array.from(types).sort(),
    },
    questions,
  };
}

/**
 * @returns {string|null} the new quiz's id, or null on failure — a thrown
 *   error (storage failure) and a same-level name collision are both
 *   reported the same way to the caller (see saveLocally's `if (quizId)`
 *   branch), but a collision sets `saveToUserQuizzes.lastError` first so the
 *   caller can show a specific message instead of the generic fallback.
 */
function saveToUserQuizzes(quizToSave) {
  try {
    const existingQuizzes = JSON.parse(
      localStorage.getItem("user_quizzes") || "[]",
    );
    const title = quizToSave.title?.trim() || "Untitled";

    if (hasSameLevelCollision(existingQuizzes, { type: "quiz", title, parentId: null })) {
      saveToUserQuizzes.lastError =
        "يوجد امتحان بنفس الاسم في المستوى الرئيسي من امتحاناتك بالفعل.";
      return null;
    }

    const quizId = `user_quiz_${Date.now()}`;
    const newQuiz = { id: quizId, ...buildQuizPayload(quizToSave, quizId) };
    existingQuizzes.push(newQuiz);
    localStorage.setItem("user_quizzes", JSON.stringify(existingQuizzes));
    return quizId;
  } catch (error) {
    console.error("Error saving quiz:", error);
    return null;
  }
}

/**
 * @returns {string|null} the quiz's id, or null on failure — same
 *   `lastError` convention as saveToUserQuizzes (see its doc comment).
 */
function updateInUserQuizzes(quizId, quizToSave) {
  try {
    const existingQuizzes = JSON.parse(
      localStorage.getItem("user_quizzes") || "[]",
    );
    const quizIndex = existingQuizzes.findIndex((q) => q.id === quizId);
    if (quizIndex === -1) return null;
    const existing = existingQuizzes[quizIndex];
    const title = quizToSave.title?.trim() || "Untitled";

    if (
      hasSameLevelCollision(existingQuizzes, {
        type: "quiz",
        title,
        parentId: existing.meta?.parentId || null,
        excludeId: quizId,
      })
    ) {
      updateInUserQuizzes.lastError =
        "يوجد امتحان بنفس الاسم في هذا المستوى من امتحاناتك بالفعل.";
      return null;
    }

    const payload = buildQuizPayload(
      quizToSave,
      quizId,
      existing.meta?.createdAt || existing.createdAt,
    );
    existingQuizzes[quizIndex] = { ...existing, ...payload, id: quizId };
    localStorage.setItem("user_quizzes", JSON.stringify(existingQuizzes));
    return quizId;
  } catch (error) {
    console.error("Error updating quiz:", error);
    return null;
  }
}

// ============================================================================
// EXPORT QUIZ
// ============================================================================

window.exportQuiz = function () {
  const errors = validateQuiz();
  if (errors.length > 0) {
    showNotification(
      "خطأ في التحقق",
      "الرجاء إصلاح الأخطاء التالية:\n\n" + errors.join("\n"),
      "error",
    );
    return;
  }

  const config = {
    title: quizData.title,
    description: quizData.description,
    source: quizData.source,
  };
  const exportQuestions = quizData.questions.map((q) => {
    const out = { q: q.q };
    // Essay question: has 1 option (legacy) or has `answer` field → export as { q, answer }
    if (Array.isArray(q.options) && q.options.length === 1) {
      out.answer = q.options[0] || "";
    } else if (!Array.isArray(q.options) || q.options.length === 0) {
      out.answer = q.answer || "";
    } else {
      out.options = q.options;
      if (q.correct !== undefined && q.correct !== null) {
        out.correct = Array.isArray(q.correct)
          ? q.correct
          : typeof q.correct === "number"
            ? [q.correct]
            : [];
      }
      if (q.multiSelect !== undefined) out.multiSelect = Boolean(q.multiSelect);
    }
    if (q.explanation?.trim()) out.explanation = q.explanation;
    return out;
  });

  // Builds the JSON export meta (password/view/mode) from the current form
  // state. Shared by the download and copy paths so both stay in sync.
  const buildJsonExportMeta = () => {
    const exportMeta = {
      title: quizData.title,
      description: quizData.description,
      source: quizData.source,
    };

    const pwd = document.getElementById("quizPassword")?.value?.trim();
    if (pwd) {
      exportMeta.password = pwd;
    } else {
      delete exportMeta.password;
    }
    delete exportMeta.privacy;
    delete exportMeta.lang;

    const viewVal = document.querySelector(
      'input[name="quizView"]:checked',
    )?.value;
    if (viewVal && viewVal !== "empty") exportMeta.view = viewVal;
    const modeVal = document.querySelector(
      'input[name="quizMode"]:checked',
    )?.value;
    if (modeVal && modeVal !== "empty") exportMeta.mode = modeVal;

    return exportMeta;
  };

  const buildJsonPayloadString = async () => {
    const exportMeta = buildJsonExportMeta();
    const payload = await buildJsonQuizExport(
      exportMeta.title,
      exportMeta.description,
      exportMeta.source,
      exportQuestions,
    );
    Object.assign(payload.meta, exportMeta);
    return JSON.stringify(payload, null, 2);
  };

  const safeFilename = (quizData.title || "quiz")
    .replace(/[^a-zA-Z0-9\u0600-\u06FF]/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_|_$/g, "");

  // Shared modal (also used on the homepage's "My Quizzes" download popup —
  // see showDownloadModal() in
  // ../../components/download-quiz-modal/download-quiz-modal.js).
  // buildJsonPayloadString is passed through so the JSON export-quiz/copy still
  // carries the current password/view/mode form state.
  showDownloadModal({
    config,
    questions: exportQuestions,
    buildJsonPayloadString,
    filenameBase: safeFilename || "quiz",
  });
};

// ============================================================================
// SAVE LOCALLY
// ============================================================================

window.saveLocally = function () {
  const errors = validateQuiz();

  if (errors.length > 0) {
    showNotification(
      "خطأ في التحقق",
      "الرجاء إصلاح الأخطاء التالية:\n\n" + errors.join("\n"),
      "error",
    );
    return;
  }

  // Editing a shared/admin quiz (?id=<dbId>&mode=edit) — bypass the
  // user_quizzes localStorage branch entirely and post to the server
  // instead. Same "ملف > حفظ محليًا" menu item and Ctrl+S shortcut trigger
  // this (its label is swapped to "حفظ التعديلات" by
  // updateSaveMenuOptionForSharedEdit() when this mode is active), so
  // there's still exactly one save entry point rather than two competing
  // ones.
  if (sharedEditDbId) {
    saveSharedQuizEdit();
    return;
  }

  showLoading("يُحفظ..");

  setTimeout(() => {
    let quizId;
    if (editingQuizId) {
      quizId = updateInUserQuizzes(editingQuizId, quizData);
    } else {
      // New quiz (possibly from a draft) — save as a real published entry
      quizId = saveToUserQuizzes(quizData);
      // Promote: remove the draft entry that was tracking this work-in-progress
      if (currentDraftId) {
        removeEditorDraft(currentDraftId);
        currentDraftId = null;
      }
      editingQuizId = quizId;
    }
    hideLoading();

    if (quizId) {
      showNotification(
        "تم الحفظ!",
        'يمكنك العثور عليه في "امتحاناتك"',
        "success",
      );
      if (editingQuizId) {
        setTimeout(() => {
          editingQuizId = null;
          currentDraftId = null;
          showEntryScreen();
        }, 1000);
      }
    } else {
      showNotification(
        "خطأ",
        saveToUserQuizzes.lastError || updateInUserQuizzes.lastError || "فشل حفظ الامتحان",
        "error",
      );
      saveToUserQuizzes.lastError = null;
      updateInUserQuizzes.lastError = null;
    }
  }, 500);
};

/**
 * Posts the current form state to POST /api/admin?action=update-quiz for a
 * shared/admin quiz being edited (?id=<dbId>&mode=edit). Mirrors
 * saveLocally()'s local branch in spirit (same validateQuiz() gate already
 * run by the caller, same buildQuizPayload() shape, same loading/
 * notification UX) but posts to the server instead of writing to
 * localStorage, and requires an admin bearer token the way every other
 * write in this codebase to a shared/admin-owned row does (adminUpload.js's
 * authHeaders() pattern, reused here rather than duplicated).
 *
 * Password handling: the "كلمة المرور" field always starts blank on a
 * shared-quiz edit (see loadSharedQuizForEdit's header comment — the
 * existing hash is never sent to the client), so a blank field here must
 * NOT be read as "remove the password" the way it is on the local-save
 * path (buildQuizPayload deletes meta.password when blank, which is fine
 * for user_quizzes since there's no server-side password concept there).
 * clearPasswordCheckbox — added next to the password field specifically
 * for this mode, see create-quiz.html — is how "remove it" gets said
 * explicitly instead. Leaving the field blank with the checkbox unchecked
 * always means "leave the current password as-is."
 */
async function saveSharedQuizEdit() {
  showLoading("يُحفظ التعديلات..");

  try {
    const token = getToken();
    if (!token) {
      hideLoading();
      showNotification(
        "انتهت الجلسة",
        "يرجى تسجيل الدخول كمشرف مجددًا قبل الحفظ.",
        "error",
      );
      return;
    }

    // buildQuizPayload's 2nd arg (quizId) isn't actually read inside the
    // function — it's only relevant to saveToUserQuizzes' caller, which
    // spreads it alongside the result. Passed here anyway for readability
    // at the call site; meta.createdAt/path/author_id all get overwritten
    // or ignored server-side in handleUpdateQuiz regardless (see its
    // header comment in api/admin.js).
    const payload = buildQuizPayload(quizData, sharedEditDbId);
    // buildQuizPayload() always stamps meta.updatedAt for the local
    // user_quizzes save path (entry screen's "recent items" sort/relative-
    // date label reads it — see that function's comment). The server has no
    // such concept and api/_validateQuiz.js's meta-key whitelist doesn't
    // include it, so posting it as-is 400s with
    // INVALID_META_KEY: "updatedAt" is not permitted in meta. Strip it here
    // rather than adding it to the server's whitelist, since it's genuinely
    // meaningless server-side (the row already has its own updated_at).
    delete payload.meta.updatedAt;
    const clearPassword = Boolean(
      document.getElementById("quizPasswordClear")?.checked,
    );
    // buildQuizPayload() already drops meta.password when the field is
    // blank (see its own logic) — that's exactly the "leave unchanged"
    // case here too, so no extra handling is needed beyond passing the
    // explicit clearPassword flag alongside it.

    const res = await fetch("/api/admin", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        action: "update-quiz",
        id: sharedEditDbId,
        quiz: payload,
        clearPassword,
      }),
    });

    let body = {};
    try {
      body = await res.json();
    } catch (_) { }

    hideLoading();

    if (!res.ok) {
      showNotification("خطأ", body.error || "فشل حفظ التعديلات", "error");
      return;
    }

    showNotification("تم الحفظ!", "تم حفظ تعديلات الامتحان بنجاح", "success");
    setTimeout(() => {
      sharedEditDbId = null;
      showEntryScreen();
    }, 1000);
  } catch (err) {
    hideLoading();
    console.error("Error saving shared quiz edit:", err);
    showNotification("خطأ", "تعذّر الاتصال بالخادم. حاول مجددًا.", "error");
  }
}

// ============================================================================
// PREVIEW
// ============================================================================

/** Render one question's preview markup (question text, image, options with
 * the correct answer(s) marked, explanation). Shared by previewQuiz() (whole
 * quiz) and previewSingleQuestion() (one question from its ⋮ menu) so the
 * two stay visually identical. */
function renderQuestionPreviewHtml(q, index) {
  const isEssay = Boolean(q.answer);
  const correctSet = Array.isArray(q.correct)
    ? q.correct
    : typeof q.correct === "number"
      ? [q.correct]
      : [];

  const optionsHtml = isEssay
    ? `<div class="preview-essay-answer">${renderMarkdown(q.options?.[0] || "")}</div>`
    : `<ul class="preview-options">
          ${q.options
      .map(
        (opt, i) =>
          `<li class="${correctSet.includes(i) ? "correct" : ""}">${renderMarkdown(opt)}${correctSet.includes(i) ? " ✓" : ""}</li>`,
      )
      .join("")}
        </ul>`;

  return `
      <div class="preview-question">
        <h4 class="text-rtl">السؤال ${index + 1}: ${renderMarkdown(q.q)}</h4>
        ${optionsHtml}
        ${q.explanation ? `<div class="preview-explanation"><svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-0.125em;margin-left:4px"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg> ${renderMarkdown(q.explanation)}</div>` : ""}
      </div>
    `;
}

/** Reset #previewTitle back to its default "معاينة الامتحان" wording/icon —
 * previewSingleQuestion() temporarily overrides it, so previewQuiz() (the
 * whole-quiz preview) needs to restore it on its own open, not just rely on
 * closePreview() to do it (the modal can be reopened without an intervening
 * close if the user re-triggers it from elsewhere). */
function resetPreviewModalTitle() {
  const titleEl = document.getElementById("previewTitle");
  if (!titleEl) return;
  titleEl.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide"
                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" class="lucide lucide-eye-icon lucide-eye">
                        <path
                            d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0" />
                        <circle cx="12" cy="12" r="3" />
                    </svg> معاينة الامتحان`;
}

window.previewQuiz = function () {
  const errors = validateQuiz();

  if (errors.length > 0) {
    showNotification(
      "خطأ في التحقق",
      "الرجاء إصلاح الأخطاء التالية:\n\n" + errors.join("\n"),
      "error",
    );
    return;
  }

  const modal = document.getElementById("previewModal");
  const content = document.getElementById("previewContent");
  resetPreviewModalTitle();

  let html = `
    <div style="text-align: center; margin-bottom: 30px;">
      <h2 style="margin: 0 0 10px 0;">${escapeHtml(quizData.title)}</h2>
      ${quizData.description ? `<p style="color: var(--color-text-secondary); margin: 0;">${escapeHtml(quizData.description)}</p>` : ""}
    </div>
  `;

  quizData.questions.forEach((q, index) => {
    html += renderQuestionPreviewHtml(q, index);
  });

  content.innerHTML = html;
  modal.style.display = "flex";
};

/** Preview a single question, opened from its ⋮ dropdown menu. Reuses the
 * same #previewModal as previewQuiz() (rather than a second modal) so
 * there's only one preview look-and-feel in the app, with the title
 * swapped to "معاينة السؤال" for the duration and restored by
 * closePreview()/the next previewQuiz() call. Skips validateQuiz() — that
 * check is about the whole quiz being publishable, not about whether this
 * one question can be rendered, so an unrelated incomplete question
 * elsewhere in the quiz shouldn't block previewing this one. */
window.previewSingleQuestion = function (questionId) {
  const question = quizData.questions.find((q) => q.id === questionId);
  if (!question) return;

  const index = quizData.questions.findIndex((q) => q.id === questionId);
  const modal = document.getElementById("previewModal");
  const content = document.getElementById("previewContent");
  const titleEl = document.getElementById("previewTitle");

  if (titleEl) {
    titleEl.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" class="page-data-lucide"
                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" class="lucide lucide-eye-icon lucide-eye">
                        <path
                            d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0" />
                        <circle cx="12" cy="12" r="3" />
                    </svg> معاينة السؤال ${index + 1}`;
  }

  content.innerHTML = renderQuestionPreviewHtml(question, index);
  modal.style.display = "flex";
};

window.closePreview = function () {
  const modal = document.getElementById("previewModal");
  modal.style.display = "none";
  resetPreviewModalTitle();
};

window.updateShortcutsModal = function (show) {
  const modal = document.getElementById("shortcutsModal");
  if (!modal) return;
  modal.style.display = show ? "flex" : "none";
};

// ============================================================================
// PHASE 2: NEW UI HANDLERS
// ============================================================================

window.updateOptionCards = function (radioInput) {
  const name = radioInput.name;
  const cards = document.querySelectorAll(`input[name="${name}"]`);
  cards.forEach((card) => {
    const parent = card.closest(".option-card");
    if (parent) {
      if (card.checked) {
        parent.classList.add("selected");
      } else {
        parent.classList.remove("selected");
      }
    }
  });
};

// ============================================================================
// IMPORT QUESTIONS
// ============================================================================

window.importQuestions = function () {
  const modal = document.getElementById("importModal");
  modal.style.display = "flex";
  setupImportDropzone();
};

window.closeImportModal = function () {
  const modal = document.getElementById("importModal");
  modal.style.display = "none";
  document.getElementById("importTextarea").value = "";
  const fileInput = document.getElementById("importFileInput");
  if (fileInput) fileInput.value = "";
  const fileLabel = document.getElementById("importFileLabel");
  if (fileLabel) fileLabel.textContent = "لم يتم اختيار أي ملف";
};

function setupImportDropzone() {
  const dropzone = document.getElementById("importDropzone");
  if (!dropzone || dropzone.dataset.dropReady) return;
  dropzone.dataset.dropReady = "1";

  dropzone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropzone.classList.add("drag-active");
  });
  dropzone.addEventListener("dragleave", () =>
    dropzone.classList.remove("drag-active"),
  );
  dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropzone.classList.remove("drag-active");
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const fileInput = document.getElementById("importFileInput");
      // Can't set files directly, so read them here
      handleDroppedFiles(files);
    }
  });
}

function handleDroppedFiles(files) {
  const label = document.getElementById("importFileLabel");
  if (label) {
    label.textContent = Array.from(files)
      .map((f) => f.name)
      .join(", ");
  }
  // Store for processImport — use a module-level variable
  window._droppedImportFiles = files;
}

// ============================================================================
// SEARCH BAR TOGGLE
// ============================================================================

/**
 * Open/close the single #searchBarCollapse search field. Two triggers share
 * it: the .section-actions search icon (in-flow, scrolls with the page —
 * fine there since the button that opened it is right above it) and the
 * title bar's "إجراءات" (Actions) menu item (openQuestionSearch below),
 * whose whole point is being reachable without scrolling up first — so
 * *that* trigger pins the same bar to the viewport instead of duplicating
 * the input and forking its state/filtering logic. `pinned` controls which
 * of those two layouts is used for this particular open; closing always
 * clears the pinned state along with everything else.
 */
function setSearchBarOpen(open, { pinned = false } = {}) {
  const searchBar = document.getElementById("searchBarCollapse");
  if (!searchBar) return;
  const toggleBtn = document.getElementById("searchToggleBtn");
  const actionsBtn = document.getElementById("actionsMenuSearchBtn");

  searchBar.style.display = open ? "block" : "none";
  searchBar.classList.toggle("search-bar-fixed", open && pinned);

  [toggleBtn, actionsBtn].forEach((btn) => {
    if (!btn) return;
    btn.setAttribute("aria-expanded", String(open));
    btn.classList.toggle("active", open);
  });

  if (open) {
    const input = document.getElementById("questionSearch");
    if (input) setTimeout(() => input.focus(), 50);
  } else {
    clearSearch();
  }
}

/** .section-actions search icon — in-flow open/close (existing behavior). */
window.toggleSearchBar = function () {
  const searchBar = document.getElementById("searchBarCollapse");
  if (!searchBar) return;
  const isOpen = searchBar.style.display !== "none";
  setSearchBarOpen(!isOpen, { pinned: false });
};

/**
 * Title bar Actions-menu search item. Always opens (never toggles closed
 * from here — the menu closes itself on click, so there's no persistent
 * button state a second click could "toggle off"; closing this bar is done
 * via its own close button/Escape once open) in pinned mode, so the field
 * stays fixed under the title bar no matter how far down the page the user
 * has scrolled.
 */
window.openQuestionSearch = function () {
  setSearchBarOpen(true, { pinned: true });
};

/** Closes the search bar outright (used by the pinned bar's own close
 * button, and by Escape while it's focused/pinned — see setupEventListeners). */
window.closeQuestionSearch = function () {
  setSearchBarOpen(false);
};

window.processImport = async function () {
  const textarea = document.getElementById("importTextarea");
  const fileInput = document.getElementById("importFileInput");
  const content = textarea.value.trim();
  const files =
    window._droppedImportFiles ||
    (fileInput && fileInput.files.length > 0 ? fileInput.files : null);

  if (!content && (!files || files.length === 0)) {
    showNotification(
      "خطأ",
      "الرجاء إدخال محتوى أو اختيار ملف للاستيراد",
      "error",
    );
    return;
  }

  showLoading("جاري الاستيراد...");

  try {
    let allImportedQuestions = [];
    let savedQuizzesCount = 0;
    const multipleFiles = files && files.length > 1;

    // Process file uploads
    if (files && files.length > 0) {
      for (const file of files) {
        // Derive default title from filename
        const defaultTitle = file.name
          .replace(/\.json$/i, "")
          .replace(/[-_]/g, " ")
          .replace(/\b\w/g, (c) => c.toUpperCase());

        let parsed;
        try {
          parsed = await processQuizJsonFile(file, defaultTitle);
        } catch (err) {
          console.warn(`Could not process ${file.name}:`, err);
          showNotification(
            "تحذير",
            `تعذّر قراءة ${file.name}: ${err.message}`,
            "error",
          );
          continue;
        }

        allImportedQuestions = allImportedQuestions.concat(parsed.questions);

        // Auto-save to library only when importing multiple files
        if (multipleFiles && parsed.meta) {
          const existingQuizzes = JSON.parse(
            localStorage.getItem("user_quizzes") || "[]",
          );
          const quizId = `user_quiz_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
          existingQuizzes.push({
            id: quizId,
            title: parsed.meta.title || defaultTitle,
            description: parsed.meta.description || "",
            questions: parsed.questions,
            createdAt: new Date().toISOString(),
            author: "Imported",
          });
          localStorage.setItem("user_quizzes", JSON.stringify(existingQuizzes));
          savedQuizzesCount++;
        }

        // Apply title to current quiz if blank
        if (!quizData.title && parsed.meta) {
          quizData.title = parsed.meta.title || defaultTitle;
          quizData.description = parsed.meta.description || "";
          quizData.source = parsed.meta.source || "";
          const titleEl = document.getElementById("quizTitle");
          const descEl = document.getElementById("quizDescription");
          const sourceInput = document.getElementById("quizSource");
          if (titleEl) {
            titleEl.value = quizData.title;
            updateCharCount("titleCharCount", quizData.title.length, 100);
          }
          if (descEl) {
            descEl.value = quizData.description;
            updateCharCount("descCharCount", quizData.description.length, 500);
            autoResizeMdSource(descEl);
          }
          if (sourceInput) {
            sourceInput.value = quizData.source;
            updateCharCount("sourceCharCount", quizData.source.length, 250);
          }
        }
      }
      // Clear dropped files
      window._droppedImportFiles = null;
    }

    // Process pasted content
    if (content) {
      let parsed;
      try {
        parsed = parseQuizJson(content);
      } catch (err) {
        showNotification("خطأ في التنسيق", err.message, "error");
        hideLoading();
        return;
      }
      allImportedQuestions = allImportedQuestions.concat(parsed.questions);
      if (!quizData.title && parsed.meta) {
        quizData.title = parsed.meta.title || "";
        quizData.description = parsed.meta.description || "";
        quizData.source = parsed.meta.source || "";
        const titleEl = document.getElementById("quizTitle");
        const descEl = document.getElementById("quizDescription");
        const sourceInput = document.getElementById("quizSource");
        if (titleEl) {
          titleEl.value = quizData.title;
          updateCharCount("titleCharCount", quizData.title.length, 100);
        }
        if (descEl) {
          descEl.value = quizData.description;
          updateCharCount("descCharCount", quizData.description.length, 500);
          autoResizeMdSource(descEl);
        }
        if (sourceInput) {
          sourceInput.value = quizData.source;
          updateCharCount("sourceCharCount", quizData.source.length, 250);
        }
      }
    }

    // Add questions to current quiz
    if (allImportedQuestions.length > 0) pushHistorySnapshot();
    allImportedQuestions.forEach((q) => {
      const questionId = ++questionIdCounter;
      let importedCorrect;
      if (Array.isArray(q.correct)) {
        importedCorrect = q.correct;
      } else if (typeof q.correct === "number" && !Number.isNaN(q.correct)) {
        importedCorrect = [q.correct];
      } else {
        importedCorrect = [];
      }
      const question = {
        id: questionId,
        q: q.q || "",
        options: q.options || ["", ""],
        correct: importedCorrect,
        // Absence (rather than false) is meaningful — see
        // normalizeCorrectField's doc comment — so only set it when the
        // imported JSON actually specifies it, preserving the
        // pre-multiSelect backward-compat fallback for imports that don't.
        ...(q.multiSelect !== undefined
          ? { multiSelect: Boolean(q.multiSelect) }
          : {}),
        explanation: q.explanation || "",
      };
      quizData.questions.push(question);
      renderQuestion(question);
    });

    updateEmptyState();
    updateProgress();
    updateStatistics();
    autosave();

    hideLoading();
    closeImportModal();

    const parts = [];
    if (allImportedQuestions.length > 0)
      parts.push(`استيراد ${allImportedQuestions.length} سؤال`);
    if (savedQuizzesCount > 0)
      parts.push(`حفظ ${savedQuizzesCount} امتحان في المكتبة`);
    showNotification("تم الاستيراد!", parts.join(" و") || "اكتمل", "success");
  } catch (error) {
    hideLoading();
    console.error("Import error:", error);
    showNotification("خطأ في الاستيراد", error.message, "error");
  }
};

// ============================================================================
// RESET PAGE
// ============================================================================

/**
 * Actually performs the reset — no confirmation dialog here, since the two
 * callers need different confirmation strategies:
 *   - window.resetPage (the manual "إعادة ضبط" button) uses the app's own
 *     async _confirm() modal.
 *   - the AI Helper's reset_quiz_page tool handler (see
 *     handleAiResetPageToolCall below) must use a synchronous
 *     window.confirm() instead — onToolCall's return value is read
 *     synchronously right after it's called (see ai-agent-chat.js), so an
 *     awaited confirmation there would let the "done" chat bubble render
 *     before the user had even answered the dialog.
 */
function resetPageData() {
  // Clear the old single-key draft (backwards compat)
  localStorage.removeItem("quiz_draft");

  quizData = {
    title: "",
    description: "",
    source: "",
    questions: [],
  };

  questionIdCounter = 0;
  editingQuizId = null;
  // Every new session gets its own draft ID so old drafts are never overwritten
  currentDraftId = _generateId("draft");
  // A reset starts a brand-new quiz — old snapshots would undo back into a
  // quiz that no longer has anything to do with what's on screen.
  resetHistory();

  const headerTitle = document.querySelector(".header h1");
  if (headerTitle) headerTitle.textContent = "إنشاء امتحان جديد";
  document.title = "إنشاء امتحان - منصة بصمجي";

  const qTitleEl = document.getElementById("quizTitle");
  if (qTitleEl) qTitleEl.value = "";
  const qSrcEl = document.getElementById("quizSource");
  if (qSrcEl) qSrcEl.value = "";
  const qDescEl = document.getElementById("quizDescription");
  if (qDescEl) {
    qDescEl.value = "";
    autoResizeMdSource(qDescEl);
  }
  document.getElementById("questionsContainer").innerHTML = "";

  updateCharCount("titleCharCount", 0, 100);
  updateCharCount("descCharCount", 0, 500);
  updateEmptyState();
  updateProgress();
  updateStatistics();
}

window.resetPage = async function () {
  if (
    !(await _confirm(
      "هل أنت متأكد من إعادة ضبط الصفحة؟ سيتم حذف جميع البيانات!",
    ))
  ) {
    return;
  }

  resetPageData();
  showNotification("تم إعادة الضبط", "تم مسح جميع البيانات", "success");
};

// ============================================================================
// AI HELPER INTEGRATION
// ============================================================================
// Mounted once from DOMContentLoaded (see bottom of setupEventListeners'
// caller below). Offers exactly two tools — edit_quiz and reset_quiz_page
// (see api/ai-agent/_tools.js) — deliberately NOT create_quiz/delete_quiz:
// there is exactly one quiz in scope on this page (the one currently in
// the form), so "create another" or "delete a different one" don't apply
// here the way they do on the home page's quiz list.

/**
 * Lightweight text snapshot of the in-progress quiz, sent as a live
 * contextPrompt (not contextSummary — that option's rendering in
 * ai-agent-chat.js is hardcoded to the home page's "list of saved
 * quizzes" shape/wording, e.g. "امتحانات المستخدم الحالية" and a
 * title/questionCount/types-per-item format; this page has exactly one
 * quiz and needs its own wording, e.g. explicitly saying when it's empty)
 * so the assistant knows what's already on the page without a tool
 * round-trip.
 *
 * @returns {string}
 */
function buildCurrentQuizContextForAI() {
  const count = quizData.questions.length;
  if (count === 0) {
    return "حالة الصفحة الآن: الصفحة فارغة تمامًا — لا يوجد عنوان ولا أي أسئلة بعد.";
  }
  const title = quizData.title?.trim() || "(بدون عنوان)";
  return `حالة الصفحة الآن: يوجد امتحان قيد الإعداد بعنوان "${title}" ويحتوي على ${count} سؤال.`;
}

/**
 * Applies an edit_quiz tool call to the live in-progress quiz. currentTitle
 * is ignored on purpose — see CREATE_QUIZ_PAGE_SYSTEM_PROMPT's note that
 * this page has only one quiz in scope, so there's nothing to disambiguate.
 *
 * Title/description are applied directly to quizData AND their visible
 * <input>/<textarea> elements — the same four-line pattern
 * processImport() already uses after a paste/file import, reused verbatim
 * so AI edits and manual imports keep the form in sync identically.
 *
 * If `questions` is present, it REPLACES the whole list (per
 * EDIT_QUIZ_TOOL's contract — the system prompt explicitly warns the model
 * to resend unchanged questions too, not just new/changed ones). The
 * replacement is rendered via the exact same clear-container-then-
 * renderQuestion-per-item loop loadQuizFromLocalStorage() already uses for
 * "load a full quiz for editing" — proven at whatever size a saved quiz
 * can already reach, so this is not a new, untested rendering path.
 * @param {{name: string, input: object}} toolCall
 * @returns {string} chat bubble text
 */
function handleAiEditQuizToolCall(toolCall) {
  const input = toolCall?.input || {};
  const hasTitle = typeof input.title === "string" && input.title.trim() !== "";
  const hasDescription = typeof input.description === "string";
  const hasQuestions = Array.isArray(input.questions) && input.questions.length > 0;

  if (!hasTitle && !hasDescription && !hasQuestions) {
    const err = new Error("edit_quiz tool call had no usable fields");
    err.userMessage = "تعذر تنفيذ التعديل: لم يتم إرسال أي بيانات صالحة.";
    throw err;
  }

  pushHistorySnapshot();

  if (hasTitle) {
    quizData.title = input.title.trim();
    const titleEl = document.getElementById("quizTitle");
    if (titleEl) {
      titleEl.value = quizData.title;
      updateCharCount("titleCharCount", quizData.title.length, 100);
    }
    // titleEl.value is a direct JS set, not a real keystroke, so it never
    // fires "input" — the event #appTitleText's own sync relies on (see
    // commitTitleEdit). Without this, every other part of the page updates
    // except the app-bar title. Call the same sync function directly.
    updateAppTitleBar();
  }

  if (hasDescription) {
    quizData.description = input.description;
    const descEl = document.getElementById("quizDescription");
    if (descEl) {
      descEl.value = quizData.description;
      updateCharCount("descCharCount", quizData.description.length, 500);
      autoResizeMdSource(descEl);
    }
  }

  if (hasQuestions) {
    const { questions, maxId } = normalizeQuestionsWithIds(input.questions);
    quizData.questions = questions;
    questionIdCounter = maxId;

    const container = document.getElementById("questionsContainer");
    if (container) container.innerHTML = "";
    quizData.questions.forEach((question) => renderQuestion(question));
  }

  updateEmptyState();
  updateProgress();
  updateStatistics();
  autosave();

  const parts = [];
  if (hasTitle) parts.push("العنوان");
  if (hasDescription) parts.push("الوصف");
  if (hasQuestions) parts.push(`${quizData.questions.length} سؤال`);

  showNotification("تم التعديل", `تم تحديث: ${parts.join("، ")}`, "success");
  return `✅ تم تعديل الامتحان (${parts.join("، ")})`;
}

/**
 * Applies a reset_quiz_page tool call. No second confirmation dialog here
 * — the system prompt (CREATE_QUIZ_PAGE_SYSTEM_PROMPT) already requires
 * the model to warn the user this is irreversible and get an explicit
 * "yes" in chat before ever calling this tool. A prior version added a
 * native window.confirm() on top of that, which produced a confusing
 * double confirmation (once in chat, once in a popup) for the exact same
 * decision, and — being a blocking native dialog — was also a plain
 * window.confirm() rather than the app's own in-app notification UI. The
 * chat confirmation is the single source of truth, matching how
 * handleAiEditQuizToolCall below has no extra gate either.
 * @param {{name: string, input: object}} toolCall
 * @returns {string} chat bubble text
 */
function handleAiResetPageToolCall(toolCall) {
  resetPageData();
  showNotification("تم إعادة الضبط", "تم مسح جميع البيانات", "success");
  return "🗑️ تم مسح الصفحة بالكامل.";
}

/**
 * Single entry point passed as onToolCall to createAIAgentFab — dispatches
 * by tool name, same pattern as handleQuizToolCall in user-quizzes-view.js.
 * @param {{name: string, input: object}} toolCall
 * @returns {string} chat bubble text
 */
function handleCreateQuizPageToolCall(toolCall) {
  switch (toolCall?.name) {
    case "edit_quiz":
      return handleAiEditQuizToolCall(toolCall);
    case "reset_quiz_page":
      return handleAiResetPageToolCall(toolCall);
    default: {
      const err = new Error(`Unknown tool call: ${toolCall?.name}`);
      err.userMessage = "أداة غير معروفة.";
      throw err;
    }
  }
}

/**
 * Mounts the AI Helper FAB onto the page. Called once from
 * DOMContentLoaded, after the initial quiz (draft or ?edit=) has already
 * been loaded/rendered — though since buildCurrentQuizContextForAI is
 * passed as a function (not called once here), it stays accurate for the
 * whole lifetime of the page anyway, not just at this initial mount.
 */
function mountAIHelper() {
  const container = document.querySelector(".container");
  if (!container) return;
  container.appendChild(
    createAIAgentFab({
      placeholder: "اسأل الباشــمبصمج",
      pageKey: "create",
      defaultSystemPrompt: CREATE_QUIZ_PAGE_SYSTEM_PROMPT,
      suggestedPrompts: CREATE_QUIZ_PAGE_SUGGESTED_PROMPTS,
      enableFileUpload: true,
      enableTools: true,
      toolNames: ["edit_current_quiz", "reset_quiz_page"],
      contextPrompt: buildCurrentQuizContextForAI,
      onToolCall: handleCreateQuizPageToolCall,
    }),
  );
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function showLoading(text = "جاري التحميل...") {
  const overlay = document.getElementById("loadingOverlay");
  const loadingText = document.getElementById("loadingText");
  if (overlay && loadingText) {
    loadingText.textContent = text;
    overlay.style.display = "flex";
  }
}

function hideLoading() {
  const overlay = document.getElementById("loadingOverlay");
  if (overlay) {
    overlay.style.display = "none";
  }
}