// =============================================================================
// public/src/components/ai-agent/ai-agent-suggested-prompts.js
// Default "quick prompt" chips shown above the chat input before the user
// sends their first message — one tap fills + sends that exact text. Mirrors
// ai-agent-default-prompts.js's pattern: home page is a static list, result
// page is a function since good suggestions there depend on the actual
// attempt (see buildResultSuggestedPrompts).
// =============================================================================

export const HOME_PAGE_SUGGESTED_PROMPTS = [
  "أنت تقدر تعمل إيه؟",
  "عايز اعرف امتحاناتي الحالية",
  "اعمل امتحان جديد من الملف ده",
  "شوف آخر امتحان عملته وراجع ورايا لو فيه أي أخطاء.",
];

// Create-quiz page ("إنشاء امتحان") — scoped to the single in-progress
// quiz on that page, unlike HOME_PAGE_SUGGESTED_PROMPTS above which talks
// about "your quizzes" (plural, picked from a list).
export const CREATE_QUIZ_PAGE_SUGGESTED_PROMPTS = [
  "أضف سؤال جديد عن نفس الموضوع",
  "حوّل هذا الملف لأسئلة اختيار من متعدد",
  "راجع الأسئلة الحالية وقولي لو فيه أي غلط",
];

// Notebook page ("دفتر الأكواد") — about the open notebook's cells, outputs and challenges.
export const NOTEBOOK_PAGE_SUGGESTED_PROMPTS = [
  "لخّص لي هذا الدفتر في نقاط بسيطة",
  "اشرح لي الخلية الحالية سطرًا بسطر",
  "شغّل الخلايا وقولي لو فيه أي خطأ وأصلحه",
  "أضف تحديًا برمجيًا في آخر الدفتر",
  "أعطني تلميحًا للتحدي من غير ما تكشف الحل",
];

export const LESSON_PAGE_SUGGESTED_PROMPTS = [
  "لخّص لي هذا الدرس في نقاط بسيطة",
  "اشرح لي أصعب فكرة في هذا الدرس بمثال",
  "اقترح أسئلة تدريبية عن هذا الدرس",
  "أنشئ لي امتحانًا تفاعليًا من هذا الدرس",
];

export const CREATE_LESSON_PAGE_SUGGESTED_PROMPTS = [
  "اقترح سؤال اختيار من متعدد لهذا الدرس",
  "أضف سؤالًا مقاليًا مع إجابة نموذجية",
  "اقترح سؤالًا بإجابات متعددة",
];

/**
 * @param {object} summary - same shape as resultSummaryForAI in result.js
 * @returns {string[]}
 */
export function buildResultSuggestedPrompts(summary) {
  const prompts = ["إيه هي أخطائي؟", "اركز على إيه في المذاكرة عشان أحسن من مستوايا؟"];

  if (Array.isArray(summary?.questions) && summary.questions.length) {
    prompts.push("اشرحلي أول سؤال غلطت فيه");
  }
  if (typeof summary?.percentage === "number" && summary.percentage < 50) {
    prompts.push("أنا مذاكر صح ولا لأ؟");
  }

  return prompts;
}
