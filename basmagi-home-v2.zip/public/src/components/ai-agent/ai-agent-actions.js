// =============================================================================
// public/src/components/ai-agent/ai-agent-actions.js
// Modular Actions (Slash Commands) system & Registry for AI Helper.
//
// Provides:
//   1. Action Registry: Allows pages or plugins to register their own
//      slash command actions (plugin/registry pattern), with zero hardcoded
//      page knowledge in the agent core.
//   2. Built-in defaults: Sensible page-specific action sets for home,
//      create-quiz, create-lesson, lesson view, and result pages.
//   3. Slash Command Dropdown Menu (createSlashMenu): Renders an anchored
//      popover when user types `/`, supporting keyboard navigation,
//      fuzzy/substring filtering, and auto-insertion into the textarea.
//   4. Direct Execution Directives: Explicit slash commands instruct the AI
//      to execute tools immediately with NO confirmation step.
// =============================================================================

// Standard SVG icons for actions
const ICON_QUIZ = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`;
const ICON_NOTEBOOK = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="m8 10 3 2-3 2"/><path d="M13 15h3"/></svg>`;
const ICON_FOLDER = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg>`;
const ICON_COURSE = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`;
const ICON_QUESTION = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>`;
const ICON_SPARKLE = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>`;
const ICON_TRASH = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>`;
const ICON_ANALYZE = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>`;
const ICON_LESSON = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>`;
const ICON_SECTION = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h16"/><path d="M4 12h10"/><path d="M4 19h7"/><path d="M19 14v6"/><path d="M16 17h6"/></svg>`;

// Registry maps
const pageActionsRegistry = new Map();
const patternActionsRegistry = [];

/**
 * Registers an array of actions for a given pageKey or pattern matcher.
 * @param {string|((key: string) => boolean)|RegExp} pageKeyOrMatcher
 * @param {Array<object>} actions
 */
export function registerPageActions(pageKeyOrMatcher, actions) {
    if (typeof pageKeyOrMatcher === "function" || pageKeyOrMatcher instanceof RegExp) {
        patternActionsRegistry.push({ matcher: pageKeyOrMatcher, actions });
    } else {
        pageActionsRegistry.set(pageKeyOrMatcher, actions);
    }
}

/**
 * Unregisters actions for a given pageKey or pattern matcher.
 * @param {string|((key: string) => boolean)|RegExp} pageKeyOrMatcher
 */
export function unregisterPageActions(pageKeyOrMatcher) {
    if (typeof pageKeyOrMatcher === "function" || pageKeyOrMatcher instanceof RegExp) {
        const idx = patternActionsRegistry.findIndex((p) => p.matcher === pageKeyOrMatcher);
        if (idx !== -1) patternActionsRegistry.splice(idx, 1);
    } else {
        pageActionsRegistry.delete(pageKeyOrMatcher);
    }
}

/**
 * Retrieves the registered actions for a given pageKey.
 * Checks instanceActions first, then exact pageKey, then pattern matchers.
 * @param {string} pageKey
 * @param {Array<object>} [instanceActions]
 * @returns {Array<object>}
 */
export function getPageActions(pageKey, instanceActions = null) {
    if (Array.isArray(instanceActions)) {
        return instanceActions;
    }
    const key = pageKey || "default";
    if (pageActionsRegistry.has(key)) {
        return pageActionsRegistry.get(key) || [];
    }
    for (const entry of patternActionsRegistry) {
        if (typeof entry.matcher === "function" && entry.matcher(key)) {
            return entry.actions || [];
        }
        if (entry.matcher instanceof RegExp && entry.matcher.test(key)) {
            return entry.actions || [];
        }
    }
    return [];
}

// ── Built-in Standard Action Sets ─────────────────────────────────────────────

// Home page actions ("امتحاناتك")
const HOME_PAGE_ACTIONS = [
    {
        id: "create-lesson",
        command: "create-lesson",
        label: "إنشاء درس",
        description: "إنشاء درس جديد بأقسام ومحتوى تعليمي وحفظه في «امتحاناتك»",
        icon: ICON_LESSON,
        systemDirective: "The user explicitly invoked /create-lesson. Prepare a lesson with a title, description, ordered sections, Markdown blocks, and suitable embedded interactive MCQ or essay questions. Use zero-based correctIndex/correctIndexes, multiSelect for multiple answers, explanations for MCQs, and a complete modelAnswer for essays. Call create_lesson immediately to save it in the user's library without confirmation.",
        placeholder: "موضوع الدرس ومستوى التفصيل المطلوب...",
    },
    {
        id: "create-quiz",
        command: "create-quiz",
        label: "إنشاء امتحان",
        description: "إنشاء امتحان جديد وحفظه مباشرة في قسم «امتحاناتك»",
        icon: ICON_QUIZ,
        systemDirective: "المستخدم يطلب إنشاء امتحان جديد بشكل صريح عبر أمر /create-quiz. نفّذ الإجراء مباشرة فوراً واستدعِ أداة create_quiz لحفظه في قسم «امتحاناتك» دون طلب أي تأكيد مسبق.",
        placeholder: "اكتب موضوع الامتحان وعدد الأسئلة...",
    },
    {
        id: "create-notebook",
        command: "create-notebook",
        label: "إنشاء دفتر",
        description: "إنشاء دفتر كود وملاحظات برمجية تفاعلي وحفظه في «امتحاناتك»",
        icon: ICON_NOTEBOOK,
        systemDirective: "المستخدم يطلب إنشاء دفتر ملاحظات برمجية تفاعلي (Notebook) صراحة عبر أمر /create-notebook. جهّز محتوى الدفتر أو خلايا الكود والشرح ونفّذ الإجراء دون طلب تأكيد مسبق.",
        placeholder: "موضوع الدفتر، لغة البرمجة، والملاحظات المطلوبة...",
    },
    {
        id: "create-folder",
        command: "create-folder",
        label: "إنشاء مجلد",
        description: "إنشاء مجلد جديد لتنظيم وترتيب امتحاناتك",
        icon: ICON_FOLDER,
        systemDirective: "المستخدم يطلب إنشاء مجلد جديد صراحة عبر أمر /create-folder. استدعِ أداة create_folder فوراً دون طلب تأكيد.",
        placeholder: "اسم المجلد ومكانه...",
    },
    {
        id: "create-course",
        command: "create-course",
        label: "إنشاء مادة",
        description: "إنشاء مادة دراسية جديدة (كورس) في المستوى الأعلى",
        icon: ICON_COURSE,
        systemDirective: "المستخدم يطلب إنشاء مادة جديدة صراحة عبر أمر /create-course. استدعِ أداة create_course فوراً دون طلب تأكيد.",
        placeholder: "اسم المادة الدراسية...",
    },
];

// Create Quiz page actions ("إنشاء امتحان")
const CREATE_QUIZ_PAGE_ACTIONS = [
    {
        id: "generate-quiz",
        command: "generate-quiz",
        label: "توليد امتحان",
        description: "توليد محتوى الامتحان وتعبئته مباشرة في النموذج الحالي",
        icon: ICON_SPARKLE,
        systemDirective: "المستخدم يطلب توليد أو استبدال أسئلة الامتحان الحالي صراحة عبر أمر /generate-quiz. استدعِ أداة edit_current_quiz فوراً وضع الأسئلة الجديدة في النموذج دون طلب تأكيد.",
        placeholder: "موضوع الامتحان، عدد الأسئلة، ونوعها...",
    },
    {
        id: "add-questions",
        command: "add-questions",
        label: "إضافة أسئلة",
        description: "إضافة أسئلة جديدة إلى الامتحان الحالي مع الإبقاء على الأسئلة السابقة",
        icon: ICON_QUESTION,
        systemDirective: "المستخدم يطلب إضافة أسئلة جديدة للامتحان الحالي عبر أمر /add-questions. استدعِ أداة edit_current_quiz مع الاحتفاظ بكافة الأسئلة الحالية وإضافة الأسئلة الجديدة دون طلب تأكيد.",
        placeholder: "اكتب الأسئلة المراد إضافتها أو موضوعها...",
    },
    {
        id: "clear-quiz",
        command: "clear-quiz",
        label: "مسح النموذج",
        description: "مسح كافة حقول وأسئلة النموذج الحالي وإعادة ضبط الصفحة",
        icon: ICON_TRASH,
        systemDirective: "المستخدم يطلب مسح الصفحة بالكامل صراحة عبر أمر /clear-quiz. استدعِ أداة reset_quiz_page فوراً دون طلب تأكيد.",
    },
];

// Lesson Reader page actions ("صفحة الدرس")
const LESSON_PAGE_ACTIONS = [
    {
        id: "create-quiz",
        command: "create-quiz",
        label: "إنشاء تدريب من الدرس",
        description: "إنشاء تدريب تفاعلي مؤقت من محتوى هذا الدرس كاملاً، يظهر داخل الصفحة فقط",
        icon: ICON_QUIZ,
        systemDirective: "المستخدم يطلب إنشاء تدريب تفاعلي مؤقت من محتوى هذا الدرس صراحة عبر أمر /create-quiz. استخرج الأسئلة من الدرس كاملاً واستدعِ أداة create_quiz فوراً لعرض التدريب داخل صفحة الدرس. هذا التدريب مؤقت ولا يُحفظ في «امتحاناتك» ولا يظهر فيها أبداً — دون طلب تأكيد.",
        placeholder: "عدد الأسئلة أو الأقسام المراد التركيز عليها...",
    },
    {
        id: "create-quiz-section",
        command: "create-quiz-section",
        label: "تدريب من القسم الحالي فقط",
        description: "إنشاء تدريب تفاعلي مؤقت يغطي القسم الذي يقرأه المستخدم الآن فقط، لا الدرس كاملاً",
        icon: ICON_QUIZ,
        systemDirective: "المستخدم يطلب إنشاء تدريب تفاعلي مؤقت من القسم الحالي فقط (وليس الدرس كاملاً) عبر أمر /create-quiz-section. استخدم القسم الحالي المُشار إليه في سياق الصفحة فقط كمصدر للأسئلة، واستدعِ أداة create_quiz فوراً لعرض التدريب داخل صفحة الدرس دون طلب تأكيد. هذا التدريب مؤقت ولا يُحفظ في «امتحاناتك».",
        placeholder: "عدد الأسئلة المطلوبة من هذا القسم...",
    },
    {
        id: "explain",
        command: "explain",
        label: "شرح وتبسيط",
        description: "شرح تفصيلي ومبسط لأهم نقاط ومفاهيم هذا الدرس",
        icon: ICON_LESSON,
        systemDirective: "المستخدم يطلب شرحاً وتبسيطاً للدرس عبر أمر /explain. قدّم شرحاً تعليمياً ممتعاً ومبسطاً.",
        placeholder: "أي مفهوم تريد شرحه بالتحديد؟...",
    },
    {
        id: "simplify-section",
        command: "simplify",
        label: "بسّط القسم الحالي",
        description: "إعادة صياغة القسم الذي يقرأه المستخدم الآن بأسلوب أبسط",
        icon: ICON_LESSON,
        systemDirective: "المستخدم يطلب تبسيط القسم الحالي عبر أمر /simplify. أعد صياغة أفكار القسم الحالي فقط (المُشار إليه في سياق الصفحة) بلغة أبسط وأمثلة أوضح، دون اختصار المعلومات المهمة.",
        placeholder: "أي جزء بالتحديد تريد تبسيطه؟...",
    },
    {
        id: "flashcards",
        command: "flashcards",
        label: "بطاقات مراجعة",
        description: "توليد بطاقات مراجعة (سؤال/جواب) من أهم أفكار هذا الدرس — للمذاكرة فقط، لا تُحفظ",
        icon: ICON_SPARKLE,
        systemDirective: "المستخدم يطلب بطاقات مراجعة تفاعلية من هذا الدرس عبر أمر /flashcards. استخرج أهم المفاهيم من محتوى الدرس الحالي، ثم استدعِ أداة create_flashcards فوراً مع 6 إلى 12 زوجاً واضحاً من السؤال والإجابة (أو العدد الذي حدده المستخدم). لا تكتب البطاقات كنص عادي ولا تطلب تأكيداً؛ ستُعرض كبطاقات قابلة للقلب داخل المحادثة، ولا تُحفظ كاختبار.",
        placeholder: "عدد البطاقات أو الموضوع المطلوب التركيز عليه...",
    },
    {
        id: "summarize-full-lesson",
        command: "summarize",
        label: "تلخيص الدرس كامل",
        description: "ملخص شامل ومركز لكل أقسام الدرس",
        icon: ICON_LESSON,
        systemDirective: "المستخدم يطلب تلخيصاً شاملاً للدرس كاملاً عبر أمر /summarize. لخّص كل الأقسام بشكل مركز ومرتب، وليس قسماً واحداً فقط.",
    },
    {
        id: "practice-weak-topic",
        command: "practice",
        label: "تدريب على نقطة محددة",
        description: "أسئلة تدريبية نصية (غير تفاعلية) على مفهوم معين يشعر المستخدم بالضعف فيه",
        icon: ICON_QUESTION,
        systemDirective: "المستخدم يطلب أسئلة تدريبية إضافية على مفهوم معين يشعر بالضعف فيه عبر أمر /practice. اكتب أسئلة نصية (وليس عبر أداة create_quiz) تركز على النقطة التي يذكرها المستخدم، مع ذكر الإجابة الصحيحة وسبب صحتها لكل سؤال.",
        placeholder: "ما هي النقطة أو المفهوم الذي تريد التدرب عليه؟...",
    },
];

// Create Lesson page actions ("محرر الدروس")
const CREATE_LESSON_PAGE_ACTIONS = [
    {
        id: "create-lesson",
        command: "create-lesson",
        label: "إنشاء محتوى الدرس",
        description: "إنشاء عنوان الدرس وأقسامه ومحتواها في المحرر الحالي",
        icon: ICON_LESSON,
        systemDirective: "The user explicitly invoked /create-lesson. Create a title, description, ordered sections with Markdown blocks, and suitable embedded interactive MCQ or essay questions. Use zero-based correctIndex/correctIndexes, multiSelect for multiple answers, MCQ explanations, and a complete modelAnswer for essays. Call create_lesson immediately to fill the current editor without confirmation.",
        placeholder: "موضوع الدرس ومستوى التفصيل المطلوب...",
    },
    {
        id: "add-section",
        command: "add-section",
        label: "إضافة قسم",
        description: "إضافة قسم جديد ومحتوى تعليمي إلى الدرس الحالي",
        icon: ICON_SECTION,
        systemDirective: "المستخدم يطلب إضافة قسم صراحة عبر أمر /add-section. أنشئ عنوان القسم ومحتواه، ثم استدعِ أداة add_lesson_section فوراً دون طلب تأكيد.",
        placeholder: "عنوان القسم ومحتواه...",
    },
    {
        id: "add-question",
        command: "add-question",
        label: "إضافة سؤال للدرس",
        description: "صياغة وإدراج سؤال تفاعلي جديد في الدرس الحالي",
        icon: ICON_QUESTION,
        systemDirective: "المستخدم يطلب إضافة سؤال تفاعلي للدرس صراحة عبر أمر /add-question. استدعِ أداة add_lesson_question فوراً لإدراج السؤال في الدرس دون طلب تأكيد.",
        placeholder: "اكتب صيغة السؤال أو فكرته وقسمه...",
    },
    {
        id: "summarize-lesson",
        command: "summarize-lesson",
        label: "تلخيص الدرس",
        description: "توليد ملخص مركز وشامل لنقاط وأقسام الدرس",
        icon: ICON_LESSON,
        systemDirective: "المستخدم يطلب تلخيص الدرس عبر أمر /summarize-lesson. قدّم تلخيصاً واضحاً لأقسام الدرس.",
    },
];

// Notebook page actions ("دفتر الأكواد")
const NOTEBOOK_PAGE_ACTIONS = [
    {
        id: "add-cell",
        command: "add-cell",
        label: "إضافة خلية",
        description: "إضافة خلية كود أو شرح جديدة إلى الدفتر",
        icon: ICON_NOTEBOOK,
        systemDirective: "The user explicitly invoked /add-cell. Write the cell (markdown explanation or runnable code in the notebook's language) and call notebook_add_cell immediately without asking for confirmation.",
        placeholder: "ماذا تريد أن تضيف؟ (مثلاً: خلية كود لحساب المتوسط)",
    },
    {
        id: "edit-cell",
        command: "edit-cell",
        label: "تعديل خلية",
        description: "تعديل خلية موجودة (تحسين، تبسيط، إعادة صياغة)",
        icon: ICON_SECTION,
        systemDirective: "The user explicitly invoked /edit-cell. Identify the cell from the request (by number or content), then call notebook_edit_cell immediately with the COMPLETE new source, without asking for confirmation.",
        placeholder: "رقم الخلية وما تريد تعديله...",
    },
    {
        id: "delete-cell",
        command: "delete-cell",
        label: "حذف خلية",
        description: "حذف خلية من الدفتر",
        icon: ICON_TRASH,
        systemDirective: "The user explicitly invoked /delete-cell. If they named a cell number, call notebook_delete_cell immediately. If they did not name one, ask which cell number to delete and do not call the tool.",
        placeholder: "رقم الخلية التي تريد حذفها...",
    },
    {
        id: "fix-error",
        command: "fix-error",
        label: "إصلاح الأخطاء",
        description: "تشخيص خطأ في الخلايا وإصلاحه ثم إعادة تشغيله",
        icon: ICON_ANALYZE,
        systemDirective: "The user explicitly invoked /fix-error. Find the cell whose output has errors (or the cell they name), explain the cause briefly, fix it with notebook_edit_cell, then verify it with notebook_run_cell. Do not ask for confirmation.",
        placeholder: "اختياري: رقم الخلية أو وصف المشكلة...",
    },
    {
        id: "add-challenge",
        command: "add-challenge",
        label: "إضافة تحدٍّ برمجي",
        description: "خلية تحدٍّ تُقيَّم على الناتج المطبوع فقط",
        icon: ICON_QUESTION,
        systemDirective: "The user explicitly invoked /add-challenge. Add a markdown cell with the task statement followed by a code cell with starter code and a challenge object (expectedOutput traced from your model solution, matchMode, hint, solution; testStdin for C++ input). Call notebook_add_cell for each cell immediately, then verify the solution's output against expectedOutput if you can run it.",
        placeholder: "موضوع التحدي ومستواه...",
    },
    {
        id: "explain-notebook",
        command: "explain-notebook",
        label: "شرح وتلخيص الدفتر",
        description: "تلخيص الدفتر وشرح فكرته وخلاياه",
        icon: ICON_LESSON,
        systemDirective: "The user invoked /explain-notebook. Summarize what the notebook teaches and walk through its cells in order, briefly. Do not modify the notebook.",
    },
];

// Result page actions ("صفحة النتيجة")
const RESULT_PAGE_ACTIONS = [
    {
        id: "analyze-result",
        command: "analyze-result",
        label: "تحليل النتيجة",
        description: "تحليل تفصيلي لأدائك في الامتحان وتحديد مواطن القوة والضعف",
        icon: ICON_ANALYZE,
        systemDirective: "المستخدم يطلب تحليلاً تفصيلياً لنتيجته عبر أمر /analyze-result. حلل الأداء وقدم تقييماً شاملاً.",
    },
    {
        id: "recommendations",
        command: "recommendations",
        label: "توصيات وخطة مراجعة",
        description: "اقتراح خطة مراجعة مخصصة تركز على الأسئلة الخاطئة والمتروكة",
        icon: ICON_SPARKLE,
        systemDirective: "المستخدم يطلب خطة وتوصيات عبر أمر /recommendations. قدم خطة مراجعة عملية ومباشرة.",
    },
];

// Register the defaults
registerPageActions("home", HOME_PAGE_ACTIONS);
registerPageActions("create", CREATE_QUIZ_PAGE_ACTIONS);
registerPageActions("create-lesson", CREATE_LESSON_PAGE_ACTIONS);
registerPageActions("notebook", NOTEBOOK_PAGE_ACTIONS);
registerPageActions((key) => key && key.startsWith("lesson-"), LESSON_PAGE_ACTIONS);
registerPageActions("result", RESULT_PAGE_ACTIONS);

// ── Slash Dropdown Menu Component ─────────────────────────────────────────────

/**
 * Creates the slash command dropdown menu controller.
 * @param {object} options
 * @param {HTMLTextAreaElement} options.textarea
 * @param {() => Array<object>} options.getActions
 * @param {(action: object) => void} options.onPick
 * @param {(menu: HTMLElement, anchor: HTMLElement) => void} options.positionMenu
 * @returns {{open: (slashIndex: number) => void, close: () => void, isOpen: () => boolean, handleInput: () => boolean, handleKeydown: (e: KeyboardEvent) => boolean, getTriggerStart: () => number}}
 */
let slashMenuIdSequence = 0;

export function createSlashMenu(options) {
    const { textarea, getActions, onPick, positionMenu } = options;

    let menuEl = null;
    let triggerStart = -1; // index of the '/' character
    let activeIndex = -1;
    let currentActions = [];
    let menuId = "";

    function close() {
        if (!menuEl) return;
        menuEl.remove();
        menuEl = null;
        textarea.removeAttribute("aria-controls");
        textarea.removeAttribute("aria-expanded");
        textarea.removeAttribute("aria-activedescendant");
        triggerStart = -1;
        activeIndex = -1;
        currentActions = [];
        window.removeEventListener("resize", reposition);
        window.removeEventListener("scroll", reposition, true);
        document.removeEventListener("click", onOutsideClick);
        window.removeEventListener("aiw:close-popups", close);
    }

    function reposition() {
        if (menuEl) positionMenu(menuEl, textarea);
    }

    function onOutsideClick(e) {
        if (!menuEl) return;
        if (menuEl.contains(e.target) || textarea.contains(e.target)) return;
        close();
    }

    function currentRows() {
        return Array.from(menuEl?.querySelectorAll("[data-slash-row]") || []);
    }

    function setActiveIndex(index) {
        const rows = currentRows();
        if (rows.length === 0) return;
        activeIndex = ((index % rows.length) + rows.length) % rows.length;
        rows.forEach((row, i) => {
            row.classList.toggle("is-active", i === activeIndex);
            row.setAttribute("aria-selected", i === activeIndex ? "true" : "false");
        });
        textarea.setAttribute("aria-activedescendant", rows[activeIndex]?.id || "");
        rows[activeIndex]?.scrollIntoView({ block: "nearest" });
    }

    function buildRow(action, index) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.setAttribute("data-slash-row", "");
        btn.id = `${menuId}-option-${index}`;
        btn.setAttribute("role", "option");
        btn.setAttribute("aria-selected", index === activeIndex ? "true" : "false");
        btn.className = "ai-agent-dropdown-item ai-agent-slash-row" + (index === activeIndex ? " is-active" : "");
        btn.setAttribute("aria-label", `/${action.command} — ${action.description || action.label}`);

        const icon = document.createElement("span");
        icon.className = "ai-agent-slash-row-icon";
        icon.setAttribute("aria-hidden", "true");
        const iconTemplate = document.createElement("template");
        iconTemplate.innerHTML = action.icon || ICON_SPARKLE;
        icon.appendChild(iconTemplate.content);

        const text = document.createElement("span");
        text.className = "ai-agent-slash-row-text";
        const header = document.createElement("span");
        header.className = "ai-agent-slash-row-header";
        const title = document.createElement("span");
        title.className = "ai-agent-slash-row-title";
        title.dir = "auto";
        title.textContent = action.label || `/${action.command}`;
        const command = document.createElement("code");
        command.className = "ai-agent-slash-row-cmd";
        command.dir = "ltr";
        command.textContent = `/${action.command}`;
        header.append(title, command);
        text.appendChild(header);
        if (action.description) {
            const description = document.createElement("span");
            description.className = "ai-agent-slash-row-desc";
            description.dir = "auto";
            description.textContent = action.description;
            text.appendChild(description);
        }
        btn.append(icon, text);

        btn.addEventListener("click", (e) => {
            e.stopPropagation();
            onPick(action);
            close();
        });

        return btn;
    }

    function render(query = "") {
        if (!menuEl) return;
        menuEl.replaceChildren();

        const allActions = getActions() || [];
        const cleanQuery = (query || "").trim().toLowerCase();

        currentActions = cleanQuery
            ? allActions.filter((a) => {
                const cmd = (a.command || "").toLowerCase();
                const label = (a.label || "").toLowerCase();
                const desc = (a.description || "").toLowerCase();
                return cmd.includes(cleanQuery) || label.includes(cleanQuery) || desc.includes(cleanQuery);
            })
            : allActions;

        if (currentActions.length === 0) {
            const emptyEl = document.createElement("div");
            emptyEl.className = "ai-agent-slash-empty";
            emptyEl.setAttribute("role", "status");
            emptyEl.textContent = cleanQuery ? "لا توجد أوامر مطابقة" : "لا توجد أوامر متوفرة لهذه الصفحة";
            menuEl.appendChild(emptyEl);
            activeIndex = -1;
            textarea.removeAttribute("aria-activedescendant");
            reposition();
            return;
        }

        const sectionHeader = document.createElement("div");
        sectionHeader.className = "ai-agent-mention-section-header ai-agent-slash-section-header";
        const sectionTitle = document.createElement("span");
        sectionTitle.textContent = "الأوامر المتاحة";
        const count = document.createElement("span");
        count.className = "ai-agent-slash-count";
        count.textContent = String(currentActions.length).padStart(2, "0");
        sectionHeader.append(sectionTitle, count);
        menuEl.appendChild(sectionHeader);

        const resultsEl = document.createElement("div");
        resultsEl.className = "ai-agent-slash-results";
        resultsEl.setAttribute("role", "group");
        resultsEl.setAttribute("aria-label", "الأوامر");
        activeIndex = 0;
        currentActions.forEach((action, idx) => {
            resultsEl.appendChild(buildRow(action, idx));
        });
        menuEl.appendChild(resultsEl);
        textarea.setAttribute("aria-activedescendant", `${menuId}-option-0`);

        reposition();
    }

    function open(slashCharIndex) {
        close();
        const available = getActions();
        if (!available || available.length === 0) {
            return; // No actions for this page, don't open
        }

        triggerStart = slashCharIndex;
        menuEl = document.createElement("div");
        menuEl.className = "ai-agent-dropdown-menu ai-agent-slash-menu";
        menuId = `ai-agent-slash-list-${++slashMenuIdSequence}`;
        menuEl.id = menuId;
        menuEl.setAttribute("role", "listbox");
        menuEl.setAttribute("aria-label", "الأوامر المتاحة");
        menuEl.style.visibility = "hidden";
        document.body.appendChild(menuEl);
        textarea.setAttribute("aria-controls", menuId);
        textarea.setAttribute("aria-expanded", "true");

        render("");
        positionMenu(menuEl, textarea);
        menuEl.style.visibility = "visible";

        window.addEventListener("resize", reposition);
        window.addEventListener("scroll", reposition, true);
        document.addEventListener("click", onOutsideClick);
        window.addEventListener("aiw:close-popups", close);
    }

    function handleInput() {
        if (!menuEl) return false;
        const caret = textarea.selectionStart;

        // User erased the '/'
        if (caret <= triggerStart) {
            close();
            return false;
        }

        // Query text between '/' and caret
        const raw = textarea.value.slice(triggerStart + 1, caret);
        if (/\s/.test(raw)) {
            // Whitespace encountered — user moved on to args
            close();
            return false;
        }

        render(raw);
        return true;
    }

    function handleKeydown(e) {
        if (!menuEl) return false;

        if (e.key === "Escape") {
            close();
            return true;
        }
        if (e.key === "ArrowDown") {
            setActiveIndex(activeIndex + 1);
            return true;
        }
        if (e.key === "ArrowUp") {
            setActiveIndex(activeIndex - 1);
            return true;
        }
        if (e.key === "Enter" || e.key === "Tab") {
            if (activeIndex >= 0 && currentActions[activeIndex]) {
                onPick(currentActions[activeIndex]);
                close();
                return true;
            }
            if (currentActions.length === 0) {
                close();
                return true;
            }
        }
        return false;
    }

    return {
        open,
        close,
        isOpen: () => Boolean(menuEl),
        handleInput,
        handleKeydown,
        getTriggerStart: () => triggerStart,
    };
}
