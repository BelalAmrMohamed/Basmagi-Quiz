// ============================================================================
// public/src/features/home/category-view.js
// CATEGORY VIEW — the drilled-into category screen (subcategory + exam
// cards), the category card builder, and lazy root-category listing.
// ============================================================================

import { toSlug } from "./slug-utils.js";
import { getItemText } from "./item-text.js";
import { container, title } from "./dom-refs.js";
import {
  getNavigationStack,
  setNavigationStack,
  isRestoring,
  getSearchManager,
  getCategoryTree,
  getCategoriesCache,
  setCategoriesCache,
} from "./app-state.js";
import { updateBreadcrumb } from "./breadcrumb.js";
import { renderTitleBreadcrumb } from "./title-breadcrumb.js";
import { refreshUserQuizzesCard } from "./course-count.js";
import { isRecentlyAdded } from "./date-utils.js";
import { getSubjectIcon } from "./subject-icons.js";
import { createExamCard, createLessonCard, createNotebookCard, createFolderCard } from "./item-card.js";
import { buildContainerInfoRows } from "./info-details.js";
import { openItemDropdownMenu, createActionGroupSubmenu, createExamInfoSubmenu } from "./item-dropdown-menu.js";
import { showFolderInfoModal } from "./folder-info-modal.js";
import { userProfile } from "../../shared/userProfile.js";
import {
  canManageItem,
  openSharedMoveToDialog,
  renameSharedItem,
  deleteSharedItem,
} from "./admin-item-actions.js";
import {
  COPY_ICON_SVG,
  DUPLICATE_ICON_SVG,
  SHARE_ICON_SVG,
  SPARKLE_ICON_SVG,
  RENAME_ICON_SVG,
  MOVE_TO_ICON_SVG,
  TRASH_ICON_SVG,
} from "./icons.js";
import { copyCategoryTreeToUserQuizzes, withCopyButtonLoadingState } from "./copy-to-my-quizzes.js";
import { showNotification } from "../../components/notifications/notifications.js";
import {
  openAIAgentWithAttachment,
  buildPlatformFolderAttachment,
} from "../../components/ai-agent/ai-agent-attach-launcher.js";
import { HOME_PAGE_SYSTEM_PROMPT } from "../../components/ai-agent/ai-agent-default-prompts.js";

export function getCategoriesLazy() {
  const cached = getCategoriesCache();
  if (cached) return cached;

  const categoryTree = getCategoryTree();
  const computed = Object.values(categoryTree || {})
    .filter((cat) => !cat.parent)
    .sort((a, b) => a.name.localeCompare(b.name));
  setCategoriesCache(computed);

  return computed;
}

export function renderCategory(category) {
  try {
    const navigationStack = getNavigationStack();
    navigationStack.push(category);
    updateBreadcrumb();

    // ── Obj 4: Update the URL — real pathname segments for both the course
    // and any nested subfolders ─────────────────────────────────────────────
    // Courses cannot be nested (single-segment categoryTree key, parent ===
    // null), so a top-level course gets a real, crawlable pathname:
    //   /course/{courseSlug}
    // (courseSlug is toSlug(course.name) — dashes, not raw %20-encoded
    // spaces — matching render-course.js's slug-based fetchCourseMeta()
    // lookup.)
    //
    // Nested subfolders *within* a course now get their own real path
    // segments too (not a #hash), so each folder level is server-visible and
    // gets its own accurate OG image/title (see render-course.js's :path*
    // handling and api/og.js's ?folder= support) — a hash is never sent to
    // the server, so a crawler hitting a hash-based link could only ever see
    // the course-level page, not the specific folder that was shared:
    //   /course/{courseSlug}/{subSlug}/{subSlug2}/...
    // Each "/" segment of the categoryTree key (including the course-name
    // prefix) is passed through toSlug(). Literal hyphens in names are
    // double-encoded ("--") so they survive a round-trip; spaces become a
    // single "-".
    const categoryTree = getCategoryTree();
    const catKey = category.key || Object.keys(categoryTree || {}).find(
      (k) => categoryTree[k] === category,
    );
    if (catKey) {
      const keyParts = catKey.split("/");

      // Encode each slug segment individually (encodeURIComponent handles
      // Arabic, Cyrillic, etc.) then rejoin with "/" so the path separator
      // is preserved. "-" and "--" are ASCII and pass through
      // encodeURIComponent unchanged, so the space↔hyphen and literal-
      // hyphen↔"--" round-trip is unaffected.
      const url = "/course/" + keyParts.map((part) => encodeURIComponent(toSlug(part))).join("/");

      // ── Bug 1 Fix: record this navigation in the browser history ───────────
      // pushState so back fires popstate → restoreViewFromURL(); during popstate
      // restoration only replaceState so we don't create a phantom entry.
      try {
        if (!isRestoring()) {
          history.pushState({ view: "category", catKey }, "", url);
          if (typeof window.syncActiveNavState === "function") window.syncActiveNavState();
        } else {
          history.replaceState({ view: "category", catKey }, "", url);
          if (typeof window.syncActiveNavState === "function") window.syncActiveNavState();
        }
      } catch (pushErr) {
        // Genuine error handling (kept) — history.pushState/replaceState can
        // throw (e.g. SecurityError from too-frequent calls, or a
        // non-serializable state object), and silently swallowing that would
        // leave the URL out of sync with the rendered view.
        console.error("Failed to update URL for category navigation:", pushErr, {
          urlAttempted: url,
        });
      }
    }
    // Update search context when entering a category
    const searchManager = getSearchManager();
    if (searchManager) {
      searchManager.updateContextVisibility();
    }

    // Update the #Subjects-text pill with a smart collapsible breadcrumb.
    // Build the items array from the navigationStack (which already includes
    // the just-pushed category at the end).
    if (title) {
      // Snapshot the stack at this moment
      const stackSnapshot = [...navigationStack];
      const items = [
        // Root item — always first
        {
          label: "الرئيسية",
          icon: "🏠",
          onClick: () => {
            // Lazy import to avoid circular dependency (root-view imports category-view)
            import("./root-view.js").then((m) => m.renderRootCategories());
          },
        },
        // Intermediate + current items from the stack
        ...stackSnapshot.map((cat, idx) => ({
          label: cat.name,
          icon: cat.icon || getSubjectIcon(cat.name, idx > 0),
          onClick:
            idx < stackSnapshot.length - 1
              ? () => {
                // Navigate to this ancestor: reset the stack to the items
                // above it, then renderCategory (which pushes it again).
                setNavigationStack(stackSnapshot.slice(0, idx));
                renderCategory(stackSnapshot[idx]);
              }
              : undefined, // last = current page, non-clickable
        })),
      ];
      renderTitleBreadcrumb(title, items);
    }

    container.innerHTML = "";
    container.className = "grid-container";

    const fragment = document.createDocumentFragment();

    // Shared course/folder links open for everyone, so tell visitors who
    // aren't subscribed to this course (and let them subscribe in one tap).
    const subscribeBanner = createCourseSubscribeBanner(
      categoryTree?.[(catKey || "").split("/")[0]],
    );
    if (subscribeBanner) fragment.appendChild(subscribeBanner);

    // Render subcategories
    (category.subcategories || []).forEach((subCatKey) => {
      const subCat = categoryTree[subCatKey];
      if (subCat) {
        const stats = getCategoryContentsStats(subCat);
        const itemCount = stats.quizCount;
        const card = createCategoryCard(subCat.name, itemCount, true, subCat, true, formatCategoryContents(stats));
        card.onclick = () => renderCategory(subCat);
        fragment.appendChild(card);
      }
    });

    // Render exams
    (category.exams || []).forEach((exam) => {
      const card = createExamCard(exam);
      fragment.appendChild(card);
    });

    (category.lessons || []).forEach((lesson) => {
      fragment.appendChild(createLessonCard(lesson));
    });

    (category.notebooks || []).forEach((notebook) => {
      fragment.appendChild(createNotebookCard(notebook));
    });

    container.appendChild(fragment);

    // Show empty state if no content
    if ((category.subcategories || []).length === 0 && (category.exams || []).length === 0 && (category.lessons || []).length === 0 && (category.notebooks || []).length === 0) {
      container.innerHTML = `
        <div class="empty-state" role="status">
          <div class="empty-state-icon" aria-hidden="true">🔭</div>
          <h3>لا يوجد محتوى بعد</h3>
          <p>هذا القسم فارغ حالياً، تابعنا لمزيد من المحتوى قريباً!</p>
        </div>
      `;
    }
  } catch (error) {
    console.error("Error rendering category:", error);
    if (container) {
      container.innerHTML = `
        <div class="error-state" role="alert">
          <p>حدث خطأ أثناء تحميل المحتوى. يرجى تحديث الصفحة.</p>
          <button onclick="renderRootCategories()" type="button">الرجوع للرئيسية</button>
        </div>
      `;
    }
  }
}

/**
 * "أنت غير مشترك في هذه المادة" banner with a subscribe button. Returns null
 * when there is no course to subscribe to or the visitor is already
 * subscribed — subscribed users never see it.
 * @param {object|undefined} course - the course node (root of the tree branch)
 * @returns {HTMLElement|null}
 */
function createCourseSubscribeBanner(course) {
  if (!course?.id || userProfile.isSubscribed(course.id)) return null;

  const banner = document.createElement("div");
  banner.className = "all-courses-banner course-subscribe-banner";
  banner.setAttribute("role", "status");

  const icon = document.createElement("span");
  icon.className = "all-courses-banner-icon";
  icon.setAttribute("aria-hidden", "true");
  icon.textContent = "🔔";

  const text = document.createElement("span");
  text.className = "all-courses-banner-text";
  text.textContent = `أنت غير مشترك في هذه المادة (${course.name}). اشترك لتظهر في صفحتك الرئيسية.`;

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "course-subscribe-banner-btn";
  btn.textContent = "اشترك الآن";
  btn.onclick = () => {
    try {
      userProfile.subscribeToCourse(course.id);
      banner.remove();
      showNotification("تم الإشتراك", `تم إضافة ${course.name} إلى موادك`, "./favicon.png");
    } catch (error) {
      console.error("Error subscribing to course:", error);
      showNotification("تعذّر الإشتراك", "حدث خطأ أثناء الإشتراك. حاول مرة أخرى.", "warning");
    }
  };

  banner.append(icon, text, btn);
  return banner;
}

/** Folder card for a subcategory inside a course. */
export function createCategoryCard(name, itemCount, isFolder = false, courseData = null, isSubfolder = true, subtextOverride = null) {
  const subtext = subtextOverride || `${itemCount > 2 ? itemCount : ""} ${getItemText(itemCount)}`.trim();
  return createFolderCard({
    title: name,
    subtext,
    isNew: !!courseData && isRecentlyAdded(courseData.createdAt),
    onMore: courseData ? (btn) => openFolderMenu(btn, courseData) : null,
    onOpen: null,
  });
}

function openFolderMenu(btn, courseData) {
  openItemDropdownMenu(btn, (menu, closeMenu, reposition) => {
    // Build a shareable URL matching the real-path scheme used by
    // renderCategory(): /course/{courseSlug}/{subSlug}/{subSlug2}/...
    // (all real path segments now, not a #hash — see renderCategory()'s
    // comment for why: a hash is never sent to the server, so a shared
    // link to a nested folder needs a real path segment to get its own
    // accurate OG image.)
    const pathSegments = courseData.path || [courseData.name];
    const folderUrl = `${window.location.origin}/course/` +
      pathSegments.map((seg) => encodeURIComponent(toSlug(seg))).join("/");
    const copyLink = document.createElement("button");
    copyLink.type = "button";
    copyLink.className = "exam-action-btn";
    copyLink.innerHTML = `${COPY_ICON_SVG}<span>نسخ الرابط</span>`;
    copyLink.onclick = async (e) => {
      e.stopPropagation();
      await navigator.clipboard.writeText(folderUrl);
      closeMenu();
      showNotification("تم النسخ", "تم نسخ رابط المجلد.", "success");
    };
    menu.appendChild(copyLink);

    const shareLink = document.createElement("button");
    shareLink.type = "button";
    shareLink.className = "exam-action-btn";
    shareLink.innerHTML = `${SHARE_ICON_SVG}<span>مشاركة الرابط</span>`;
    shareLink.onclick = async (e) => {
      e.stopPropagation();
      closeMenu();
      if (navigator.share) {
        await navigator.share({ title: courseData.name, url: folderUrl }).catch(() => { });
      } else {
        await navigator.clipboard.writeText(folderUrl);
        showNotification("تم النسخ", "تم نسخ رابط المجلد.", "success");
      }
    };
    menu.appendChild(shareLink);

    const copyToMine = document.createElement("button");
    copyToMine.type = "button";
    copyToMine.className = "exam-action-btn";
    copyToMine.innerHTML = `${DUPLICATE_ICON_SVG}<span>نسخ إلى محتواي</span>`;
    copyToMine.onclick = async (e) => {
      e.stopPropagation();
      await withCopyButtonLoadingState(copyToMine, () =>
        copyCategoryTreeToUserQuizzes(courseData, getCategoryTree(), "folder"),
      );
      refreshUserQuizzesCard();
      closeMenu();
    };
    menu.appendChild(copyToMine);

    const askAi = document.createElement("button");
    askAi.type = "button";
    askAi.className = "exam-action-btn";
    askAi.innerHTML = `${SPARKLE_ICON_SVG}<span>اسأل الباشـمبصمج</span>`;
    askAi.onclick = () => {
      closeMenu();
      openAIAgentWithAttachment(buildPlatformFolderAttachment(courseData, getCategoryTree()), {
        defaultSystemPrompt: HOME_PAGE_SYSTEM_PROMPT,
      });
    };
    menu.appendChild(askAi);

    // "معلومات المجلد" — quick rows inline, "كل المعلومات" opens the
    // full folder info modal (dates, path, creator, counts).
    const folderRows = buildContainerInfoRows(getCategoryTree(), courseData);
    menu.appendChild(createExamInfoSubmenu(
      folderRows,
      () => showFolderInfoModal(courseData),
      closeMenu,
      reposition,
      "معلومات المجلد",
    ));

    // ── Admin manage group — نقل / تغيير العنوان / حذف (→ trash) ──────
    // Folders only: gated on the same canManageItem() 3-tier check as
    // quizzes (owner → creator match → scope match), grouped below the
    // public actions with a divider, collapsed into a single "إدارة"
    // submenu-trigger row. `courseData` here is the category-tree
    // folder node, which quizManifest.js now threads with the DB
    // folder id / course_id / parent_folder_id / created_by it needs.
    if (canManageItem(courseData)) {
      const divider = document.createElement("div");
      divider.className = "exam-action-divider";
      menu.appendChild(divider);

      const adminSubmenu = createActionGroupSubmenu(
        [
          {
            // نقل — shared Move-Source dialog over the DB
            // courses+folders tree.
            label: "نقل",
            icon: MOVE_TO_ICON_SVG,
            onClick: () => openSharedMoveToDialog(courseData),
          },
          {
            // تغيير العنوان.
            label: "تغيير العنوان",
            icon: RENAME_ICON_SVG,
            onClick: () => renameSharedItem(courseData),
          },
          {
            // حذف — soft-deletes the folder + its whole subtree to the
            // shared trash (one batch, fully restorable until purged).
            label: "حذف المجلد",
            icon: TRASH_ICON_SVG,
            danger: true,
            onClick: () => deleteSharedItem(courseData),
          },
        ],
        closeMenu,
        reposition,
      );
      menu.appendChild(adminSubmenu);
    }
  });
}

function getCategoryContentsStats(category) {
  const tree = getCategoryTree() || {};
  let quizCount = 0;
  let lessonCount = 0;
  let notebookCount = 0;
  let subfolderCount = 0;
  const visit = (node, isChild = false) => {
    if (!node) return;
    if (isChild) subfolderCount += 1;
    quizCount += Array.isArray(node.exams) ? node.exams.length : 0;
    lessonCount += Array.isArray(node.lessons) ? node.lessons.length : 0;
    notebookCount += Array.isArray(node.notebooks) ? node.notebooks.length : 0;
    (node.subcategories || []).forEach((key) => visit(tree[key], true));
  };
  visit(category);
  return { quizCount, lessonCount, notebookCount, subfolderCount };
}

function formatCategoryContents({ quizCount, lessonCount, notebookCount = 0, subfolderCount }) {
  const parts = [];
  if (quizCount) parts.push(`${quizCount} ${quizCount === 1 ? "امتحان" : "امتحانات"}`);
  if (lessonCount) parts.push(`${lessonCount} ${lessonCount === 1 ? "درس" : "دروس"}`);
  if (notebookCount) parts.push(`${notebookCount} ${notebookCount === 1 ? "دفتر" : "دفاتر"}`);
  if (subfolderCount) parts.push(`${subfolderCount} ${subfolderCount === 1 ? "مجلد" : "مجلدات"}`);
  return parts.join(" · ") || "لا يوجد محتوى بعد";
}