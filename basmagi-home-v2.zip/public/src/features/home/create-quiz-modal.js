// ============================================================================
// public/src/features/home/create-quiz-modal.js
// CREATE-QUIZ MODALS
// ============================================================================
// Two related flows, both reachable from the "محتواي" (My Content) view:
//   1. openPromptSelectionModal() — pick one of the three AI prompt presets
//      (see ai-prompts.js) and copy it to clipboard for use with an external AI.
//   2. openInlineCreateQuizModal() — paste text or import a file, parse it
//      into quiz JSON, and save it to localStorage. Exported so the
//      #userQuizContextMenu and create-folder-btn dropdowns
//      (user-quizzes-folders.js / user-quizzes-view.js) can offer the same
//      "إنشاء امتحان جديد" action — see docs/plans/implementation-plan.md
//      item 10. This used to also be reachable via a standalone
//      .user-create-quiz-card rendered inline in the quiz grid
//      (createInlineCreateQuizCard()); that card was removed once item 10
//      made it fully redundant (per the plan's testing notes) — this
//      function's caller was updated accordingly in user-quizzes-view.js.
//
// Both modals previously leaked a document-level Escape-key listener whenever
// closed via a button rather than Escape/overlay-click — fixed here using the
// shared wireModalDismiss() helper (see modal-utils.js).
// ============================================================================

import { parseQuizJson } from "../../shared/quiz-json.js";
import { wireModalDismiss, fadeOutAndRemove } from "./modal-utils.js";
import { UPLOAD_ICON_SVG } from "./icons.js";
import {
  General_Purpose_AI_Prompt,
  English_Specializing_Prompt,
  Math_Specializing_Prompt,
} from "./ai-prompts.js";
import { saveNewUserQuiz } from "./quiz-schema.js";
import { renderRootCategories } from "./root-view.js";
import { renderUserQuizzesView } from "./user-quizzes-view.js";
import { currentFolderId } from "./user-quizzes-folders.js";
import {
  importJsonQuizFiles,
  wireJsonFileDropZone,
} from "./quiz-file-import.js";
import { showNotification } from "../../components/notifications/notifications.js";

export function openInlineCreateQuizModal() {
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.setAttribute("role", "dialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-labelledby", "inlineCreateQuizTitle");
  overlay.style.cssText = `
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    background: rgba(0, 0, 0, 0.6);
  `;

  const modalCard = document.createElement("div");
  modalCard.className = "modal-card create-quiz-inline-modal";

  if (!document.getElementById("modal-pop-in-style")) {
    const style = document.createElement("style");
    style.id = "modal-pop-in-style";
    style.textContent = `
      @keyframes modalPopIn {
        to { transform: translateY(0); opacity: 1; }
      }
    `;
    document.head.appendChild(style);
  }

  modalCard.innerHTML = `
    <div class="create-quiz-modal__header">
      <h2 id="inlineCreateQuizTitle" class="create-quiz-modal__title">
        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-file-plus create-quiz-modal__title-icon"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M9 15h6"/><path d="M12 18v-6"/></svg>
        إنشاء امتحان جديد
      </h2>
      <button type="button" id="copyAiPromptBtn" class="create-quiz-modal__copy-prompt-btn">
        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-sparkles create-quiz-modal__copy-prompt-btn-icon"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>
        <span class="create-quiz-modal__copy-prompt-btn-label">Prompt</span>
        <span id="createQuizPromptHintArrow" class="create-quiz-modal__prompt-hint-arrow" aria-hidden="true">
        <svg xmlns="http://www.w3.org/2000/svg" width="35" height="18" viewBox="0 0 44 18" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M42 9H4"/><path d="m11 2-7 7 7 7"/></svg>
        </span>
      </button>
      <button type="button" id="inlineQuizClose" class="create-quiz-modal__close-btn" aria-label="إغلاق">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
      </button>
    </div>
    <p class="create-quiz-modal__subtitle">ألصق بيانات الامتحان بصيغة JSON، مع كتابة العنوان والوصف والمصدر داخل حقل <code>meta</code>. يمكنك نسخ برومبت جاهز من زر Prompt.</p>
    <div class="create-quiz-modal__form-group create-quiz-modal__form-group--content">
      <label for="inlineQuizContent" class="create-quiz-modal__label">محتوى الامتحان</label>
      <textarea id="inlineQuizContent" class="inline-quiz-textarea create-quiz-modal__textarea" rows="4"></textarea>
    </div>
    <div class="create-quiz-modal__actions">
      <div class="create-quiz-modal__main-actions">
        <button type="button" id="inlineQuizImport" class="inline-quiz-btn create-quiz-modal__btn create-quiz-modal__btn--import">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-upload"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>
          استيراد ملف
        </button>
        <button type="button" id="inlineQuizCreate" class="inline-quiz-btn create-quiz-modal__btn create-quiz-modal__btn--create">إنشاء  ✨</button>
      </div>
    </div>
    <input type="file" id="inlineQuizFileInput" class="create-quiz-modal__file-input" accept=".json,application/json" />
  `;

  // Set the JSON example via JS (avoids escaping a huge quoted blob inside an HTML attribute)
  const placeholderJSON = `{
  "meta": {
    "title": "امتحان النحو: أسلوب الشرط",
    "description": "تدريب على أدوات الشرط وإعراب الفعلين.",
    "source": "مذكرة النحو - الوحدة الثالثة"
  },
  "questions": [
    {
      "q": "«إنَّ مستشارِي الغدِ مُهيَّؤون لِحمْلِ الأمانةِ.»\\n\\nعند وضع الفعل (عسى) بدلاً من الحرف الناسخ (إنّ)، تصبح الجملة الصحيحة:",
      "explanation": "الفعل (عسى) من أفعال الرجاء يعمل عمل كان برفع الاسم ونصب الخبر، ويشترط في خبره أن يكون جملة فعلية فعلها مضارع ويكثر اقترانها بـ (أن). وبناءً عليه: اسم عسى مرفوع وعلامة رفعه الواو لأنه جمع مذكر سالم وحذفت النون للإضافة فيصبح (مستشارو)، والخبر المقترن بأن الناصبة يصبح الفعل المضارع بعده منصوبًا بحذف النون (أن يُهيَّؤوا).",
      "options": [
        "عسى مستشاري الغدِ أنْ يُهيَّؤوا لِحملِ الأمانةِ.",
        "عسى مستشارو الغدِ مُهيَّئين لِحملِ الأمانةِ.",
        "عسى مستشارو الغدِ أنْ يُهيَّؤوا لِحملِ الأمانةِ.",
        "عسى مستشارو الغدِ يُهيَّؤون لِحملِ الأمانةِ."
      ],
      "correct": 2
    },
    {
      "q": "«من أخلص في عمله، نال تقدير مجتمعه.»\\n\\nصُغ من الجملة السابقة أسلوب شرط مستخدمًا (مَنْ) الشرطية الجازمة، مع جعل فعل جواب الشرط مقترنًا بالفاء، واضبط الفعلين بالشكل.",
      "explanation": "عند تحويل أسلوب الشرط للمضارع الجازم، يُجزم فعل الشرط بالسكون لأنه صحيح الآخر. واقتران جواب الشرط بالفاء يستوجب وجود مسوغ (اسمية طلبية وبجامد وبما وقد وبلن وبالتنفيس)، وعند اختيار السين أو سوف يرتفع المضارع بعدها وتصبح الجملة في محل جزم.",
      "answer": "الصياغة الصحيحة للأسلوب هي:\\n**«مَنْ يُخْلِصْ في عمله، فَسَيَنَالُ تقدير مجتمعه.»** (أو: فَقَدْ يَنَالُ / فَسَوْفَ يَنَالُ)\\n\\n**ضبط الفعلين بالشكل:**\\n1. **يُخْلِصْ:** فعل مضارع مجزوم (فعل الشرط) وعلامة جزمه السكون.\\n2. **يَنَالُ:** فعل مضارع مرفوع وعلامة رفعه الضمة الظاهرة، لأن اقتران جواب الشرط بالفاء ودخول السين/سوف يمنع الجزم المباشر عن الفعل، وتصبح الجملة الفعلية بأكملها (فسينال...) في محل جزم جواب الشرط."
    }
  ]
}`;

  const inlineQuizContentEl = modalCard.querySelector("#inlineQuizContent");
  inlineQuizContentEl.placeholder = placeholderJSON;

  // Bouncing hint arrow above the Prompt button — dismiss it once the user
  // actually notices/clicks the button, so it doesn't nag indefinitely.
  const copyAiPromptBtn = modalCard.querySelector("#copyAiPromptBtn");
  const promptHintArrow = modalCard.querySelector("#createQuizPromptHintArrow");

  const dismissPromptHint = () => {
    promptHintArrow.classList.add(
      "create-quiz-modal__prompt-hint-arrow--hidden",
    );
  };

  copyAiPromptBtn.addEventListener("click", dismissPromptHint, { once: true });

  overlay.appendChild(modalCard);
  document.body.appendChild(overlay);

  const contentInput = modalCard.querySelector("#inlineQuizContent");
  const closeBtn = modalCard.querySelector("#inlineQuizClose");
  const createBtn = modalCard.querySelector("#inlineQuizCreate");
  const importBtn = modalCard.querySelector("#inlineQuizImport");
  const fileInput = modalCard.querySelector("#inlineQuizFileInput");
  const copyPromptBtn = modalCard.querySelector("#copyAiPromptBtn");

  if (copyPromptBtn) {
    copyPromptBtn.onclick = (e) => {
      e.stopPropagation();
      openPromptSelectionModal();
    };
    copyPromptBtn.onmouseover = () => {
      copyPromptBtn.style.borderColor = "var(--color-primary)";
      copyPromptBtn.style.color = "var(--color-primary)";
    };
    copyPromptBtn.onmouseout = () => {
      copyPromptBtn.style.borderColor = "var(--color-border)";
      copyPromptBtn.style.color = "var(--color-text-secondary)";
    };
  }

  importBtn.onmouseover = () => {
    importBtn.style.borderColor = "var(--color-primary)";
    importBtn.style.color = "var(--color-primary)";
  };
  importBtn.onmouseout = () => {
    importBtn.style.borderColor = "var(--color-border)";
    importBtn.style.color = "var(--color-text-primary)";
  };
  createBtn.onmouseover = () => {
    createBtn.style.transform = "translateY(-2px)";
    createBtn.style.boxShadow = "0 6px 20px rgba(220, 38, 38, 0.5)";
  };
  createBtn.onmouseout = () => {
    createBtn.style.transform = "translateY(0)";
    createBtn.style.boxShadow = "0 4px 14px rgba(220, 38, 38, 0.4)";
  };

  const close = wireModalDismiss(
    overlay,
    () => fadeOutAndRemove(overlay, modalCard),
    { dismissOnBackdrop: false },
  );

  closeBtn.onclick = close;

  importBtn.onclick = () => fileInput.click();

  // Drop JSON onto the modal card itself
  wireJsonFileDropZone(
    modalCard,
    async (files) => {
      // Multiple files / multi-quiz payloads → import straight into محتواي
      if (files.length > 1) {
        const count = await importJsonQuizFiles(files, { refresh: false });
        if (count > 0) {
          close();
          renderRootCategories();
          renderUserQuizzesView();
        }
        return;
      }

      const file = files[0];
      if (!file) return;

      try {
        const text = await file.text();
        let data;
        try {
          data = JSON.parse(text);
        } catch (e) {
          showNotification(
            "خطأ في التنسيق",
            `${file.name}: JSON غير صالح`,
            "error",
          );
          return;
        }

        // Multi-quiz file → import all and close
        if (
          Array.isArray(data) &&
          data.some((item) => item && Array.isArray(item.questions))
        ) {
          const count = await importJsonQuizFiles([file], { refresh: false });
          if (count > 0) {
            close();
            renderRootCategories();
            renderUserQuizzesView();
          }
          return;
        }

        // Single quiz → fill the form for review/edit
        contentInput.value = text;
        showNotification(
          "نجاح",
          "تم تحميل ملف JSON. تأكد من وجود عنوان داخل meta.title (أو title) قبل إنشاء الامتحان.",
          "success",
        );
      } catch (err) {
        showNotification(
          "خطأ في القراءة",
          `تعذّر قراءة ${file.name}: ${err.message}`,
          "error",
        );
      }
    },
    { activeClass: "create-quiz-inline-modal--drag-over" },
  );

  fileInput.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    importBtn.innerHTML =
      '<span class="adm-spinner" style="margin: 0; border-color: var(--color-primary); border-top-color: transparent;"></span> استخراج...';
    importBtn.disabled = true;

    try {
      const text = await file.text();
      contentInput.value = text;

      showNotification(
        "نجاح",
        "تم تحميل ملف JSON. تأكد من وجود عنوان داخل meta.title (أو title) قبل إنشاء الامتحان.",
        "success",
      );
    } catch (err) {
      console.error("Import read error:", err);
      showNotification(
        "خطأ في القراءة",
        `تعذّر قراءة ${file.name}: ${err.message}`,
        "error",
      );
    } finally {
      importBtn.innerHTML = `${UPLOAD_ICON_SVG} استيراد ملف`;
      importBtn.disabled = false;
      fileInput.value = "";
    }
  };

  createBtn.onclick = async () => {
    const content = (contentInput.value || "").trim();
    if (!content) {
      showNotification("بيانات ناقصة", "الرجاء إدخال المحتوى.", "warning", 10);
      return;
    }

    let parsed;
    try {
      parsed = parseQuizJson(content);
    } catch (err) {
      showNotification("خطأ في التنسيق", err.message, "error", 10);
      return;
    }

    if (!parsed.questions || !parsed.questions.length) {
      showNotification(
        "لا توجد أسئلة",
        "لم يتم العثور على أسئلة صالحة في المحتوى.",
        "error",
      );
      return;
    }

    const title = String(parsed.meta?.title || "").trim();
    if (!title) {
      showNotification(
        "العنوان مطلوب",
        "أضف عنوان الامتحان داخل JSON في meta.title (أو title) ثم حاول مرة أخرى.",
        "warning",
        10,
      );
      return;
    }

    // Create inside whatever folder/course the user is currently browsing
    // (currentFolderId, kept live by user-quizzes-folders.js as the user
    // navigates), not always at the "امتحاناتك" root — previously this
    // modal never passed a destination at all, so every quiz landed at
    // root regardless of where the "إنشاء اختبار" button was opened from.
    const result = saveNewUserQuiz(parsed, title, currentFolderId);
    if (result.ok === false) {
      // Same-level name clash — keep the pasted JSON available for editing.
      showNotification("الاسم مستخدم", result.reason, "warning", 10);
      return;
    }
    close();
    showNotification(
      "تم الإنشاء",
      currentFolderId
        ? "تم إنشاء الامتحان وإضافته إلى هذا المجلد"
        : 'تم إنشاء الامتحان وإضافته إلى "محتواي"',
      "success",
    );
    renderRootCategories();
    renderUserQuizzesView();
  };

  // Escape-key and overlay-click dismissal are already wired by
  // wireModalDismiss() above — no separate handlers needed here.

  setTimeout(() => {
    contentInput.focus();
  }, 50);
}

/**
 * Open a prompt selection modal to choose between different AI prompts
 * (General Purpose, English Specializing, Math Specializing)
 */
export function openPromptSelectionModal() {
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.setAttribute("role", "dialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-labelledby", "promptSelectionTitle");
  overlay.style.cssText = `
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    background: rgba(0, 0, 0, 0.6);
  `;

  const modalCard = document.createElement("div");
  modalCard.className = "modal-card prompt-selection-modal";

  // Ensure modal pop-in style exists
  if (!document.getElementById("modal-pop-in-style")) {
    const style = document.createElement("style");
    style.id = "modal-pop-in-style";
    style.textContent = `
      @keyframes modalPopIn {
        to { transform: translateY(0); opacity: 1; }
      }
    `;
    document.head.appendChild(style);
  }

  modalCard.innerHTML = `
    <button type="button" id="promptSelectionClose" class="create-quiz-modal__close-btn prompt-selection-modal__close-btn" aria-label="إغلاق">
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
    </button>
    <h2 id="promptSelectionTitle" style="margin-bottom: 16px; font-size: 1.3rem; display: flex; align-items: center; gap: 10px; color: var(--color-text-primary); padding-left: 36px;">
    <svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" viewBox="0 -960 960 960" fill="currentColor" style="color: var(--color-primary);">
      <path d="M160-120v-200q0-33 23.5-56.5T240-400h480q33 0 56.5 23.5T800-320v200H160Zm200-320q-83 0-141.5-58.5T160-640q0-83 58.5-141.5T360-840h240q83 0 141.5 58.5T800-640q0 83-58.5 141.5T600-440H360ZM240-200h480v-120H240v120Zm120-320h240q50 0 85-35t35-85q0-50-35-85t-85-35H360q-50 0-85 35t-35 85q0 50 35 85t85 35Zm28.5-91.5Q400-623 400-640t-11.5-28.5Q377-680 360-680t-28.5 11.5Q320-657 320-640t11.5 28.5Q343-600 360-600t28.5-11.5Zm240 0Q640-623 640-640t-11.5-28.5Q617-680 600-680t-28.5 11.5Q560-657 560-640t11.5 28.5Q583-600 600-600t28.5-11.5ZM480-200Zm0-440Z"/>
    </svg>
      اختر البرومبت
    </h2>
    <p style="margin-bottom: 20px; color: var(--color-text-secondary); font-size: 0.95rem; line-height: 1.5;">اختر النموذج الأنسب لنوع الامتحان الذي تريد إنشاءه</p>
    
    <div class="prompt-buttons-container" style="display: flex; flex-direction: column; gap: 12px;">
      <button type="button" class="prompt-btn prompt-btn-general" data-prompt="general" style="padding: 14px 16px; border: 1.5px solid var(--color-border); border-radius: 12px; background: var(--color-background-secondary); color: var(--color-text-primary); font-family: inherit; font-size: 0.95rem; font-weight: 500; cursor: pointer; transition: all 0.2s; text-align: right;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-lightbulb" style="flex-shrink: 0;"><path d="M15 12c0 1.657-1.343 3-3 3s-3-1.343-3-3"/><path d="M9 17H7a2 2 0 0 0-2 2v2h12v-2a2 2 0 0 0-2-2h-2"/><path d="M12 21v1"/><path d="M9 12h6"/></svg>
          <div style="text-align: right;">
            <div style="font-weight: 600; font-size: 1rem;">الاستخدام العام</div>
            <div style="font-size: 0.85rem; color: var(--color-text-secondary); margin-top: 2px;">تحويل أي نوع امتحان إلى JSON</div>
          </div>
        </div>
      </button>
      
      <button type="button" class="prompt-btn prompt-btn-english" data-prompt="english" style="padding: 14px 16px; border: 1.5px solid var(--color-border); border-radius: 12px; background: var(--color-background-secondary); color: var(--color-text-primary); font-family: inherit; font-size: 0.95rem; font-weight: 500; cursor: pointer; transition: all 0.2s; text-align: right;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-book-open" style="flex-shrink: 0;"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
          <div style="text-align: right;">
            <div style="font-weight: 600; font-size: 1rem;">اللغة الإنجليزية</div>
            <div style="font-size: 0.85rem; color: var(--color-text-secondary); margin-top: 2px;">تخصص في امتحانات اللغة الإنجليزية</div>
          </div>
        </div>
      </button>
      
      <button type="button" class="prompt-btn prompt-btn-math" data-prompt="math" style="padding: 14px 16px; border: 1.5px solid var(--color-border); border-radius: 12px; background: var(--color-background-secondary); color: var(--color-text-primary); font-family: inherit; font-size: 0.95rem; font-weight: 500; cursor: pointer; transition: all 0.2s; text-align: right;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-function-square" style="flex-shrink: 0;"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><path d="M9 17c0-1 1-4 3-5m0 0c2-1 3-4 3-5s-1-3-3-3-3 1-3 3m0 0c-1 2-2 3-2 5"/></svg>
          <div style="text-align: right;">
            <div style="font-weight: 600; font-size: 1rem;">الرياضيات والعلوم</div>
            <div style="font-size: 0.85rem; color: var(--color-text-secondary); margin-top: 2px;">تخصص في المعادلات والمسائل الحسابية</div>
          </div>
        </div>
      </button>
    </div>
  `;

  overlay.appendChild(modalCard);
  document.body.appendChild(overlay);

  const promptButtons = modalCard.querySelectorAll(".prompt-btn");
  const closeBtn = modalCard.querySelector("#promptSelectionClose");

  // Close modal function — MUST be defined before being referenced.
  const close = wireModalDismiss(overlay, () =>
    fadeOutAndRemove(overlay, modalCard),
  );

  // Handle button hover effects and click handlers
  promptButtons.forEach((btn) => {
    btn.onmouseover = () => {
      btn.style.borderColor = "var(--color-primary)";
      btn.style.background = "var(--color-background)";
      btn.style.transform = "translateX(-4px)";
    };
    btn.onmouseout = () => {
      btn.style.borderColor = "var(--color-border)";
      btn.style.background = "var(--color-background-secondary)";
      btn.style.transform = "translateX(0)";
    };

    // Copy prompt on click
    btn.onclick = async (e) => {
      e.stopPropagation();
      let promptText = "";
      const promptType = btn.getAttribute("data-prompt");

      if (promptType === "general") {
        promptText = General_Purpose_AI_Prompt;
      } else if (promptType === "english") {
        promptText = English_Specializing_Prompt;
      } else if (promptType === "math") {
        promptText = Math_Specializing_Prompt;
      }

      try {
        await navigator.clipboard.writeText(promptText);
        close();
        const promptLabel = {
          general: "البرومبت العام",
          english: "برومبت اللغة الإنجليزية",
          math: "برومبت الرياضيات",
        }[promptType];
        showNotification(
          "تم نسخ البرومبت",
          `تم نسخ ${promptLabel}، يمكنك الآن لصقه في أي ذكاء اصطناعي`,
          "success",
        );
      } catch (err) {
        console.error("Clipboard copy error:", err);
        showNotification(
          "خطأ في النسخ",
          "فشل نسخ البرومبت. حاول مرة أخرى.",
          "error",
        );
      }
    };
  });

  // Close button — .create-quiz-modal__close-btn already supplies the
  // hover styling (see index.css), matching the same `x` button used by
  // .create-quiz-inline-modal instead of a separate text-styled "إغلاق"
  // button down in the footer.
  closeBtn.onclick = close;

  // Escape-key and overlay-click dismissal are already wired by
  // wireModalDismiss() above — no separate handlers needed here.

  // Auto-focus first button
  setTimeout(() => {
    promptButtons[0]?.focus();
  }, 50);
}
