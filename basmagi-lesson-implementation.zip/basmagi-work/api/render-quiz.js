// =============================================================================
// api/render-quiz.js
//
// Serverless function (Node.js runtime) that handles all requests to /quiz/:id.
//
// What it does:
//   1. Reads the quiz ID from ?id= (injected by the vercel.json rewrite rule).
//   2. Fetches quiz metadata from Supabase via @supabase/supabase-js (HTTP/
//      PostgREST — never a raw pg TCP connection, safe on the free tier).
//   3. Reads the raw public/quiz.html template from disk.
//   4. Injects server-side OG meta tags so scrapers see them in the raw HTML.
//   5. Injects a <meta name="quiz:id"> data island for quiz.js to hydrate from.
//   6. Returns the modified HTML with edge-cache headers.
//
// URL contract:
//   /quiz/QUIZ_ID  →  (vercel.json rewrite)  →  /api/render-quiz?id=QUIZ_ID
//   Browser URL stays /quiz/QUIZ_ID. quiz.js reads the ID from <meta name="quiz:id">.
//   (The old /q/:id path is still rewritten too, for anyone with a bookmarked
//   or shared link — see vercel.json.)
// =============================================================================

import fs from "fs";
import path from "path";
import { createClient } from "@supabase/supabase-js";

// ── Supabase client ──────────────────────────────────────────────────────────
// Uses the anon key — the quizzes table should allow public SELECT via RLS.
// If your RLS policy blocks anon reads, swap to SUPABASE_SERVICE_KEY.
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY,
);

// ── quiz.html template path ──────────────────────────────────────────────────
// Vercel sets process.cwd() to the project root. The static outputDirectory is
// "public", so quiz.html lives at <root>/public/quiz.html.
const TEMPLATE_PATH = path.join(process.cwd(), "public", "quiz.html");

/**
 * Finds a quiz entry by ID across all subjects in the local manifest.
 * Mirrors quizManifest.js's flattened examList lookup, but done directly
 * against the manifest shape since we don't have the browser-only
 * buildCompatStructures() helper available server-side.
 *
 * @param {string} quizId
 * @returns {{title:string, description:string|null, questionCount:number|null, questionTypes:string|null}|null}
 */
// ── OG image version bump ────────────────────────────────────────────────────
// Increment this when you change the /api/og layout to bust platforms' cache.
const OG_IMAGE_VERSION = 3;

// ── Canonical site origin ────────────────────────────────────────────────────
const SITE_ORIGIN = "https://basmagi-quiz.vercel.app";

// ── Question type translation (Arabic) ────────────────────────────────────────
// Mirrors og.js's QUESTION_TYPE_AR — kept in sync so the page <title>/OG title
// and the generated thumbnail always show the same translated labels.
// The quiz-scanning script always emits these exact, case-sensitive English
// labels; we translate them for display only.
const QUESTION_TYPE_AR = {
  "MCQ": "إختياري",
  "Essay": "مقالي",
  "True/False": "صح/خطأ",
};

/**
 * Translates a questionTypes string (already joined with " · ") into Arabic
 * when isArabic is true, by exact-matching each known English label.
 * Order and separators are preserved; unrecognized labels pass through as-is.
 */
function translateQuestionTypes(questionTypesStr, isArabic) {
  if (!questionTypesStr || !isArabic) return questionTypesStr;
  return questionTypesStr
    .split(" · ")
    .map((part) => QUESTION_TYPE_AR[part] || part)
    .join(" · ");
}

// =============================================================================
// Handler
// =============================================================================
export default async function handler(req, res) {
  if (req.method !== "GET" && req.method !== "HEAD") {
    return res.status(405).end();
  }

  const id = req.query.id;

  if (!id || typeof id !== "string" || id.trim() === "") {
    // No quiz ID → redirect to the homepage so users aren't left on a blank page.
    return res.redirect(302, "/");
  }

  const quizId = id.trim();

  // ── User-copied quiz short-circuit ────────────────────────────────────────
  if (req.query.type === "user") {
    let userHtml;
    try {
      userHtml = fs.readFileSync(TEMPLATE_PATH, "utf8");
    } catch (err) {
      console.error("[render-quiz] Could not read quiz.html:", err);
      return res.status(500).send("Internal Server Error");
    }
    userHtml = userHtml.replace(
      "</head>",
      `  <meta name="quiz:id" content="${escapeHtml(quizId)}">\n</head>`,
    );
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    // Never cache — this response has no real OG metadata and the same URL
    // could later belong to a different visitor's different local quiz.
    res.setHeader("Cache-Control", "no-store");
    return res.status(200).send(userHtml);
  }

  // ── 1. Fetch quiz metadata from Supabase ──────────────────────────────────
  let meta = null;
  try {
    meta = await fetchQuizMeta(quizId);
  } catch (err) {
    console.error("[render-quiz] Supabase lookup failed:", err);
    // Fall through — we'll still try the local manifest below.
  }

  if (!meta) {
    // No metadata found in Supabase, so we will not attempt to find it in the local manifest.
    return res.status(404).send("Quiz not found");
  }

  // ── 2. Read HTML template ─────────────────────────────────────────────────
  let html;
  try {
    html = fs.readFileSync(TEMPLATE_PATH, "utf8");
  } catch (err) {
    console.error("[render-quiz] Could not read quiz.html:", err);
    return res.status(500).send("Internal Server Error");
  }

  // ── 3. Inject quiz ID meta island (always — quiz.js reads this) ───────────
  // Inserted right before </head> so it is available synchronously.
  const dbIdMeta = meta?.dbId
    ? `  <meta name="quiz:db_id" content="${escapeHtml(meta.dbId)}">\n`
    : "";
  html = html.replace(
    "</head>",
    `  <meta name="quiz:id" content="${escapeHtml(quizId)}">\n${dbIdMeta}</head>`,
  );

  // ── 4. Inject OG / title tags if we have metadata ────────────────────────
  if (meta) {
    const title = buildTitle(meta);
    const description = meta.description || "";
    const canonicalUrl = `${SITE_ORIGIN}/quiz/${encodeURIComponent(quizId)}`;
    const ogImageUrl = `${SITE_ORIGIN}/api/og?quizId=${encodeURIComponent(quizId)}&v=${OG_IMAGE_VERSION}`;

    // <title>
    html = html.replace(
      /<title>[^<]*<\/title>/i,
      `<title>${escapeHtml(title)}</title>`,
    );

    // canonical
    html = replaceLinkHref(html, "canonical", canonicalUrl);

    // Open Graph
    html = replaceMetaContent(html, "property", "og:title", title);
    html = replaceMetaContent(html, "property", "og:url", canonicalUrl);
    html = replaceMetaContent(html, "property", "og:image", ogImageUrl);
    if (description) {
      html = replaceMetaContent(html, "property", "og:description", description);
    }

    // Twitter
    html = replaceMetaContent(html, "name", "twitter:title", title);
    html = replaceMetaContent(html, "name", "twitter:image", ogImageUrl);
    html = replaceMetaContent(html, "name", "twitter:image:alt", title);
    if (description) {
      html = replaceMetaContent(html, "name", "twitter:description", description);
    }

    // Standard description
    if (description) {
      html = replaceMetaContent(html, "name", "description", description);
    }

    // Robots: quiz.html the *template* is noindex (bare /quiz.html should
    // never be indexed — see docs/plans/SEO-GEO-plan.md Phase 0.1), but a
    // successfully resolved /quiz/:id page is real, indexable content —
    // override the template's default back to index,follow here.
    html = replaceMetaContent(
      html,
      "name",
      "robots",
      "index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1",
    );

    // JSON-LD (plan §8.4): Quiz + BreadcrumbList. Only injected on the
    // successful-lookup branch, same as the robots override above — a
    // 404/user-copy page has no real entity to describe.
    const quizJsonLd = buildQuizJsonLd(meta, title, description, canonicalUrl);
    const breadcrumbJsonLd = await buildBreadcrumbChain(meta, canonicalUrl, title);
    const jsonLdScripts =
      `  <script type="application/ld+json">${JSON.stringify(quizJsonLd)}</script>\n` +
      `  <script type="application/ld+json">${JSON.stringify(breadcrumbJsonLd)}</script>\n`;
    html = html.replace("</head>", `${jsonLdScripts}</head>`);
  }

  // ── 5. Respond ────────────────────────────────────────────────────────────
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  if (meta) {
    // Metadata injection succeeded — safe to cache at the edge for 1 hour,
    // serving stale for up to 24 h while revalidating in the background.
    res.setHeader(
      "Cache-Control",
      "public, s-maxage=3600, stale-while-revalidate=86400",
    );
  } else {
    // No metadata (Supabase miss/error) — this response only has default
    // OG tags. Never cache it, so the next request (including the next
    // scraper hit) gets a fresh attempt instead of the fallback being
    // baked into the CDN for up to a day.
    res.setHeader("Cache-Control", "no-store");
  }
  return res.status(200).send(html);
}

// =============================================================================
// Data fetching
// =============================================================================

/**
 * Fetches quiz metadata from Supabase.
 * The `data` JSONB column contains:
 *   { meta: { id, title, description, … }, stats: { questionCount, questionTypes, … } }
 *
 * @param {string} quizId - The 8-char base32 quiz ID.
 * @returns {Promise<{title:string, description:string|null, questionCount:number|null, questionTypes:string|null}|null>}
 */
async function fetchQuizMeta(quizId) {
  // The quiz ID is stored inside the JSONB column: data->meta->>'id'
  const { data, error } = await supabase
    .from("quizzes")
    .select("id, data, title")
    .filter("data->meta->>id", "eq", quizId)
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error("[render-quiz] Supabase error:", error.message);
    return null;
  }

  if (!data) return null;

  const quizMeta = data.data?.meta || {};
  const quizStats = data.data?.stats || {};

  return {
    dbId: data.id || null, // Supabase row UUID — used by quiz.js to gate report button
    title: quizMeta.title || data.title || quizId,
    description: quizMeta.description || null,
    questionCount: quizStats.questionCount != null ? quizStats.questionCount : null,
    questionTypes: formatQuestionTypes(quizStats.questionTypes),
    courseId: data.course_id || null,
    folderId: data.folder_id || null,
    createdAt: data.created_at || null,
    syncedAt: data.synced_at || null,
  };
}

// =============================================================================
// JSON-LD (plan §8.4) — Quiz + BreadcrumbList
// =============================================================================

// Mirrors render-course.js's toSlug() exactly (kept in sync manually — this
// is a separate Node serverless function, same convention as api/_urls.js's
// header comment explains).
function toSlug(str) {
  return String(str || "").trim().replace(/-/g, "--").replace(/\s+/g, "-");
}

/**
 * Walks course_id/folder_id up to build the breadcrumb chain for a quiz:
 * home -> course -> [folder...] -> quiz. Best-effort: any lookup failure
 * just shortens the breadcrumb rather than failing the page render, since
 * JSON-LD is supplementary structured data, not the page's core content.
 */
async function buildBreadcrumbChain(meta, canonicalUrl, title) {
  const items = [{ name: "الرئيسية", url: SITE_ORIGIN }];

  try {
    if (meta.courseId) {
      const { data: course } = await supabase
        .from("courses")
        .select("id, name")
        .eq("id", meta.courseId)
        .maybeSingle();

      if (course?.name) {
        const courseSlug = toSlug(course.name);
        items.push({ name: course.name, url: `${SITE_ORIGIN}/course/${encodeURIComponent(courseSlug)}` });

        if (meta.folderId) {
          // Walk parent_folder_id up to the course root, then reverse, to
          // get an ordered folder chain — same traversal shape as
          // render-course.js's fetchFolderPath(), done in reverse (leaf ->
          // root) since we start from a known folder id, not a slug path.
          const folderChain = [];
          let currentId = meta.folderId;
          let guard = 0;
          while (currentId && guard < 20) {
            guard += 1;
            const { data: folder } = await supabase
              .from("folders")
              .select("id, name, parent_folder_id")
              .eq("id", currentId)
              .maybeSingle();
            if (!folder) break;
            folderChain.unshift(folder);
            currentId = folder.parent_folder_id;
          }

          let pathAcc = courseSlug;
          for (const folder of folderChain) {
            pathAcc += `/${toSlug(folder.name)}`;
            items.push({ name: folder.name, url: `${SITE_ORIGIN}/course/${encodeURIComponent(pathAcc)}` });
          }
        }
      }
    }
  } catch (err) {
    console.error("[render-quiz] breadcrumb chain lookup failed (non-fatal):", err?.message || err);
  }

  items.push({ name: title, url: canonicalUrl });

  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  };
}

function buildQuizJsonLd(meta, title, description, canonicalUrl) {
  return {
    "@context": "https://schema.org",
    "@type": ["LearningResource", "Quiz"],
    name: title,
    description: description || title,
    learningResourceType: "Exam / Practice Test",
    educationalUse: "Assessment",
    isAccessibleForFree: true,
    dateCreated: meta.createdAt || undefined,
    dateModified: meta.syncedAt || meta.createdAt || undefined,
    url: canonicalUrl,
    inLanguage: "ar",
    author: { "@type": "Organization", name: "منصة امتحانات بصمجي", url: SITE_ORIGIN },
    provider: {
      "@type": "Organization",
      name: "منصة امتحانات بصمجي",
      sameAs: ["https://github.com/BelalAmrMohamed/Basmagi-Quiz"],
    },
  };
}

// =============================================================================
// Title formatting
// =============================================================================

/**
 * Formats the page title.
 * Example (Arabic):  "قواعد اللغة: 20 سؤال (اختيار من متعدد)"
 * Example (English): "Calculus Midterm: 15 Questions (MCQ)"
 */
function buildTitle(meta) {
  if (!meta?.title) return "";
  const firstLetterMatch = meta.title.match(/\p{L}/u);
  const isArabic =
    firstLetterMatch &&
    /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/.test(firstLetterMatch[0]);
  const label = isArabic ? "سؤال" : "Questions";
  const translatedTypes = translateQuestionTypes(meta.questionTypes, isArabic);

  let details = "";
  if (meta.questionCount != null) {
    details = `${meta.questionCount} ${label}`;
    if (translatedTypes) {
      details += ` (${translatedTypes})`;
    }
  } else if (translatedTypes) {
    details = translatedTypes;
  }

  return details ? `${meta.title}: ${details}` : meta.title;
}

// =============================================================================
// HTML helpers
// =============================================================================

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * Finds a <meta attr="value"> tag and replaces its content="…" value.
 * Attribute order in the tag does not matter.
 */
function replaceMetaContent(html, attr, value, newContent) {
  const tagRe = new RegExp(
    `<meta[^>]*\\b${attr}=["']${escapeRegex(value)}["'][^>]*>`,
    "i",
  );
  return html.replace(tagRe, (tag) => {
    if (/content=["'][^"']*["']/i.test(tag)) {
      return tag.replace(
        /content=["'][^"']*["']/i,
        `content="${escapeHtml(newContent)}"`,
      );
    }
    return tag;
  });
}

/**
 * Finds a <link rel="canonical"> and replaces its href.
 */
function replaceLinkHref(html, rel, newHref) {
  const tagRe = new RegExp(
    `<link[^>]*\\brel=["']${escapeRegex(rel)}["'][^>]*>`,
    "i",
  );
  return html.replace(tagRe, (tag) => {
    if (/href=["'][^"']*["']/i.test(tag)) {
      return tag.replace(
        /href=["'][^"']*["']/i,
        `href="${escapeHtml(newHref)}"`,
      );
    }
    return tag;
  });
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function formatQuestionTypes(qt) {
  if (!qt) return null;
  if (Array.isArray(qt)) return qt.length ? qt.join(" · ") : null;
  return String(qt) || null;
}