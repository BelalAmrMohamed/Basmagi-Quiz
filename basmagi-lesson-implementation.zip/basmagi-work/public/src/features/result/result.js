// public/src/features/result/result.js

// Temporary | For performance debugging
console.log("result.js loaded successfully");

import { getManifest } from "../../shared/quizManifest.js";
import { loadFullQuizData } from "../home/quiz-data-loader.js";

// Download modal (shared component)
import { showDownloadModal } from "../../components/download-quiz-modal/download-quiz-modal.js";

// Notifications
import { showNotification } from "../../components/notifications/notifications.js";

// Question helpers
import {
  gradeEssay,
  isEssayQuestion,
  calculateQuizMetrics,
  isAnswerCorrect,
  isMultiSelectQuestion,
  singleCorrectIndex,
} from "../../shared/rate-answers.js";

import {
  buildQuizInfoModalHtml,
  fetchCreatorProfile,
} from "../../components/quiz-info-modal/quiz-info-html.js";

// ── Shared Markdown engine ─────────
// renderMarkdown:           full GFM renderer with KaTeX, tables, copy buttons
// scanDirections:           post-render direction scan for non-markdown elements
import { renderMarkdown, scanDirections } from "../../shared/markdown.js";

// ── Shared media URL resolution ────
// Same module quiz.js uses, so both pages resolve quiz-folder-relative
// media (e.g. "./assets/quiz-media/...") and detect YouTube URLs identically.


// Report Question Modal
import {
  openReportModal,
  isQuestionReported,
} from "../../components/report-question/report-question.js";

// AI Helper (result-page analysis mode — read-only, no quiz creation)
import { createAIAgentFab } from "../../components/ai-agent/ai-agent.js";
import { buildResultSystemPrompt } from "../../components/ai-agent/ai-agent-default-prompts.js";
import { buildResultSuggestedPrompts } from "../../components/ai-agent/ai-agent-suggested-prompts.js";

// Helpers
const userName = localStorage.getItem("username") || "User";
const result = JSON.parse(localStorage.getItem("last_quiz_result"));
if (!result) window.location.href = "/";

let resolvedQuizDbId = result?.quizDbId || null;

// ─── Helpers ──────────────────────────────────────────────────────────────────
const getEssayAnswer = (q) => q.answer ?? "";

// === Helper: HTML Escaping ===
const escapeHtml = (unsafe) => {
  if (unsafe === null || unsafe === undefined) return "";
  return String(unsafe)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
};

// ── Media base URL ─────────────────────────────────────────────────────────
// All question media (inline <img>/<audio>/<video> tags inside q.q/
// q.passage) is resolved and rendered by renderMarkdown() itself via its
// mediaBaseUrl option below — the legacy q.image/q.audio/q.video fields and
// their dedicated renderers have been removed. `resultBaseUrl` still closes
// the gap this file previously had: it resolves quiz-folder-relative
// co-located media (e.g. "./assets/quiz-media/TEST_1/Part_1.mp4") against
// the result page's own directory, same as quiz.js's `quizBaseUrl` — result.
// html and quiz.html are sibling pages served from the same directory.
const resultBaseUrl = new URL("./", window.location.href).href;

const renderReadingPassage = (passage) => {
  if (!passage) return "";
  return `
    <div class="reading-passage" role="region" aria-label="Reading passage">
      ${renderMarkdown(passage, { mediaBaseUrl: resultBaseUrl })}
    </div>
  `;
};

const starRating = (score, max = 5) =>
  `<span class="star-rating" aria-label="Score ${score} of ${max}">` +
  "★".repeat(score) +
  `<span class="star-empty">${"★".repeat(max - score)}</span>` +
  `</span>`;

// ─── Helper: HTML escape for raw user-supplied attribute values ───────────────
// This is used for image src URLs only — NOT for markdown content.
// renderMarkdown() handles its own escaping internally.
function escapeHTML(input) {
  if (input === undefined || input === null) return "";
  return String(input)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// ─────────────────────────────────────────────────────────────────────────────

const formatQuestionTypes = (stats) => {
  const qt = stats?.questionTypes;
  if (!qt) return null;
  if (Array.isArray(qt)) return qt.length ? qt.join(" · ") : null;
  return String(qt) || null;
};

document.addEventListener("DOMContentLoaded", async () => {
  const scoreHeader = document.getElementById("scoreHeader");
  const scoreDisplay = document.getElementById("scoreDisplay");
  const container = document.getElementById("reviewContainer");
  const backBtn = document.getElementById("backHomeBtn");
  const openDownloadModalBtn = document.getElementById("openDownloadModalBtn");

  const els = {
    breadcrumb: document.getElementById("quizBreadcrumb"),
    dateBadge: document.getElementById("dateBadge"),
    quizInfoBtn: document.getElementById("quizInfoBtn"),
    quizInfoDialog: document.getElementById("quizInfoDialog"),
    quizInfoDialogClose: document.getElementById("quizInfoDialogClose"),
    quizInfoTable: document.getElementById("quizInfoTable"),
  };

  let examList = [];
  try {
    const manifest = await getManifest();
    examList = manifest.examList || [];
  } catch (e) {
    console.error("Failed to load manifest", e);
  }

  const manifestEntry = examList.find((e) => e.id === result.examId);
  if (!resolvedQuizDbId && manifestEntry?.dbId) {
    resolvedQuizDbId = manifestEntry.dbId;
  }
  const resultMeta = result.meta || {};

  const config = {
    id: result.examId,
    title:
      result.examTitle ||
      resultMeta.title ||
      (manifestEntry && manifestEntry.title) ||
      "User Quiz",
    description:
      result.description ||
      resultMeta.description ||
      (manifestEntry && manifestEntry.description) ||
      "Custom user-created quiz",
    source:
      result.source ||
      resultMeta.source ||
      (manifestEntry && manifestEntry.source) ||
      null,
    createdAt:
      result.createdAt ||
      resultMeta.createdAt ||
      (manifestEntry && manifestEntry.createdAt) ||
      null,
    dbId: resolvedQuizDbId,
    author:
      result.author ||
      resultMeta.author ||
      (manifestEntry && manifestEntry.author) ||
      null,
    authorHandle:
      result.authorHandle ||
      resultMeta.author_handle ||
      (manifestEntry && manifestEntry.authorHandle) ||
      null,
    authorId:
      result.authorId ||
      resultMeta.author_id ||
      (manifestEntry && manifestEntry.authorId) ||
      null,
    category:
      result.category ||
      resultMeta.category ||
      (manifestEntry && manifestEntry.category) ||
      null,
    view:
      result.view ||
      resultMeta.view ||
      (manifestEntry && manifestEntry.view) ||
      null,
    mode:
      result.mode ||
      resultMeta.mode ||
      (manifestEntry && manifestEntry.mode) ||
      null,
    questionTypes:
      result.questionTypes ||
      resultMeta.questionTypes ||
      (manifestEntry && manifestEntry.questionTypes) ||
      null,
  };

  // Patch runtime fields onto config.
  // view and mode are never on manifest entries; read them from result.
  // questionTypes may come from the manifest as a raw array or an already-joined
  // string; normalise both cases through formatQuestionTypes.
  if (!config.view) config.view = result.view || null;
  if (!config.mode) config.mode = result.mode || null;
  config.questionTypes =
    formatQuestionTypes({ questionTypes: config.questionTypes }) ||
    formatQuestionTypes({ questionTypes: result.questionTypes }) ||
    null;

  let questions = [];
  if (
    result.questions &&
    Array.isArray(result.questions) &&
    result.questions.length > 0
  ) {
    questions = result.questions;
  } else if (config.dbId) {
    try {
      const loaded = await loadFullQuizData({ dbId: config.dbId });
      questions = loaded.questions || [];
      if (loaded.meta) {
        if (loaded.meta.createdAt && !config.createdAt)
          config.createdAt = loaded.meta.createdAt;
        if (loaded.meta.description && !config.description)
          config.description = loaded.meta.description;
        if (loaded.meta.source && !config.source)
          config.source = loaded.meta.source;
        if (loaded.meta.author && !config.author)
          config.author = loaded.meta.author;
        if (loaded.meta.author_handle && !config.authorHandle)
          config.authorHandle = loaded.meta.authorHandle;
        if (loaded.meta.author_id && !config.authorId)
          config.authorId = loaded.meta.author_id;
      }
    } catch (e) {
      console.error("Failed to load questions", e);
    }
  } else {
    try {
      const userQuizzes = JSON.parse(
        localStorage.getItem("user_quizzes") || "[]",
      );
      const found = userQuizzes.find((q) => q.id === result.examId);
      if (found) {
        questions = found.questions || [];
        config.title = found.title || config.title;
        config.source = found.source || config.source;
        config.createdAt = found.createdAt || config.createdAt;
      }
    } catch (e) {
      console.error("Error loading user quiz questions", e);
    }
  }

  document.title = `نتائج امتحان ${config.title}`;

  // ── Score breakdown via centralised metrics calculator ─────────────────────
  const {
    mcqCorrect,
    mcqWrong,
    mcqSkipped,
    mcqTotal,
    essayCount,
    essayScoreTotal,
    essayMaxTotal,
    isEssayOnly,
    percentage,
    actualPercentage,
  } = calculateQuizMetrics(questions, result.userAnswers);

  // displayScore / displayTotal are kept for the legacy scoreDisplay element
  // and the countUp animation — they are NOT used in the score-circle percentage.
  const displayScore =
    result.score !== undefined ? result.score : mcqCorrect + essayScoreTotal;
  const displayTotal =
    result.total !== undefined ? result.total : mcqTotal + essayMaxTotal;

  backBtn && (backBtn.onclick = goHome);

  openDownloadModalBtn &&
    (openDownloadModalBtn.onclick = () => {
      showDownloadModal({
        config,
        questions,
        userAnswers: result.userAnswers,
        resultMeta: result,
        filenameBase: config.title || "quiz",
      });
    });

  const limit = 30;
  const title = result.examTitle;

  /* Since the page is RTL and the welcome title is in Arabic,
     but most exam Titles are in English (but not all), The placement
     of the `...` Should be dynamic */
  const quizTitleEl = document.getElementById("quiz-title");
  if (quizTitleEl) {
    quizTitleEl.textContent =
      title.length > limit ? `${title.substring(0, limit)}...` : title;
    scanDirections(quizTitleEl.parentElement || quizTitleEl);
  }

  // ── Quiz Info Dialog ───────────────────────────────────────────────────────
  // Populate the info dialog using the shared HTML builder.
  if (els.quizInfoDialog) {
    if (!config.category) {
      config.category = config.category || "";
    }

    const authorIdentifier = config.authorId || config.authorHandle;
    let creatorProfile = null;
    if (authorIdentifier) {
      const type = config.authorId ? "id" : "handle";
      creatorProfile = await fetchCreatorProfile(authorIdentifier, type);
    }

    els.quizInfoDialog.innerHTML = buildQuizInfoModalHtml(
      config,
      questions.length,
      creatorProfile,
    );

    // Wire up close button (rendered dynamically into the shell)
    const closeBtn = els.quizInfoDialog.querySelector(
      ".quiz-info-dialog-close",
    );
    if (closeBtn) {
      closeBtn.addEventListener("click", () => els.quizInfoDialog.close());
    }
  }

  if (els.quizInfoBtn && els.quizInfoDialog) {
    els.quizInfoBtn.addEventListener("click", () => {
      els.quizInfoDialog.showModal();
    });
  }

  // Close dialog when the user clicks the backdrop
  els.quizInfoDialog?.addEventListener("click", (e) => {
    if (e.target === els.quizInfoDialog) els.quizInfoDialog.close();
  });

  renderHeader(
    scoreHeader,
    scoreDisplay,
    result,
    percentage,
    actualPercentage,
    isEssayOnly,
    mcqCorrect,
    mcqWrong,
    mcqSkipped,
    mcqTotal,
    essayCount,
    essayScoreTotal,
    essayMaxTotal,
  );

  // Kick off the count-up animation on #scoreDisplay.
  // Fade out the static fraction text that renderHeader just wrote, then let
  // countUp rewrite textContent from 0→displayScore while fading back in.
  if (scoreDisplay) {
    scoreDisplay.style.opacity = "0";
    requestAnimationFrame(() => {
      scoreDisplay.style.opacity = "1"; // CSS transition: opacity 300ms ease
      countUp(scoreDisplay, displayScore);
    });
  }

  renderReview(container, questions, result.userAnswers);

  // Remove loading skeletons now that real content is rendered
  document.getElementById("scoreHeaderSkeleton")?.remove();
  document.getElementById("reviewSkeleton")?.remove();

  // ── AI Helper — result analysis mode ────────────────────────────────────
  // Build a compact structured summary (not the raw localStorage blob) of
  // the quiz + user's answers + marks, sourced from data already in scope
  // above. Cap to wrong/skipped questions only by default — right answers
  // need no discussion — to keep the system prompt from bloating past
  // reasonable token limits on quizzes with many questions.
  {
    // Resolves a raw stored MCQ answer (a 0-based index, an array of
    // indices for multi-correct questions, undefined/null if skipped) to
    // the actual option text. The AI was previously handed the raw index
    // (e.g. "1") instead of the option's text, which it has no way to
    // interpret without the options list — this is what q.options below
    // is for too. Returns "—" for a skipped/missing answer so it reads
    // the same way as the header's placeholder rather than "undefined".
    const answerToText = (value, options) => {
      if (value === undefined || value === null) return "—";
      if (Array.isArray(value)) {
        if (!value.length) return "—";
        const texts = value
          .map((idx) => (Array.isArray(options) ? options[idx] : undefined))
          .filter((t) => t !== undefined);
        return texts.length ? texts.join("، ") : "—";
      }
      if (Array.isArray(options) && typeof value === "number") {
        return options[value] ?? "—";
      }
      // Essay/free-text answers are already the text itself.
      return String(value);
    };

    const perQuestion = questions.map((q, i) => {
      const ua = result.userAnswers?.[i];
      const essay = isEssayQuestion(q);
      const options = Array.isArray(q.options) ? q.options : null;
      const userAnswer = essay ? (ua ?? "—") : answerToText(ua, options);
      const correctAnswer = essay
        ? q.answer
        : answerToText(q.correct ?? q.answer, options);
      const wasCorrect = essay
        ? gradeEssay(ua, q.answer ?? "") >= 4 // treat a near-full essay grade as "correct" for filtering
        : isAnswerCorrect(ua, q.correct ?? q.answer);
      return {
        question: q.q || q.question,
        options: essay ? null : options,
        userAnswer,
        correctAnswer,
        wasCorrect,
        explanation: q.explanation || "",
      };
    });

    const wrongOrSkipped = perQuestion.filter((q) => !q.wasCorrect);
    const omittedCorrectCount = perQuestion.length - wrongOrSkipped.length;

    const resultSummaryForAI = {
      quizTitle: result.examTitle || "",
      percentage: actualPercentage,
      passed: actualPercentage >= 70,
      mcq: { correct: mcqCorrect, wrong: mcqWrong, skipped: mcqSkipped, total: mcqTotal },
      essay: essayCount > 0 ? { score: essayScoreTotal, max: essayMaxTotal } : null,
      questions: wrongOrSkipped,
      omittedCorrectCount,
    };

    document.body.appendChild(
      createAIAgentFab({
        pageKey: "result",
        defaultSystemPrompt: buildResultSystemPrompt(resultSummaryForAI),
        suggestedPrompts: buildResultSuggestedPrompts(resultSummaryForAI),
        placeholder: "اسأل عن نتيجتك أو اطلب توصيات...",
        // No enableTools/onToolCall here — analysis only, no quiz creation
        // ability on this page (see IMPLEMENTATION_PLAN_v2.md Task 3C step 5).
      }),
    );
  }

  // ── Perfect-Score Certificate ──────────────────────────────────────────────
  if (questions.length > 10 && actualPercentage === 100) {
    // Short delay so the page renders first
    setTimeout(() => {
      launchConfetti();
      showCertificate(
        userName,
        config.title,
        config.category,
      );
    }, 800);

    // Inject a persistent button so the user can reopen the certificate
    // at any time after closing the modal.
    const certReopenBtn = document.createElement("button");
    certReopenBtn.id = "reopenCertBtn";
    certReopenBtn.className = "nav-btn primary cert-reopen-btn";
    certReopenBtn.innerHTML =
      '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="6"/><path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"/></svg>' +
      "<span>عرض الشهادة — View Certificate</span>";
    certReopenBtn.addEventListener("click", () => {
      showCertificate(
        userName,
        config.title,
        config.category,
      );
    });
    scoreHeader && scoreHeader.appendChild(certReopenBtn);
  }

  // ── UX 2.5: Review Card Stagger Animation ─────────────────────────────────
  // Set --stagger on each rendered card so the CSS animation-delay kicks in.
  // Capped at index 8: cards beyond the initial fold share the same max delay
  // and don't make the user wait an increasingly long time to see them appear.
  document
    .querySelectorAll("#reviewContainer .review-card")
    .forEach((el, i) => {
      el.style.setProperty("--stagger", Math.min(i, 8));
    });

  // ── Result Cards Filtering ─────────────────────────────────────────────────
  const filterBar = document.getElementById("filterBar");
  if (filterBar) {
    filterBar.addEventListener("click", (e) => {
      const btn = e.target.closest(".filter-btn");
      if (!btn) return;

      // Update the active pill highlight
      filterBar
        .querySelectorAll(".filter-btn")
        .forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      const filter = btn.dataset.filter;

      document
        .querySelectorAll("#reviewContainer .review-card")
        .forEach((card) => {
          let visible = true;

          switch (filter) {
            case "all":
              visible = true;
              break;
            case "correct":
              visible = card.classList.contains("correct");
              break;
            case "wrong":
              visible = card.classList.contains("wrong");
              break;
            case "skipped":
              visible = card.classList.contains("skipped");
              break;
            case "essay":
              visible = card.classList.contains("essay-card");
              break;
            case "mcq":
              // MCQ & T/F = any card that is NOT an essay card
              visible = !card.classList.contains("essay-card");
              break;
          }

          card.style.display = visible ? "" : "none";
        });
    });
  }

  const newBadges = result.gamification ? result.gamification.newBadges : [];
  newBadges.forEach((badge, index) => {
    setTimeout(
      () =>
        showNotification(
          `Congratulations, ${userName}`,
          `You've earned the ${badge.title} badge`,
          `${badge.icon}`,
        ),
      index * 500,
    );
  });
});

function goHome() {
  window.location.href = "/";
}

/**
 * countUp — animates el.textContent from 0 to target over `duration` ms.
 * Pure: the only DOM side-effect is writing el.textContent.
 * Uses a cubic ease-out curve: eased = 1 − (1 − t)³
 *
 * @param {HTMLElement} el       - Target element whose textContent will be updated.
 * @param {number}      target   - Final numeric value to count up to.
 * @param {number}      duration - Animation length in milliseconds (default 1200).
 */
function countUp(el, target, duration = 1200) {
  const start = performance.now();
  function tick(now) {
    const elapsed = now - start;
    const t = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - t, 3); // cubic ease-out
    el.textContent = Math.round(eased * target);
    if (t < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

/**
 * renderHeader — builds the score-circle + stats panel inside #scoreHeader.
 *
 * `actualPercentage` is the holistic combined score (MCQ + essay) from
 * calculateQuizMetrics. `percentage` is preserved for the legacy scoreDisplay
 * count-up animation (MCQ-only view).
 *
 * Layout:
 *   .score-header-inner
 *     ├── .score-circle  (hero percentage ring)
 *     └── .score-header-body
 *           ├── h2 greeting + .points-pill
 *           ├── .score-detail-table  ← new results-detail style table
 *           ├── .time-line
 *           └── .new-badges-section  (if any badges earned)
 */
function renderHeader(
  scoreHeader,
  scoreDisplay,
  data,
  percentage,
  actualPercentage,
  isEssayOnly,
  mcqCorrect,
  mcqWrong,
  mcqSkipped,
  mcqTotal,
  essayCount,
  essayScoreTotal,
  essayMaxTotal,
) {
  // ── Time display ───────────────────────────────────────────────────────────
  // For timed/timed_exam modes the meaningful number is how much time was
  // *remaining* when the quiz ended (saved as data.timeRemaining).  For
  // regular (elapsed) mode we show how long the user spent.
  const savedMode = data.quizMode ?? data.mode ?? "";
  const isTimed = savedMode === "timed" || savedMode === "timed_exam";
  let timeStr, remainingStr;
  if (isTimed && data.timeRemaining !== undefined && data.timeRemaining > 0) {
    const rm = data.timeRemaining;
    remainingStr = `${Math.floor(rm / 60)}m ${rm % 60}s`;
  }
  const el = data.timeElapsed ?? 0;
  timeStr = `${Math.floor(el / 60)}m ${el % 60}s`;

  const points = data.gamification ? data.gamification.pointsEarned : 0;
  const newBadges = data.gamification ? data.gamification.newBadges : [];

  // Use actualPercentage for the hero circle (holistic); fall back to
  // percentage for safety in case the metric isn't available yet.
  const displayPct =
    actualPercentage !== undefined ? actualPercentage : percentage;
  const passed = displayPct >= 70;

  const hasMcq = mcqTotal > 0;
  const hasEssay = essayCount > 0;

  // ── Badges section ─────────────────────────────────────────────────────────
  let badgeHTML = "";
  if (newBadges.length > 0) {
    badgeHTML = `
      <div class="new-badges-section">
        <h3><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-award-icon lucide-award"><path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"/><circle cx="12" cy="8" r="6"/></svg> شارات تم إكتسابها</h3>
        <div class="badge-grid">
          ${newBadges
        .map(
          (b) => `
            <div class="badge-item">
              <span class="badge-icon">${b.icon}</span>
              <span class="badge-name">${b.title}</span>
            </div>`,
        )
        .join("")}
        </div>
      </div>`;
  }

  // ── Score detail table rows (adaptive per quiz type) ───────────────────────
  const userNameHtml = `<span id="result-page-username">${userName}</span>`;
  let tableRows = "";

  if (hasMcq && hasEssay) {
    // Mixed quiz — show all breakdowns
    const mcqPct = mcqTotal > 0 ? Math.round((mcqCorrect / mcqTotal) * 100) : 0;
    const essayPct =
      essayMaxTotal > 0
        ? Math.round((essayScoreTotal / essayMaxTotal) * 100)
        : 0;
    const essayStars =
      "★".repeat(Math.round((essayScoreTotal / essayMaxTotal) * 5)) +
      `<span class="sdt-star-empty">${"★".repeat(5 - Math.round((essayScoreTotal / essayMaxTotal) * 5))}</span>`;
    const totalScore = mcqCorrect + essayScoreTotal;
    const totalPossible = mcqTotal + essayMaxTotal;

    tableRows = `
      <div class="sdt-row sdt-highlight">
        <span class="sdt-label">النتيجة الكلية</span>
        <span class="sdt-value">${displayPct}%</span>
      </div>
      <div class="sdt-row">
        <span class="sdt-label">المجموع</span>
        <span class="sdt-value">${totalScore} / ${totalPossible} نقطة</span>
      </div>
      <div class="sdt-row">
        <span class="sdt-label">الأسئلة الموضوعية</span>
        <span class="sdt-value">${mcqCorrect} / ${mcqTotal} &nbsp;<span class="sdt-pct">${mcqPct}%</span></span>
      </div>
      <div class="sdt-row">
        <span class="sdt-label">خطأ</span>
        <span class="sdt-value sdt-wrong">${mcqWrong}</span>
      </div>
      ${mcqSkipped > 0
        ? `
      <div class="sdt-row">
        <span class="sdt-label">متخطى</span>
        <span class="sdt-value sdt-skipped">${mcqSkipped}</span>
      </div>`
        : ""
      }
      <div class="sdt-row">
        <span class="sdt-label">المقالي</span>
        <span class="sdt-value">${essayScoreTotal} / ${essayMaxTotal} &nbsp;<span class="sdt-stars">${essayStars}</span></span>
      </div>
      <div class="sdt-row sdt-last">
        <span class="sdt-label">الحالة</span>
        <span class="sdt-value ${passed ? "sdt-pass" : "sdt-fail"}">${passed ? "✓ ناجح" : "✗ راسب"}</span>
      </div>`;
  } else if (hasEssay) {
    // Essay-only quiz
    const essayStars =
      "★".repeat(Math.round((essayScoreTotal / essayMaxTotal) * 5)) +
      `<span class="sdt-star-empty">${"★".repeat(5 - Math.round((essayScoreTotal / essayMaxTotal) * 5))}</span>`;
    tableRows = `
      <div class="sdt-row sdt-highlight">
        <span class="sdt-label">النتيجة الكلية</span>
        <span class="sdt-value">${displayPct}%</span>
      </div>
      <div class="sdt-row">
        <span class="sdt-label">درجة المقالي</span>
        <span class="sdt-value">${essayScoreTotal} / ${essayMaxTotal} نقطة</span>
      </div>
      <div class="sdt-row">
        <span class="sdt-label">التقييم</span>
        <span class="sdt-value sdt-stars">${essayStars}</span>
      </div>
      <div class="sdt-row sdt-last">
        <span class="sdt-label">الحالة</span>
        <span class="sdt-value ${passed ? "sdt-pass" : "sdt-fail"}">${passed ? "✓ ناجح" : "✗ راسب"}</span>
      </div>`;
  } else {
    // MCQ-only quiz
    tableRows = `
      <div class="sdt-row sdt-highlight">
        <span class="sdt-label">النتيجة</span>
        <span class="sdt-value">${displayPct}%</span>
      </div>
      <div class="sdt-row">
        <span class="sdt-label">الإجابات الصحيحة</span>
        <span class="sdt-value sdt-correct">${mcqCorrect} / ${mcqTotal}</span>
      </div>
      <div class="sdt-row">
        <span class="sdt-label">الإجابات الخاطئة</span>
        <span class="sdt-value sdt-wrong">${mcqWrong}</span>
      </div>
      ${mcqSkipped > 0
        ? `
      <div class="sdt-row">
        <span class="sdt-label">متخطى</span>
        <span class="sdt-value sdt-skipped">${mcqSkipped}</span>
      </div>`
        : ""
      }
      <div class="sdt-row sdt-last">
        <span class="sdt-label">الحالة</span>
        <span class="sdt-value ${passed ? "sdt-pass" : "sdt-fail"}">${passed ? "✓ ناجح" : "✗ راسب"}</span>
      </div>`;
  }

  // ── Assemble the header ────────────────────────────────────────────────────
  if (scoreHeader)
    scoreHeader.innerHTML = `
    <div class="score-header-inner">
      <div class="score-circle ${passed ? "pass" : "fail"}">
        <span>${displayPct}%</span>
      </div>

      <div class="score-header-body">
        <h2 class="score-greeting">
          ${passed
        ? `🎉 أحسنت يا ${userNameHtml}!`
        : `📚 استمر في المذاكرة يا ${userNameHtml}`
      }
        </h2>

        <div class="points-pill">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-gem"><path d="M10.5 3 8 9l4 13 4-13-2.5-6"/><path d="M17 3a2 2 0 0 1 1.6.8l3 4a2 2 0 0 1 .013 2.382l-7.99 10.986a2 2 0 0 1-3.247 0l-7.99-10.986A2 2 0 0 1 2.4 7.8l2.998-3.997A2 2 0 0 1 7 3z"/><path d="M2 9h20"/></svg>
          +${points} نقطة
        </div>

        <div class="score-detail-table">
          ${tableRows}
        </div>

        <p class="time-line">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clock"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
          ${isTimed ? `الوقت المتبقّي: ${remainingStr} | الوقت: ${timeStr}` : `الوقت: ${timeStr}`}
        </p>

        ${badgeHTML}
      </div>
    </div>

  `;

  if (scoreDisplay) scoreDisplay.textContent = `${mcqCorrect} / ${mcqTotal}`;
}

function renderReview(container, questions, userAnswers) {
  if (!container) return;
  let html = "";
  const quizDbId = resolvedQuizDbId;

  questions.forEach((q, index) => {
    const isEssay = isEssayQuestion(q);
    const userAns = userAnswers[index];
    const alreadyReported = quizDbId ? isQuestionReported(quizDbId, index) : false;
    const reportBtnHtml = quizDbId
      ? `<button class="report-question-btn ${alreadyReported ? "active" : ""}" onclick="window.reportReviewQuestion(${index})" title="${alreadyReported ? "تم الإبلاغ عن هذا السؤال" : "الإبلاغ عن خطأ في هذا السؤال"}"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-triangle-alert"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></button>`
      : "";

    if (isEssay) {
      const score = gradeEssay(userAns, getEssayAnswer(q));
      const stars = starRating(score);
      const scoreLabel =
        score >= 4
          ? "ممتاز"
          : score === 3
            ? "جيد"
            : score === 2
              ? "مقبول"
              : score === 1
                ? "ضعيف"
                : userAns?.trim()
                  ? "صفر"
                  : "لم يُجَب";

      const scoreLabelClass =
        score >= 4
          ? "essay-score-excellent"
          : score >= 3
            ? "essay-score-good"
            : score >= 1
              ? "essay-score-poor"
              : "essay-score-none";

      const userText = userAns
        ? renderMarkdown(String(userAns), { mediaBaseUrl: resultBaseUrl })
        : "<em>لم تُجِب</em>";
      const formalText = renderMarkdown(getEssayAnswer(q), { mediaBaseUrl: resultBaseUrl });
      const explanationText = q.explanation
        ? renderMarkdown(q.explanation, { mediaBaseUrl: resultBaseUrl })
        : "";

      html += `
        <div class="review-card essay-card">
          <div class="review-header">
            <span class="q-num" title="This is question number ${index + 1}">#${index + 1}</span>
            <div class="review-header-right">
              <span class="essay-badge" title="Your score is (${score}/5)"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-scroll-text-icon lucide-scroll-text"><path d="M15 12h-5"/><path d="M15 8h-5"/><path d="M19 17V5a2 2 0 0 0-2-2H4"/><path d="M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3"/></svg> Essay</span>
              <span class="essay-score-badge ${scoreLabelClass}" title="Your score is (${score}/5)">${stars} ${scoreLabel} (${score}/5)</span>
              ${reportBtnHtml}
            </div>
          </div>
          ${renderReadingPassage(q.passage)}
          <div class="q-text">${renderMarkdown(q.q, { mediaBaseUrl: resultBaseUrl })}</div>
          <div class="essay-comparison">
            <div class="essay-answer-box user-essay">
              <div class="centered-label small-text"><svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pencil-line-icon lucide-pencil-line"><path d="M13 21h8"/><path d="m15 5 4 4"/><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/></svg> إجابتك</div>
              <div class="essay-text">${userText}</div>
            </div>
            <div class="essay-answer-box formal-essay">
              <div class="centered-label small-text"><svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-book-open-icon lucide-book-open"><path d="M12 7v14"/><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"/></svg> الإجابة النموذجية</div>
              <div class="essay-text">${formalText}</div>
            </div>
          </div>
          ${explanationText
          ? `
          <div class="explanation">
            <div class="centered-label"><strong><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-lightbulb-icon lucide-lightbulb"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg> الشرح</strong></div>
            <div class="explanation-body">${explanationText}</div>
          </div>`
          : ""
        }
        </div>`;
    } else {
      const correctIdx = q.correct ?? q.answer;
      const isMultiple = isMultiSelectQuestion(q);
      const isSkipped =
        userAns === undefined ||
        userAns === null ||
        (isMultiple && Array.isArray(userAns) && userAns.length === 0);

      // For multi-select: user must have selected exactly the correct set
      let isCorrect;
      if (isSkipped) {
        isCorrect = false;
      } else if (isMultiple) {
        isCorrect =
          Array.isArray(userAns) &&
          Array.isArray(correctIdx) &&
          userAns.length === correctIdx.length &&
          correctIdx.every((idx) => userAns.includes(idx));
      } else {
        isCorrect = isAnswerCorrect(userAns, correctIdx);
      }

      const statusClass = isCorrect
        ? "correct"
        : isSkipped
          ? "skipped"
          : "wrong";
      const statusIcon = isCorrect
        ? `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-check-icon lucide-circle-check"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>`
        : isSkipped
          ? `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-minus-icon lucide-circle-minus"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/></svg>`
          : `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-x-icon lucide-circle-x"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>`;

      const optionsHtml = q.options
        .map((opt, i) => {
          let isSelected = false;
          if (isMultiple) {
            isSelected = Array.isArray(userAns) && userAns.includes(i);
          } else {
            isSelected = userAns === i;
          }

          let optionClass = "option-row locked";
          if (isSelected) optionClass += " selected";

          const isCorrectOption = isMultiple
            ? Array.isArray(correctIdx) && correctIdx.includes(i)
            : i === singleCorrectIndex(q);

          if (isCorrectOption) optionClass += " correct";
          if (isSelected && !isCorrectOption) optionClass += " wrong";

          const inputType = isMultiple ? "checkbox" : "radio";
          const inputName = isMultiple
            ? `answer-${index}-${i}`
            : `answer-${index}`;

          return `
          <div class="${optionClass}">
            <input type="${inputType}" name="${inputName}" ${isSelected ? "checked" : ""} disabled aria-label="Option ${i + 1}">
            <span class="option-label">${renderMarkdown(opt, { mediaBaseUrl: resultBaseUrl })}</span>
          </div>`;
        })
        .join("");

      const explanationText = q.explanation
        ? renderMarkdown(q.explanation, { mediaBaseUrl: resultBaseUrl })
        : "";

      html += `
        <div class="review-card ${statusClass}">
          <div class="review-header">
            <span class="q-num">#${index + 1}</span>
            <div class="review-header-right">
              <span class="status-icon status-${statusClass}" title="This question is ${statusClass}">${statusIcon}</span>
              ${reportBtnHtml}
            </div>
          </div>
          ${renderReadingPassage(q.passage)}
          <div class="q-text">${renderMarkdown(q.q, { mediaBaseUrl: resultBaseUrl })}</div>
          <div class="options-grid">
            ${optionsHtml}
          </div>
          ${explanationText
          ? `
          <div class="explanation">
            <div class="centered-label"><strong><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-lightbulb-icon lucide-lightbulb"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg> الشرح</strong></div>
            <div class="explanation-body">${explanationText}</div>
          </div>`
          : ""
        }
        </div>`;
    }
  });

  container.innerHTML = html;
}

window.reportReviewQuestion = (index) => {
  const quizDbId = resolvedQuizDbId;
  if (!quizDbId) return;
  const questions = result?.questions || [];
  const q = questions[index];
  openReportModal({
    quizId: quizDbId,
    questionIndex: index,
    questionText: q?.q || q?.question || q?.text || `سؤال رقم ${index + 1}`,
    onSuccess: () => {
      const container = document.getElementById("reviewContainer");
      if (container) {
        renderReview(container, questions, result.userAnswers);
      }
    },
  });
};

// ─── Confetti Burst ────────────────────────────────────────────────────────────
function launchConfetti() {
  const canvas = document.createElement("canvas");
  Object.assign(canvas.style, {
    position: "fixed",
    top: "0",
    left: "0",
    width: "100%",
    height: "100%",
    pointerEvents: "none",
    zIndex: "9998",
  });
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  document.body.appendChild(canvas);

  const ctx = canvas.getContext("2d");
  const COUNT = 80;
  const COLORS = [
    "#6366f1",
    "#8b5cf6",
    "#f59e0b",
    "#10b981",
    "#ef4444",
    "#3b82f6",
    "#fbbf24",
    "#a78bfa",
  ];

  const particles = Array.from({ length: COUNT }, () => ({
    x: Math.random() * canvas.width,
    y: -20 - Math.random() * 60,
    vx: (Math.random() - 0.5) * 6,
    vy: 2 + Math.random() * 5,
    rot: Math.random() * 360,
    vrot: (Math.random() - 0.5) * 8,
    w: 6 + Math.random() * 8,
    h: 3 + Math.random() * 5,
    color: COLORS[Math.floor(Math.random() * COLORS.length)],
    opacity: 1,
  }));

  let start = null;
  const DURATION = 3500;

  function draw(ts) {
    if (!start) start = ts;
    const elapsed = ts - start;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    let allGone = true;
    for (const p of particles) {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.12; // gravity
      p.rot += p.vrot;
      p.opacity = Math.max(0, 1 - elapsed / DURATION);
      if (p.y < canvas.height + 20) allGone = false;

      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate((p.rot * Math.PI) / 180);
      ctx.globalAlpha = p.opacity;
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      ctx.restore();
    }

    if (elapsed < DURATION && !allGone) {
      requestAnimationFrame(draw);
    } else {
      canvas.remove();
    }
  }
  requestAnimationFrame(draw);
}

// ─── Certificate ───────────────────────────────────────────────────────────────
// Fully canvas-drawn: avoids html2canvas RTL/Arabic rendering bugs.

async function showCertificate(name, quizTitle, quizCategory) {
  const overlay = document.getElementById("certificateOverlay");
  if (!overlay) return;

  // Build the canvas once; reuse it for preview + download
  const certCanvas = await drawCertificateCanvas(name, quizTitle, quizCategory);

  // Inject as <img> into the preview wrapper
  const previewWrap = document.getElementById("certPreviewWrap");
  if (previewWrap) {
    previewWrap.innerHTML = "";
    const img = document.createElement("img");
    img.src = certCanvas.toDataURL("image/png");
    img.alt = "Certificate preview";
    img.style.cssText =
      "width:100%;height:auto;display:block;border-radius:8px;";
    previewWrap.appendChild(img);
  }

  overlay.style.display = "flex";

  // ── Download PNG ────────────────────────────────────────────────────────────
  document.getElementById("certDownloadBtn")?.addEventListener(
    "click",
    () => {
      const link = document.createElement("a");
      link.href = certCanvas.toDataURL("image/png");
      link.download = `certificate-${(name || "student").replace(/\s+/g, "_")}.png`;
      link.click();
    },
    { once: true },
  );

  // ── Close ───────────────────────────────────────────────────────────────────
  document
    .getElementById("certCloseBtn")
    ?.addEventListener("click", closeCertificate);
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) closeCertificate();
  });
}

function closeCertificate() {
  const overlay = document.getElementById("certificateOverlay");
  if (!overlay) return;
  overlay.classList.add("closing");
  overlay.addEventListener(
    "animationend",
    () => {
      overlay.style.display = "none";
      overlay.classList.remove("closing");
    },
    { once: true },
  );
}

// ── Canvas certificate renderer ─────────────────────────────────────────────
// All drawing is done via the Canvas 2D API so Arabic text is natively shaped
// and joined by the browser's text renderer — no html2canvas quirks.
async function drawCertificateCanvas(name, quizTitle, quizCategory) {
  await document.fonts.ready;

  const W = 1200,
    H = 820;
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");

  // ── Background ──────────────────────────────────────────────────────────────
  ctx.fillStyle = "#fffdf5";
  ctx.fillRect(0, 0, W, H);

  // ── Outer border ────────────────────────────────────────────────────────────
  ctx.strokeStyle = "#b8860b";
  ctx.lineWidth = 7;
  ctx.strokeRect(6, 6, W - 12, H - 12);

  ctx.strokeStyle = "#d4a017";
  ctx.lineWidth = 1.5;
  ctx.strokeRect(22, 22, W - 44, H - 44);
  ctx.strokeRect(28, 28, W - 56, H - 56);

  // ── Corner diamonds ─────────────────────────────────────────────────────────
  const corners = [
    [40, 40],
    [W - 40, 40],
    [40, H - 40],
    [W - 40, H - 40],
  ];
  ctx.fillStyle = "#b8860b";
  for (const [cx, cy] of corners) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(Math.PI / 4);
    ctx.fillRect(-5, -5, 10, 10);
    ctx.restore();
  }

  // ── Watermark logo ───────────────────────────────────────────────────────────
  await new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      ctx.save();
      ctx.globalAlpha = 0.07;
      const s = 260;
      ctx.drawImage(img, (W - s) / 2, (H - s) / 2, s, s);
      ctx.restore();
      resolve();
    };
    img.onerror = resolve;
    img.crossOrigin = "anonymous";
    img.src = "favicon.png";
  });

  // ── Gold seal ───────────────────────────────────────────────────────────────
  const sx = W / 2,
    sy = 118,
    sr = 52;

  // Rays
  ctx.strokeStyle = "#b8860b";
  ctx.lineWidth = 1.5;
  for (let i = 0; i < 8; i++) {
    const a = (i * Math.PI) / 4;
    ctx.beginPath();
    ctx.moveTo(sx + Math.cos(a) * (sr + 3), sy + Math.sin(a) * (sr + 3));
    ctx.lineTo(sx + Math.cos(a) * (sr + 12), sy + Math.sin(a) * (sr + 12));
    ctx.stroke();
  }

  // Circle fill + outline
  ctx.fillStyle = "#fdf6e3";
  ctx.beginPath();
  ctx.arc(sx, sy, sr, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#b8860b";
  ctx.lineWidth = 2;
  ctx.stroke();

  // 5-point star
  _drawStar(ctx, sx, sy - 8, 5, 30, 13, "#d4a017");

  // Platform Arabic label inside seal
  ctx.fillStyle = "#7c3f00";
  ctx.font = 'bold 14px "Amiri", serif';
  ctx.textAlign = "center";
  ctx.direction = "ltr"; // canvas text direction
  ctx.fillText("شهادة تقدير", sx, sy + 36);

  // ── Horizontal divider (top) ─────────────────────────────────────────────────
  _gradLine(ctx, W, 195, 2);

  // ── Main title ───────────────────────────────────────────────────────────────
  ctx.fillStyle = "#7c3f00";
  ctx.font = 'bold 58px "Playfair Display", "Amiri", Georgia, serif';
  ctx.textAlign = "center";
  ctx.fillText("Certificate of Excellence", W / 2, 270);

  // ── Divider (under title) ────────────────────────────────────────────────────
  _gradLine(ctx, W, 295, 1.5);

  // ── Body ────────────────────────────────────────────────────────────────────
  ctx.fillStyle = "#8a5a30";
  ctx.font = '22px "Amiri", Georgia, serif';
  ctx.fillText("This certifies that", W / 2, 348);

  // Name
  ctx.fillStyle = "#1a0a00";
  ctx.font = 'bold italic 52px "Amiri", Georgia, serif';
  ctx.fillText(name, W / 2, 420);

  // Underline for name
  const nm = ctx.measureText(name);
  const nw = Math.min(nm.width + 60, W - 200);
  ctx.strokeStyle = "rgba(184,134,11,0.45)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(W / 2 - nw / 2, 432);
  ctx.lineTo(W / 2 + nw / 2, 432);
  ctx.stroke();

  ctx.fillStyle = "#8a5a30";
  ctx.font = '22px "Amiri", Georgia, serif';
  ctx.fillText("has successfully completed", W / 2, 476);

  // Quiz title (with wrapping)
  ctx.fillStyle = "#1a0a00";
  ctx.font = 'bold 34px "Amiri", Georgia, serif';
  let titleBottom = _wrapText(ctx, quizTitle, W / 2, 530, W - 220, 44);

  // Category
  if (quizCategory) {
    ctx.fillStyle = "#8a5a30";
    ctx.font = '18px "Amiri", Georgia, serif';
    titleBottom = Math.max(titleBottom, 540);
    ctx.fillText(`Subject: ${quizCategory}`, W / 2, titleBottom + 38);
    titleBottom += 38;
  }

  // Score line
  ctx.fillStyle = "#7c3f00";
  ctx.font = '20px "Amiri", Georgia, serif';
  ctx.fillText("with a perfect score of 100%", W / 2, titleBottom + 54);

  // ── Divider (footer) ─────────────────────────────────────────────────────────
  _gradLine(ctx, W, H - 115, 1);

  // ── Footer ───────────────────────────────────────────────────────────────────
  const dateStr = new Date().toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  // Left: date
  ctx.textAlign = "left";
  ctx.fillStyle = "#4a2810";
  ctx.font = 'bold 17px "Amiri", Georgia, serif';
  ctx.fillText(dateStr, 90, H - 80);
  ctx.fillStyle = "#b8860b";
  ctx.font = '13px "Amiri", Georgia, serif';
  ctx.fillText("Issue Date", 90, H - 60);

  // Right: platform name (Arabic) + author
  ctx.textAlign = "right";
  ctx.direction = "ltr";
  ctx.fillStyle = "#4a2810";
  ctx.font = 'bold 22px "Amiri", serif';
  ctx.fillText("امتحانات بصمجي", W - 90, H - 77);
  ctx.fillStyle = "#8a5a30";
  ctx.font = '14px "Amiri", Georgia, serif';

  return canvas;
}

// ── Private helpers ────────────────────────────────────────────────────────────
function _drawStar(ctx, cx, cy, spikes, outer, inner, color) {
  let rot = (Math.PI / 2) * 3;
  const step = Math.PI / spikes;
  ctx.beginPath();
  ctx.moveTo(cx, cy - outer);
  for (let i = 0; i < spikes; i++) {
    ctx.lineTo(cx + Math.cos(rot) * outer, cy + Math.sin(rot) * outer);
    rot += step;
    ctx.lineTo(cx + Math.cos(rot) * inner, cy + Math.sin(rot) * inner);
    rot += step;
  }
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
}

function _gradLine(ctx, W, y, lw) {
  const g = ctx.createLinearGradient(0, 0, W, 0);
  g.addColorStop(0, "transparent");
  g.addColorStop(0.2, "#b8860b");
  g.addColorStop(0.8, "#b8860b");
  g.addColorStop(1, "transparent");
  ctx.strokeStyle = g;
  ctx.lineWidth = lw;
  ctx.beginPath();
  ctx.moveTo(80, y);
  ctx.lineTo(W - 80, y);
  ctx.stroke();
}

// Wraps text at maxWidth, returns Y of the last line drawn.
function _wrapText(ctx, text, x, y, maxWidth, lineH) {
  const words = text.split(" ");
  let line = "",
    curY = y;
  for (const word of words) {
    const test = line + (line ? " " : "") + word;
    if (ctx.measureText(test).width > maxWidth && line) {
      ctx.fillText(line, x, curY);
      line = word;
      curY += lineH;
    } else {
      line = test;
    }
  }
  if (line) ctx.fillText(line, x, curY);
  return curY;
}