// ============================================================================
// public/src/features/home/quiz-navigation.js
// QUIZ NAVIGATION — navigating to the quiz-taking page for a manifest exam.
// (The user-created-quiz equivalent, playUserQuiz(), lives in
// user-quiz-card.js since it's only ever called from that card.)
// ============================================================================

import { _alert } from "../../components/notifications/notifications.js";

export function startQuiz(id) {
  try {
    localStorage.setItem("quiz_start_time", Date.now().toString());

    // Only the quiz ID travels in the URL → links are shareable
    window.location.href = `/quiz/${encodeURIComponent(id)}`;
  } catch (error) {
    console.error("Error starting quiz:", error);
    _alert("حدث خطأ أثناء بدء الامتحان. حاول مرة أخرى.");
  }
}