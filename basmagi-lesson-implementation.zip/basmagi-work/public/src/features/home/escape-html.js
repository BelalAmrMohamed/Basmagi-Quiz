// ============================================================================
// public/src/features/home/escape-html.js
// escapeHtml — sanitizes untrusted strings before innerHTML interpolation
// ============================================================================

export function escapeHtml(unsafe) {
  if (unsafe === null || unsafe === undefined) return "";
  return String(unsafe)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
