// ============================================================================
// public/src/features/home/navigation.js
// NAVIGATION — app initialisation, URL/history routing, and popstate handling.
// ============================================================================
// Contains:
//   initApp()              — manifest load, first-visit detection, initial render
//   finalizeAppRender()    — stamps history entry + restores view from URL
//   restoreViewFromURL()   — maps window.location.hash → the correct view
//   findCategoryAncestors()— reconstructs breadcrumb ancestor chain from hash
//
// Original source lines (for verification):
//   findCategoryAncestors  ~1321-1343
//   restoreViewFromURL     ~1345-1417
//   initApp                ~748-808
//   finalizeAppRender      ~785-808
// ============================================================================
// NOTE: notifications are provided by src/components/notifications.js; this
// module imports showNotification directly where it needs it. `_confirm` is a
// runtime global loaded via a non-module <script> tag — no import for it.
// ============================================================================

import { getManifest } from "../../shared/quizManifest.js";
import {
  getCategoryTree,
  setCategoryTree,
  getNavigationStack,
  setNavigationStack,
  isRestoring,
  setRestoring,
} from "./app-state.js";
import { migrateLegacyUserProfile } from "./profile-migration.js";
import { initializeSearchManager } from "./search-integration.js";
import { renderRootCategories } from "./root-view.js";
import { renderCategory } from "./category-view.js";
import { renderUserQuizzesView } from "./user-quizzes-view.js";
import { renderLandingScreen } from "./landing-screen.js";
import { toSlug, fromSlug } from "./slug-utils.js";
import { setFolderState } from "./user-quizzes-folders.js";
import { getFromStorage } from "../../shared/storage-helpers.js";
import { showNotification } from "../../components/notifications/notifications.js";
import { renderLessonView } from "../lesson/lesson-view.js";

// ============================================================================
// findCategoryAncestors — original lines 1321-1343
// ============================================================================

/**
 * Find the chain of ancestor category objects for a given category key.
 * Returns an array ordered from root → direct parent (not including the target itself).
 * Used to reconstruct navigationStack when loading from a deep-link hash.
 *
 * @param {string} targetKey  - The key of the category we navigated to
 * @param {object} tree       - The flat categoryTree object
 * @returns {Array}           - Array of ancestor category objects (may be empty for root categories)
 */
function findCategoryAncestors(targetKey, tree) {
  if (!tree || !targetKey) return [];
  for (const [key, cat] of Object.entries(tree)) {
    if (
      Array.isArray(cat.subcategories) &&
      cat.subcategories.includes(targetKey)
    ) {
      // `cat` is the direct parent — recurse to find grandparents
      const grandAncestors = findCategoryAncestors(key, tree);
      return [...grandAncestors, cat];
    }
  }
  return []; // targetKey is a root-level category
}

// ============================================================================
// restoreViewFromURL — original lines 1345-1417
// ============================================================================

// Bug 1 Fix — restoreViewFromURL
// Re-renders the correct SPA view from the current window.location.hash.
// Called by:
//   • initApp()            - on initial page load / deep-link / refresh
//   • popstate listener    - on every browser back / forward navigation
//
// IMPORTANT: This function must always be called with _isRestoringState = true
// so that renderCategory / renderUserQuizzesView use history.replaceState
// (stamp the state object) rather than history.pushState (add a new entry).

export function restoreViewFromURL() {
  const hash = window.location.hash.slice(1); // strip leading #
  const pathname = window.location.pathname;

  // ── Lesson view — pathname-based: /lesson/:id ─────────────────────────────
  // Phase 1 skeleton (see docs/plans/lessons-feature-plan.md): renders the
  // lesson's title + raw markdown body via renderMarkdown() with no chrome.
  // The real content lives in the <meta name="lesson:*"> data-island
  // injected by api/render-course.js's contentType=lesson branch — read
  // directly from the DOM here rather than re-fetching, same as the
  // course:* island is consumed elsewhere in this file only via
  // categoryTree (already-loaded data), not a second network round trip.
  const lessonMatch = pathname.match(/^\/lesson\/([^/]+)\/?$/);
  if (lessonMatch) {
    setNavigationStack([]);
    renderLessonView();
    return;
  }

  // ── Course view — pathname-based: /course/:name/:subSlug/:subSlug2/... ────
  // Courses are always top-level (single-segment categoryTree key, parent
  // === null), so the first path segment is resolved directly against a
  // root category's `name` (case-insensitive / slug match, same approach
  // toSlug/fromSlug already use elsewhere) rather than walked like a nested
  // key. Any further segments are nested-subfolder slugs, walked one level
  // at a time the same way the legacy #hash chain below still is — these
  // are now real path segments (server-visible, so shared links get an
  // accurate per-folder OG image; see render-course.js/api/og.js), not a
  // hash the server never saw.
  //
  // A #hash after a /course/:name path (no extra path segments) is still
  // accepted and resolved the same way, for backward compatibility with
  // links shared before this change.
  const courseMatch = pathname.match(/^\/course\/([^/]+)((?:\/[^/]+)*)\/?$/);
  if (courseMatch) {
    // NOTE: this is already a slug (dashes for spaces, "--" for literal
    // hyphens) straight from the URL path segment — NOT a raw display name.
    // It must be compared directly against toSlug(node.name), the same way
    // subSlugParts is compared a few lines below. Do NOT run it through
    // toSlug() again: toSlug() isn't idempotent (it double-encodes an
    // existing "-" as "--"), so re-slugging an already-slugged segment like
    // "Artificial-Intelligence" produces "Artificial--Intelligence", which
    // never matches any real course and silently falls through to
    // renderRootCategories() below — this was a real bug (the root-view
    // reset), not just a hypothetical one.
    let courseSlug;
    try {
      courseSlug = decodeURIComponent(courseMatch[1]);
    } catch {
      courseSlug = courseMatch[1];
    }

    // Extra path segments (new scheme) take priority; fall back to the
    // #hash chain (old scheme) only when there are no extra path segments,
    // so an old bookmarked /course/:name#sub/sub2 link still resolves.
    const extraPathSegments = courseMatch[2]
      .split("/")
      .filter(Boolean)
      .map((s) => {
        try {
          return decodeURIComponent(s);
        } catch {
          return s;
        }
      });
    const subSlugParts = extraPathSegments.length > 0
      ? extraPathSegments
      : hash
        .split("/")
        .filter(Boolean)
        .map((s) => {
          try {
            return decodeURIComponent(s);
          } catch {
            return s;
          }
        });

    const categoryTree = getCategoryTree();
    if (categoryTree) {
      const courseKey = Object.keys(categoryTree).find((key) => {
        const node = categoryTree[key];
        return !node.parent && toSlug(node.name) === courseSlug;
      });

      if (courseKey) {
        if (subSlugParts.length === 0) {
          // No nested subfolder — render the course itself.
          setNavigationStack([]);
          renderCategory(categoryTree[courseKey]);
          return;
        }

        let catKey = courseKey;
        let cat = categoryTree[courseKey];
        let resolved = true;

        for (const slugPart of subSlugParts) {
          // slugPart is already a slug (both the new path segments and the
          // legacy #hash chain are built via toSlug() on the write side —
          // see category-view.js) — compare directly, don't re-slug it:
          // toSlug() isn't idempotent (it double-encodes existing "-" as
          // "--"), so running it again here would break the match for any
          // folder name containing a literal hyphen.
          const nextKey = (cat.subcategories || []).find(
            (subKey) =>
              categoryTree[subKey] && toSlug(categoryTree[subKey].name) === slugPart,
          );
          if (!nextKey) {
            resolved = false;
            break;
          }
          catKey = nextKey;
          cat = categoryTree[nextKey];
        }

        if (resolved) {
          const ancestors = findCategoryAncestors(catKey, categoryTree);
          setNavigationStack([...ancestors]);
          renderCategory(cat);
          return;
        }

        // Subfolder chain didn't resolve — fall back to the course itself.
        setNavigationStack([]);
        renderCategory(categoryTree[courseKey]);
        return;
      }
    }
    // Course name didn't resolve against the tree (e.g. manifest not loaded
    // yet, or a stale/typo'd link) — fall through to root.
    renderRootCategories();
    return;
  }

  // ── Root view ──────────────────────────────────────────────────────────────
  if (!hash) {
    renderRootCategories();
    return;
  }

  // ── User-quizzes folder ────────────────────────────────────────────────────
  if (hash === "my-quizzes") {
    setNavigationStack([]); // reset so renderUserQuizzesView can push cleanly
    setFolderState([], null); // reset to root
    renderUserQuizzesView();
    return;
  }

  // ── Nested user-quiz folder: #my-quizzes/slug1/slug2/... ─────────────────
  if (hash.startsWith("my-quizzes/")) {
    const segments = hash
      .slice("my-quizzes/".length)
      .split("/")
      .filter(Boolean)
      .map((s) => {
        try { return decodeURIComponent(s); } catch { return s; }
      });

    if (segments.length > 0) {
      // Sequentially match each slug against the stored user_quizzes
      const userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
      const stack = [];
      let parentId = null;
      let resolved = true;

      for (const slug of segments) {
        const match = userQuizzes.find(
          (q) =>
            (q.meta?.parentId || null) === parentId &&
            (q.meta?.type === "folder" || q.meta?.type === "course") &&
            toSlug(q.meta?.title || "") === slug
        );
        if (!match) { resolved = false; break; }
        const itemId = match.id || match.meta?.id;
        stack.push({ id: itemId, title: match.meta?.title });
        parentId = itemId;
      }

      if (resolved && stack.length > 0) {
        setNavigationStack([]);
        setFolderState(stack, stack[stack.length - 1].id);
        renderUserQuizzesView();
        return;
      }
    }
    // Slug didn't resolve — fall back to root my-quizzes view
    setNavigationStack([]);
    setFolderState([], null);
    renderUserQuizzesView();
    return;
  }

  // ── Category / subfolder — slug-based routing ─────────────────────────────
  // URL format: #{categorySlug}  or  #{categorySlug}/{subfolderSlug}/...
  // Each segment of a categoryTree key (split by "/") was passed through
  // toSlug() + encodeURIComponent() when the URL was built.
  //
  // IMPORTANT: split BEFORE decoding so a literal encoded "/" (%2F) inside a
  // segment is never mistaken for a path separator.  Then decode each segment
  // individually so both percent-encoded Arabic (%D8%A3…) and already-decoded
  // Arabic (أسئلة-الدكتور) resolve to the same slug string.
  const categoryTree = getCategoryTree();
  if (categoryTree) {
    const slugParts = hash
      .split("/")
      .filter(Boolean)
      .map((s) => {
        try {
          return decodeURIComponent(s);
        } catch {
          return s;
        }
      });

    let catKey = null;
    let cat = null;

    for (const [key, node] of Object.entries(categoryTree)) {
      const keyParts = key.split("/");
      if (keyParts.length !== slugParts.length) continue;
      if (keyParts.every((part, i) => toSlug(part) === slugParts[i])) {
        catKey = key;
        cat = node;
        break;
      }
    }

    if (cat) {
      // Reconstruct ancestor chain so breadcrumb "back" works correctly
      const ancestors = findCategoryAncestors(catKey, categoryTree);
      setNavigationStack([...ancestors]); // pre-load ancestors without re-rendering
      renderCategory(cat); // pushes cat itself and renders content
      return;
    }
  }

  // ── Fallback: unknown / unresolvable hash → root ───────────────────────────
  renderRootCategories();
}

// ============================================================================
// finalizeAppRender — original lines 785-808
// Also exported so landing-screen.js can call it after the skip-button
// dismiss animation completes (via a dynamic import to avoid a static cycle).
// ============================================================================

export function finalizeAppRender() {
  // ── Full render now that manifest is ready ────────────────────────────────
  try {
    // ── Bug 1 Fix: Stamp initial history entry ──────────────────────────────
    // Replace the browser's synthetic state-less entry with one that carries a
    // proper state object.  This guarantees that popstate fires (with non-null
    // event.state) if/when the user navigates forward and then returns here.
    history.replaceState({ view: "initial" }, "", window.location.href);

    // ── Restore the view indicated by the current URL ───────────────────────
    // _isRestoringState suppresses pushState inside renderCategory /
    // renderUserQuizzesView so we don't create a phantom forward entry on
    // the very first load.
    setRestoring(true);
    try {
      restoreViewFromURL();
    } finally {
      setRestoring(false);
    }
  } catch (error) {
    console.error("Error in initApp render phase:", error);
    renderRootCategories(); // retry once
  }
}

// ============================================================================
// initApp — original lines 748-783
// ============================================================================

/**
 * Bootstrap the home page: migrate legacy profile, fetch the quiz manifest,
 * then either show the first-visit landing screen or finalise the app render.
 *
 * Called from DOMContentLoaded (see new entrypoint index.js).
 */
export async function initApp() {
  migrateLegacyUserProfile();

  let hasVisited = true;
  try {
    hasVisited = !!localStorage.getItem("first_visit_complete");
  } catch (e) {
    console.error("Error checking first-visit state:", e);
  }

  // ── 1. Leave skeleton visible; just mark aria state ───────────────────────
  // The skeleton HTML in index.html is shown while we wait for the manifest.
  // Do NOT clear container.innerHTML here — that would hide the skeleton.
  const contentArea = document.getElementById("contentArea");
  if (contentArea) {
    contentArea.setAttribute("aria-busy", "true");
  }

  // ── 2. Fetch manifest asynchronously, then render all categories ─────────
  try {
    const manifest = await getManifest();
    setCategoryTree(manifest.categoryTree);
    initializeSearchManager();
    if (manifest.fromCache) {
      // Supabase is unreachable/timing out — getManifest() fell back to the
      // last-good snapshot from localStorage. The catalog is still usable;
      // tell the user why it might be slightly stale.
      console.warn("[initApp] Supabase unreachable — showing last-good catalog from local snapshot.");
      showNotification(
        "وضع عدم الاتصال",
        "تعذّر الوصول للخادم حالياً — يتم عرض المواد من نسخة محفوظة مسبقاً.",
        "warning",
      );
    }
  } catch (err) {
    console.error("Failed to load quiz manifest:", err);
    // null (NOT {}) signals "load failed" so renderRootCategories() shows a
    // retry error state instead of a misleading "توجد مواد غير متاحة" empty
    // state — {} remains reserved for a genuinely empty catalog.
    setCategoryTree(null);
  }

  // ── If first-time visitor, show landing layout instead of default content
  if (!hasVisited) {
    renderLandingScreen();
    return; // Wait for user decision (skip/onboard button)
  }

  finalizeAppRender();
}

/**
 * Re-attempts the quiz-manifest load from the retry/error state without a
 * full page reload. Used by the manifest-failure error state rendered from
 * renderRootCategories() (see root-view.js); a dynamic import from that
 * module avoids the navigation.js <-> root-view.js circular import.
 *
 * The manifest is only cached in memory on success, so a retry after a
 * timeout/failure re-fetches from Supabase — falling back to the last-good
 * snapshot if it is still unreachable, or reaching the error state if no
 * snapshot exists yet.
 */
export async function retryLoadManifest() {
  try {
    const manifest = await getManifest();
    setCategoryTree(manifest.categoryTree);
    initializeSearchManager();
  } catch (err) {
    console.error("Retry failed to load quiz manifest:", err);
    setCategoryTree(null);
  }
  finalizeAppRender();
}