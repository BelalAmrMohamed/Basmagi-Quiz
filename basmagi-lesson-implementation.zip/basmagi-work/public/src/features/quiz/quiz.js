// public/src/features/quiz/quiz.js - Supabase quizzes or user quizzes.

// Temporary | For performance debugging
console.log("quiz.js loaded successfully");

// Quiz page ports its own standalone sidebar (see quiz.css) rather than
// sharing side-menu.js, so it needs its own call to stamp pathLength/dash
// geometry onto the sidebar's icons — otherwise the `menu-item-draw` hover
// animation in quiz.css has nothing to draw. Safe to call this early: it
// waits for DOMContentLoaded internally and then watches for any menu items
// injected later in the page's lifecycle.
initMenuIconDrawing();

import { getManifest } from "../../shared/quizManifest.js";
import { initMenuIconDrawing } from "../../components/side-menu/menu-icon-draw.js";
import { gameEngine } from "../../shared/gameEngine.js";
import {
  _confirm,
  _alert,
  showNotification,
} from "../../components/notifications/notifications.js";
import { userProfile } from "../../shared/userProfile.js";
import { initKeyboardNav } from "./keyboard-nav.js";
import {
  gradeEssay,
  isEssayQuestion,
  isAnswerCorrect,
  isMultiSelectQuestion,
  singleCorrectIndex,
} from "../../shared/rate-answers.js";
import { renderMarkdown, scanDirections } from "../../shared/markdown.js";
import {
  getMediaUrlCandidates as _getMediaUrlCandidates,
  resolveMediaUrl as _resolveMediaUrl,
  renderMediaElement as _renderMediaElement,
} from "../../shared/media-resolve.js";
import {
  buildQuizInfoModalHtml,
  fetchCreatorProfile,
} from "../../components/quiz-info-modal/quiz-info-html.js";
import { loadFullQuizData } from "../home/quiz-data-loader.js";
import { openReportModal, isQuestionReported } from "../../components/report-question/report-question.js";
import {
  isDownloadPasswordVerified,
  markDownloadPasswordVerified,
} from "../home/download-password.js";

// Bug 1 Fix — "start of exam" notification moved out of the top-level
// import block and wrapped in try/catch. It previously ran as a bare
// statement sandwiched between two `import`s: any throw inside
// showNotification() (e.g. a missing toast container, a not-yet-ready
// DOM node, anything) would abort evaluation of this entire module,
// silently killing every feature defined below it in the file —
// including the whole sidebar/accordion wiring IIFE near the bottom.
// A single non-critical notification must never be able to take down
// the rest of the page's interactivity.
try {
  showNotification(
    "الامتحان بدأ",
    "أسأل الله لك التوفيق والسداد",
    "./assets/images/صلى_على_النبي_2.png",
  );
} catch (err) {
  console.error("Failed to show 'exam started' notification:", err);
}

// === MEMORY CACHE for exam modules ===
const examModuleCache = new Map();
const MAX_CACHE_SIZE = 10; // Keep last 10 exams in memory

// === State Management ===
let questions = [];
let metaData = {};
let currentIdx = 0;
let userAnswers = {};
let lockedQuestions = {};
let timeElapsed = 0;
let timerInterval = null;
let examId = null;
let quizMode = "exam";
let timeRemaining = 0;
let viewMode = "grid";
let autoSubmitTimeout = null;
let quizStyle = "pagination"; // "pagination" | "vertical"
let quizBaseUrl = null; // directory URL of the loaded quiz JSON file
// Supabase row UUID — only set for DB-backed quizzes (via quiz:db_id meta tag).
// null for local/manifest-only quizzes. Report button is gated on this.
let quizDbId = null;

// === Performance: Debounce helpers ===
let renderNavDebounce = null;
let saveStateDebounce = null;

// Bug 2 Fix: track which question card was last interacted with so that
// renderAllQuestionsVertical() only rebuilds that specific card instead of
// replacing every card (which would reset all media playback).
let lastChangedIdx = null;

// Bug 3 Fix: media timestamps loaded from saved state, applied after first render.
let pendingMediaTimestamps = null;

// Pagination media cache: stores { url -> { time, paused } } per question index
// so that navigating away from a question and coming back restores the exact
// playback position. Session-only (Map is cleared on quiz restart/finish).
const paginationMediaCache = new Map();

// === DOM Elements (cached references) ===
const els = {
  title: document.getElementById("quizTitle"),
  progressFill: document.getElementById("progressFill"),
  progressText: document.getElementById("progressText"),
  questionContainer: document.getElementById("questionContainer"),
  timer: document.getElementById("timer"),
  timerBadge: document.getElementById("timerBadge"),
  prevBtn: document.getElementById("prevBtn"),
  nextBtn: document.getElementById("nextBtn"),
  finishBtn: document.getElementById("finishBtn"),
  restartBtn: document.getElementById("restartBtn"),
  exitBtn: document.getElementById("exitBtn"),
  statsBar: document.getElementById("statsBar"),
  statLevel: document.getElementById("statLevel"),
  statPoints: document.getElementById("statPoints"),
  statStreak: document.getElementById("statStreak"),
  viewToggle: document.getElementById("viewToggle"),
  viewIcon: document.getElementById("viewIcon"),
  viewText: document.getElementById("viewText"),
  quizViewStyleSection: document.getElementById("quizViewStyleSection"),
  quizViewStyleDivider: document.getElementById("quizViewStyleDivider"),
  quizViewStylePagination: document.getElementById("quizViewStylePagination"),
  quizViewStyleVertical: document.getElementById("quizViewStyleVertical"),
  quizSource: document.getElementById("quizSource"),
  quizInfoBtn: document.getElementById("quizInfoBtn"),
  quizInfoDialog: document.getElementById("quizInfoDialog"),
};

// === Quiz Info Dialog: open / close wiring ===
// The dialog is a shell (#quizInfoDialog) populated on-demand by
// populateInfoDialog() in init() once metaData is available.
(function initInfoDialog() {
  const btn = els.quizInfoBtn;
  const dialog = els.quizInfoDialog;
  if (!btn || !dialog) return;

  btn.addEventListener("click", () => {
    if (typeof dialog.showModal === "function") dialog.showModal();
  });

  // Close on backdrop click
  dialog.addEventListener("click", (e) => {
    const rect = dialog.getBoundingClientRect();
    const isBackdrop =
      e.clientX < rect.left ||
      e.clientX > rect.right ||
      e.clientY < rect.top ||
      e.clientY > rect.bottom;
    if (isBackdrop) dialog.close();
  });
})();

// === Quiz Password Lock: teacher-enforced access gate ===
// Used by init() when metaData.password is present. Resolves `true` once the
// student enters the correct password, `false` if they cancel out. While
// shown, no quiz content (questions, info dialog data already populated
// elsewhere) is rendered — init() awaits this before doing anything else.
function isStoredPasswordHash(value) {
  return typeof value === "string" && /^[a-f0-9]{64}$/i.test(value);
}

async function sha256Hex(text) {
  const buf = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(text),
  );
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function quizPasswordMatches(input, stored) {
  if (!stored) return false;
  if (isStoredPasswordHash(stored)) {
    return (await sha256Hex(input)) === stored.toLowerCase();
  }
  return String(input) === String(stored);
}

function promptForQuizPassword(correctPassword) {
  return new Promise((resolve) => {
    let dialog = document.getElementById("quizPasswordDialog");
    if (!dialog) {
      document.body.insertAdjacentHTML(
        "beforeend",
        `
        <dialog class="quiz-password-dialog" id="quizPasswordDialog" aria-labelledby="quizPasswordDialogTitle">
          <form class="quiz-password-dialog-inner" id="quizPasswordForm">
            <div class="quiz-password-dialog-header">
              <h2 id="quizPasswordDialogTitle">هذا الإختبار محمي بكلمة سر</h2>
            </div>
            <div class="quiz-password-dialog-body">
              <p class="quiz-password-dialog-hint">يرجى إدخال كلمة السر التي زودك بها المعلم للوصول إلى هذا الامتحان.</p>
              <input type="password" id="quizPasswordInput" class="quiz-password-input"
                     placeholder="كلمة السر" autocomplete="off" aria-label="كلمة السر">
              <p class="quiz-password-error" id="quizPasswordError" role="alert" hidden>كلمة السر غير صحيحة. حاول مرة أخرى.</p>
            </div>
            <div class="quiz-password-dialog-actions">
              <button type="button" class="quiz-password-cancel-btn" id="quizPasswordCancel">الصفحة الرئيسية</button>
              <button type="submit" class="quiz-password-submit-btn" id="quizPasswordSubmit">دخول</button>
            </div>
          </form>
        </dialog>
      `,
      );
      dialog = document.getElementById("quizPasswordDialog");
    }

    const form = dialog.querySelector("#quizPasswordForm");
    const input = dialog.querySelector("#quizPasswordInput");
    const errorEl = dialog.querySelector("#quizPasswordError");
    const cancelBtn = dialog.querySelector("#quizPasswordCancel");

    // Reset state for this attempt (dialog may be reused across navigations).
    input.value = "";
    errorEl.hidden = true;
    dialog.classList.remove("shake");

    const cleanup = () => {
      form.removeEventListener("submit", onSubmit);
      cancelBtn.removeEventListener("click", onCancel);
      dialog.removeEventListener("cancel", onNativeCancel);
    };

    const onSubmit = async (e) => {
      e.preventDefault();
      const ok = await quizPasswordMatches(input.value, correctPassword);
      if (ok) {
        cleanup();
        dialog.close();
        resolve(true);
      } else {
        errorEl.hidden = false;
        input.value = "";
        input.focus();
        // Small shake animation to signal the wrong attempt without being
        // disruptive — purely cosmetic, no information about the password
        // itself is ever revealed.
        dialog.classList.remove("shake");
        // Force reflow so the animation can restart on consecutive wrong tries.
        void dialog.offsetWidth;
        dialog.classList.add("shake");
      }
    };

    const onCancel = () => {
      cleanup();
      dialog.close();
      resolve(false);
    };

    // Block Escape/backdrop dismissal from silently granting access: treat
    // a native "cancel" event (Escape key) the same as pressing the Cancel
    // button — it does not unlock the quiz.
    const onNativeCancel = (e) => {
      e.preventDefault();
      onCancel();
    };

    form.addEventListener("submit", onSubmit);
    cancelBtn.addEventListener("click", onCancel);
    dialog.addEventListener("cancel", onNativeCancel);

    if (typeof dialog.showModal === "function") {
      dialog.showModal();
    } else {
      // Extremely old browsers without <dialog> support: fail safe by
      // denying access rather than silently rendering quiz content.
      resolve(false);
      return;
    }
    input.focus();
  });
}

window.finishEarly = () => finish();
window.restartQuiz = () => restart(); // Not implemented
window.exitQuiz = () => exit();
window.prevQuestion = () => nav(-1);
window.nextQuestion = () => nav(1);

// Vertical style: select option for a specific question
window.handleSelectForQuestion = (qIdx, optIdx) => {
  if (lockedQuestions[qIdx]) return;

  const q = questions[qIdx];
  const isMultiple = isMultiSelectQuestion(q);

  if (isMultiple) {
    // Multiple selection: toggle the checkbox
    if (!Array.isArray(userAnswers[qIdx])) {
      userAnswers[qIdx] = [];
    }
    const answerArray = userAnswers[qIdx];
    const pos = answerArray.indexOf(optIdx);
    if (pos > -1) {
      answerArray.splice(pos, 1);
    } else {
      answerArray.push(optIdx);
    }
  } else {
    userAnswers[qIdx] = optIdx;
  }

  lastChangedIdx = qIdx; // Bug 2 Fix: only rebuild this card
  saveStateDebounced();
  renderQuestion();
  renderMenuNavigationDebounced();
  maybeAutoSubmit();
};

// Vertical style: تحقق من الإجابة for a specific question
window.checkAnswerForQuestion = (qIdx) => {
  const q = questions[qIdx];
  const isEssay = isEssayQuestion(q);
  if (isEssay) {
    const textarea = document.getElementById(`essayInput-${qIdx}`);
    if (!textarea || !textarea.value.trim()) return;
  } else {
    const userAnswer = userAnswers[qIdx];
    if (userAnswer === undefined) return;
    // For multiple choice, ensure answer exists (could be empty array)
    if (Array.isArray(userAnswer) && userAnswer.length === 0) return;
  }
  lastChangedIdx = qIdx; // Bug 2 Fix: only rebuild this card
  lockedQuestions[qIdx] = true;
  saveStateDebounced();
  renderQuestion();
  renderMenuNavigationDebounced();
  updateNav();
};

// Vertical style: essay input for a specific question
window.handleEssayInputForQuestion = (qIdx) => {
  if (lockedQuestions[qIdx]) return;
  const textarea = document.getElementById(`essayInput-${qIdx}`);
  if (textarea) {
    userAnswers[qIdx] = textarea.value;
    saveStateDebounced();
    const checkBtn = textarea
      .closest(".question-card")
      ?.querySelector(".check-answer-btn");
    if (checkBtn) checkBtn.disabled = !textarea.value.trim();
  }
};

// === Helper: HTML Escaping ===
const escapeHtml = (unsafe) => {
  if (unsafe === null || unsafe === undefined) return "";
  return String(unsafe)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
};

// === Helper: Get the model answer for an essay question ===
const getEssayAnswer = (q) => q.answer ?? "";

// Fix 2: Removed the automatic >400-char heuristic that previously
// promoted long questions into a passage/large-card layout.
// Large format now only applies when the question has an explicit
// reading passage — media is inline in q.q now, so it no longer factors in.
const isLargeFormatQuestion = (q) => !!q?.passage;

// Media URL resolution, MIME sniffing, YouTube detection, and the bare
// <audio>/<video> element renderer now live in the shared media-resolve.js
// module (also used by result.js and by markdown.js's inline ![audio]/
// ![video] tag renderer, so there's a single source of truth instead of
// three diverging copies). Thin wrappers below bind the module's
// `baseUrl` parameter to this page's `quizBaseUrl` so existing call sites
// in this file don't need to change.
const getMediaUrlCandidates = (url) =>
  _getMediaUrlCandidates(url, quizBaseUrl);
const resolveMediaUrl = (url) => _resolveMediaUrl(url, quizBaseUrl);
const renderMediaElement = (tag, className, mediaUrl) =>
  _renderMediaElement(tag, className, mediaUrl, quizBaseUrl);

// Legacy per-question q.image/q.audio/q.video fields and their dedicated
// renderers (renderQuestionImage/Audio/Video) have been removed — all
// question media is now authored as inline <img>/<audio>/<video> tags
// inside q.q (and q.passage), rendered by renderMarkdown() itself (see
// markdown.js's "Step -1: Raw HTML media tags"), which reuses the same
// .media-container/skeleton/candidate-retry machinery below. renderQuestionMedia
// is kept as a no-op so the two card-build call sites (which still expect a
// separate mediaHTML string to place outside the reloadable/patchable
// region) don't need restructuring.
const renderQuestionMedia = (_q, _resizeKey) => "";

const renderReadingPassage = (passage) => {
  if (!passage) return "";
  // The passage wrapper and per-element direction classes are handled
  // entirely by renderMarkdown (via the ```passage``` fence) and the
  // RTL/LTR engine embedded in it. No wrapper or alignClass needed here.
  return `<div class="reading-passage" role="region" aria-label="Reading passage">${renderMarkdown(passage, { mediaBaseUrl: quizBaseUrl })}</div>`;
};

const applyMediaSrc = (media, url) => {
  // Add cache-busting to each candidate URL to bypass stale service worker cache
  const urlWithCacheBust = url
    ? `${url}${url.includes("?") ? "&" : "?"}_cb=${Date.now()}`
    : url;
  media.src = urlWithCacheBust;
  const source = media.querySelector("source");
  if (source) source.src = urlWithCacheBust;
  if (media.tagName !== "IMG") media.load();
};

const initMediaSkeletons = (root = document) => {
  initMediaResize(root);
  root.querySelectorAll(".media-container").forEach((container) => {
    const media = container.querySelector("img, audio, video");
    const skeleton = container.querySelector(".media-skeleton");
    if (!media || !skeleton) return;

    let candidates = [];
    try {
      candidates = JSON.parse(media.dataset.mediaCandidates || "[]");
    } catch {
      candidates = getMediaUrlCandidates(media.dataset.mediaRaw || media.src);
    }
    if (!candidates.length) candidates = [media.src];

    // Find current candidate index by comparing base URLs (without cache-bust param)
    const currentUrl = media.src;
    const currentBaseUrl = currentUrl ? currentUrl.split("?")[0] : "";
    let candidateIdx = Math.max(
      0,
      candidates.findIndex(
        (url) => url === currentBaseUrl || url === currentUrl,
      ),
    );

    const reveal = () => {
      skeleton.classList.add("media-skeleton--hidden");
      media.classList.add("media-loaded");
    };

    const showError = () => {
      skeleton.classList.remove("media-skeleton--hidden");
      skeleton.classList.add("media-skeleton--error");
      skeleton.innerHTML =
        '<span class="media-error">تعذّر تحميل الوسائط. تحقق من المسار أو الرابط.</span>';
      console.warn(
        `[Media] Failed to load all candidates for: ${media.dataset.mediaRaw}`,
      );
    };

    const tryNextCandidate = () => {
      candidateIdx += 1;
      if (candidateIdx < candidates.length) {
        console.log(
          `[Media] Trying candidate ${candidateIdx}: ${candidates[candidateIdx]}`,
        );
        applyMediaSrc(media, candidates[candidateIdx]);
        return true;
      }
      showError();
      return false;
    };

    if (media.tagName === "IMG") {
      const onLoad = () => reveal();
      const onError = () => {
        if (!tryNextCandidate()) return;
        media.addEventListener("load", onLoad, { once: true });
        media.addEventListener("error", onError, { once: true });
      };
      if (media.complete && media.naturalWidth > 0) {
        reveal();
      } else {
        media.addEventListener("load", onLoad, { once: true });
        media.addEventListener("error", onError, { once: true });
      }
      return;
    }

    // Audio/Video specific handling
    const onMediaReady = () => {
      if (media.readyState >= 1) reveal();
    };
    const onMediaError = () => {
      console.warn(`[Media] Error loading: ${media.src}`);
      if (!tryNextCandidate()) return;
      // Reset listeners for next candidate
      media.addEventListener("loadedmetadata", onMediaReady, { once: true });
      media.addEventListener("canplay", onMediaReady, { once: true });
      media.addEventListener("error", onMediaError, { once: true });
    };

    media.addEventListener("loadedmetadata", onMediaReady, { once: true });
    media.addEventListener("loadeddata", onMediaReady, { once: true });
    media.addEventListener("canplay", onMediaReady, { once: true });
    media.addEventListener("error", onMediaError, { once: true });

    // Initial check
    onMediaReady();

    // Catch late metadata (innerHTML can finish loading before listeners attach)
    requestAnimationFrame(() => {
      if (!skeleton.classList.contains("media-skeleton--hidden"))
        onMediaReady();
    });

    // Increased timeout to handle slow network connections better
    setTimeout(() => {
      if (
        !skeleton.classList.contains("media-skeleton--hidden") &&
        !skeleton.classList.contains("media-skeleton--error") &&
        media.readyState >= 1
      ) {
        reveal();
      }
    }, 500);
  });
};

// === Feature: User-Resizable Media ===
// Lets the user drag-resize images, audio players, videos, and YouTube
// iframes via the native CSS `resize` handle. Sizes are persisted per
// exam+question+media-type so they survive re-renders, navigation, and
// page reloads.
const RESIZE_STORAGE_PREFIX = "quiz_media_size_";

const getMediaSizeStorageKey = (resizeKey) =>
  `${RESIZE_STORAGE_PREFIX}${examId}_${resizeKey}`;

const loadSavedMediaSize = (resizeKey) => {
  try {
    const raw = localStorage.getItem(getMediaSizeStorageKey(resizeKey));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (
      parsed &&
      typeof parsed.width === "number" &&
      typeof parsed.height === "number"
    ) {
      return parsed;
    }
  } catch {
    /* ignore malformed/legacy entries */
  }
  return null;
};

const saveMediaSize = (resizeKey, width, height) => {
  try {
    localStorage.setItem(
      getMediaSizeStorageKey(resizeKey),
      JSON.stringify({ width, height }),
    );
  } catch {
    /* localStorage may be full or unavailable; resizing still works for this session */
  }
};

// Debounce writes so dragging the resize handle doesn't hammer localStorage
const resizeSaveDebounces = new Map();
const saveMediaSizeDebounced = (resizeKey, width, height) => {
  clearTimeout(resizeSaveDebounces.get(resizeKey));
  resizeSaveDebounces.set(
    resizeKey,
    setTimeout(() => saveMediaSize(resizeKey, width, height), 400),
  );
};

// ── initMediaResize ───────────────────────────────────────────────────────────
// Fix A: Aspect-ratio-locked resizing via custom corner drag handles.
//         The original aspect ratio is captured the first time a drag starts
//         (or from the saved size). All four handles produce proportional
//         scaling so the media is never distorted.
//
// Fix B: Media is centered by its .media-center-wrap flex parent. The
//         container does NOT default to 100% width once a saved/dragged size
//         is applied — it becomes exactly <n>px wide and the flex parent
//         keeps it centered.
//
// Fix C: Dragging any handle resizes symmetrically from the center: the
//         container width grows/shrinks by 2× the pointer delta so both sides
//         move equally. Because the flex parent is justify-content:center the
//         visual center never shifts.
const initMediaResize = (root = document) => {
  root
    .querySelectorAll(".media-container[data-resize-key]")
    .forEach((container) => {
      if (container.dataset.resizeInit) return; // avoid double-binding
      container.dataset.resizeInit = "1";
      container.classList.add("resizable-media");

      const resizeKey = container.dataset.resizeKey;
      const isAudio = container.classList.contains("question-audio-container");

      // ── Inject handles appropriate for this media type ─────────────────
      // Audio is 1-D (fixed height) → only E/W side handles make sense.
      // Images/video/iframes get all 8 (4 corners + 4 sides, sides hidden on touch).
      const handlesToInject = isAudio
        ? ["e", "w"]
        : ["nw", "ne", "sw", "se", "n", "s", "e", "w"];

      handlesToInject.forEach((dir) => {
        if (container.querySelector(`.resize-handle--${dir}`)) return;
        const h = document.createElement("div");
        h.className = `resize-handle resize-handle--${dir}`;
        h.setAttribute("aria-hidden", "true");
        container.appendChild(h);
      });

      // ── Restore saved size ─────────────────────────────────────────────
      const saved = loadSavedMediaSize(resizeKey);
      if (saved) {
        container.style.width = `${saved.width}px`;
        if (!isAudio) container.style.height = `${saved.height}px`;
      }

      // ── Drag-resize logic ──────────────────────────────────────────────
      container.querySelectorAll(".resize-handle").forEach((handle) => {
        handle.addEventListener("pointerdown", (eDown) => {
          eDown.preventDefault();
          eDown.stopPropagation();
          handle.setPointerCapture(eDown.pointerId);
          handle.classList.add("is-active");
          document.body.classList.add("is-resizing-media");

          const startW = container.offsetWidth;
          const startH = container.offsetHeight;
          const startX = eDown.clientX;
          const startY = eDown.clientY;

          // ── Aspect ratio ───────────────────────────────────────────────
          // Priority: natural media dimensions > explicit 16:9 for iframes
          // (YouTube). Never fall back to the rendered box size — that bakes
          // in any previous distortion as the new "correct" ratio.
          const mediaEl = container.querySelector("img, video, iframe, audio");
          const isIframe = mediaEl instanceof HTMLIFrameElement;
          const aspectRatio =
            mediaEl instanceof HTMLImageElement && mediaEl.naturalWidth > 0
              ? mediaEl.naturalWidth / mediaEl.naturalHeight
              : mediaEl instanceof HTMLVideoElement && mediaEl.videoWidth > 0
                ? mediaEl.videoWidth / mediaEl.videoHeight
                : isIframe
                  ? 16 / 9 // YouTube and other embeds are always 16:9
                  : startH > 0
                    ? startW / startH
                    : 16 / 9;

          const minW = isAudio ? 200 : 120;
          const minH = isAudio ? 52 : 80;
          const maxW = container.parentElement
            ? container.parentElement.clientWidth
            : window.innerWidth;

          const onMove = (eMove) => {
            const dxRaw = eMove.clientX - startX;
            const dyRaw = eMove.clientY - startY;

            const cl = handle.classList;
            const isCorner =
              cl.contains("resize-handle--nw") ||
              cl.contains("resize-handle--ne") ||
              cl.contains("resize-handle--sw") ||
              cl.contains("resize-handle--se");
            const isSideE = cl.contains("resize-handle--e");
            const isSideW = cl.contains("resize-handle--w");
            const isSideN = cl.contains("resize-handle--n");
            const isSideS = cl.contains("resize-handle--s");

            // Positive dx/dy = growing
            const isRight =
              cl.contains("resize-handle--ne") ||
              cl.contains("resize-handle--se") ||
              isSideE;
            const isBottom =
              cl.contains("resize-handle--sw") ||
              cl.contains("resize-handle--se") ||
              isSideS;

            const dx = isRight ? dxRaw : -dxRaw;
            const dy = isBottom ? dyRaw : -dyRaw;

            if (isAudio) {
              // Audio: width-only, height is always fixed by the browser.
              const newW = Math.max(minW, Math.min(maxW, startW + dx * 2));
              container.style.width = `${newW}px`;
              saveMediaSizeDebounced(resizeKey, Math.round(newW), startH);
              return;
            }

            let newW, newH;

            if (isCorner) {
              // Use the dominant axis to drive scale; other follows ratio.
              const scaleByX = (startW + dx * 2) / startW;
              const scaleByY = (startH + dy * 2) / startH;
              const scale = Math.abs(dx) >= Math.abs(dy) ? scaleByX : scaleByY;
              newW = Math.max(minW, Math.min(maxW, startW * scale));
              newH = newW / aspectRatio;
            } else if (isSideE || isSideW) {
              // Horizontal drag → width drives, height follows ratio.
              newW = Math.max(minW, Math.min(maxW, startW + dx * 2));
              newH = newW / aspectRatio;
            } else {
              // Vertical drag (N/S) → height drives, width follows ratio.
              newH = Math.max(minH, startH + dy * 2);
              newW = Math.min(maxW, newH * aspectRatio);
              if (newW < minW) {
                newW = minW;
                newH = newW / aspectRatio;
              }
            }

            // Floor clamp on height.
            if (newH < minH) {
              newH = minH;
              newW = newH * aspectRatio;
            }

            container.style.width = `${newW}px`;
            container.style.height = `${newH}px`;
            saveMediaSizeDebounced(
              resizeKey,
              Math.round(newW),
              Math.round(newH),
            );
          };

          const onUp = () => {
            handle.classList.remove("is-active");
            document.body.classList.remove("is-resizing-media");
            handle.removeEventListener("pointermove", onMove);
            handle.removeEventListener("pointerup", onUp);
            handle.removeEventListener("pointercancel", onUp);
          };

          handle.addEventListener("pointermove", onMove);
          handle.addEventListener("pointerup", onUp);
          handle.addEventListener("pointercancel", onUp);
        });
      });
    });
};

function updateGamificationStats() {
  const userData = gameEngine.getUserData();
  const levelInfo = gameEngine.calculateLevel(userData.totalPoints);

  if (els.statLevel) els.statLevel.textContent = `Lv ${levelInfo.level || 0}`;
  if (els.statPoints)
    els.statPoints.textContent = `${userData.totalPoints || 0} pts`;
  if (els.statStreak) {
    const streak = userData.streaks?.currentDaily || 0;
    els.statStreak.textContent = `${streak} day${streak !== 1 ? "s" : ""}`;
  }
}

// === View Toggle ===
function toggleView() {
  viewMode = viewMode === "grid" ? "list" : "grid";
  localStorage.setItem("quiz_view_mode", viewMode);

  if (els.viewIcon && els.viewText) {
    if (viewMode === "grid") {
      els.viewIcon.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-list-icon lucide-list"><path d="M3 5h.01"/><path d="M3 12h.01"/><path d="M3 19h.01"/><path d="M8 5h13"/><path d="M8 12h13"/><path d="M8 19h13"/></svg>`;
      els.viewText.textContent = "شكل القائمة";
    } else {
      els.viewIcon.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-layout-grid-icon lucide-layout-grid"><rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/></svg>`;
      els.viewText.textContent = "شكل الأيقونات";
    }
  }

  renderMenuNavigation();
}

// === Quiz Display Style Switcher (pagination vs vertical) ===
// Reflects the current quizStyle onto the sidebar's segmented toggle buttons.
function updateQuizViewStyleButtons() {
  if (els.quizViewStylePagination) {
    els.quizViewStylePagination.setAttribute(
      "aria-pressed",
      quizStyle === "pagination" ? "true" : "false",
    );
  }
  if (els.quizViewStyleVertical) {
    els.quizViewStyleVertical.setAttribute(
      "aria-pressed",
      quizStyle === "vertical" ? "true" : "false",
    );
  }
}

// Switches between "pagination" (one question per page) and "vertical" (all
// questions in a scrollable list) on the fly, preserving the user's exact
// progress (currentIdx, answers, locks). Persists the choice both to the
// user profile and to localStorage (mirroring how init() reads it back).
window.switchQuizStyle = function switchQuizStyle(newStyle) {
  if (newStyle !== "pagination" && newStyle !== "vertical") return;
  if (newStyle === quizStyle) return;

  // Snapshot media state from whichever view we're leaving so playback
  // position isn't lost across the switch.
  if (quizStyle !== "vertical") snapshotPaginationMedia(currentIdx);

  quizStyle = newStyle;

  if (userProfile && userProfile.setQuizStyle) {
    userProfile.setQuizStyle(quizStyle);
  }
  try {
    localStorage.setItem("quiz_style", quizStyle);
  } catch (_) {
    /* non-fatal — localStorage unavailable (e.g. private mode) */
  }

  updateQuizViewStyleButtons();

  if (els.nextBtn) els.nextBtn.style.display = quizStyle === "vertical" ? "none" : "";
  if (els.prevBtn) els.prevBtn.style.display = quizStyle === "vertical" ? "none" : "";

  // Force a full rebuild rather than a partial patch, since we're switching
  // the entire rendering mode, not answering a question.
  lastChangedIdx = null;
  els.questionContainer.classList.remove("vertical-style");

  if (quizStyle === "vertical") {
    renderAllQuestionsVertical({ smoothScroll: true });
  } else {
    // Ensure renderQuestion() treats this as "navigated to a different
    // question" (full rebuild) rather than an in-place patch.
    els.questionContainer.innerHTML = "";
    renderQuestion();
  }

  renderMenuNavigation();
};

// === Breadcrumb Logic ===
function updateBreadcrumb(meta) {
  if (!meta.path) return { courseName: "", fullBreadcrumb: "" };

  // const parts = meta.path.split("/");
  let rawPath = meta.path;
  try {
    const qIdx = rawPath.indexOf("?");
    if (qIdx !== -1) {
      const params = new URLSearchParams(rawPath.slice(qIdx + 1));
      const p = params.get("path");
      if (p) rawPath = decodeURIComponent(p);
    }
  } catch (_) { }
  const parts = rawPath.split("/");
  let courseName = "";
  let intermediate = [];

  const quizzesIdx = parts.indexOf("quizzes");
  if (quizzesIdx !== -1 && quizzesIdx + 4 < parts.length) {
    courseName = parts[quizzesIdx + 4];
    if (quizzesIdx + 5 < parts.length - 1) {
      intermediate = parts.slice(quizzesIdx + 5, parts.length - 1);
    }
  } else if (parts.length >= 3) {
    courseName = parts[parts.length - 2];
  }

  if (!courseName) courseName = meta.category || "";

  // The full, untruncated trail — e.g. "IELTS Exams → Cambridge IELTS 2020 → Test 2"
  const fullBreadcrumb =
    intermediate.length > 0
      ? `${courseName} → ${intermediate.join(" → ")}`
      : courseName;

  if (els.breadcrumb) {
    const isMobile = window.innerWidth <= 768;
    const limit = isMobile ? 40 : 60;

    let breadcrumbText = "";

    if (intermediate.length > 0) {
      const fullString = `${courseName} → ${intermediate.join(" → ")}`;
      if (fullString.length > limit) {
        breadcrumbText = `${courseName} → ... `;
      } else {
        breadcrumbText = fullString;
      }
    } else {
      breadcrumbText = `${courseName} `;
    }

    els.breadcrumb.textContent = `Course: ${breadcrumbText}`;
  }

  return { courseName, fullBreadcrumb };
}

// === OPTIMIZED: Load exam JSON with caching ===
// === Helper: safely format stats.questionTypes for display ===
// Root cause of "stats fail to appear for static quizzes": loadExamModule
// (below) never read the `stats` field out of the fetched quiz JSON at all,
// so module.stats was always undefined and questionTypes was silently lost
// before it ever reached the info dialog — even when the quiz file legitimately
// had it. That's fixed below by actually carrying `stats` through.
// This helper additionally guards a real (if narrower) crash: when stats
// exists but questionTypes doesn't (stats = {}), `stats?.questionTypes.join`
// throws — the `?.` only short-circuits the `.questionTypes` read, not the
// `.join()` call chained after it. It also tolerates questionTypes already
// being a plain string (some hand-authored quizzes store it that way).
const formatQuestionTypes = (stats) => {
  const qt = stats?.questionTypes;
  if (!qt) return null;
  if (Array.isArray(qt)) return qt.length ? qt.join(" · ") : null;
  return String(qt) || null;
};

async function loadExamModule(config) {
  // Check cache first
  if (examModuleCache.has(config.id)) {
    console.log(`[Quiz] Using cached exam: ${config.id}`);
    return examModuleCache.get(config.id);
  }

  console.log(`[Quiz] Loading exam: ${config.id}`);
  const module = await loadFullQuizData(config);

  // Cache it
  examModuleCache.set(config.id, module);

  // Limit cache size (LRU-style)
  if (examModuleCache.size > MAX_CACHE_SIZE) {
    const firstKey = examModuleCache.keys().next().value;
    examModuleCache.delete(firstKey);
  }

  return module;
}

async function init() {
  // ── Bug 2 Fix: reset all in-flight state before (re-)initialising ─────────
  // init() may be called a second time via the popstate listener when the user
  // presses the back button from the results page.  Without resetting, the
  // previous timer and answer state would bleed into the new session.
  resetQuizState();

  const params = new URLSearchParams(window.location.search);

  // ── Bug 2 Fix: safe param extraction ─────────────────────────────────────
  // params.get("id") returns null when the parameter is absent.
  // decodeURIComponent(null) produces the string "null", which is truthy and
  // bypasses the !examId guard below — leading to a confusing "Exam not found"
  // error.  Guard against null explicitly before decoding.
  //
  // SSR fallback: Under the /quiz/:id URL structure, there is no ?id= query
  // param. The server-side render-quiz function injects a
  // <meta name="quiz:id" content="…"> tag instead. Fall back to that, then
  // to extracting the ID from the /quiz/:id pathname as a last resort.
  // (Also matches the old /q/:id form for anyone who still has that URL
  // cached client-side, e.g. a service-worker response.)
  let rawId = params.get("id");
  if (rawId === null) {
    const metaEl = document.querySelector('meta[name="quiz:id"]');
    rawId = metaEl ? metaEl.getAttribute("content") : null;
  }
  if (rawId === null) {
    const pathMatch = window.location.pathname.match(/^\/(?:quiz|q)\/(.+)/);
    if (pathMatch) rawId = decodeURIComponent(pathMatch[1]);
  }
  examId = rawId !== null ? decodeURIComponent(rawId) : null;

  // Read the Supabase row UUID injected by render-quiz.js for DB-backed quizzes.
  // This is null for local/manifest-only quizzes — report button is gated on it.
  const dbIdMeta = document.querySelector('meta[name="quiz:db_id"]');
  quizDbId = dbIdMeta ? dbIdMeta.getAttribute("content") : null;

  // ── Quiz Mode ────────────────────────────────────────────────────────────
  // Mode is intentionally NOT in the URL (links stay mode-agnostic).
  // Each device/user gets its own mode from their profile / localStorage.
  quizMode = userProfile.getProfile().defaultQuizMode;

  const startTime = localStorage.getItem("quiz_start_time");

  // User-created quizzes still use ?type=user (URL-only, unchanged)
  const quizType = params.get("type");
  const startAt = params.get("startAt");

  // Validate quiz data exists
  if (!examId && !quizType) {
    console.error("No quiz selected");
    _alert("لم يتم اختيار امتحان. سيتم توجيهك للصفحة الرئيسية.");
    window.location.href = "/";
    return;
  }

  // Validate start time (prevent stale quiz sessions - max 24 hours)
  if (startTime && examId) {
    const now = Date.now();
    const maxSessionAge = 24 * 60 * 60 * 1000; // 24 hours
    if (now - parseInt(startTime) > maxSessionAge) {
      console.warn("Quiz session expired");
      localStorage.removeItem("quiz_start_time");
      _alert("انتهت صلاحية الجلسة. يرجى بدء الامتحان من جديد.");
      window.location.href = "/";
      return;
    }
  }

  // Load saved view mode (grid/list nav style — unaffected by teacher overrides)
  const savedView = localStorage.getItem("quiz_view_mode");
  if (savedView) viewMode = savedView;

  // Update view toggle button
  if (els.viewIcon && els.viewText) {
    if (viewMode === "grid") {
      els.viewIcon.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-list-icon lucide-list"><path d="M3 5h.01"/><path d="M3 12h.01"/><path d="M3 19h.01"/><path d="M8 5h13"/><path d="M8 12h13"/><path d="M8 19h13"/></svg>`;
      els.viewText.textContent = "شكل القائمة";
    } else {
      els.viewIcon.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-layout-grid-icon lucide-layout-grid"><rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/></svg>`;
      els.viewText.textContent = "شكل الأيقونات";
    }
  }

  try {
    // -----------------------------------------------------------
    // BRANCHING LOGIC: Check if this is a User Created Quiz or Standard Exam
    // -----------------------------------------------------------

    if (quizType === "user") {
      // === LOGIC FOR USER QUIZ ===
      let userQuizData = sessionStorage.getItem("active_user_quiz");

      // ── Bug 2 Fix: recover from localStorage when sessionStorage is empty ──
      // sessionStorage is tab-scoped and survives within a session.  However,
      // pressing the browser back button from the results page causes a full
      // page reload of quiz.html?id=…&type=user.  If the session storage item
      // was cleared (e.g. another quiz was opened in the same tab), the quiz
      // would show "Quiz not found!" and redirect to root instead of reloading.
      // As a fallback, scan the localStorage user_quizzes array for a matching
      // entry and restore it into sessionStorage so the quiz can continue.
      if (!userQuizData && examId) {
        try {
          const allUserQuizzes = JSON.parse(
            localStorage.getItem("user_quizzes") || "[]",
          );
          const recovered = allUserQuizzes.find((q) => q.id === examId);
          if (recovered) {
            userQuizData = JSON.stringify(recovered);
            // Restore so subsequent page interactions keep working normally.
            sessionStorage.setItem("active_user_quiz", userQuizData);
          }
        } catch (e) {
          console.warn(
            "[Quiz] Could not recover user quiz from localStorage:",
            e,
          );
        }
      }

      if (!userQuizData) {
        _alert("Quiz not found!");
        window.location.href = "/";
        return;
      }

      const userQuiz = JSON.parse(userQuizData);

      // Map user questions to ensure correct format, handling both old and new essay style
      questions = userQuiz.questions.map((q) => {
        const out = { q: q.q };
        if (q.passage) out.passage = q.passage;
        if (q.explanation) out.explanation = q.explanation;
        // Normalize essay: old 1-option → new answer field
        if (Array.isArray(q.options) && q.options.length === 1) {
          out.answer = q.options[0] ?? "";
        } else if (!Array.isArray(q.options) && q.answer !== undefined) {
          out.answer = q.answer;
        } else {
          out.options = q.options;
          if (q.correct !== undefined) out.correct = q.correct;
          if (q.multiSelect !== undefined) out.multiSelect = q.multiSelect;
        }
        return out;
      });

      // Support both old flat schema (title) and new nested schema (meta.title)
      metaData = {
        id: examId,
        title: userQuiz.meta?.title || userQuiz.title,
        category: "Your Quiz",
        createdAt: userQuiz.meta?.createdAt || null,
        path: userQuiz.meta?.path || null,
        description: userQuiz.meta?.description || null,
        source: userQuiz.meta?.source || null,
        author: userQuiz.meta?.author || null,
        author_handle: userQuiz.meta?.author_handle || null,
        author_id: userQuiz.meta?.author_id || null,
        view: userQuiz.meta?.view || null,
        mode: userQuiz.meta?.mode || null,
        password: userQuiz.meta?.password || null,
        questionTypes: formatQuestionTypes(userQuiz.stats),
      };
    } else {
      // === LOGIC FOR STANDARD EXAM (Original Code) ===
      const { examList } = await getManifest();
      const config = examList.find((e) => e.id === examId);

      if (!config) {
        _alert("Exam not found!");
        window.location.href = "/";
        return;
      }

      // Use optimized loader with caching
      const module = await loadExamModule(config);
      questions = module.questions;
      if (!quizDbId) {
        quizDbId = module.dbId || config.dbId || null;
      }
      quizBaseUrl = new URL("./", window.location.href).href;
      metaData = {
        id: config.id,
        title: config.title || "",
        category: config.category || "",
        createdAt: module.meta?.createdAt || null,
        path: module.meta?.path || null,
        description: module.meta?.description || null,
        source: module.meta?.source || null,
        author: module.meta?.author || null,
        author_handle: module.meta?.author_handle || null,
        author_id: module.meta?.author_id || null,
        view: module.meta?.view || null,
        mode: module.meta?.mode || null,
        password: module.meta?.password || config.password || null,
        questionTypes: formatQuestionTypes(module.stats),
      };
    }

    // -----------------------------------------------------------
    // SHARED LOGIC: UI Updates & Game Initialization
    // -----------------------------------------------------------

    // ── Teacher-enforced settings ───────────────────────────────────────────
    // meta.view / meta.mode, when present in the quiz JSON, STRICTLY override
    // whatever the student has locally configured (profile / localStorage).
    // The student's own preference is never consulted in that case — this is
    // intentionally not a "default", it's a hard override.
    let quizStyleForced = false;
    if (metaData.view === "pagination" || metaData.view === "vertical") {
      quizStyle = metaData.view;
      quizStyleForced = true;
    } else {
      quizStyle =
        userProfile && userProfile.getQuizStyle
          ? userProfile.getQuizStyle()
          : localStorage.getItem("quiz_style") || "pagination";
      if (quizStyle !== "vertical") quizStyle = "pagination";
    }

    // Wire up / reflect the sidebar's view-style switcher. When the teacher
    // forces a style via meta.view, hide the switcher entirely rather than
    // letting the student change it out from under that override.
    // Uses .onclick (not addEventListener) so re-running init() — e.g. the
    // popstate re-init path — safely replaces the handler instead of
    // stacking duplicate listeners on the same persistent DOM elements.
    if (els.quizViewStyleSection) {
      if (quizStyleForced) {
        els.quizViewStyleSection.style.display = "none";
        if (els.quizViewStyleDivider) els.quizViewStyleDivider.style.display = "none";
      } else {
        els.quizViewStyleSection.style.display = "";
        if (els.quizViewStyleDivider) els.quizViewStyleDivider.style.display = "";
        updateQuizViewStyleButtons();
        if (els.quizViewStylePagination) {
          els.quizViewStylePagination.onclick = () =>
            window.switchQuizStyle("pagination");
        }
        if (els.quizViewStyleVertical) {
          els.quizViewStyleVertical.onclick = () =>
            window.switchQuizStyle("vertical");
        }
      }
    }

    if (
      metaData.mode === "exam" ||
      metaData.mode === "practice" ||
      metaData.mode === "timed" ||
      metaData.mode === "timed_exam"
    ) {
      quizMode = metaData.mode;
    }

    if (quizStyle === "vertical") {
      if (els.nextBtn) els.nextBtn.style.display = "none";
      if (els.prevBtn) els.prevBtn.style.display = "none";
    }

    // ── Teacher-enforced password lock ──────────────────────────────────────
    // meta.password, when present, fully blocks access to the quiz content
    // (questions are never rendered) until the correct password is entered
    // in a dedicated pop-up dialog. Re-prompts on a wrong attempt; does not
    // give up access to any quiz data while locked.
    //
    // Shared memory with the home page's download-password gate: if the
    // user already verified this quiz's password there (this tab session),
    // skip the prompt entirely. Conversely, a password entered here is
    // remembered the same way, so returning to the home page to download
    // the same quiz won't ask again either.
    if (metaData.password) {
      if (!isDownloadPasswordVerified(examId)) {
        const unlocked = await promptForQuizPassword(metaData.password);
        if (!unlocked) {
          window.location.href = "/";
          return;
        }
        markDownloadPasswordVerified(examId);
      }
    }

    // Update page title
    document.title = metaData.title;

    // === Populate Quiz Info Dialog ===
    (async function populateInfoDialog() {
      const dialog = els.quizInfoDialog;
      if (!dialog) return;

      // Build the config for the shared HTML builder.
      // Use updateBreadcrumb to get the computed category name from the path.
      const { fullBreadcrumb } = updateBreadcrumb(metaData);

      const config = {
        id: metaData.id,
        title: metaData.title,
        description: metaData.description || null,
        // The breadcrumb gives the course name (المادة), while metaData.path
        // gives the raw file path for the المسار field in the builder.
        category: fullBreadcrumb || metaData.category || null,
        path: metaData.path || null,
        createdAt: metaData.createdAt || null,
        source: metaData.source || null,
        author: metaData.author || null,
        authorHandle: metaData.author_handle || null,
        authorId: metaData.author_id || null,
        mode: metaData.mode || null,
        view: metaData.view || null,
        questionTypes: metaData.questionTypes || null,
      };

      const authorIdentifier = config.authorId || config.authorHandle;
      let creatorProfile = null;
      if (authorIdentifier) {
        const type = config.authorId ? "id" : "handle";
        creatorProfile = await fetchCreatorProfile(authorIdentifier, type);
      }

      dialog.innerHTML = buildQuizInfoModalHtml(
        config,
        questions.length,
        creatorProfile,
      );

      // Wire up close button (rendered dynamically into the shell)
      const closeBtn = dialog.querySelector(".quiz-info-dialog-close");
      if (closeBtn) {
        closeBtn.addEventListener("click", () => dialog.close());
      }
    })();

    // Update Title UI
    if (els.title) {
      els.title.textContent = metaData.title || "Quiz";
      // Apply RTL/LTR direction to the title (it lives outside the
      // markdown pipeline so we call the engine directly).
      applyQuizTitleDirection();
    }

    // Setup Timer
    if (quizMode === "timed" || quizMode === "timed_exam") {
      timeRemaining = questions.length * 30;
    }

    // Setup State Restoration
    if (startAt !== null) {
      currentIdx = parseInt(startAt);
    } else {
      // Note: We use examId here. For user quizzes, ensure examId is unique or handles collision
      const saved = localStorage.getItem(`quiz_state_${examId}`);
      if (saved && quizMode === "practice") {
        const state = JSON.parse(saved);
        if (await _confirm("استئناف الامتحان؟")) {
          currentIdx = state.currentIdx || 0;
          userAnswers = state.userAnswers || {};
          lockedQuestions = state.lockedQuestions || {};
          timeElapsed = state.timeElapsed || 0;
          // Bug 3 Fix: store media timestamps to be applied after the first render
          pendingMediaTimestamps = state.mediaTimestamps || null;
        } else {
          localStorage.removeItem(`quiz_state_${examId}`);
        }
      }
    }

    // Initialize Game Engine
    updateGamificationStats();
    renderMenuNavigation();
    renderQuestion();
    // Bug 3 Fix: apply any saved media timestamps after the first render
    applyPendingMediaTimestamps();
    startTimer();

    // Global handlers
    window.handleSelect = (i) => handleSelect(i);
    window.handleEssayInput = () => handleEssayInput();
    window.checkAnswer = () => checkAnswer();
    window.toggleView = () => toggleView();
    window.toggleBookmark = () => {
      gameEngine.toggleBookmark(examId, currentIdx);
      renderQuestion();
      renderMenuNavigationDebounced();
    };
    window.toggleFlag = () => {
      gameEngine.toggleFlag(examId, currentIdx);
      renderQuestion();
      renderMenuNavigationDebounced();
    };
    window.toggleQuestionBookmark = (idx) => {
      gameEngine.toggleBookmark(examId, idx);
      renderMenuNavigationDebounced();
      if (idx === currentIdx) {
        renderQuestion();
      }
    };
    window.toggleQuestionFlag = (idx) => {
      gameEngine.toggleFlag(examId, idx);
      renderMenuNavigationDebounced();
      if (idx === currentIdx) {
        renderQuestion();
      }
    };

    window.reportQuestion = (idx) => {
      if (!quizDbId) return; // Should never be called without a DB quiz
      const q = questions[idx];
      openReportModal({
        quizId: quizDbId,
        questionIndex: idx,
        questionText: q?.question || q?.text || `سؤال رقم ${idx + 1}`,
        onSuccess: () => {
          // Re-render to update button state (active class)
          if (quizStyle === "vertical") {
            renderAllQuestionsVertical();
          } else {
            renderQuestion();
          }
        },
      });
    };

    window.shareQuestion = async () => {
      const questionCard =
        quizStyle === "vertical"
          ? document.getElementById(`q-${currentIdx}`)
          : document.querySelector(".question-card");
      if (!questionCard) return;

      try {
        if (!window.html2canvas) {
          showNotification("جاري التجهيز", "يتم تحضير الصورة للمشاركة", "info");
          await new Promise((resolve, reject) => {
            const script = document.createElement("script");
            script.src =
              "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js";
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
          });
        }

        // hide buttons temporarily for the screenshot
        const actions = questionCard.querySelector(".question-actions");
        if (actions) actions.style.display = "none";
        const checkBtn = questionCard.querySelector(".check-answer-btn");
        if (checkBtn) checkBtn.style.display = "none";

        const canvas = await html2canvas(questionCard, {
          backgroundColor: getComputedStyle(document.body).backgroundColor,
          scale: 2,
        });

        // restore buttons
        if (actions) actions.style.display = "";
        if (checkBtn) checkBtn.style.display = "";

        canvas.toBlob(async (blob) => {
          const file = new File([blob], "question-share.png", {
            type: "image/png",
          });
          if (
            navigator.share &&
            navigator.canShare &&
            navigator.canShare({ files: [file] })
          ) {
            await navigator.share({
              files: [file],
              title: "سؤال من الامتحان",
            });
          } else {
            // fallback download
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = "Basmagi Quiz Question.png";
            a.click();
            URL.revokeObjectURL(url);
            showNotification("تم", "تم تحميل صورة السؤال", "success");
          }
        });
      } catch (e) {
        console.error("Error sharing question", e);
        showNotification("خطأ", "حدث خطأ أثناء محاولة مشاركة السؤال", "error");
      }
    };

    window.copyCodeBlock = (btn) => {
      const wrapper = btn.closest(".code-block-wrapper");
      if (!wrapper) return;
      const codeEl = wrapper.querySelector("code");
      if (!codeEl) return;

      navigator.clipboard.writeText(codeEl.innerText).then(() => {
        const originalContent = btn.innerHTML;
        btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-icon lucide-check"><path d="M20 6 9 17l-5-5"/></svg>`;
        btn.classList.add("copied");
        setTimeout(() => {
          btn.innerHTML = originalContent;
          btn.classList.remove("copied");
        }, 2000);
      });
    };
    window.jumpToQuestion = (idx) => {
      // Snapshot current question's media state before leaving (pagination only).
      if (quizStyle !== "vertical") snapshotPaginationMedia(currentIdx);
      currentIdx = idx;
      saveStateDebounced();
      renderQuestion();
      renderMenuNavigationDebounced();

      const questionCard =
        quizStyle === "vertical"
          ? document.getElementById(`q-${idx}`)
          : document.querySelector(".question-card");
      if (questionCard) {
        questionCard.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    };

    /**
     * Bug fix: in vertical mode, `currentIdx` is only ever updated by
     * `nav()` / `jumpToQuestion()` (i.e. clicking prev/next or a menu
     * item) - it is never updated by scrolling. Since every question's
     * card is stacked in the DOM at once in vertical mode, a user who
     * scrolls down to question 5 without using next/prev leaves
     * `currentIdx` stuck at whatever it last was (usually 0), so
     * keyboard actions like Enter silently targeted the wrong question -
     * appearing to "only work on the first question on the page".
     *
     * This resolves the question a keyboard action should actually
     * target: whichever card currently contains focus (most precise -
     * matches e.g. an option just navigated to via Up/Down), falling
     * back to whichever vertical card's center is closest to the
     * viewport's center (matches what the user is actually looking at
     * while scrolling), falling back to `currentIdx` only if neither can
     * be determined.
     *
     * @returns {number}
     */
    function getActiveVerticalQuestionIndex() {
      const focusedCard = document.activeElement?.closest(
        "[data-question-index]",
      );
      if (focusedCard) {
        const idx = parseInt(focusedCard.dataset.questionIndex, 10);
        if (!Number.isNaN(idx)) return idx;
      }

      const cards = document.querySelectorAll(
        ".vertical-question-card[data-question-index]",
      );
      if (cards.length === 0) return currentIdx;

      const viewportCenter = window.innerHeight / 2;
      let closest = null;
      let closestDistance = Infinity;
      cards.forEach((card) => {
        const rect = card.getBoundingClientRect();
        if (rect.bottom < 0 || rect.top > window.innerHeight) return;
        const cardCenter = rect.top + rect.height / 2;
        const distance = Math.abs(cardCenter - viewportCenter);
        if (distance < closestDistance) {
          closestDistance = distance;
          closest = card;
        }
      });

      if (!closest) return currentIdx;
      const idx = parseInt(closest.dataset.questionIndex, 10);
      return Number.isNaN(idx) ? currentIdx : idx;
    }

    initKeyboardNav({
      onNext: () => nav(1),
      onPrev: () => nav(-1),
      onCheck: () => {
        if (quizMode === "exam" || quizMode === "timed_exam") return;
        if (quizStyle === "vertical") {
          window.checkAnswerForQuestion(getActiveVerticalQuestionIndex());
        } else {
          checkAnswer();
        }
      },
      onBookmark: () => window.toggleBookmark(),
      onFlag: () => window.toggleFlag(),
      onSelect: (i) => {
        if (quizStyle === "vertical") {
          const idx = getActiveVerticalQuestionIndex();
          if (lockedQuestions[idx]) return;
          const q = questions[idx];
          if (!q?.options || i >= q.options.length) return;
          window.handleSelectForQuestion(idx, i);
          return;
        }
        if (lockedQuestions[currentIdx]) return;
        const q = questions[currentIdx];
        if (!q?.options || i >= q.options.length) return;
        userAnswers[currentIdx] = i;
        saveStateDebounced();
        renderQuestion();
        renderMenuNavigationDebounced();
        maybeAutoSubmit();
      },
    });
    if (els.viewToggle) {
      els.viewToggle.addEventListener("click", toggleView);
    }

    let scrollNavRaf = null;
    window.addEventListener(
      "scroll",
      () => {
        if (quizStyle !== "vertical") return;
        if (scrollNavRaf) return;
        scrollNavRaf = requestAnimationFrame(() => {
          scrollNavRaf = null;
          const activeIdx = getActiveVerticalQuestionIndex();
          if (activeIdx !== currentIdx) {
            currentIdx = activeIdx;
            renderMenuNavigationDebounced();
          }
        });
      },
      { passive: true },
    );
  } catch (err) {
    console.error("Initialization Error:", err);
    if (els.questionContainer) {
      els.questionContainer.innerHTML = `<p style="color:red">Failed to load quiz data. ${err.message}</p>`;
    }
  }
}

// === OPTIMIZED: Debounced navigation rendering ===
function renderMenuNavigationDebounced() {
  if (renderNavDebounce) clearTimeout(renderNavDebounce);
  renderNavDebounce = setTimeout(() => {
    renderMenuNavigation();
  }, 100); // Wait 100ms before re-rendering
}

// === OPTIMIZED: Menu Navigation with smart updates ===
function renderMenuNavigation() {
  let navContainer = document.getElementById("menuNavContainer");
  if (!navContainer) return;

  const flagCount = gameEngine.getFlaggedCount(examId);
  const flagInfo =
    flagCount > 0
      ? `<span class="menu-flag-count"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-flag-off-icon lucide-flag-off"><path d="M16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528"/><path d="m2 2 20 20"/><path d="M4 22V4"/><path d="M7.656 2H8c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10.347"/></svg> ذو علامة مرجعية:  ${flagCount}</span>`
      : "";

  if (viewMode === "grid") {
    renderGridView(navContainer, flagInfo);
  } else {
    renderListView(navContainer, flagInfo);
  }

  // Always refresh icons after re-rendering nav (fixes debounced icon stale state)
}

// === OPTIMIZED: Grid view with DocumentFragment ===
function renderGridView(navContainer, flagInfo) {
  // Use DocumentFragment for better performance
  const fragment = document.createDocumentFragment();
  const container = document.createElement("div");
  container.className = "menu-nav-items grid-view";

  // Build all items at once
  questions.forEach((q, idx) => {
    const item = createGridItem(q, idx);
    container.appendChild(item);
  });

  fragment.appendChild(container);

  // Single DOM update
  navContainer.innerHTML = `
    <div class="menu-nav-grid">
      <div class="menu-nav-header">التنقل بين الأسئلة</div>
      <div class="menu-nav-legend">
        <span><span class="legend-dot current"></span> الحالي</span>
        <span><span class="legend-dot answered"></span> سؤالٌ مُجاب</span>
        <span><span class="legend-dot correct"></span> صحيح</span>
        <span><span class="legend-dot wrong"></span> خطأ</span>
        ${flagInfo}
        </div>
    </div>
  `;
  navContainer.querySelector(".menu-nav-grid").appendChild(container);
}

// === Helper: Create grid item element ===
function createGridItem(q, idx) {
  const isAnswered = userAnswers[idx] !== undefined;
  const isLocked = lockedQuestions[idx];
  const isBookmarked = gameEngine.isBookmarked(examId, idx);
  const isFlagged = gameEngine.isFlagged(examId, idx);
  const isCurrent = idx === currentIdx;

  let statusClass = "unanswered";
  let statusIcon = "";

  if (isCurrent) {
    statusClass = "current";
  } else if (isLocked) {
    let isCorrect;
    if (isEssayQuestion(q)) {
      // Bug 1 Fix: grade essay by score (≥3/5), not by exact string match
      const essayScore = gradeEssay(userAnswers[idx], getEssayAnswer(q));
      isCorrect = essayScore >= 3;
    } else {
      const correctIdx = q.correct ?? q.answer;
      isCorrect = isAnswerCorrect(userAnswers[idx], correctIdx);
    }
    statusClass = isCorrect ? "correct" : "wrong";
    statusIcon = isCorrect ? "✓" : "✗";
  } else if (isAnswered) {
    statusClass = "answered";
    statusIcon = "●";
  }

  const button = document.createElement("button");
  button.className = `menu-nav-item grid-item ${statusClass}`;
  button.onclick = () => window.jumpToQuestion(idx);
  button.title = `Question ${idx + 1}${isBookmarked ? " - Bookmarked" : ""}${isFlagged ? " - Flagged" : ""
    }`;

  button.innerHTML = `
    <span>${idx + 1}</span>
    ${statusIcon
      ? `<span class="menu-nav-status grid-status">${statusIcon}</span>`
      : ""
    }
    ${isBookmarked || isFlagged
      ? `
      <div class="menu-nav-badges">
        ${isBookmarked ? '<span class="mini-badge bookmark"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star-icon lucide-star"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/></svg></span>' : ""}
        ${isFlagged ? '<span class="mini-badge flag"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-flag-off-icon lucide-flag-off"><path d="M16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528"/><path d="m2 2 20 20"/><path d="M4 22V4"/><path d="M7.656 2H8c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10.347"/></svg></span>' : ""}
      </div>
    `
      : ""
    }
  `;

  return button;
}

// === List view (similar optimization) ===
function renderListView(navContainer, flagInfo) {
  // 1. Clear the container completely
  navContainer.innerHTML = "";

  // 2. Add Header and Legend as flat elements
  const headerDiv = document.createElement("div");
  headerDiv.innerHTML = `
    <div class="menu-nav-header">التنقل بين الأسئلة</div>
    <div class="menu-nav-legend">
      <span><span class="legend-dot current"></span> الحالي</span>
      <span><span class="legend-dot answered"></span> سؤالٌ مُجاب</span>
      <span><span class="legend-dot correct"></span> صحيح</span>
      <span><span class="legend-dot wrong"></span> خطأ</span>
     ${flagInfo || ""}     
     </div>
   
  `;
  navContainer.appendChild(headerDiv);

  // 3. Create the list container (no height limits)
  const listContainer = document.createElement("div");
  listContainer.className = "menu-nav-items list-view";

  // 4. Append buttons
  questions.forEach((q, idx) => {
    listContainer.appendChild(createListItem(q, idx));
  });

  navContainer.appendChild(listContainer);
}

// === Helper: Create list item element ===
function createListItem(q, idx) {
  const isAnswered = userAnswers[idx] !== undefined;
  const isLocked = lockedQuestions[idx];
  const isBookmarked = gameEngine.isBookmarked(examId, idx);
  const isFlagged = gameEngine.isFlagged(examId, idx);
  const isCurrent = idx === currentIdx;

  let statusClass = "unanswered";
  let statusIcon = "";

  if (isCurrent) {
    statusClass = "current";
  } else if (isLocked) {
    let isCorrect;
    if (isEssayQuestion(q)) {
      // Bug 1 Fix: grade essay by score (≥3/5), not by exact string match
      const essayScore = gradeEssay(userAnswers[idx], getEssayAnswer(q));
      isCorrect = essayScore >= 3;
    } else {
      const correctIdx = q.correct ?? q.answer;
      isCorrect = isAnswerCorrect(userAnswers[idx], correctIdx);
    }
    statusClass = isCorrect ? "correct" : "wrong";
    statusIcon = isCorrect ? "✓" : "✗";
  } else if (isAnswered) {
    statusClass = "answered";
    statusIcon = "●";
  }

  const div = document.createElement("div");
  div.className = `menu-nav-item list-item ${statusClass}`;

  div.innerHTML = `
    <div class="menu-nav-item-left" onclick="window.jumpToQuestion(${idx})">
      <span class="menu-nav-number">Q${idx + 1}</span>
      ${statusIcon
      ? `<span class="menu-nav-status list-status">${statusIcon}</span>`
      : ""
    }
    </div>
    <div class="menu-nav-item-right">
      <span class="menu-nav-icon bookmark-icon ${isBookmarked ? "active" : ""}" 
            onclick="event.stopPropagation(); window.toggleQuestionBookmark(${idx})"
            title="${isBookmarked ? "إزالة السؤال من الأسئلة المحفوظة" : "حفظ السؤال في الملف الشخصي (profile)"}">
        ${isBookmarked ? '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star-off-icon lucide-star-off"><path d="m10.344 4.688 1.181-2.393a.53.53 0 0 1 .95 0l2.31 4.679a2.12 2.12 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.237 3.152"/><path d="m17.945 17.945.43 2.505a.53.53 0 0 1-.771.56l-4.618-2.428a2.12 2.12 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.12 2.12 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a8 8 0 0 0 .4-.099"/><path d="m2 2 20 20"/></svg>' : '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star-icon lucide-star"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/></svg>'}
      </span>
      <span class="menu-nav-icon flag-icon ${isFlagged ? "active" : ""}" 
            onclick="event.stopPropagation(); window.toggleQuestionFlag(${idx})"
            title="${isFlagged ? "إزالة العلامة" : "إضافة علامة للمراجعة"}">
        ${isFlagged ? '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-flag-off-icon lucide-flag-off"><path d="M16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528"/><path d="m2 2 20 20"/><path d="M4 22V4"/><path d="M7.656 2H8c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10.347"/></svg>' : '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-flag-icon lucide-flag"><path d="M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528"/></svg>'}
      </span>
    </div>
  `;

  return div;
}

function buildVerticalQuestionBodyHTML(q, idx) {
  const isEssay = isEssayQuestion(q);
  const correctIdx = q.correct ?? q.answer;
  const isMultiple = isMultiSelectQuestion(q);
  const isLocked = !!lockedQuestions[idx];
  const userSelected = userAnswers[idx];
  const isBookmarked = gameEngine.isBookmarked(examId, idx);
  const isFlagged = gameEngine.isFlagged(examId, idx);
  const showCheckButton = quizMode !== "exam" && quizMode !== "timed_exam";
  const alreadyReported = quizDbId ? isQuestionReported(quizDbId, idx) : false;
  const reportBtnHtml = quizDbId
    ? `<button class="report-question-btn ${alreadyReported ? "active" : ""}" onclick="window.reportQuestion(${idx})" title="${alreadyReported ? "تم الإبلاغ عن هذا السؤال" : "الإبلاغ عن خطأ في هذا السؤال"}"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-triangle-alert"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></button>`
    : "";

  const actionBtns = `
    <div class="question-actions">
      <button class="bookmark-btn ${isBookmarked ? "active" : ""}" onclick="window.toggleQuestionBookmark(${idx})" title="${isBookmarked ? "إزالة السؤال من الأسئلة المحفوظة" : "حفظ السؤال في الملف الشخصي (profile)"}">${isBookmarked ? `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star-off-icon lucide-star-off"><path d="m10.344 4.688 1.181-2.393a.53.53 0 0 1 .95 0l2.31 4.679a2.12 2.12 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.237 3.152"/><path d="m17.945 17.945.43 2.505a.53.53 0 0 1-.771.56l-4.618-2.428a2.12 2.12 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.12 2.12 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a8 8 0 0 0 .4-.099"/><path d="m2 2 20 20"/></svg>` : `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star-icon lucide-star"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/></svg>`}</button>
      <button class="flag-btn ${isFlagged ? "active" : ""}" onclick="window.toggleQuestionFlag(${idx})" title="${isFlagged ? "إزالة العلامة" : "إضافة علامة للمراجعة"}">${isFlagged ? `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-flag-off-icon lucide-flag-off"><path d="M16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528"/><path d="m2 2 20 20"/><path d="M4 22V4"/><path d="M7.656 2H8c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10.347"/></svg>` : `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-flag-icon lucide-flag"><path d="M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528"/></svg>`}</button>
      ${reportBtnHtml}
    </div>
  `;

  const largeClass = isLargeFormatQuestion(q) ? " question-card--large" : "";
  // mediaHTML is returned SEPARATELY — it will live outside .reloadable-context
  // so the media DOM is never destroyed when the user answers the question.
  const mediaHTML = renderQuestionMedia(q, `q${idx}`);

  // The reloadable section contains only the question number, action buttons,
  // reading passage, question text, options/essay, check button, and feedback.
  // NO media.
  const header = `
    <div class="question-header">
      <div class="question-number">سؤال ${idx + 1} من ${questions.length}</div>
      ${actionBtns}
    </div>
    ${renderReadingPassage(q.passage)}
    <!-- Bug fix: this was previously a real <h2>. q.q is run through
         renderMarkdown(), which can output its own block-level tags
         (h1-h6, p, ul/ol, blockquote, pre) whenever a question's full
         content is authored directly in \`q\` instead of a separate
         \`passage\` field. A <div> has no content-model restriction;
         role="heading" aria-level="2" preserves the same heading
         semantics for screen readers that the real <h2> provided. -->
    <div class="question-text" role="heading" aria-level="2">${renderMarkdown(q.q, { mediaBaseUrl: quizBaseUrl })}</div>
  `;

  // Feedback/model-answer content is ALWAYS rendered here, up front —
  // never deferred to a later "reveal" render — and is shown/hidden
  // purely via CSS (.show class, display:none by default; see quiz.css).
  // This mirrors export-to-quiz.js's static-export player exactly: its
  // .explanation div is written into the page once and only ever gets a
  // "show" class toggled on click, with no re-render at all. Computing it
  // up front (rather than only once locked) means checking the answer
  // NEVER calls renderMarkdown() or touches the question card's markup —
  // only classList/attribute toggles on nodes that already exist — so any
  // inline <img>/<video>/<audio> in the question text, options, or this
  // feedback text itself is mounted exactly once and never rebuilt.
  let feedbackCorrectClass = "";
  let feedbackText = "";
  const explanationText =
    q.explanation || q.desc || q.info || "No explanation provided.";
  if (isEssay) {
    const essayScore = gradeEssay(userSelected, getEssayAnswer(q));
    feedbackCorrectClass = "essay-feedback";
    feedbackText = `<strong>الشرح</strong> <div class="feedback-body">${renderMarkdown(explanationText, { mediaBaseUrl: quizBaseUrl })}</div>`;
  } else {
    let isCorrect;
    if (isMultiple) {
      isCorrect =
        Array.isArray(userSelected) &&
        Array.isArray(correctIdx) &&
        userSelected.length === correctIdx.length &&
        correctIdx.every((i) => userSelected.includes(i));
    } else {
      isCorrect = isAnswerCorrect(userSelected, correctIdx);
    }
    feedbackCorrectClass = isCorrect ? "correct" : "wrong";
    feedbackText = `<div class="feedback-body"><div class="mcq-explanation-label"><strong>الشرح</strong></div><div class="feedback-body-text">${renderMarkdown(explanationText, { mediaBaseUrl: quizBaseUrl })}</div></div>`;
  }
  const feedbackShowClass = isLocked ? ` ${feedbackCorrectClass} show` : "";
  const feedbackHtml = `<div class="feedback${feedbackShowClass}" data-correct-class="${feedbackCorrectClass}">${feedbackText}</div>`;

  if (isEssay) {
    const essayScore = gradeEssay(userSelected, getEssayAnswer(q));
    const stars = "★".repeat(essayScore) + "☆".repeat(5 - essayScore);
    // Formal-answer block is likewise always rendered (hidden via CSS
    // until locked) — see the .formal-answer/.show rule added to
    // quiz.css — instead of being conditionally inserted into the markup
    // only once isLocked is true.
    const formalAnswerHtml = `
      <div class="formal-answer${isLocked ? " show" : ""}">
        <strong style="text-align: center;">(${essayScore}/5) ${stars}</strong>
        <strong style="text-align: center;">الإجابة النموذجية</strong>
        <div class="formal-answer-text">${renderMarkdown(getEssayAnswer(q), { mediaBaseUrl: quizBaseUrl })}</div>
      </div>`;
    return {
      largeClass,
      mediaHTML,
      html: `
        ${header}
        <div class="essay-container">
          <textarea id="essayInput-${idx}" class="essay-textarea ${isLocked ? "locked" : ""}" placeholder="اكتب إجابتك هنا..." ${isLocked ? "disabled" : ""} oninput="window.handleEssayInputForQuestion(${idx})">${escapeHtml(userSelected || "")}</textarea>
        </div>
        <button class="check-answer-btn ${isLocked || !showCheckButton ? "hidden" : ""}" title="إظهار الإجابة الصحيحة" onclick="window.checkAnswerForQuestion(${idx})" ${!userSelected || String(userSelected).trim() === "" ? "disabled" : ""}>تحقق من الإجابة</button>
        ${formalAnswerHtml}
        ${feedbackHtml}
      `,
    };
  }

  // === MCQ card === (checkboxes for multi-answer questions, radios otherwise)
  const optionsHtml = q.options
    .map((opt, i) => {
      let isSelected;
      if (isMultiple) {
        isSelected = Array.isArray(userSelected) && userSelected.includes(i);
      } else {
        isSelected = userSelected === i;
      }
      let optionClass = "option-row";
      if (isSelected) optionClass += " selected";
      if (isLocked) {
        optionClass += " locked";
        const isCorrectOption = isMultiple
          ? Array.isArray(correctIdx) && correctIdx.includes(i)
          : i === singleCorrectIndex(q);
        if (isCorrectOption) optionClass += " correct";
        if (isSelected && !isCorrectOption) optionClass += " wrong";
      }
      const inputType = isMultiple ? "checkbox" : "radio";
      const inputName = isMultiple ? `answer-${idx}-${i}` : `answer-${idx}`;
      return `
        <div class="${optionClass}" ${isLocked ? "" : `onclick="window.handleSelectForQuestion(${idx}, ${i})"`}>
          <input type="${inputType}" name="${inputName}" ${isSelected ? "checked" : ""} ${isLocked ? "disabled" : ""} aria-label="Option ${i + 1}">
          <span class="option-label">${renderMarkdown(opt, { mediaBaseUrl: quizBaseUrl })}</span>
        </div>`;
    })
    .join("");

  const checkDisabled = isMultiple
    ? !Array.isArray(userSelected) || userSelected.length === 0
    : userSelected === undefined;

  return {
    largeClass,
    mediaHTML,
    html: `
      ${header}
      <div class="options-grid">${optionsHtml}</div>
      <button class="check-answer-btn ${isLocked || !showCheckButton ? "hidden" : ""}" title="إظهار الإجابة الصحيحة" onclick="window.checkAnswerForQuestion(${idx})" ${checkDisabled ? "disabled" : ""}>تحقق من الإجابة</button>
      ${feedbackHtml}
    `,
  };
}

// === Answer-state DOM toggle (NO re-render, ever) ===
// Selecting an option or checking the answer must NEVER re-render the
// question card — not even a "small" patch of it. The question card
// (question text, options, feedback, formal-answer) is built exactly
// ONCE, by buildVerticalQuestionBodyHTML/buildQuestionBodyHTML, the first
// time a question is shown. From that point on, this function is the
// ONLY thing interactions call, and it does nothing but toggle
// classList/checked/disabled on nodes that already exist in the DOM —
// mirroring export-to-quiz.js's selectAnswer/checkAnswerForQuestion
// exactly, which never call renderMarkdown() or touch innerHTML for an
// answer update. This is what actually fixes inline <img>/<video>/<audio>
// (living inside q.q/option text) getting destroyed and restarted on
// every click.
function patchQuestionAnswerState(cardEl, q, idx) {
  const isEssay = isEssayQuestion(q);
  const isLocked = !!lockedQuestions[idx];
  const userSelected = userAnswers[idx];
  const showCheckButton = quizMode !== "exam" && quizMode !== "timed_exam";

  if (isEssay) {
    const textarea = cardEl.querySelector(`#essayInput-${idx}, .essay-textarea`);
    if (textarea) {
      textarea.disabled = isLocked;
      textarea.classList.toggle("locked", isLocked);
    }
    const checkBtn = cardEl.querySelector(".check-answer-btn");
    if (checkBtn) {
      checkBtn.classList.toggle("hidden", isLocked || !showCheckButton);
      checkBtn.disabled = !userSelected || String(userSelected).trim() === "";
    }
    // The model-answer block (only shown once locked) and star rating are
    // small enough, and different enough in structure pre/post-lock, that
    // rebuilding just this one leaf sub-block is simpler and safer than
    // trying to incrementally patch it — it carries no persistent media.
    const essayContainer = cardEl.querySelector(".essay-container");
    let formalAnswerEl = cardEl.querySelector(".formal-answer");
    if (isLocked) {
      const essayScore = gradeEssay(userSelected, getEssayAnswer(q));
      const stars = "★".repeat(essayScore) + "☆".repeat(5 - essayScore);
      const formalHtml = `
            <strong style="text-align: center;">(${essayScore}/5) ${stars}</strong>
            <strong style="text-align: center;">الإجابة النموذجية</strong>
            <div class="formal-answer-text">${renderMarkdown(getEssayAnswer(q), { mediaBaseUrl: quizBaseUrl })}</div>`;
      if (!formalAnswerEl) {
        formalAnswerEl = document.createElement("div");
        formalAnswerEl.className = "formal-answer";
        essayContainer?.insertAdjacentElement("afterend", formalAnswerEl);
      }
      formalAnswerEl.innerHTML = formalHtml;
    } else if (formalAnswerEl) {
      formalAnswerEl.remove();
    }
  } else {
    const correctIdx = q.correct ?? q.answer;
    const isMultiple = isMultiSelectQuestion(q);
    cardEl.querySelectorAll(".option-row").forEach((row, i) => {
      let isSelected;
      if (isMultiple) {
        isSelected = Array.isArray(userSelected) && userSelected.includes(i);
      } else {
        isSelected = userSelected === i;
      }
      row.classList.toggle("selected", isSelected);
      row.classList.toggle("locked", isLocked);
      const input = row.querySelector("input");
      if (input) {
        input.checked = isSelected;
        input.disabled = isLocked;
      }
      if (isLocked) {
        const isCorrectOption = isMultiple
          ? Array.isArray(correctIdx) && correctIdx.includes(i)
          : i === singleCorrectIndex(q);
        row.classList.toggle("correct", isCorrectOption);
        row.classList.toggle("wrong", isSelected && !isCorrectOption);
        row.removeAttribute("onclick");
      } else {
        row.classList.remove("correct", "wrong");
        row.setAttribute("onclick", `window.handleSelectForQuestion(${idx}, ${i})`);
      }
    });
    const checkBtn = cardEl.querySelector(".check-answer-btn");
    if (checkBtn) {
      checkBtn.classList.toggle("hidden", isLocked || !showCheckButton);
      const checkDisabled = isMultiple
        ? !Array.isArray(userSelected) || userSelected.length === 0
        : userSelected === undefined;
      checkBtn.disabled = checkDisabled;
    }
  }

  // Feedback block: safe to fully regenerate — it holds only explanation/
  // model-answer prose, never the question or option text, so there is no
  // persistent media here to lose.
  const feedbackEl = cardEl.querySelector(".feedback");
  if (feedbackEl) {
    let feedbackClass = "feedback";
    let feedbackText = "";
    const explanationText =
      q.explanation || q.desc || q.info || "No explanation provided.";
    if (isLocked) {
      if (isEssay) {
        const essayScore = gradeEssay(userSelected, getEssayAnswer(q));
        feedbackClass += " essay-feedback show";
        feedbackText = `<strong>الشرح</strong> <div class="feedback-body">${renderMarkdown(explanationText, { mediaBaseUrl: quizBaseUrl })}</div>`;
      } else {
        const isMultiple = isMultiSelectQuestion(q);
        const correctIdx = q.correct ?? q.answer;
        const isCorrect = isMultiple
          ? Array.isArray(userSelected) &&
          Array.isArray(correctIdx) &&
          userSelected.length === correctIdx.length &&
          correctIdx.every((i) => userSelected.includes(i))
          : isAnswerCorrect(userSelected, correctIdx);
        feedbackClass += isCorrect ? " correct show" : " wrong show";
        feedbackText = `<div class="feedback-body"><div class="mcq-explanation-label"><strong>الشرح</strong></div><div class="feedback-body-text">${renderMarkdown(explanationText, { mediaBaseUrl: quizBaseUrl })}</div></div>`;
      }
    }
    feedbackEl.className = feedbackClass;
    feedbackEl.innerHTML = feedbackText;
    scanDirections(feedbackEl);
  }

  // Bookmark/flag/report buttons in the header can change independently
  // (e.g. via the side menu) — keep them in sync too, cheaply.
  const isBookmarked = gameEngine.isBookmarked(examId, idx);
  const isFlagged = gameEngine.isFlagged(examId, idx);
  const bookmarkBtn = cardEl.querySelector(".bookmark-btn");
  if (bookmarkBtn) bookmarkBtn.classList.toggle("active", isBookmarked);
  const flagBtn = cardEl.querySelector(".flag-btn");
  if (flagBtn) flagBtn.classList.toggle("active", isFlagged);
}

const applyAnswerStateToCard = patchQuestionAnswerState;

// Structure inside .question-body:
//   [.media-center-wrap …]   ← persistent, rendered once, never replaced
//   .reloadable-context       ← replaced on every answer interaction
function buildVerticalQuestionCard(q, idx) {
  const {
    largeClass,
    mediaHTML,
    html: bodyHTML,
  } = buildVerticalQuestionBodyHTML(q, idx);
  return `
    <div class="question-card vertical-question-card${largeClass}" data-question-index="${idx}" id="q-${idx}">
      <div class="question-body">
        ${mediaHTML}
        <div class="reloadable-context">${bodyHTML}</div>
      </div>
    </div>
  `;
}

// Bug 2 Fix: helper that replaces the question container HTML while preserving
// media playback state (currentTime + paused/playing) in pagination mode.
// Matches media elements by their canonical URL (data-media-raw) so the
// restore is robust even if element count or order changes across questions.
// Saves the current question's media playback positions into paginationMediaCache
// so they can be restored when the user navigates back to this question.
// Call this BEFORE changing currentIdx in pagination mode.
function snapshotPaginationMedia(idx) {
  const stateMap = new Map();
  els.questionContainer.querySelectorAll("audio, video").forEach((el) => {
    const key = el.dataset.mediaRaw || el.src.split("?")[0];
    if (key) stateMap.set(key, { time: el.currentTime, paused: el.paused });
  });
  if (stateMap.size) paginationMediaCache.set(idx, stateMap);
}

// Restores media playback positions from paginationMediaCache (or the supplied
// fallback map) onto media elements that have just been inserted into the DOM.
function restoreMediaFromMap(container, stateMap) {
  if (!stateMap || !stateMap.size) return;
  container.querySelectorAll("audio, video").forEach((el) => {
    const key = el.dataset.mediaRaw || el.src.split("?")[0];
    const state = key ? stateMap.get(key) : null;
    if (!state || state.time <= 0) return;
    const restore = () => {
      el.currentTime = state.time;
      if (!state.paused) el.play().catch(() => { });
    };
    if (el.readyState >= 1) restore();
    else el.addEventListener("loadedmetadata", restore, { once: true });
  });
}

function setQuestionHTML(html) {
  els.questionContainer.innerHTML = html;

  // Apply text direction classes synchronously before MutationObserver fires.
  scanDirections(els.questionContainer);

  // Restore playback position for this question if we navigated back to it.
  // paginationMediaCache is populated by snapshotPaginationMedia() just before
  // currentIdx changes, so the Map entry for currentIdx (if any) holds the
  // state the user left this question in.
  const cached = paginationMediaCache.get(currentIdx);
  if (cached) restoreMediaFromMap(els.questionContainer, cached);
}

function renderAllQuestionsVertical(opts) {
  const smoothScroll = !!(opts && opts.smoothScroll);
  if (!els.questionContainer || !questions.length) return;

  const answeredCount = Object.keys(userAnswers).length;
  const progressPercent = (answeredCount / questions.length) * 100;
  if (els.progressFill) {
    els.progressFill.style.width = `${progressPercent}%`;
    els.progressFill.classList.toggle(
      "progress-near-complete",
      progressPercent >= 80,
    );
  }
  if (els.progressText)
    els.progressText.textContent = `${Math.round(progressPercent)}% (${answeredCount}/${questions.length})`;

  // Partial re-render (vertical mode): if we know which card changed, patch
  // ONLY the small set of answer-state DOM bits via patchQuestionAnswerState
  // (option selection/lock classes, check button, feedback block) — the
  // question text and option labels are never regenerated, so any inline
  // <img>/<video>/<audio> media inside them is never destroyed/recreated.
  if (
    lastChangedIdx !== null &&
    document.getElementById(`q-${lastChangedIdx}`)
  ) {
    const targetIdx = lastChangedIdx;
    lastChangedIdx = null;

    const existingCard = document.getElementById(`q-${targetIdx}`);
    const reloadableEl = existingCard.querySelector(".reloadable-context");

    if (reloadableEl) {
      patchQuestionAnswerState(reloadableEl, questions[targetIdx], targetIdx);
    } else {
      // Defensive fallback: full rebuild for this card only,
      // with media state snapshot/restore.
      const mediaStates = [];
      existingCard.querySelectorAll("audio, video").forEach((el) => {
        mediaStates.push({ time: el.currentTime, paused: el.paused });
      });

      const temp = document.createElement("div");
      temp.innerHTML = buildVerticalQuestionCard(
        questions[targetIdx],
        targetIdx,
      );
      const newCard = temp.firstElementChild;
      existingCard.replaceWith(newCard);

      if (mediaStates.length) {
        newCard.querySelectorAll("audio, video").forEach((el, i) => {
          const state = mediaStates[i];
          if (!state || state.time <= 0) return;
          const restore = () => {
            el.currentTime = state.time;
            if (!state.paused) el.play().catch(() => { });
          };
          if (el.readyState >= 1) restore();
          else el.addEventListener("loadedmetadata", restore, { once: true });
        });
      }

      initMediaSkeletons(newCard);
      scanDirections(newCard);
    }
    return;
  }

  lastChangedIdx = null;

  // Full (first) render
  els.questionContainer.innerHTML = questions
    .map((q, idx) => buildVerticalQuestionCard(q, idx))
    .join("");
  els.questionContainer.classList.remove("loading");
  els.questionContainer.classList.add("vertical-style");
  initMediaSkeletons(els.questionContainer);
  // Scan all cards in one pass after the full render so direction classes
  // are set before the browser paints — no per-card flicker.
  scanDirections(els.questionContainer);

  // After a page reload with restored progress, scroll the user back to
  // the question they were on without forcing them to scroll manually.
  // requestAnimationFrame ensures the cards are painted before we scroll.
  // "instant" is intentional on cold load: smooth scrolling on first paint
  // feels jarring and can overshoot on long quizzes. When switching TO this
  // view from pagination (smoothScroll: true), a smooth scroll instead
  // gives the user visual continuity to the question they were just on.
  if (currentIdx > 0 || smoothScroll) {
    requestAnimationFrame(() => {
      const targetCard = document.getElementById(`q-${currentIdx}`);
      if (targetCard)
        targetCard.scrollIntoView({
          behavior: smoothScroll ? "smooth" : "instant",
          block: "start",
        });
    });
  }
}

// === Core: Render Question ===
// Key architectural principle: mediaHTML is returned as a SEPARATE property
// so the caller can place it in a persistent sibling element (.media-center-wrap
// elements rendered once) while only the .reloadable-context gets innerHTML
// replaced on every interaction. This prevents media from unmounting/reloading.
// Splitting this out lets renderQuestion() patch just this part on every
// input interaction without touching the media DOM at all — so audio/video/
// YouTube elements never unmount, reload, or flicker while answering.
function buildQuestionBodyHTML(q, idx) {
  const isEssay = isEssayQuestion(q);
  const correctIdx = q.correct ?? q.answer;
  const isLocked = !!lockedQuestions[idx];
  const userSelected = userAnswers[idx];
  const isBookmarked = gameEngine.isBookmarked(examId, idx);
  const isFlagged = gameEngine.isFlagged(examId, idx);
  const showCheckButton = quizMode !== "exam" && quizMode !== "timed_exam";

  let feedbackClass = "feedback";
  let feedbackText = "";
  const explanationText =
    q.explanation || q.desc || q.info || "No explanation provided.";

  if (isLocked) {
    let isCorrect = false;

    if (isEssay) {
      const essayScore = gradeEssay(userSelected, getEssayAnswer(q));
      isCorrect = essayScore >= 3;
      feedbackClass += " essay-feedback show";
      feedbackText = `<strong>الشرح</strong> <div class="feedback-body">${renderMarkdown(explanationText, { mediaBaseUrl: quizBaseUrl })}</div>`;
    } else {
      if (isMultiSelectQuestion(q)) {
        isCorrect =
          Array.isArray(userSelected) &&
          Array.isArray(correctIdx) &&
          userSelected.length === correctIdx.length &&
          correctIdx.every((i) => userSelected.includes(i));
      } else {
        isCorrect = isAnswerCorrect(userSelected, correctIdx);
      }
      feedbackClass += isCorrect ? " correct show" : " wrong show";
      feedbackText = `<div class="feedback-body"><div class="mcq-explanation-label"><strong>الشرح</strong></div><div class="feedback-body-text">${renderMarkdown(explanationText, { mediaBaseUrl: quizBaseUrl })}</div></div>`;
    }
  }

  const actionButtons = `
    <div class="question-actions">
      <button class="bookmark-btn ${isBookmarked ? "active" : ""}" 
              onclick="window.toggleBookmark()" 
              title="${isBookmarked ? "إزالة السؤال من الأسئلة المحفوظة" : "حفظ السؤال في الملف الشخصي (profile)"}">
        ${isBookmarked ? `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star-off-icon lucide-star-off"><path d="m10.344 4.688 1.181-2.393a.53.53 0 0 1 .95 0l2.31 4.679a2.12 2.12 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.237 3.152"/><path d="m17.945 17.945.43 2.505a.53.53 0 0 1-.771.56l-4.618-2.428a2.12 2.12 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.12 2.12 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a8 8 0 0 0 .4-.099"/><path d="m2 2 20 20"/></svg>` : `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star-icon lucide-star"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/></svg>`}
      </button>
      <button class="flag-btn ${isFlagged ? "active" : ""}" 
              onclick="window.toggleFlag()" 
              title="${isFlagged ? "إزالة العلامة" : "إضافة علامة للمراجعة"}">
        ${isFlagged ? `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-flag-off-icon lucide-flag-off"><path d="M16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528"/><path d="m2 2 20 20"/><path d="M4 22V4"/><path d="M7.656 2H8c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10.347"/></svg>` : `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-flag-icon lucide-flag"><path d="M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528"/></svg>`}
      </button>
      ${quizDbId ? `<button class="report-question-btn ${isQuestionReported(quizDbId, idx) ? "active" : ""}" onclick="window.reportQuestion(${idx})" title="${isQuestionReported(quizDbId, idx) ? "تم الإبلاغ عن هذا السؤال" : "الإبلاغ عن خطأ في هذا السؤال"}"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-triangle-alert"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></button>` : ""}
    </div>
  `;

  const largeClass = isLargeFormatQuestion(q) ? " question-card--large" : "";
  // mediaHTML is returned SEPARATELY so the caller can render it outside
  // .reloadable-context. This is the core of the fix: media lives in its own
  // persistent siblings and is never touched when the interactive content changes.
  const mediaHTML = renderQuestionMedia(q, `q${idx}`);

  // The reloadable header only contains the question number, action buttons,
  // reading passage, and question text — NO media.
  const reloadableHeaderHTML = `
    <div class="question-header">
      <div class="question-number">سؤال ${idx + 1} من ${questions.length}</div>
      ${actionButtons}
    </div>
    ${renderReadingPassage(q.passage)}
    <div class="question-text" role="heading" aria-level="2">${renderMarkdown(q.q, { mediaBaseUrl: quizBaseUrl })}</div>
  `;

  if (isEssay) {
    const essayScore = gradeEssay(userSelected, getEssayAnswer(q));
    const stars = "★".repeat(essayScore) + "☆".repeat(5 - essayScore);
    return {
      largeClass,
      mediaHTML,
      html: `
        ${reloadableHeaderHTML}
        <div class="essay-container">
          <textarea 
            id="essayInput" 
            class="essay-textarea ${isLocked ? "locked" : ""}" 
            placeholder="اكتب إجابتك هنا..."
            ${isLocked ? "disabled" : ""}
            oninput="window.handleEssayInput()"
          >${escapeHtml(userSelected || "")}</textarea>
        </div>
        <button class="check-answer-btn ${isLocked || !showCheckButton ? "hidden" : ""
        }"
                id="checkBtn" onclick="window.checkAnswer()"
                ${!userSelected || String(userSelected).trim() === ""
          ? "disabled"
          : ""
        }>
          تحقق من الإجابة
        </button>
        ${isLocked
          ? `
          <div class="formal-answer">
            <strong style="text-align: center;">(${essayScore}/5) ${stars}</strong>
            <strong style="text-align: center;">الإجابة النموذجية</strong>
            <div class="formal-answer-text">${renderMarkdown(getEssayAnswer(q), { mediaBaseUrl: quizBaseUrl })}</div>
          </div>
        `
          : ""
        }
        <div class="${feedbackClass}">${feedbackText}</div>
      `,
    };
  }

  const isMultiple = isMultiSelectQuestion(q);

  return {
    largeClass,
    mediaHTML,
    html: `
      ${reloadableHeaderHTML}
      <div class="options-grid">
        ${q.options
        .map((opt, i) => {
          let isSelected = false;
          if (isMultiple) {
            isSelected =
              Array.isArray(userSelected) && userSelected.includes(i);
          } else {
            isSelected = userSelected === i;
          }

          let optionClass = "option-row";
          if (isSelected) optionClass += " selected";
          if (isLocked) {
            optionClass += " locked";
            const isCorrectOption = isMultiple
              ? Array.isArray(q.correct) && q.correct.includes(i)
              : i === singleCorrectIndex(q);
            if (isCorrectOption) optionClass += " correct";
            if (isSelected && !isCorrectOption) optionClass += " wrong";
          }

          const inputType = isMultiple ? "checkbox" : "radio";
          const inputName = isMultiple ? `answer-${i}` : "answer";

          return `
            <div class="${optionClass}" ${isLocked ? "" : `onclick="window.handleSelect(${i})"`
            }>
              <input type="${inputType}" name="${inputName}" ${isSelected ? "checked" : ""
            } 
                     ${isLocked ? "disabled" : ""} aria-label="Option ${i + 1}">
              <span class="option-label">${renderMarkdown(opt, { mediaBaseUrl: quizBaseUrl })}</span>
            </div>`;
        })
        .join("")}
      </div>
      <button title="إظهار الإجابة الصحيحة" class="check-answer-btn ${isLocked || !showCheckButton ? "hidden" : ""
      }"
              id="checkBtn" onclick="window.checkAnswer()"
              ${userSelected === undefined || (isMultiple && (!Array.isArray(userSelected) || userSelected.length === 0)) ? "disabled" : ""}>
        تحقق من الإجابة
      </button>
      <div class="${feedbackClass}">${feedbackText}</div>
    `,
  };
}

// === Core: Render Question (pagination style) ===
// The question card is split into two sibling zones inside .question-body:
//   1. .media-center-wrap elements  — rendered ONCE on first load / navigation,
//      never touched again on same-question interactions.
//   2. .reloadable-context          — replaced on every handleSelect /
//      checkAnswer / essay-input cycle. Contains header text, reading passage,
//      question text, options/essay, check button, feedback.
// This prevents any audio/video/iframe from unmounting while the user answers.
function renderQuestion() {
  if (!questions.length) return;

  if (quizStyle === "vertical") {
    renderAllQuestionsVertical();
    updateNav();
    return;
  }

  const q = questions[currentIdx];

  // Update Progress
  const answeredCount = Object.keys(userAnswers).length;
  const progressPercent = (answeredCount / questions.length) * 100;
  if (els.progressFill) {
    els.progressFill.style.width = `${progressPercent}%`;
    els.progressFill.classList.toggle(
      "progress-near-complete",
      progressPercent >= 80,
    );
  }
  if (els.progressText)
    els.progressText.textContent = `${Math.round(
      progressPercent,
    )}% (${answeredCount}/${questions.length})`;

  const existingCard = els.questionContainer.querySelector(".question-card");
  const sameQuestion =
    existingCard && Number(existingCard.dataset.questionIndex) === currentIdx;

  if (sameQuestion) {
    els.questionContainer.classList.remove("loading");
    // In-place update for the same question (e.g. after answering or
    // checking): patch ONLY the small set of answer-state DOM bits via
    // patchQuestionAnswerState (option classes, check button, feedback) —
    // question text and option labels are never regenerated, so inline
    // <img>/<video>/<audio> media inside them is never destroyed/recreated.
    const reloadableEl = existingCard.querySelector(".reloadable-context");
    if (reloadableEl) {
      patchQuestionAnswerState(reloadableEl, q, currentIdx);
    } else {
      // Defensive fallback (unexpected DOM shape): full rebuild.
      const {
        largeClass,
        mediaHTML,
        html: bodyHTML,
      } = buildQuestionBodyHTML(q, currentIdx);
      setQuestionHTML(
        renderFullQuestionCard(q, currentIdx, largeClass, mediaHTML, bodyHTML),
      );
      initMediaSkeletons(els.questionContainer);
    }
  } else {
    // Navigated to a different question (or first render): full rebuild,
    // including fresh media elements for the new question.
    els.questionContainer.classList.remove("loading");
    const {
      largeClass,
      mediaHTML,
      html: bodyHTML,
    } = buildQuestionBodyHTML(q, currentIdx);
    setQuestionHTML(
      renderFullQuestionCard(q, currentIdx, largeClass, mediaHTML, bodyHTML),
    );
    initMediaSkeletons(els.questionContainer);
  }

  updateNav();
}

// Builds the full question card HTML.
// Structure inside .question-body:
//   [.media-center-wrap …]   ← persistent, never replaced after first render
//   .reloadable-context       ← replaced on every interaction
function renderFullQuestionCard(q, idx, largeClass, mediaHTML, bodyHTML) {
  return `
    <div class="question-card${largeClass}" data-question-index="${idx}">
      <div class="question-body">
        ${mediaHTML}
        <div class="reloadable-context">${bodyHTML}</div>
      </div>
    </div>
  `;
}

// === Event Handlers ===
function handleSelect(index) {
  if (lockedQuestions[currentIdx]) return;

  const q = questions[currentIdx];
  const isMultiple = isMultiSelectQuestion(q);

  if (isMultiple) {
    // Multiple selection: toggle the checkbox
    if (!Array.isArray(userAnswers[currentIdx])) {
      userAnswers[currentIdx] = [];
    }
    const answerArray = userAnswers[currentIdx];
    const idx = answerArray.indexOf(index);
    if (idx > -1) {
      answerArray.splice(idx, 1);
    } else {
      answerArray.push(index);
    }
  } else {
    // Single selection: replace with new answer
    userAnswers[currentIdx] = index;
  }

  saveStateDebounced();
  lastChangedIdx = currentIdx; // Bug 2 Fix: tag for targeted pagination re-render
  renderQuestion();
  renderMenuNavigationDebounced();
  maybeAutoSubmit();
}

function handleEssayInput() {
  if (lockedQuestions[currentIdx]) return;
  const textarea = document.getElementById("essayInput");
  if (textarea) {
    userAnswers[currentIdx] = textarea.value;
    saveStateDebounced();
    const checkBtn = document.getElementById("checkBtn");
    if (checkBtn) {
      checkBtn.disabled = !textarea.value.trim();
    }
  }
}

// #quizTitle direction: applied once after the title element is set.
// The RTL/LTR engine now lives in markdown.js; quiz.js uses the
// exported scanDirections() to handle this one non-markdown element.
function applyQuizTitleDirection() {
  const titleEl = els.title || document.getElementById("quizTitle");
  if (titleEl) scanDirections(titleEl.parentElement || document);
}

const maybeAutoSubmit = () => {
  if (autoSubmitTimeout) {
    clearTimeout(autoSubmitTimeout);
    autoSubmitTimeout = null;
  }

  const answered = Object.keys(userAnswers).length;
  if (answered === questions.length && questions.length > 0) {
    autoSubmitTimeout = setTimeout(async () => {
      try {
        if (
          await _confirm(
            "لقد أجبت على جميع الأسئلة. هل تريد تسليم الامتحان الآن؟",
          )
        ) {
          finish(true);
        }
      } catch (e) {
        console.error("Auto-submit error:", e);
      }
      autoSubmitTimeout = null;
    }, 5000);
  }
};

function nav(dir) {
  const newIdx = currentIdx + dir;
  if (newIdx < 0 || newIdx >= questions.length) return;
  // Snapshot current question's media state before leaving (pagination only).
  if (quizStyle !== "vertical") snapshotPaginationMedia(currentIdx);
  currentIdx = newIdx;
  saveStateDebounced();
  renderQuestion();
  renderMenuNavigationDebounced();
  if (quizStyle === "vertical") {
    const el = document.getElementById(`q-${currentIdx}`);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

async function finish(skipconfirmationNotification) {
  if (autoSubmitTimeout) {
    clearTimeout(autoSubmitTimeout);
    autoSubmitTimeout = null;
  }

  if (!skipconfirmationNotification && !(await _confirm("هل تريد أن تسلم؟")))
    return;

  stopTimer();

  let correctCount = 0; // MCQ points
  let essayScore = 0; // Essay points earned
  let essayMaxScore = 0; // Essay points possible
  let essayQuestions = [];

  questions.forEach((q, i) => {
    if (isEssayQuestion(q)) {
      essayQuestions.push(i);
      const score = gradeEssay(userAnswers[i], getEssayAnswer(q));
      essayScore += score;
      essayMaxScore += 5;
    } else {
      const correctIdx = q.correct ?? q.answer;
      if (isAnswerCorrect(userAnswers[i], correctIdx)) correctCount++;
    }
  });

  const mcqCount = questions.length - essayQuestions.length;
  const totalScore = correctCount + essayScore;
  const totalPossible = mcqCount + essayMaxScore;

  const rawResult = {
    examId,
    quizDbId,
    examTitle: metaData.title,
    source: metaData.source || null,
    description: metaData.description || null,
    createdAt: metaData.createdAt || null,
    author: metaData.author || null,
    authorHandle: metaData.author_handle || null,
    authorId: metaData.author_id || null,
    category: metaData.category || null,
    path: metaData.path || null,
    meta: metaData,
    questions: questions,
    score: totalScore,
    total: totalPossible,
    mcqScore: correctCount,
    mcqTotal: mcqCount,
    essayScore: essayScore,
    essayMaxScore: essayMaxScore,
    totalQuestions: questions.length,
    essayQuestions: essayQuestions,
    userAnswers,
    timeElapsed:
      quizMode === "timed" || quizMode === "timed_exam"
        ? questions.length * 30 - timeRemaining
        : timeElapsed,
    timeRemaining:
      quizMode === "timed" || quizMode === "timed_exam" ? timeRemaining : 0,
    quizMode,
    mode: quizMode,
    view: quizStyle,
    questionTypes: metaData.questionTypes || null,
  };

  const gamifiedResult = gameEngine.processResult(rawResult);

  const finalOutput = {
    ...rawResult,
    gamification: gamifiedResult,
  };

  localStorage.setItem("last_quiz_result", JSON.stringify(finalOutput));
  localStorage.removeItem(`quiz_state_${examId}`);
  gameEngine.clearFlags(examId);

  // Clear quiz session data
  localStorage.removeItem("quiz_start_time");

  // Trigger an immediate sync of owner progress to the DB so shareable
  // profiles reflect the latest results for visitors. Don't await —
  // use a fire-and-forget keepalive-capable request.
  try {
    if (window.syncProgressToServer) window.syncProgressToServer();
  } catch (e) { }

  window.location.href = "result";
}

async function restart(skipconfirmationNotification) {
  // 1. _confirm Intent
  if (
    !skipconfirmationNotification &&
    !(await _confirm("هل تريد إعادة الامتحان؟ سيتم فقدان التقدم الحالي"))
  )
    return;

  // 2. SAFETY: Kill the pending save timer immediately.
  // This prevents the previous state from overwriting our "clean slate"
  // 300ms after this function runs.
  if (saveStateDebounce) {
    clearTimeout(saveStateDebounce);
    saveStateDebounce = null;
  }

  // 3. Clear Intervals
  if (timerInterval) clearInterval(timerInterval);
  if (autoSubmitTimeout) {
    clearTimeout(autoSubmitTimeout);
    autoSubmitTimeout = null;
  }

  // 4. Wipe Storage
  localStorage.removeItem(`quiz_state_${examId}`);

  // 5. Reset Memory State
  currentIdx = 0;
  userAnswers = {};
  lockedQuestions = {};
  timeElapsed = 0;

  // 6. Reset Timed Mode Logic
  if (quizMode === "timed" || quizMode === "timed_exam") {
    timeRemaining = questions.length * 30;
  }

  // 7. Reset UI
  if (els.timer) {
    els.timer.style.color = "";
    if (quizMode === "timed" || quizMode === "timed_exam") {
      const mins = Math.floor(timeRemaining / 60)
        .toString()
        .padStart(2, "0");
      const secs = (timeRemaining % 60).toString().padStart(2, "0");
      els.timer.textContent = `${mins}:${secs}`;
    } else {
      els.timer.textContent = `00:00`;
    }
  }

  // 8. Re-render
  renderQuestion();
  renderMenuNavigation();
  startTimer();

  // 9. Scroll to top
  window.scrollTo(0, 0);
}

async function exit(skipconfirmationNotification) {
  if (
    !skipconfirmationNotification &&
    !(await _confirm("هل أنت متأكد من الخروج؟"))
  )
    return;

  localStorage.removeItem(`quiz_state_${examId}`);

  localStorage.removeItem("quiz_start_time");

  window.location.href = "/";
}

function checkAnswer() {
  const q = questions[currentIdx];
  const isEssay = isEssayQuestion(q);

  if (isEssay) {
    const textarea = document.getElementById("essayInput");
    if (!textarea || !textarea.value.trim()) return;
  } else {
    const userAnswer = userAnswers[currentIdx];
    if (userAnswer === undefined) return;
    // For multiple choice, ensure answer exists (could be empty array)
    if (Array.isArray(userAnswer) && userAnswer.length === 0) return;
  }

  lockedQuestions[currentIdx] = true;
  saveStateDebounced();
  renderQuestion();
  renderMenuNavigationDebounced();
  updateNav();
}

// === Utilities ===
function updateNav() {
  if (quizStyle === "vertical") {
    // In vertical mode, prev/next scroll to previous/next question card
    if (els.prevBtn) {
      els.prevBtn.disabled = currentIdx === 0;
      els.prevBtn.textContent = "السابق ←";
    }
    if (els.nextBtn) {
      els.nextBtn.disabled = currentIdx === questions.length - 1;
      els.nextBtn.textContent = "→ التالي";
    }
  } else {
    if (els.prevBtn) els.prevBtn.disabled = currentIdx === 0;
    if (els.nextBtn) {
      els.nextBtn.style.display = "inline-block";
      els.nextBtn.disabled = currentIdx === questions.length - 1;
    }
  }
  if (els.finishBtn) {
    els.finishBtn.style.display = "flex";
    const totalLocked = Object.keys(lockedQuestions).length;
  }
}

// === OPTIMIZED: Debounced save state ===
function saveStateDebounced() {
  if (quizMode === "timed" || quizMode === "timed_exam") return;

  if (saveStateDebounce) clearTimeout(saveStateDebounce);
  saveStateDebounce = setTimeout(() => {
    // Bug 3 Fix: capture current media timestamps so they survive a page reload.
    // Keys are the canonical media URL (data-media-raw) so they survive
    // re-renders that may change element order.
    const mediaTimestamps = {};
    const captureMedia = (container, idxKey) => {
      container.querySelectorAll("audio, video").forEach((el) => {
        if (el.currentTime > 0) {
          const key = el.dataset.mediaRaw || el.src.split("?")[0];
          if (!key) return;
          if (!mediaTimestamps[idxKey]) mediaTimestamps[idxKey] = {};
          mediaTimestamps[idxKey][key] = el.currentTime;
        }
      });
    };

    if (quizStyle === "vertical") {
      els.questionContainer
        .querySelectorAll(".vertical-question-card")
        .forEach((card) => {
          const idx = parseInt(card.dataset.questionIndex, 10);
          if (isNaN(idx)) return;
          captureMedia(card, idx);
        });
    } else {
      captureMedia(els.questionContainer, currentIdx);
    }

    const state = {
      currentIdx,
      userAnswers,
      timeElapsed,
      lockedQuestions,
      mediaTimestamps,
    };
    localStorage.setItem(`quiz_state_${examId}`, JSON.stringify(state));
    // NOTE: Do NOT call history.replaceState here (neither directly nor via
    // safeReplaceState).  This function only persists quiz progress to
    // localStorage.  Touching the browser history from a periodic debounce
    // timer is the root cause of the URL-stripping bug — if window.location
    // has been altered by another module, replaceState would stamp the
    // already-wrong URL into history and make it permanent.
  }, 300); // Wait 300ms before saving
}

// Bug 3 Fix: apply media timestamps that were saved before a page reload.
// Called once after the very first renderQuestion() in init().
// Timestamps are stored per-question-index as an object keyed by data-media-raw
// URL (set by saveStateDebounced), so they survive even if element order changes.
function applyPendingMediaTimestamps() {
  if (!pendingMediaTimestamps || !Object.keys(pendingMediaTimestamps).length)
    return;

  const timestamps = pendingMediaTimestamps;
  pendingMediaTimestamps = null;

  const applyToContainer = (container, timeMap) => {
    if (!timeMap || typeof timeMap !== "object") return;
    container.querySelectorAll("audio, video").forEach((el) => {
      const key = el.dataset.mediaRaw || el.src.split("?")[0];
      const time = key ? timeMap[key] : undefined;
      if (!time || time <= 0) return;
      const restore = () => {
        el.currentTime = time;
      };
      if (el.readyState >= 1) restore();
      else el.addEventListener("loadedmetadata", restore, { once: true });
    });
  };

  if (quizStyle === "vertical") {
    Object.entries(timestamps).forEach(([idxStr, timeMap]) => {
      const card = document.getElementById(`q-${idxStr}`);
      if (card) applyToContainer(card, timeMap);
    });
  } else {
    const timeMap = timestamps[currentIdx];
    if (timeMap) applyToContainer(els.questionContainer, timeMap);
  }
}

// ── Bug 2 Fix: popstate listener ─────────────────────────────────────────────
// If future development adds history.pushState calls inside quiz.js (e.g. to
// give each question its own URL so the user can share a direct link), the back
// button will fire popstate *within* the quiz rather than causing a full page
// reload.  This listener handles that case by re-running init() so the quiz
// re-reads the (still-intact) URL parameters and restores to the correct state.
//
// For the current navigation model (finish() → window.location.href →
// result.html), pressing back causes a full reload and popstate never fires —
// init() is simply called fresh by the script loader, which is equally correct.
window.addEventListener("popstate", async () => {
  const params = new URLSearchParams(window.location.search);
  const hasQuizParams =
    params.get("id") !== null || params.get("type") !== null;
  if (hasQuizParams) {
    await init();
  }
});

async function startTimer() {
  try {
    if (timerInterval) clearInterval(timerInterval);

    timerInterval = setInterval(() => {
      if (quizMode === "timed" || quizMode === "timed_exam") {
        timeRemaining--;
        if (timeRemaining <= 0) {
          clearInterval(timerInterval);
          _alert("Time's up! Submitting quiz...");
          finish(true);
          return;
        }

        const mins = Math.floor(timeRemaining / 60)
          .toString()
          .padStart(2, "0");
        const secs = (timeRemaining % 60).toString().padStart(2, "0");
        if (els.timer) {
          els.timer.textContent = `${mins}:${secs}`;
          if (timeRemaining < 30) els.timer.style.color = "var(--color-error)";
        }
      } else {
        timeElapsed++;
        const mins = Math.floor(timeElapsed / 60)
          .toString()
          .padStart(2, "0");
        const secs = (timeElapsed % 60).toString().padStart(2, "0");
        if (els.timer) els.timer.textContent = `${mins}:${secs}`;

        // Save less frequently during timer (every 10 seconds)
        if (timeElapsed % 10 === 0) {
          saveStateDebounced();
        }
      }
    }, 1000);
  } catch (error) {
    console.error("Error starting timer:", error);
    _alert("Error starting timer. Please try again.");
  }
}

function stopTimer() {
  clearInterval(timerInterval);
}

// ============================================================================
// Bug 2 Fix — resetQuizState
// Cleans up all in-flight timers and resets every module-level variable to its
// initial value so that init() can be safely called again (e.g. when the user
// presses the back button and the browser re-fires the popstate event on a
// quiz.html?id=… history entry).
// ============================================================================
function resetQuizState() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
  if (autoSubmitTimeout) {
    clearTimeout(autoSubmitTimeout);
    autoSubmitTimeout = null;
  }
  if (saveStateDebounce) {
    clearTimeout(saveStateDebounce);
    saveStateDebounce = null;
  }
  resizeSaveDebounces.forEach((timeoutId) => clearTimeout(timeoutId));
  resizeSaveDebounces.clear();
  paginationMediaCache.clear();
  questions = [];
  metaData = {};
  currentIdx = 0;
  userAnswers = {};
  lockedQuestions = {};
  timeElapsed = 0;
  timeRemaining = 0;
  quizBaseUrl = null;
}

init();

// ============================================================================
// Quiz page — Persistent collapsible icon-rail sidebar navigation
// Self-contained: isolated from the shared side-menu.js implementation.
// Desktop: 64px collapsed ↔ 240px expanded, state in localStorage
// Mobile (≤768px): bottom sheet with backdrop
// ============================================================================

(function () {
  const sidebar = document.getElementById("sidebar");
  const backdrop = document.getElementById("sideMenuBackdrop");
  const hamburgerBtn = document.getElementById("menuBtn"); // mobile-only
  const expandBtn = document.getElementById("sidebarExpandBtn"); // desktop expand trigger (collapsed rail favicon)
  const collapseBtn = document.getElementById("sidebarCollapseBtn"); // desktop collapse button (expanded header)
  const animationToggle = document.getElementById("animationToggle");

  const MOBILE_BP = 768;
  const STORAGE_KEY = "sidebar_expanded";
  const FOCUSABLE =
    'a[href], button:not([disabled]), input, [tabindex]:not([tabindex="-1"])';

  // ── Helpers ────────────────────────────────────────────────────────────────

  function isMobile() {
    return window.innerWidth <= MOBILE_BP;
  }

  /** Apply sidebar expanded/collapsed state on desktop */
  function applyDesktopState(expanded) {
    if (expanded) {
      sidebar.classList.add("expanded");
      document.body.classList.add("sidebar-expanded");
    } else {
      sidebar.classList.remove("expanded");
      document.body.classList.remove("sidebar-expanded");
    }
  }

  /** Open the sidebar (mobile bottom-sheet mode) */
  function openMobileSidebar() {
    sidebar.classList.add("expanded");
    backdrop.classList.add("visible");
    hamburgerBtn.setAttribute("aria-expanded", "true");
    sidebar.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden"; // prevent scroll behind sheet
    // Focus first focusable item
    const first = sidebar.querySelectorAll(FOCUSABLE)[0];
    if (first) first.focus();
  }

  /** Close the sidebar (mobile bottom-sheet mode) */
  function closeMobileSidebar() {
    sidebar.classList.remove("expanded");
    backdrop.classList.remove("visible");
    hamburgerBtn.setAttribute("aria-expanded", "false");
    sidebar.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    hamburgerBtn.focus();
  }

  // ── Collapsed-rail hover tooltips ────────────────────────────────────────
  // .sidebar nav uses `overflow-x: clip` (see that rule's comment in
  // quiz.css), which clips anything painted past nav's edges — including a
  // plain [data-tooltip]::after positioned outside the icon. That's why
  // labels used to only work for the two .sidebar-pinned-actions buttons,
  // the only .menu-items that live OUTSIDE <nav>. Fixed the same way the
  // reference side-menu.js solves this exact problem: one shared element,
  // `position: fixed`, positioned from the hovered/focused icon's own
  // getBoundingClientRect() instead of relying on CSS containment.
  function setupHoverTooltips() {
    let tooltipEl = document.querySelector(".sidebar-hover-tooltip");
    if (!tooltipEl) {
      tooltipEl = document.createElement("div");
      tooltipEl.className = "sidebar-hover-tooltip";
      tooltipEl.setAttribute("role", "tooltip");
      tooltipEl.setAttribute("aria-hidden", "true");
      document.body.appendChild(tooltipEl);
    }

    let activeTarget = null;

    function positionTooltip(target) {
      const rect = target.getBoundingClientRect();
      const GAP = 10;
      tooltipEl.style.top = `${rect.top + rect.height / 2}px`;
      // RTL sidebar sits on the right edge — tooltip opens to the left of
      // the icon, toward the content area.
      tooltipEl.style.right = `${window.innerWidth - rect.left + GAP}px`;
      tooltipEl.style.left = "auto";
      tooltipEl.style.transform = "translateY(-50%)";
    }

    function showTooltip(target) {
      // Only relevant for the collapsed desktop rail — expanded sidebar
      // already shows full text labels inline, and mobile suppresses this
      // element entirely via CSS.
      if (isMobile() || sidebar.classList.contains("expanded")) return;
      const label = target.getAttribute("data-tooltip");
      if (!label) return;

      activeTarget = target;
      tooltipEl.textContent = label;
      positionTooltip(target);
      tooltipEl.classList.add("visible");
    }

    function hideTooltip() {
      activeTarget = null;
      tooltipEl.classList.remove("visible");
    }

    // Delegate from the sidebar itself so this covers every current and
    // future [data-tooltip] element (.menu-item links/buttons, the
    // collapsed-rail .theme-section-header, pinned actions) uniformly,
    // instead of re-querying and re-binding after every DOM change.
    sidebar.addEventListener("mouseover", (e) => {
      const target = e.target.closest("[data-tooltip]");
      if (target && sidebar.contains(target)) showTooltip(target);
    });

    sidebar.addEventListener("mouseout", (e) => {
      const target = e.target.closest("[data-tooltip]");
      if (target && target === activeTarget) hideTooltip();
    });

    sidebar.addEventListener(
      "focusin",
      (e) => {
        const target = e.target.closest("[data-tooltip]");
        if (target) showTooltip(target);
      },
      true,
    );

    sidebar.addEventListener(
      "focusout",
      (e) => {
        const target = e.target.closest("[data-tooltip]");
        if (target && target === activeTarget) hideTooltip();
      },
      true,
    );

    // Keep it glued to its target through scroll/resize/expand-collapse
    // instead of leaving a stale tooltip floating in place.
    window.addEventListener(
      "scroll",
      () => {
        if (activeTarget) positionTooltip(activeTarget);
      },
      true,
    );
    window.addEventListener("resize", hideTooltip);
    sidebar.addEventListener("transitionend", (e) => {
      if (e.propertyName === "width") hideTooltip();
    });
  }

  // ── Initialise ─────────────────────────────────────────────────────────────

  function init() {
    if (!sidebar) return;

    if (isMobile()) {
      // Mobile: sidebar starts hidden
      sidebar.setAttribute("aria-hidden", "true");
      document.body.style.overflow = "";
    } else {
      // Desktop: restore saved preference
      const saved = localStorage.getItem(STORAGE_KEY);
      const expanded = saved === null ? false : saved === "true";
      applyDesktopState(expanded);
      sidebar.setAttribute("aria-hidden", "false");
    }

    // Sync theme buttons pressed state
    const currentTheme =
      document.documentElement.getAttribute("data-theme") || "light";
    sidebar.querySelectorAll("[data-theme]").forEach((btn) => {
      btn.setAttribute(
        "aria-pressed",
        btn.dataset.theme === currentTheme ? "true" : "false",
      );
    });

    // Sync animation toggle state
    if (animationToggle) {
      const animsEnabled =
        document.documentElement.getAttribute("data-animations") !== "disabled";
      animationToggle.checked = animsEnabled;
    }

    // Collapsed-rail hover tooltips (desktop only; no-ops safely on mobile)
    setupHoverTooltips();
  }

  // ── Desktop Expand/Collapse Toggles ────────────────────────────────────────

  if (expandBtn) {
    expandBtn.addEventListener("click", () => {
      applyDesktopState(true);
      try {
        localStorage.setItem(STORAGE_KEY, "true");
      } catch (_) { }
    });
  }

  if (collapseBtn) {
    collapseBtn.addEventListener("click", () => {
      applyDesktopState(false);
      try {
        localStorage.setItem(STORAGE_KEY, "false");
      } catch (_) { }
    });
  }

  // ── Mobile Hamburger ────────────────────────────────────────────────────────

  if (hamburgerBtn) {
    hamburgerBtn.addEventListener("click", () => {
      if (sidebar.classList.contains("expanded")) {
        closeMobileSidebar();
      } else {
        openMobileSidebar();
      }
    });
  }

  // ── Backdrop Click ──────────────────────────────────────────────────────────

  if (backdrop) {
    backdrop.addEventListener("click", closeMobileSidebar);
  }

  // ── Focus trap (mobile keyboard) ───────────────────────────────────────────

  if (sidebar) {
    sidebar.addEventListener("keydown", (e) => {
      if (!isMobile()) return;

      if (e.key === "Escape") {
        closeMobileSidebar();
        return;
      }

      if (e.key !== "Tab") return;
      const focusable = [...sidebar.querySelectorAll(FOCUSABLE)];
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (
        e.shiftKey
          ? document.activeElement === first
          : document.activeElement === last
      ) {
        e.preventDefault();
        (e.shiftKey ? last : first).focus();
      }
    });
  }

  // ── Draggable Bottom Sheet (mobile) ─────────────────────────────────────────
  // Bug 5 Fix — Mobile draggability. quiz.html already renders a
  // #sidebarDragHandle element, but nothing in this file ever wired it up,
  // so the mobile bottom-sheet couldn't be dragged/swiped. Ported verbatim
  // from side-menu.js: grab-and-drag the sheet up/down by its handle,
  // YouTube-comments-style. Dragging up snaps back open; dragging down past
  // a distance/velocity threshold and releasing dismisses the sheet.

  const dragHandle = document.getElementById("sidebarDragHandle");

  if (dragHandle && sidebar) {
    const DISMISS_DISTANCE_RATIO = 0.28; // fraction of sheet height
    const DISMISS_VELOCITY = 0.5; // px/ms, fast downward flick dismisses early

    let dragging = false;
    let startY = 0;
    let currentY = 0;
    let startTime = 0;
    let sheetHeight = 0;
    let pointerId = null;

    const onPointerDown = (e) => {
      if (!isMobile()) return;
      if (!sidebar.classList.contains("expanded")) return;

      dragging = true;
      pointerId = e.pointerId;
      startY = e.clientY;
      currentY = e.clientY;
      startTime = performance.now();
      sheetHeight = sidebar.getBoundingClientRect().height || 1;

      sidebar.classList.add("dragging");
      dragHandle.classList.add("dragging");

      try {
        dragHandle.setPointerCapture(pointerId);
      } catch (_) { }

      window.addEventListener("pointermove", onPointerMove);
      window.addEventListener("pointerup", onPointerUp);
      window.addEventListener("pointercancel", onPointerUp);
    };

    const onPointerMove = (e) => {
      if (!dragging) return;
      currentY = e.clientY;
      const deltaY = Math.max(0, currentY - startY); // only allow downward drag
      sidebar.style.transform = `translateY(${deltaY}px)`;
    };

    const onPointerUp = () => {
      if (!dragging) return;
      dragging = false;

      sidebar.classList.remove("dragging");
      dragHandle.classList.remove("dragging");
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerUp);

      const deltaY = Math.max(0, currentY - startY);
      const elapsed = Math.max(1, performance.now() - startTime);
      const velocity = deltaY / elapsed; // px per ms

      // Clear the inline transform either way — closing uses the sheet's
      // own CSS transition (translateY(100%)); staying open just resets
      // back to the sheet's normal expanded position (translateY(0)).
      sidebar.style.transform = "";

      const shouldDismiss =
        deltaY > sheetHeight * DISMISS_DISTANCE_RATIO ||
        velocity > DISMISS_VELOCITY;

      if (shouldDismiss) {
        closeMobileSidebar();
      }
    };

    dragHandle.addEventListener("pointerdown", onPointerDown);
  }

  // ── Resize: reset state on breakpoint cross ─────────────────────────────────

  let lastMobile = isMobile();
  window.addEventListener("resize", () => {
    const nowMobile = isMobile();
    if (nowMobile === lastMobile) return;
    lastMobile = nowMobile;

    if (!nowMobile) {
      // Switched to desktop — restore preference, remove overlay artefacts
      backdrop.classList.remove("visible");
      document.body.style.overflow = "";
      sidebar.setAttribute("aria-hidden", "false");
      const saved = localStorage.getItem(STORAGE_KEY);
      applyDesktopState(saved === "true");
    } else {
      // Switched to mobile — close/reset
      sidebar.classList.remove("expanded");
      document.body.classList.remove("sidebar-expanded");
      backdrop.classList.remove("visible");
      sidebar.setAttribute("aria-hidden", "true");
      document.body.style.overflow = "";
    }
  });

  // ── Action buttons (data-action) ────────────────────────────────────────────

  sidebar.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const action = btn.dataset.action;
      const fn = window[action];
      if (typeof fn === "function") {
        fn();
      }
      if (isMobile()) {
        closeMobileSidebar();
      }
    });
  });

  // ── Theme buttons ───────────────────────────────────────────────────────────

  sidebar.querySelectorAll("[data-theme]").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (typeof themeManager !== "undefined" && themeManager.applyTheme) {
        themeManager.applyTheme(btn.dataset.theme);
      }
      // Update pressed states
      sidebar.querySelectorAll("[data-theme]").forEach((b) => {
        b.setAttribute("aria-pressed", b === btn ? "true" : "false");
      });
    });
  });

  // ── Animation toggle ────────────────────────────────────────────────────────

  if (animationToggle) {
    animationToggle.addEventListener("change", () => {
      if (typeof themeManager !== "undefined" && themeManager.applyAnimations) {
        themeManager.applyAnimations(animationToggle.checked);
      }
    });
  }

  // ── Theme Controls Accordion ────────────────────────────────────────────────
  // Retractable "المظهر والأداء" (appearance & performance) section — mirrors
  // the main side-menu's theme-controls accordion pattern exactly. Persists
  // open/closed across page loads the same way the sidebar's own
  // expanded/collapsed state does. Only wired for the toggle button itself;
  // the collapsed-rail icon (.sidebar-collapsed-only) below just expands the
  // whole sidebar, matching how every other collapsed-rail icon behaves.

  const THEME_ACCORDION_KEY = "theme_controls_expanded";
  const themeControlsToggle = document.getElementById("themeControlsToggle");
  const themeControlsPanel = document.getElementById("themeControlsPanel");

  function setThemeControlsExpanded(expanded) {
    if (!themeControlsToggle || !themeControlsPanel) return;
    themeControlsToggle.setAttribute("aria-expanded", String(expanded));
    themeControlsPanel.classList.toggle("collapsed", !expanded);
    try {
      localStorage.setItem(THEME_ACCORDION_KEY, String(expanded));
    } catch (_) { }
  }

  if (themeControlsToggle && themeControlsPanel) {
    const savedAccordionState = localStorage.getItem(THEME_ACCORDION_KEY);
    // Defaults open (matches the toggle's markup-default aria-expanded="true")
    setThemeControlsExpanded(savedAccordionState !== "false");

    themeControlsToggle.addEventListener("click", () => {
      const isExpanded =
        themeControlsToggle.getAttribute("aria-expanded") === "true";
      setThemeControlsExpanded(!isExpanded);
    });
  }

  // Collapsed-rail entry point for the theme/animation section — same
  // pattern as clicking any other icon while collapsed: there's no href to
  // follow, so clicking it simply opens the sidebar (desktop) so the person
  // can reach the actual controls.
  const themeSectionCollapsedIcon = sidebar.querySelector(
    ".theme-controls-section .sidebar-collapsed-only",
  );
  if (themeSectionCollapsedIcon) {
    themeSectionCollapsedIcon.addEventListener("click", () => {
      if (isMobile()) return; // not shown on mobile anyway (always expanded sheet)
      applyDesktopState(true);
      try {
        localStorage.setItem(STORAGE_KEY, "true");
      } catch (_) { }
    });
  }

  // ── Question Navigation Accordion ───────────────────────────────────────────
  // Retractable "التنقل بين الأسئلة" (question navigation) section — mirrors
  // the main side-menu's theme-controls accordion pattern exactly. Persists
  // open/closed across page loads the same way the sidebar's own
  // expanded/collapsed state does. #menuNavContainer doubles as the panel:
  // renderMenuNavigation()/renderGridView()/renderListView() in quiz.js only
  // ever touch its innerHTML, never its classList, so the "collapsed" class
  // toggled here survives every re-render triggered by answering a question
  // or switching grid/list view.

  const QUIZ_NAV_ACCORDION_KEY = "quiz_nav_expanded";
  const quizNavToggle = document.getElementById("quizNavToggle");
  const quizNavPanel = document.getElementById("menuNavContainer");
  // #viewToggle now lives inside .quiz-nav-section (moved there so it
  // retracts/expands together with the question-nav list/grid), but it is
  // a sibling of #menuNavContainer, not a child of it — #menuNavContainer's
  // innerHTML is fully rebuilt by quiz.js on every render, so anything that
  // needs to survive those re-renders has to stay outside it. That means
  // the "collapsed" class can't live on #menuNavContainer alone anymore; it
  // has to also apply to #viewToggle directly.
  const quizNavViewToggle = document.getElementById("viewToggle");

  function setQuizNavExpanded(expanded) {
    if (!quizNavToggle || !quizNavPanel) return;
    quizNavToggle.setAttribute("aria-expanded", String(expanded));
    quizNavPanel.classList.toggle("collapsed", !expanded);
    if (quizNavViewToggle) {
      quizNavViewToggle.classList.toggle("collapsed", !expanded);
    }
    try {
      localStorage.setItem(QUIZ_NAV_ACCORDION_KEY, String(expanded));
    } catch (_) { }
  }

  if (quizNavToggle && quizNavPanel) {
    const savedNavAccordionState = localStorage.getItem(
      QUIZ_NAV_ACCORDION_KEY,
    );
    // Defaults open (matches the toggle's markup-default aria-expanded="true")
    setQuizNavExpanded(savedNavAccordionState !== "false");

    quizNavToggle.addEventListener("click", () => {
      const isExpanded = quizNavToggle.getAttribute("aria-expanded") === "true";
      setQuizNavExpanded(!isExpanded);
    });
  }

  // Collapsed-rail entry point for the question-navigation section — same
  // pattern as clicking any other icon while collapsed: there's no href to
  // follow, so clicking it simply opens the sidebar (desktop) so the person
  // can reach the actual navigation list/grid.
  const quizNavCollapsedIcon = sidebar.querySelector(
    ".quiz-nav-section .sidebar-collapsed-only",
  );
  if (quizNavCollapsedIcon) {
    quizNavCollapsedIcon.addEventListener("click", () => {
      if (isMobile()) return; // not shown on mobile anyway (always expanded sheet)
      applyDesktopState(true);
      try {
        localStorage.setItem(STORAGE_KEY, "true");
      } catch (_) { }
    });
  }

  // ── Run ─────────────────────────────────────────────────────────────────────
  init();
})();