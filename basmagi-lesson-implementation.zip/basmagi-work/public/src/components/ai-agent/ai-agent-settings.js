// =============================================================================
// public/src/components/ai-agent/ai-agent-settings.js
// Settings tab: lets users pick a provider and (optionally) store their own
// API key. Keys are stored client-side ONLY (localStorage via the shared
// storage-helpers), never sent anywhere except as part of a single request
// body to /api/ai-agent/chat, which does not persist them server-side.
// =============================================================================

import { getFromStorage, setInStorage } from "../../shared/storage-helpers.js";
import { isAdminAuthenticated } from "../../shared/adminAuth.js";

const PROVIDER_STORAGE_KEY = "ai_agent_provider";
const KEY_STORAGE_PREFIX = "ai_agent_key__"; // + provider
const SYSTEM_PROMPT_STORAGE_PREFIX = "ai_agent_system_prompt__"; // + pageKey
const MODEL_STORAGE_PREFIX = "ai_agent_model__"; // + provider

// Per-provider model catalog. The FIRST entry in each list is always the
// "default" — deliberately the lightest/cheapest/latest model the provider
// offers, mirroring api/ai-agent/_providerClients.js's own hardcoded
// choice, so a user who never opens this dropdown still gets the same
// default behavior as before this feature existed. `value: ""` means
// "let the backend decide" (i.e. use its own default pointer) rather than
// pinning a specific model string from the client — this is the initial/
// unset state and is what an empty/never-saved selection resolves to.
//
// Google uses a dynamic "-latest" pointer (gemini-flash-lite-latest) that
// the provider itself keeps pointed at its current lightest model, so no
// version number ever goes stale here. DeepSeek and Claude don't publish
// that kind of alias, so their entries are the latest hardcoded snapshot
// versions available at time of writing — see _providerClients.js, which
// this list is kept in sync with.
const MODELS_BY_PROVIDER = {
  google: [
    { value: "gemini-flash-lite-latest", label: "Gemini Flash-Lite" },
    { value: "gemini-flash-latest", label: "Gemini Flash" },
    { value: "gemini-2.5-pro", label: "Gemini 2.5 Pro" },
  ],
  deepseek: [
    { value: "deepseek-chat", label: "DeepSeek Chat" },
    { value: "deepseek-reasoner", label: "DeepSeek Reasoner" },
  ],
  claude: [
    { value: "claude-haiku-4-5-20251001", label: "Claude Haiku 4.5" },
    { value: "claude-sonnet-4-6", label: "Claude Sonnet 4.6" },
    { value: "claude-opus-4-6", label: "Claude Opus 4.6" },
  ],
};

const PROVIDERS = [
  { value: "google", label: "Google AI Studio (Gemini)" },
  { value: "deepseek", label: "DeepSeek" },
  { value: "claude", label: "Claude" },
];

export function getSelectedProvider() {
  return getFromStorage(PROVIDER_STORAGE_KEY, "google");
}

function setSelectedProvider(provider) {
  setInStorage(PROVIDER_STORAGE_KEY, provider);
}

/**
 * @returns {{ key: string, hasKey: boolean }} the stored key for the
 *   currently-selected provider, if any.
 */
export function getOwnKey() {
  const provider = getSelectedProvider();
  const key = getFromStorage(`${KEY_STORAGE_PREFIX}${provider}`, "");
  return { key, hasKey: !!key };
}

function setOwnKey(provider, key) {
  setInStorage(`${KEY_STORAGE_PREFIX}${provider}`, key);
}

function clearOwnKey(provider) {
  setInStorage(`${KEY_STORAGE_PREFIX}${provider}`, "");
}

/**
 * @returns {Array<{value: string, label: string}>} the model catalog for
 *   the given provider, falling back to google's list shape for an
 *   unrecognized provider so callers never get `undefined`.
 */
export function getModelsForProvider(provider) {
  return MODELS_BY_PROVIDER[provider] || MODELS_BY_PROVIDER.google;
}

/**
 * @returns {string} the currently-selected model for the currently-selected
 *   provider, or "" (meaning "use the provider's own default") if unset.
 *   Cleared automatically per-provider — switching providers never leaks
 *   one provider's model id into another's request.
 */
export function getSelectedModel() {
  const provider = getSelectedProvider();
  return getFromStorage(`${MODEL_STORAGE_PREFIX}${provider}`, "");
}

export function setSelectedModel(provider, model) {
  setInStorage(`${MODEL_STORAGE_PREFIX}${provider}`, model || "");
}

/**
 * @param {string} pageKey - "home" | "result"
 * @param {string} defaultPrompt - the page's default system prompt
 * @returns {string} the stored override, or defaultPrompt if unset/empty
 */
export function getSystemPrompt(pageKey, defaultPrompt) {
  const stored = getFromStorage(`${SYSTEM_PROMPT_STORAGE_PREFIX}${pageKey}`, "");
  return stored || defaultPrompt || "";
}

export function setSystemPrompt(pageKey, value) {
  setInStorage(`${SYSTEM_PROMPT_STORAGE_PREFIX}${pageKey}`, value);
}

export function resetSystemPrompt(pageKey) {
  setInStorage(`${SYSTEM_PROMPT_STORAGE_PREFIX}${pageKey}`, "");
}

/**
 * Whether the AI Helper can actually be used right now. Platform-key access
 * is open to everyone (admins uncapped, everyone else subject to a daily
 * quota enforced server-side — see AI_AGENT_DAILY_LIMIT in
 * api/ai-agent/chat.js), so this always returns true; kept as a named
 * function rather than inlined `true` since ai-agent-chat.js still calls
 * it as its eligibility check at the two call sites that predate this
 * change.
 * @returns {boolean}
 */
export function isAiHelperAvailable() {
  // Platform-key access is now open to everyone (admins uncapped, everyone
  // else subject to a server-enforced daily quota — see AI_AGENT_DAILY_LIMIT
  // in api/ai-agent/chat.js). There's no client-side way to know remaining
  // quota without a round trip, so this just reflects "the feature exists
  // for this user"; a 429 from the backend surfaces the actual cap.
  return true;
}

/**
 * @param {object} [options]
 * @param {string} [options.pageKey] - "home" | "result"; used to key the
 *   per-page system-prompt storage.
 * @param {string} [options.defaultSystemPrompt] - the page's default prompt,
 *   shown when no override has been saved.
 * @returns {HTMLElement} the settings panel root element
 */
// Suffixed onto every field id this function generates below, so two
// panel instances on the same page (unlikely today — see call site — but
// cheap to guard against) never collide on duplicate ids/label `for`
// targets.
let settingsPanelInstanceCounter = 0;

export function createSettingsPanel(options = {}) {
  const { pageKey = "default", defaultSystemPrompt = "", onKeyChanged = null } = options;
  const instanceId = `ai-agent-settings-${settingsPanelInstanceCounter++}`;
  const panel = document.createElement("div");
  panel.className = "ai-agent-panel ai-agent-settings-panel";

  const note = document.createElement("div");
  note.className = "ai-agent-settings-note";
  note.textContent =
    "لن يتم تخزين مفتاحك على خوادمنا — يُحفظ فقط على متصفحك.";
  panel.appendChild(note);

  // ── Provider select ──
  const providerLabel = document.createElement("label");
  providerLabel.className = "ai-agent-field-label";
  providerLabel.textContent = "مزوّد الذكاء الاصطناعي";
  providerLabel.htmlFor = `${instanceId}-provider`;
  panel.appendChild(providerLabel);

  const providerSelect = document.createElement("select");
  providerSelect.id = `${instanceId}-provider`;
  providerSelect.className = "ai-agent-provider-select";
  PROVIDERS.forEach(({ value, label }) => {
    const opt = document.createElement("option");
    opt.value = value;
    opt.textContent = label;
    providerSelect.appendChild(opt);
  });
  providerSelect.value = getSelectedProvider();
  panel.appendChild(providerSelect);

  // ── Model select ──
  // Scoped per-provider (not per-page) — a user's model preference for
  // "Google" should follow them from the home page's chat to the result
  // page's chat, same as the provider and own-key choices already do.
  const modelLabel = document.createElement("label");
  modelLabel.className = "ai-agent-field-label";
  modelLabel.textContent = "النموذج (Model)";
  modelLabel.htmlFor = `${instanceId}-model`;
  panel.appendChild(modelLabel);

  const modelSelect = document.createElement("select");
  modelSelect.id = `${instanceId}-model`;
  modelSelect.className = "ai-agent-provider-select";
  panel.appendChild(modelSelect);

  // Same rationale as the chat tab's model bar (ai-agent-chat.js): model
  // selection only has any effect once the request uses the user's own
  // key — the platform-key path always forces the default server-side
  // (see api/ai-agent/chat.js) — so disable this select whenever no own
  // key is saved, rather than letting it look interactive but do nothing.
  function refreshModelSelectAvailability() {
    const { hasKey } = getOwnKey();
    modelSelect.disabled = !hasKey;
    modelSelect.title = hasKey
      ? ""
      : "اختيار النموذج متاح فقط عند استخدام مفتاح API الخاص بك";
  }

  function loadModelsForCurrentProvider() {
    const provider = providerSelect.value;
    modelSelect.innerHTML = "";
    const models = getModelsForProvider(provider);
    models.forEach(({ value, label }) => {
      const opt = document.createElement("option");
      opt.value = value;
      opt.textContent = label;
      modelSelect.appendChild(opt);
    });
    modelSelect.value = getSelectedModel() || (models[0] && models[0].value) || "";
    refreshModelSelectAvailability();
  }
  loadModelsForCurrentProvider();

  modelSelect.addEventListener("change", () => {
    setSelectedModel(providerSelect.value, modelSelect.value);
    if (typeof onKeyChanged === "function") onKeyChanged();
  });

  // ── Own key input ──
  // NOTE: the response-language select that used to live here was removed
  // per product decision — response language is now left entirely to the
  // model to infer (from the conversation itself, or an explicit ask in
  // the user's own prompt) rather than a separate setting.
  const keyLabel = document.createElement("label");
  keyLabel.className = "ai-agent-field-label";
  keyLabel.textContent = "مفتاح API الخاص بك (اختياري)";
  keyLabel.htmlFor = `${instanceId}-key`;
  panel.appendChild(keyLabel);

  const keyInput = document.createElement("input");
  keyInput.id = `${instanceId}-key`;
  keyInput.type = "password";
  keyInput.className = "ai-agent-key-input";
  keyInput.placeholder = "sk-...";
  keyInput.autocomplete = "off";
  panel.appendChild(keyInput);

  function loadKeyForCurrentProvider() {
    const { key } = getOwnKey();
    keyInput.value = key;
  }
  loadKeyForCurrentProvider();

  providerSelect.addEventListener("change", () => {
    setSelectedProvider(providerSelect.value);
    loadKeyForCurrentProvider();
    loadModelsForCurrentProvider();
    status.textContent = "";
    refreshKeySourceIndicator();
    updateKeyActionsVisibility();
    if (typeof onKeyChanged === "function") onKeyChanged();
  });

  // ── Save / clear actions ──
  const actions = document.createElement("div");
  actions.className = "ai-agent-settings-actions";

  const saveBtn = document.createElement("button");
  saveBtn.type = "button";
  saveBtn.className = "ai-agent-btn ai-agent-btn--primary";
  saveBtn.style.width = "auto";
  saveBtn.innerHTML = "<span>حفظ المفتاح</span>";

  const clearBtn = document.createElement("button");
  clearBtn.type = "button";
  clearBtn.className = "ai-agent-btn ai-agent-btn--danger";
  clearBtn.style.width = "auto";
  clearBtn.innerHTML = "<span>مسح المفتاح</span>";

  actions.appendChild(saveBtn);
  actions.appendChild(clearBtn);
  panel.appendChild(actions);

  const status = document.createElement("div");
  status.className = "ai-agent-settings-status";
  panel.appendChild(status);

  // Save / Clear are only surfaced when they're actually actionable:
  //   - nothing saved and nothing typed → both hidden (nothing to do)
  //   - nothing saved but the user is typing → Save appears alone
  //   - a saved value sits in the field untouched → Clear appears alone
  //   - an existing saved value was edited → both appear (Save persists
  //     the new value, Clear drops the stored one)
  function updateKeyActionsVisibility() {
    const { key: savedKey, hasKey: hasSavedKey } = getOwnKey();
    const typed = keyInput.value.trim();
    if (!hasSavedKey && typed === "") {
      saveBtn.hidden = true;
      clearBtn.hidden = true;
      return;
    }
    saveBtn.hidden = !(typed !== "" && (typed !== savedKey || !hasSavedKey));
    clearBtn.hidden = !hasSavedKey;
  }
  updateKeyActionsVisibility();

  keyInput.addEventListener("input", () => {
    updateKeyActionsVisibility();
    // Any keystroke invalidates whichever status message is showing.
    status.textContent = "";
  });

  // ── Key-source indicator ──
  // Mirrors the exact precedence ai-agent-chat.js::sendMessage uses (own
  // key first if saved, otherwise the platform pool — open to everyone,
  // admins uncapped, everyone else subject to a daily quota enforced
  // server-side) so what's shown here always matches what a message will
  // actually use — without making a network call just to render this panel.
  const keySourceIndicator = document.createElement("div");
  keySourceIndicator.className = "ai-agent-key-source";
  panel.appendChild(keySourceIndicator);

  function refreshKeySourceIndicator() {
    const { hasKey } = getOwnKey();
    if (hasKey) {
      keySourceIndicator.className = "ai-agent-key-source ai-agent-key-source--own";
      keySourceIndicator.textContent = "🔑 يتم استخدام مفتاحك الخاص حاليًا";
      return;
    }
    const isAdmin = isAdminAuthenticated();
    keySourceIndicator.className = "ai-agent-key-source ai-agent-key-source--platform";
    keySourceIndicator.textContent = isAdmin
      ? "🌐 يتم استخدام مفتاح المنصة — بلا حد استخدام يومي (حساب مشرف)."
      : "🌐 يتم استخدام مفتاح المنصة — يوجد حد استخدام يومي (لا يوجد مفتاح خاص محفوظ). احفظ مفتاحك الخاص أعلاه لاستخدام غير محدود.";
  }
  refreshKeySourceIndicator();

  saveBtn.addEventListener("click", () => {
    const provider = providerSelect.value;
    const key = keyInput.value.trim();
    if (!key) {
      status.className = "ai-agent-settings-status";
      status.textContent = "أدخل مفتاحًا صالحًا أولاً";
      return;
    }
    setOwnKey(provider, key);
    status.className = "ai-agent-settings-status ai-agent-settings-status--saved";
    status.textContent = "تم الحفظ ✓";
    refreshKeySourceIndicator();
    refreshModelSelectAvailability();
    updateKeyActionsVisibility();
    if (typeof onKeyChanged === "function") onKeyChanged();
  });

  clearBtn.addEventListener("click", () => {
    const provider = providerSelect.value;
    clearOwnKey(provider);
    keyInput.value = "";
    status.className = "ai-agent-settings-status ai-agent-settings-status--cleared";
    status.textContent = "تم المسح";
    refreshKeySourceIndicator();
    refreshModelSelectAvailability();
    updateKeyActionsVisibility();
    if (typeof onKeyChanged === "function") onKeyChanged();
  });

  // ── System prompt (editable, page-scoped) ──
  const promptLabel = document.createElement("label");
  promptLabel.className = "ai-agent-field-label";
  promptLabel.textContent = "تعليمات النظام (System Prompt)";
  promptLabel.htmlFor = `${instanceId}-system-prompt`;
  panel.appendChild(promptLabel);

  const promptTextarea = document.createElement("textarea");
  promptTextarea.id = `${instanceId}-system-prompt`;
  promptTextarea.className = "ai-agent-system-prompt-input";
  promptTextarea.rows = 6;
  promptTextarea.value = getSystemPrompt(pageKey, defaultSystemPrompt);
  panel.appendChild(promptTextarea);

  const promptActions = document.createElement("div");
  promptActions.className = "ai-agent-settings-actions";

  const savePromptBtn = document.createElement("button");
  savePromptBtn.type = "button";
  savePromptBtn.className = "ai-agent-btn ai-agent-btn--primary";
  savePromptBtn.style.width = "auto";
  savePromptBtn.innerHTML = "<span>حفظ التعليمات</span>";

  const resetPromptBtn = document.createElement("button");
  resetPromptBtn.type = "button";
  resetPromptBtn.className = "ai-agent-btn ai-agent-btn--danger";
  resetPromptBtn.style.width = "auto";
  resetPromptBtn.innerHTML = "<span>إعادة تعيين للافتراضي</span>";

  promptActions.appendChild(savePromptBtn);
  promptActions.appendChild(resetPromptBtn);
  panel.appendChild(promptActions);

  const promptStatus = document.createElement("div");
  promptStatus.className = "ai-agent-settings-status";
  panel.appendChild(promptStatus);

  savePromptBtn.addEventListener("click", () => {
    setSystemPrompt(pageKey, promptTextarea.value.trim());
    promptStatus.className = "ai-agent-settings-status ai-agent-settings-status--saved";
    promptStatus.textContent = "تم الحفظ ✓";
  });

  resetPromptBtn.addEventListener("click", () => {
    resetSystemPrompt(pageKey);
    promptTextarea.value = defaultSystemPrompt || "";
    promptStatus.className = "ai-agent-settings-status ai-agent-settings-status--cleared";
    promptStatus.textContent = "تمت الإعادة للافتراضي";
  });

  return panel;
}