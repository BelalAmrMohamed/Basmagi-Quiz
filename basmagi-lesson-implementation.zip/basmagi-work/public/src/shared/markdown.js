/**
 * public/src/shared/markdown.js
 *
 * Shared Markdown + KaTeX rendering engine (ES Module).
 * Used by both quiz.html and result.html — do NOT add any
 * page-specific logic here.
 *
 * Exports:
 * renderMarkdown(str, options)   → HTML string
 *   options.mediaBaseUrl (optional): directory URL of the current quiz/
 *   result page (e.g. `new URL("./", window.location.href).href`), passed
 *   through to inline ![audio](url)/![video](url) tags so quiz-folder-
 *   relative media paths resolve the same way dedicated-field media does
 *   in quiz.js/result.js. Omit it and relative media paths fall back to
 *   site-root/current-page resolution only (see media-resolve.js).
 *
 * Side-effects on first import:
 * • window.copyCodeBlock is registered so inline onclick="…"
 * attributes on copy buttons can reach it across any page.
 */

// ─── 1. Shared media resolution (images / audio / video / YouTube) ────────────
// Same module used by quiz.js and result.js for their (legacy, field-based)
// media rendering, so inline ![audio]/![video] markdown tags resolve URLs,
// sniff MIME types, and detect YouTube links identically to how dedicated
// q.image/q.audio/q.video fields always have.
import {
  getMediaUrlCandidates,
  getMediaMimeType,
  isYouTubeUrl,
  getYouTubeVideoId,
} from "./media-resolve.js";

// ─── 2. HTML escaping ─────────────────────────────────────────────────────────
// Internal — escapes for safe insertion into markup.
export function escHtml(s) {
  return (s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Inverse of escHtml() — decodes the small set of entities escHtml produces
// back to their raw characters. Used to make downstream re-escaping
// idempotent: applyInline() is documented to receive already-escHtml'd
// input from its internal callers, but it is also an exported function that
// other pages may call directly on raw text. Decoding first and then
// escaping exactly once means both call paths produce correctly-escaped,
// non-double-encoded output — e.g. a URL's "?a=1&b=2" always renders as
// "&amp;", never "&amp;amp;", regardless of which path it arrived by.
export function unescapeHtmlEntities(s) {
  return (s || "")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&");
}

// ─── 3. Inline Markdown formatter ─────────────────────────────────────────────

// Matches the skeleton markup quiz.js's dedicated-field media renderer uses,
// so inline media looks and behaves identically (same CSS, same
// initMediaSkeletons() reveal-on-load / retry-on-error logic in quiz.js).
// Exported (alongside renderInlineMediaTag) so export-to-quiz.js's
// .toString()-based static-export bundler can inline both — renderInlineMediaTag
// references this by bare closure, same situation as _HL_KEYWORDS/ICON_COPY.
export const MD_MEDIA_SKELETON_HTML = `<div class="media-skeleton" aria-hidden="true"><div class="skeleton-block skeleton-media"></div><span class="media-skeleton-label">جاري التحميل…</span></div>`;

// ─── 3a. Resizable-media key derivation ────────────────────────────────────
// Every inline media element gets a stable `data-resize-key` so
// _initMediaResize (see the "Feature: User-Resizable Media" section further
// down) can persist a user-dragged size across re-renders, page navigation,
// and reloads — the same size sticks to the same piece of media because the
// key is derived from the media's own URL (plus the page it's rendered on),
// never from render order/position, which would shuffle if content above it
// changes.
// Exported so export-to-quiz.js's static-export bundler can inline it
// (renderInlineMediaTag/_renderRawImageTag/_renderRawMediaTag reference it
// by bare closure, same .toString()-serialization pattern as escHtml above).
export function _hashForResizeKey(s) {
  let h = 0;
  const str = String(s || "");
  for (let i = 0; i < str.length; i++) {
    h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  }
  return (h >>> 0).toString(36);
}

export function _makeResizeKey(kind, url, mediaBaseUrl) {
  return `${kind}_${_hashForResizeKey(mediaBaseUrl || "")}_${_hashForResizeKey(url || "")}`;
}

/**
 * Renders a raw `<img>` tag's src/alt/width/height into a safe <img>
 * element. Used by the raw-HTML-media-tag stash step in
 * _renderMarkdownCore (see there for why raw tags need special handling).
 * An empty src (the toolbar inserts `src=""` for the author to fill in by
 * hand) renders a small placeholder instead of a broken image icon.
 * @param {string} src
 * @param {string} alt
 * @param {string|undefined} width
 * @param {string|undefined} height
 * @param {string|null} mediaBaseUrl
 */
export function _renderRawImageTag(src, alt, width, height, mediaBaseUrl) {
  const safe = (v) => escHtml(unescapeHtmlEntities(v || ""));
  if (!src || !src.trim()) {
    return `<div class="media-container md-inline-media md-media-empty"><span class="media-skeleton-label">صورة بلا رابط بعد</span></div>`;
  }
  const candidates = getMediaUrlCandidates(src, mediaBaseUrl);
  const resolvedSrc = candidates[0] || src;
  // Render with the tag's own inline width/height (author-set or
  // previously-saved resize dimensions) so the image keeps its existing
  // on-screen size rather than snapping back to natural/100% width, then
  // wrap it in the same .media-container the other media kinds use so the
  // resize-handle machinery (_initMediaResize) can attach to it uniformly.
  const resizeKey = _makeResizeKey("image", src, mediaBaseUrl);
  const dims =
    (width ? ` width="${safe(width)}"` : "") +
    (height ? ` height="${safe(height)}"` : "");
  const img = `<img src="${safe(resolvedSrc)}" alt="${safe(alt)}" class="md-img question-image"${dims} loading="lazy" data-media-raw="${safe(src)}">`;
  return `<div class="media-container question-media-container question-image-container md-inline-media" data-resize-key="${safe(resizeKey)}" data-resize-kind="image">${img}</div>`;
}

/**
 * Renders a raw `<video>`/`<audio>` tag's src into the same markup
 * `renderInlineMediaTag` produces for bracket-syntax `![video]`/![audio]`
 * tags (skeleton wrapper, YouTube-iframe branch for video, source-type
 * sniffing) — so both authoring styles behave identically. Used by the
 * raw-HTML-media-tag stash step in _renderMarkdownCore.
 * An empty src (the toolbar inserts `src=""` for the author to fill in by
 * hand) renders a small placeholder instead of a broken player.
 * @param {"video"|"audio"} kind
 * @param {string} src
 * @param {string|null} mediaBaseUrl
 */
export function _renderRawMediaTag(kind, src, mediaBaseUrl) {
  if (!src || !src.trim()) {
    const label = kind === "video" ? "فيديو بلا رابط بعد" : "ملف صوتي بلا رابط بعد";
    return `<div class="media-container md-inline-media md-media-empty"><span class="media-skeleton-label">${label}</span></div>`;
  }
  return renderInlineMediaTag(kind, src, mediaBaseUrl);
}

/**
 * Renders one inline media tag: ![audio](url) or ![video](url).
 * Mirrors quiz.js's renderQuestionAudio/renderQuestionVideo (same
 * `.media-container`/skeleton wrapper, same YouTube-iframe branch for
 * video), so media embedded directly in markdown behaves exactly like the
 * legacy dedicated q.image/q.audio/q.video fields did.
 * Exported so export-to-quiz.js's static-export bundler can import and
 * .toString()-inline it (applyInline calls it by bare reference, same
 * .toString()-serialization pattern as escHtml/highlightCode/etc below).
 * @param {"audio"|"video"} kind
 * @param {string} url
 * @param {string|null} mediaBaseUrl
 */
export function renderInlineMediaTag(kind, url, mediaBaseUrl) {
  const safe = (v) => escHtml(unescapeHtmlEntities(v));

  if (kind === "video" && isYouTubeUrl(url)) {
    const videoId = getYouTubeVideoId(url);
    const embedSrc = `https://www.youtube.com/embed/${videoId}`;
    const resizeKey = _makeResizeKey("video", url, mediaBaseUrl);
    return `<div class="media-container question-media-container question-video-container md-inline-media" data-resize-key="${safe(resizeKey)}" data-resize-kind="video"><iframe class="question-video youtube-embed" src="${safe(embedSrc)}" data-media-raw="${safe(url)}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen loading="lazy"></iframe></div>`;
  }

  const candidates = getMediaUrlCandidates(url, mediaBaseUrl);
  const src = candidates[0] || "";
  const mime = getMediaMimeType(src);
  const typeAttr = mime ? ` type="${safe(mime)}"` : "";
  const candidatesAttr = safe(JSON.stringify(candidates));
  const fallback =
    kind === "audio"
      ? "متصفحك لا يدعم تشغيل الصوت."
      : "متصفحك لا يدعم تشغيل الفيديو.";
  const playsinline = kind === "video" ? " playsinline" : "";
  const containerClass =
    kind === "audio"
      ? "question-media-container question-audio-container"
      : "question-media-container question-video-container";
  const resizeKey = _makeResizeKey(kind, url, mediaBaseUrl);

  return `<div class="media-container ${containerClass} md-inline-media" data-resize-key="${safe(resizeKey)}" data-resize-kind="${kind}">${MD_MEDIA_SKELETON_HTML}<${kind} controls preload="metadata" class="question-${kind}"${playsinline} src="${safe(src)}" data-media-raw="${safe(url)}" data-media-candidates="${candidatesAttr}"><source src="${safe(src)}"${typeAttr} />${fallback}</${kind}></div>`;
}

// Receives an already-escHtml-encoded string; applies spans/tags for
// bold, italic, code, links, images, media (audio/video), and inline math
// ($…$).
// @param {string} s
// @param {{mediaBaseUrl?: string|null}} [options]
export function applyInline(s, options = {}) {
  const { mediaBaseUrl = null } = options;
  // Normalize KaTeX's alternate inline delimiters before the shared renderer.
  s = s.replace(/\\\\\(([^\n]*?)\\\\\)/g, (_, math) => `$${math}$`);
  // ── Inline math $…$ ─────────────────────────────────────────────────────
  const iMathStash = [];
  s = s.replace(/\$([^\$\n]+)\$/g, (_, m) => {
    const idx = iMathStash.length;
    // Decode HTML entities so KaTeX receives the original LaTeX source.
    const decoded = unescapeHtmlEntities(m.trim());
    if (typeof window.katex !== "undefined") {
      try {
        iMathStash.push(
          window.katex.renderToString(decoded, {
            displayMode: false,
            throwOnError: false,
          }),
        );
      } catch {
        iMathStash.push(
          `<span class="math-inline math-raw">$${escHtml(m)}$</span>`,
        );
      }
    } else {
      iMathStash.push(
        `<span class="math-inline math-raw">$${escHtml(m)}$</span>`,
      );
    }
    return `\x01IM${idx}\x01`;
  });

  // ── Inline code ─────────────────────────────────────────────────────────
  s = s.replace(/`([^`\n]+)`/g, '<code class="inline-code">$1</code>');
  // ── Bold + italic combined ───────────────────────────────────────────────
  s = s.replace(/\*\*\*([^*]+)\*\*\*/g, "<strong><em>$1</em></strong>");
  // ── Bold ────────────────────────────────────────────────────────────────
  s = s.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");
  // Underscore emphasis must only fire at a word boundary
  s = s.replace(/(^|[^\w])__([^_\n]+)__(?!\w)/g, "$1<strong>$2</strong>");
  // ── Italic ──────────────────────────────────────────────────────────────
  s = s.replace(/\*([^*\n]+)\*/g, "<em>$1</em>");
  s = s.replace(/(^|[^\w])_([^_\n]+)_(?!\w)/g, "$1<em>$2</em>");
  // ── Strikethrough ───────────────────────────────────────────────────────
  s = s.replace(/~~([^~\n]+)~~/g, "<del>$1</del>");
  // ── Highlight ───────────────────────────────────────────────────────────
  // ==text== -> a <mark>-equivalent span colored from --md-highlight-color
  // (defaults to a yellow-equivalent in markdown-css.js when the variable
  // is unset). A <span> rather than a literal <mark> so the color is driven
  // purely by our CSS variable instead of each browser's UA default for
  // <mark>, which differs and isn't overridable per-container the way the
  // lesson reader's font/highlight picker needs (see the lessons plan's
  // Phase 2 step 7 — only this CSS-variable *hook* lives in the shared
  // engine; the picker UI itself is lesson-page-only).
  //
  // DYNAMIC PER-SPAN COLOR: an optional `==text==(color)` suffix sets that
  // one span's color directly via an inline `style="--md-highlight-color:…"`
  // override, so different `==...==` runs in the SAME document can each
  // carry their own color instead of all sharing the one page-wide
  // `--md-highlight-color` variable. `color` may be a `#rgb`/`#rrggbb` hex
  // or a bare CSS color keyword (e.g. `pink`) — both are safe to place
  // inside a style attribute unescaped since the pattern below only ever
  // captures `[a-zA-Z0-9#]` characters, nothing that can break out of the
  // attribute. Omitting the suffix keeps the old behavior (inherits
  // whatever --md-highlight-color the container has set, e.g. from the
  // lesson reader's picker).
  //
  // SERIALIZATION NOTE: this rule is a plain regex replace with no new
  // module-scope dependency, so applyInline() stays safe to
  // .toString()-inline into standalone offline exports (see
  // export-to-quiz.js, which serializes this function by reference). Any
  // future change here that reaches for a module-scope const/helper MUST
  // also be added to that file's serialization block, or exported quizzes
  // will throw ReferenceErrors.
  s = s.replace(
    /==([^=\n]+)==(?:\(([a-zA-Z0-9#]{1,20})\))?/g,
    (full, inner, color) =>
      color
        ? `<span class="md-highlight" style="--md-highlight-color:${color}">${inner}</span>`
        : `<span class="md-highlight">${inner}</span>`,
  );

  // SECURITY: the captured URL must be HTML-escaped before being placed
  // inside the href="…"/src="…" attribute. Without this, a URL containing a
  // double-quote (e.g. `https://x/" onmouseover="alert(1)`) breaks out of
  // the attribute and injects arbitrary HTML/JS. escHtml() also neutralises
  // '<' and '>' inside the URL, which could otherwise close the tag early.
  //
  // NOTE: applyInline() is normally called with input that has ALREADY
  // been through escHtml() once (see the internal call sites throughout
  // this module), but it is also exported and may be called directly by
  // other pages on raw, unescaped text. To produce correct output on both
  // paths without double-encoding (e.g. turning "?a=1&b=2" into "&amp;amp;"
  // instead of "&amp;"), we first undo any escaping that already happened,
  // then escape exactly once.
  const safeUrl = (url) => escHtml(unescapeHtmlEntities(url));

  // ── Images / Audio / Video ────────────────────────────────────────────────
  // ![alt](url)   -> <img>                          (unchanged legacy behavior)
  // ![audio](url) -> <audio> (skeleton + retry, same as legacy q.audio field)
  // ![video](url) -> <video>, or a YouTube iframe when the URL is a YouTube link
  //
  // The alt-text position doubles as a type keyword: literal "audio" or
  // "video" (case-insensitive) switches to media rendering; any other alt
  // text (including empty) renders a plain image, exactly as before — this
  // keeps every existing `![...](...)  ` usage elsewhere in the app (e.g.
  // docs screenshots, quiz images) working unchanged.
  //
  // URL matching was widened from `https?://`-only to also accept
  // site-root-relative ("./assets/...", "assets/...") and other relative
  // paths, since legacy media data includes quiz-folder-relative paths
  // (e.g. "./assets/quiz-media/TEST_1/Part_1.mp4") that getMediaUrlCandidates()
  // already knows how to resolve — the old images-only regex never needed
  // this because dedicated-field images were normalized to absolute URLs by
  // the previous non-markdown render path; embedding directly in markdown
  // means we now receive whatever raw path form the data was saved with.
  s = s.replace(
    /!\[(audio|video|[^\]]*)\]\(([^\s)]+)\)/gi,
    (_, kind, url) => {
      const normalizedKind = kind.toLowerCase();
      if (normalizedKind === "audio" || normalizedKind === "video") {
        return renderInlineMediaTag(normalizedKind, url, mediaBaseUrl);
      }
      return `<img src="${safeUrl(url)}" alt="${safeUrl(kind)}" class="md-img" loading="lazy">`;
    },
  );
  // ── Links ───────────────────────────────────────────────────────────────
  s = s.replace(
    /\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g,
    (_, text, url) =>
      `<a href="${safeUrl(url)}" target="_blank" rel="noopener noreferrer" class="md-link">${text}</a>`,
  );


  // Restore inline math placeholders
  s = s.replace(/\x01IM(\d+)\x01/g, (_, i) => iMathStash[parseInt(i)]);
  return s;
}

// ─── 4. SVG icons (inlined so the module has zero external dependencies) ──────
export const ICON_COPY = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
  viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
  stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/>
  <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
</svg>`;

export const ICON_CHECK = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
  viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
  stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  <path d="M20 6 9 17l-5-5"/>
</svg>`;

// ─── 4b. Copy-button label (i18n) ──────────────────────────────────────────────
// The "Copy" text shown on fenced code-block copy buttons. Was previously
// hardcoded to Arabic ("نسخ") regardless of page language. Pages can set
// `window.MD_COPY_LABEL` before calling renderMarkdown() to localise it;
// otherwise it falls back to the original Arabic default to preserve
// existing visual behaviour for callers that relied on it.
export const COPY_LABEL =
  (typeof window !== "undefined" && window.MD_COPY_LABEL) || "نسخ";

// ─── 5. Copy-button handler (global registration) ─────────────────────────────
// Buttons use inline onclick="window.copyCodeBlock(this)" so this must be
// on window.  Registering here on module import means whichever page loads
// markdown.js first gets the handler for free.
window.copyCodeBlock = (btn) => {
  const wrapper = btn.closest(".code-block-wrapper");
  if (!wrapper) return;
  const codeEl = wrapper.querySelector("code");
  if (!codeEl) return;

  navigator.clipboard
    .writeText(codeEl.innerText)
    .then(() => {
      const original = btn.innerHTML;
      btn.innerHTML = `${ICON_CHECK}`;
      btn.classList.add("copied");
      btn.setAttribute("aria-label", "Copied!");
      setTimeout(() => {
        btn.innerHTML = original;
        btn.classList.remove("copied");
        btn.setAttribute("aria-label", "Copy code");
      }, 2000);
    })
    .catch(() => {
      // Fallback: select the text so the user can Ctrl+C manually
      const range = document.createRange();
      range.selectNodeContents(codeEl);
      const sel = window.getSelection();
      if (sel) {
        sel.removeAllRanges();
        sel.addRange(range);
      }
    });
};

// ─── 5b. Feature: User-Resizable Media ─────────────────────────────────────
// Restores drag-resizing of inline media (previously only available for the
// legacy dedicated q.image/q.audio/q.video fields via quiz.js's now-orphaned
// initMediaResize — nothing sets data-resize-key anymore since all media
// moved to inline markdown, see the "Step -1" comment in _renderMarkdownCore
// and MD_MEDIA_SKELETON_HTML's own doc comment above).
//
// Implemented directly in the engine (not as a page-level init call) so it
// works uniformly across quiz.html, create-quiz.html and result.html without
// any of those pages needing to know it exists: a single MutationObserver
// registered once on module import (same side-effect-on-import pattern as
// window.copyCodeBlock above) watches the whole document for newly-rendered
// `.media-container[data-resize-key]` elements — which renderInlineMediaTag/
// _renderRawImageTag/_renderRawMediaTag above already tag every inline image,
// audio, video and YouTube embed with — and equips each one the first time
// it appears. Drag handling itself is a single pair of delegated
// pointerdown/pointermove/pointerup listeners on `document`, so newly
// rendered containers are draggable immediately with no per-element binding.
//
// Handle count per the spec: images/video get 4 corner handles (proportional
// resize, aspect ratio locked); audio gets 2 handles, one on each side
// (width-only — its height is fixed by the browser's native player chrome).
export const RESIZE_STORAGE_PREFIX = "md_resizable_media_";

export function _getMediaSizeStorageKey(resizeKey) {
  return `${RESIZE_STORAGE_PREFIX}${resizeKey}`;
}

export function _loadSavedMediaSize(resizeKey) {
  try {
    const raw = localStorage.getItem(_getMediaSizeStorageKey(resizeKey));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (
      parsed &&
      typeof parsed.width === "number" &&
      (typeof parsed.height === "number" || parsed.height === null)
    ) {
      return parsed;
    }
  } catch {
    /* ignore malformed/legacy entries */
  }
  return null;
}

export function _saveMediaSize(resizeKey, width, height) {
  try {
    localStorage.setItem(
      _getMediaSizeStorageKey(resizeKey),
      JSON.stringify({ width, height }),
    );
  } catch {
    /* localStorage may be full/unavailable; resizing still works this session */
  }
}

// Debounce writes so dragging a handle doesn't hammer localStorage on every
// pointermove. Keyed per resizeKey so concurrent resizes (unlikely, but
// possible with multiple media elements) don't clobber each other's timers.
export const _resizeSaveDebounces = new Map();
export function _saveMediaSizeDebounced(resizeKey, width, height) {
  clearTimeout(_resizeSaveDebounces.get(resizeKey));
  _resizeSaveDebounces.set(
    resizeKey,
    setTimeout(() => _saveMediaSize(resizeKey, width, height), 400),
  );
}

/**
 * Injects the appropriate resize handles into one `.media-container` and
 * restores any previously-saved size. Safe to call multiple times on the
 * same container (guarded by `data-resize-init`).
 * @param {HTMLElement} container
 */
export function _equipResizableMedia(container) {
  if (container.dataset.resizeInit) return;
  container.dataset.resizeInit = "1";
  container.classList.add("resizable-media");

  const resizeKey = container.dataset.resizeKey;
  const isAudio = container.dataset.resizeKind === "audio";

  // Images/video/YouTube get 4 corner handles; audio gets 2 side handles
  // (left/right) since its height is fixed by the native player.
  const handleDirs = isAudio ? ["w", "e"] : ["nw", "ne", "sw", "se"];
  handleDirs.forEach((dir) => {
    if (container.querySelector(`.resize-handle--${dir}`)) return;
    const h = document.createElement("div");
    h.className = `resize-handle resize-handle--${dir}`;
    h.setAttribute("aria-hidden", "true");
    container.appendChild(h);
  });

  // Restore a previously-dragged size. Otherwise leave the container's
  // existing inline size attributes (e.g. an <img>'s width/height, or a
  // size a prior renderMarkdown call already baked in) exactly as rendered.
  const saved = _loadSavedMediaSize(resizeKey);
  if (saved) {
    container.style.width = `${saved.width}px`;
    if (!isAudio && saved.height) container.style.height = `${saved.height}px`;
  }
}

/**
 * Reveals inline media (hides its loading skeleton) once it's actually
 * loaded, and retries the next candidate URL on error — same reveal-on-
 * load / retry-on-error logic quiz.js's initMediaSkeletons has always had,
 * moved into the engine itself so it also runs on /create-quiz and /result,
 * which never called quiz.js's copy and so left every audio/video/image
 * permanently stuck behind its loading skeleton. Guarded by
 * `data-skeleton-init` so it only binds once per container.
 * @param {HTMLElement} container
 */
export function _equipMediaSkeleton(container) {
  if (container.dataset.skeletonInit) return;
  container.dataset.skeletonInit = "1";

  const media = container.querySelector("img, audio, video");
  const skeleton = container.querySelector(".media-skeleton");
  if (!media || !skeleton) return;

  let candidates = [];
  try {
    candidates = JSON.parse(media.dataset.mediaCandidates || "[]");
  } catch {
    candidates = getMediaUrlCandidates(media.dataset.mediaRaw || media.src);
  }
  if (!candidates.length) candidates = [media.src];

  const currentUrl = media.src;
  const currentBaseUrl = currentUrl ? currentUrl.split("?")[0] : "";
  let candidateIdx = Math.max(
    0,
    candidates.findIndex((url) => url === currentBaseUrl || url === currentUrl),
  );

  const reveal = () => {
    skeleton.classList.add("media-skeleton--hidden");
    media.classList.add("media-loaded");
  };

  const showError = () => {
    skeleton.classList.remove("media-skeleton--hidden");
    skeleton.classList.add("media-skeleton--error");
    skeleton.innerHTML =
      '<span class="media-error">تعذّر تحميل الوسائط. تحقق من المسار أو الرابط.</span>';
  };

  const applyMediaSrc = (el, url) => {
    const urlWithCacheBust = url
      ? `${url}${url.includes("?") ? "&" : "?"}_cb=${Date.now()}`
      : url;
    el.src = urlWithCacheBust;
    const source = el.querySelector && el.querySelector("source");
    if (source) source.src = urlWithCacheBust;
    if (el.tagName !== "IMG") el.load();
  };

  const tryNextCandidate = () => {
    candidateIdx += 1;
    if (candidateIdx < candidates.length) {
      applyMediaSrc(media, candidates[candidateIdx]);
      return true;
    }
    showError();
    return false;
  };

  if (media.tagName === "IMG") {
    const onLoad = () => reveal();
    const onError = () => {
      if (!tryNextCandidate()) return;
      media.addEventListener("load", onLoad, { once: true });
      media.addEventListener("error", onError, { once: true });
    };
    if (media.complete && media.naturalWidth > 0) {
      reveal();
    } else {
      media.addEventListener("load", onLoad, { once: true });
      media.addEventListener("error", onError, { once: true });
    }
    return;
  }

  const onMediaReady = () => {
    if (media.readyState >= 1) reveal();
  };
  const onMediaError = () => {
    if (!tryNextCandidate()) return;
    media.addEventListener("loadedmetadata", onMediaReady, { once: true });
    media.addEventListener("canplay", onMediaReady, { once: true });
    media.addEventListener("error", onMediaError, { once: true });
  };

  media.addEventListener("loadedmetadata", onMediaReady, { once: true });
  media.addEventListener("loadeddata", onMediaReady, { once: true });
  media.addEventListener("canplay", onMediaReady, { once: true });
  media.addEventListener("error", onMediaError, { once: true });

  onMediaReady();

  requestAnimationFrame(() => {
    if (!skeleton.classList.contains("media-skeleton--hidden")) onMediaReady();
  });

  setTimeout(() => {
    if (
      !skeleton.classList.contains("media-skeleton--hidden") &&
      !skeleton.classList.contains("media-skeleton--error") &&
      media.readyState >= 1
    ) {
      reveal();
    }
  }, 500);
}

/**
 * Scans `root` for not-yet-equipped resizable media containers and equips
 * them. Exported so export-to-quiz.js's static-export bundler can inline it
 * (same .toString()-serialization pattern as scanDirections/renderMarkdown).
 * @param {HTMLElement|Document} [root=document]
 */
export function _scanResizableMedia(root = document) {
  if (!root.querySelectorAll) return;
  root.querySelectorAll(".media-container[data-resize-key]").forEach(_equipResizableMedia);
  root.querySelectorAll(".media-container").forEach(_equipMediaSkeleton);
}

// ── Delegated drag-resize (registered once, module-load side effect) ──────
// Aspect ratio priority: natural media dimensions > explicit 16:9 for
// iframes (YouTube) > current rendered box size as a last resort. Corner
// handles scale symmetrically from the container's center (matching the
// flex-centered layout most media sits in) so dragging never shifts the
// element sideways.
if (typeof document !== "undefined") {
  let activeDrag = null;

  document.addEventListener("pointerdown", (eDown) => {
    const handle = eDown.target.closest && eDown.target.closest(".resize-handle");
    if (!handle) return;
    const container = handle.closest(".media-container[data-resize-key]");
    if (!container) return;

    eDown.preventDefault();
    eDown.stopPropagation();
    handle.setPointerCapture(eDown.pointerId);
    handle.classList.add("is-active");
    document.body.classList.add("is-resizing-media");

    const resizeKey = container.dataset.resizeKey;
    const isAudio = container.dataset.resizeKind === "audio";
    const startW = container.offsetWidth;
    const startH = container.offsetHeight;

    const mediaEl = container.querySelector("img, video, iframe, audio");
    const isIframe = typeof HTMLIFrameElement !== "undefined" && mediaEl instanceof HTMLIFrameElement;
    const aspectRatio =
      mediaEl instanceof HTMLImageElement && mediaEl.naturalWidth > 0
        ? mediaEl.naturalWidth / mediaEl.naturalHeight
        : mediaEl instanceof HTMLVideoElement && mediaEl.videoWidth > 0
          ? mediaEl.videoWidth / mediaEl.videoHeight
          : isIframe
            ? 16 / 9
            : startH > 0
              ? startW / startH
              : 16 / 9;

    const minW = isAudio ? 200 : 120;
    const minH = isAudio ? 52 : 80;
    const maxW = container.parentElement
      ? container.parentElement.clientWidth
      : window.innerWidth;

    activeDrag = {
      pointerId: eDown.pointerId,
      handle,
      container,
      resizeKey,
      isAudio,
      startW,
      startH,
      startX: eDown.clientX,
      startY: eDown.clientY,
      aspectRatio,
      minW,
      minH,
      maxW,
    };
  });

  document.addEventListener("pointermove", (eMove) => {
    if (!activeDrag || eMove.pointerId !== activeDrag.pointerId) return;
    const {
      handle, container, resizeKey, isAudio,
      startW, startH, startX, startY, aspectRatio, minW, minH, maxW,
    } = activeDrag;

    const dxRaw = eMove.clientX - startX;
    const dyRaw = eMove.clientY - startY;
    const cl = handle.classList;
    const isRight = cl.contains("resize-handle--ne") || cl.contains("resize-handle--se") || cl.contains("resize-handle--e");
    const isBottom = cl.contains("resize-handle--sw") || cl.contains("resize-handle--se");

    // Positive dx/dy = growing. Each handle drags symmetrically from the
    // center (×2) so the container never shifts sideways in its centered
    // flex parent.
    const dx = isRight ? dxRaw : -dxRaw;
    const dy = isBottom ? dyRaw : -dyRaw;

    if (isAudio) {
      const newW = Math.max(minW, Math.min(maxW, startW + dx * 2));
      container.style.width = `${newW}px`;
      _saveMediaSizeDebounced(resizeKey, Math.round(newW), null);
      return;
    }

    // Corner handle: dominant drag axis drives the scale, the other
    // dimension follows the locked aspect ratio.
    const scaleByX = (startW + dx * 2) / startW;
    const scaleByY = (startH + dy * 2) / startH;
    const scale = Math.abs(dxRaw) >= Math.abs(dyRaw) ? scaleByX : scaleByY;
    let newW = Math.max(minW, Math.min(maxW, startW * scale));
    let newH = newW / aspectRatio;
    if (newH < minH) {
      newH = minH;
      newW = newH * aspectRatio;
    }

    container.style.width = `${newW}px`;
    container.style.height = `${newH}px`;
    _saveMediaSizeDebounced(resizeKey, Math.round(newW), Math.round(newH));
  });

  const endDrag = () => {
    if (!activeDrag) return;
    activeDrag.handle.classList.remove("is-active");
    document.body.classList.remove("is-resizing-media");
    activeDrag = null;
  };
  document.addEventListener("pointerup", endDrag);
  document.addEventListener("pointercancel", endDrag);

  // Watch the whole document for newly-rendered media containers (pages
  // simply do `el.innerHTML = renderMarkdown(...)`; there is no dedicated
  // "markdown was just inserted" hook to call into instead) and equip any
  // that appear. Runs an initial scan too, in case markdown.js is imported
  // after some markdown-rendered content already exists in the DOM.
  const scheduleResizeScan = (() => {
    let scheduled = false;
    return () => {
      if (scheduled) return;
      scheduled = true;
      requestAnimationFrame(() => {
        scheduled = false;
        _scanResizableMedia(document);
      });
    };
  })();

  if (document.body) {
    new MutationObserver(scheduleResizeScan).observe(document.body, {
      childList: true,
      subtree: true,
    });
    scheduleResizeScan();
  } else {
    document.addEventListener("DOMContentLoaded", () => {
      new MutationObserver(scheduleResizeScan).observe(document.body, {
        childList: true,
        subtree: true,
      });
      scheduleResizeScan();
    });
  }
}


// Zero-dependency tokeniser that emits <span class="sh-*"> tokens.
// Supports: js/ts/jsx/tsx, python, css/scss/less, html/xml/svg, bash/sh/zsh,
//           json, sql, java, c/cpp/c#, go, rust, ruby, swift, kotlin, php,
//           yaml, toml, markdown, dockerfile, graphql, scala, dart, elixir,
//           lua, perl, r, matlab, powershell, and plain text (escHtml fallback).
//
// Strategy: single-pass regex alternation on raw (un-escaped) code.
// Each branch is mutually exclusive and tried in priority order.
// The function returns HTML-escaped, span-wrapped text ready for innerHTML.

export const _HL_KEYWORDS = {
  js: new Set([
    "break", "case", "catch", "class", "const", "continue", "debugger", "default", "delete",
    "do", "else", "export", "extends", "finally", "for", "function", "if", "import", "in",
    "instanceof", "let", "new", "of", "return", "static", "super", "switch", "throw", "try",
    "typeof", "var", "void", "while", "with", "yield", "async", "await", "from", "as", "null",
    "undefined", "true", "false", "this",
  ]),
  ts: new Set([
    "break", "case", "catch", "class", "const", "continue", "debugger", "default", "delete",
    "do", "else", "export", "extends", "finally", "for", "function", "if", "import", "in",
    "instanceof", "let", "new", "of", "return", "static", "super", "switch", "throw", "try",
    "typeof", "var", "void", "while", "with", "yield", "async", "await", "from", "as", "null",
    "undefined", "true", "false", "this", "type", "interface", "enum", "implements", "declare",
    "namespace", "abstract", "readonly", "keyof", "infer", "never", "any", "unknown", "object",
  ]),
  python: new Set([
    "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class",
    "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global",
    "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return",
    "try", "while", "with", "yield", "self", "cls",
  ]),
  java: new Set([
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class",
    "const", "continue", "default", "do", "double", "else", "enum", "extends", "final",
    "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int",
    "interface", "long", "native", "new", "null", "package", "private", "protected", "public",
    "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
    "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false",
  ]),
  csharp: new Set([
    "abstract", "as", "base", "bool", "break", "byte", "case", "catch", "char", "checked",
    "class", "const", "continue", "decimal", "default", "delegate", "do", "double", "else",
    "enum", "event", "explicit", "extern", "false", "finally", "fixed", "float", "for",
    "foreach", "goto", "if", "implicit", "in", "int", "interface", "internal", "is", "lock",
    "long", "namespace", "new", "null", "object", "operator", "out", "override", "params",
    "private", "protected", "public", "readonly", "ref", "return", "sbyte", "sealed", "short",
    "sizeof", "stackalloc", "static", "string", "struct", "switch", "this", "throw", "true",
    "try", "typeof", "uint", "ulong", "unchecked", "unsafe", "ushort", "using", "virtual",
    "void", "volatile", "while", "add", "alias", "and", "ascending", "async", "await", "by",
    "descending", "dynamic", "equals", "file", "from", "get", "global", "group", "init",
    "into", "join", "let", "managed", "nameof", "nint", "not", "notnull", "nuint", "on", "or",
    "orderby", "partial", "record", "remove", "required", "scoped", "select", "set",
    "unmanaged", "value", "var", "when", "where", "with", "yield",
  ]),
  c: new Set([
    "auto", "break", "case", "char", "const", "continue", "default", "do", "double", "else",
    "enum", "extern", "float", "for", "goto", "if", "inline", "int", "long", "register",
    "restrict", "return", "short", "signed", "sizeof", "static", "struct", "switch", "typedef",
    "union", "unsigned", "void", "volatile", "while", "NULL", "true", "false",
  ]),
  go: new Set([
    "break", "case", "chan", "const", "continue", "default", "defer", "else", "fallthrough",
    "for", "func", "go", "goto", "if", "import", "interface", "map", "package", "range",
    "return", "select", "struct", "switch", "type", "var", "nil", "true", "false", "iota",
  ]),
  rust: new Set([
    "as", "async", "await", "break", "const", "continue", "crate", "dyn", "else", "enum",
    "extern", "false", "fn", "for", "if", "impl", "in", "let", "loop", "match", "mod", "move",
    "mut", "pub", "ref", "return", "self", "Self", "static", "struct", "super", "trait",
    "true", "type", "union", "unsafe", "use", "where", "while",
  ]),
  ruby: new Set([
    "BEGIN", "END", "alias", "and", "begin", "break", "case", "class", "def", "defined", "do",
    "else", "elsif", "end", "ensure", "false", "for", "if", "in", "module", "next", "nil",
    "not", "or", "redo", "rescue", "retry", "return", "self", "super", "then", "true", "undef",
    "unless", "until", "when", "while", "yield",
  ]),
  kotlin: new Set([
    "as", "break", "class", "continue", "do", "else", "false", "for", "fun", "if", "in",
    "interface", "is", "null", "object", "package", "return", "super", "this", "throw", "true",
    "try", "typealias", "typeof", "val", "var", "when", "while", "by", "catch", "constructor",
    "delegate", "dynamic", "field", "file", "finally", "get", "import", "init", "param",
    "property", "receiver", "set", "setparam", "where", "actual", "abstract", "annotation",
    "companion", "crossinline", "data", "enum", "expect", "external", "final", "infix",
    "inline", "inner", "internal", "lateinit", "noinline", "open", "operator", "out",
    "override", "private", "protected", "public", "reified", "sealed", "suspend", "tailrec",
    "vararg",
  ]),
  swift: new Set([
    "associatedtype", "class", "deinit", "enum", "extension", "fileprivate", "func", "import",
    "init", "inout", "internal", "let", "open", "operator", "private", "precedencegroup",
    "protocol", "public", "rethrows", "static", "struct", "subscript", "typealias", "var",
    "break", "case", "catch", "continue", "default", "defer", "do", "else", "fallthrough",
    "for", "guard", "if", "in", "repeat", "return", "throw", "switch", "where", "while", "Any",
    "as", "catch", "false", "is", "nil", "rethrows", "self", "Self", "super", "throw",
    "throws", "true", "try",
  ]),
  php: new Set([
    "abstract", "and", "array", "as", "break", "callable", "case", "catch", "class", "clone",
    "const", "continue", "declare", "default", "die", "do", "echo", "else", "elseif", "empty",
    "enddeclare", "endfor", "endforeach", "endif", "endswitch", "endwhile", "eval", "exit",
    "extends", "final", "finally", "fn", "for", "foreach", "function", "global", "goto", "if",
    "implements", "include", "include_once", "instanceof", "insteadof", "interface", "isset",
    "list", "match", "namespace", "new", "or", "print", "private", "protected", "public",
    "readonly", "require", "require_once", "return", "static", "switch", "throw", "trait",
    "try", "unset", "use", "var", "while", "xor", "yield", "null", "true", "false",
  ]),
  sql: new Set([
    "SELECT", "FROM", "WHERE", "AND", "OR", "NOT", "INSERT", "INTO", "VALUES", "UPDATE", "SET",
    "DELETE", "CREATE", "TABLE", "ALTER", "ADD", "DROP", "INDEX", "VIEW", "DATABASE",
    "PRIMARY", "KEY", "FOREIGN", "REFERENCES", "UNIQUE", "CHECK", "DEFAULT", "CONSTRAINT",
    "JOIN", "INNER", "LEFT", "RIGHT", "FULL", "OUTER", "ON", "GROUP", "BY", "HAVING", "ORDER",
    "ASC", "DESC", "LIMIT", "OFFSET", "UNION", "ALL", "DISTINCT", "AS", "IN", "IS", "NULL",
    "LIKE", "BETWEEN", "EXISTS", "CASE", "WHEN", "THEN", "ELSE", "END", "WITH", "OVER",
    "PARTITION", "FUNCTION", "PROCEDURE", "BEGIN", "COMMIT", "ROLLBACK", "TRANSACTION",
    "COUNT", "SUM", "AVG", "MIN", "MAX", "COALESCE", "CAST", "CONVERT", "CONCAT",
  ]),
  bash: new Set([
    "if", "then", "else", "elif", "fi", "for", "in", "do", "done", "while", "until", "case",
    "esac", "function", "return", "exit", "break", "continue", "export", "local", "readonly",
    "declare", "typeset", "unset", "source", "alias", "echo", "printf", "read", "test", "true",
    "false", "shift", "exec", "eval", "trap", "wait", "kill", "set", "unset",
  ]),
  yaml: new Set([
    "true", "false", "null", "yes", "no", "on", "off",
  ]),
  toml: new Set([
    "true", "false", "nan", "inf",
  ]),
  graphql: new Set([
    "query", "mutation", "subscription", "fragment", "on", "type", "interface", "union",
    "enum", "input", "scalar", "schema", "directive", "extend", "implements", "true", "false",
    "null", "repeatable",
  ]),
  scala: new Set([
    "abstract", "case", "catch", "class", "def", "do", "else", "extends", "false", "final",
    "finally", "for", "forSome", "if", "implicit", "import", "lazy", "match", "new", "null",
    "object", "override", "package", "private", "protected", "return", "sealed", "super",
    "this", "throw", "trait", "try", "true", "type", "val", "var", "while", "with", "yield",
    "given", "then", "export", "enum", "end",
  ]),
  dart: new Set([
    "abstract", "as", "assert", "async", "await", "break", "case", "catch", "class", "const",
    "continue", "covariant", "default", "deferred", "do", "dynamic", "else", "enum", "export",
    "extends", "extension", "external", "factory", "false", "final", "finally", "for",
    "Function", "get", "hide", "if", "implements", "import", "in", "interface", "is", "late",
    "library", "mixin", "new", "null", "on", "operator", "part", "required", "rethrow",
    "return", "sealed", "set", "show", "static", "super", "switch", "sync", "this", "throw",
    "true", "try", "typedef", "var", "void", "when", "while", "with", "yield",
  ]),
  elixir: new Set([
    "after", "and", "catch", "cond", "def", "defcallback", "defdelegate", "defexception",
    "defimpl", "defmacro", "defmacrop", "defmodule", "defoverridable", "defp", "defprotocol",
    "defrecord", "defstruct", "do", "else", "end", "false", "fn", "for", "if", "import", "in",
    "nil", "not", "or", "raise", "receive", "require", "rescue", "super", "throw", "true",
    "try", "unless", "use", "when", "with",
  ]),
  lua: new Set([
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if",
    "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while",
  ]),
  perl: new Set([
    "if", "unless", "while", "until", "for", "foreach", "do", "given", "when", "default",
    "else", "elsif", "sub", "my", "our", "local", "use", "no", "package", "require", "return",
    "last", "next", "redo", "goto", "print", "say", "die", "warn", "chomp", "chop", "push",
    "pop", "shift", "unshift", "splice", "reverse", "sort", "map", "grep", "join", "split",
    "ref", "defined", "undef", "wantarray", "caller", "eval", "BEGIN", "END", "DESTROY",
  ]),
  r: new Set([
    "if", "else", "repeat", "while", "function", "for", "in", "next", "break", "TRUE", "FALSE",
    "NULL", "Inf", "NaN", "NA", "NA_integer_", "NA_real_", "NA_complex_", "NA_character_",
    "return", "invisible", "stop", "warning", "message", "library", "require", "source", "cat",
    "print", "paste", "sprintf",
  ]),
  matlab: new Set([
    "break", "case", "catch", "classdef", "continue", "else", "elseif", "end", "for",
    "function", "global", "if", "otherwise", "parfor", "persistent", "return", "spmd",
    "switch", "try", "while", "true", "false", "Inf", "NaN", "pi", "eps", "nargin", "nargout",
    "varargin", "varargout",
  ]),
  powershell: new Set([
    "Begin", "Break", "Catch", "Class", "Continue", "Data", "Define", "Do", "DynamicParam",
    "Else", "ElseIf", "End", "Enum", "Exit", "Filter", "Finally", "For", "ForEach", "From",
    "Function", "Hidden", "If", "In", "InlineScript", "Param", "Process", "Return", "Sequence",
    "Static", "Switch", "Throw", "Trap", "Try", "Until", "Using", "Var", "While", "Workflow",
    "$true", "$false", "$null",
  ]),
  dockerfile: new Set([
    "FROM", "RUN", "CMD", "LABEL", "EXPOSE", "ENV", "ADD", "COPY", "ENTRYPOINT", "VOLUME",
    "USER", "WORKDIR", "ARG", "ONBUILD", "STOPSIGNAL", "HEALTHCHECK", "SHELL", "MAINTAINER",
  ]),
};

// ── Language aliases ──────────────────────────────────────────────────────────
// Programming languages
_HL_KEYWORDS.javascript = _HL_KEYWORDS.js;
_HL_KEYWORDS.typescript = _HL_KEYWORDS.ts;
_HL_KEYWORDS.jsx = _HL_KEYWORDS.js;
_HL_KEYWORDS.tsx = _HL_KEYWORDS.ts;
_HL_KEYWORDS.cpp = _HL_KEYWORDS.c;
_HL_KEYWORDS["c++"] = _HL_KEYWORDS.c;
_HL_KEYWORDS.cxx = _HL_KEYWORDS.c;
_HL_KEYWORDS.cs = _HL_KEYWORDS.csharp;
_HL_KEYWORDS["c#"] = _HL_KEYWORDS.csharp;
_HL_KEYWORDS.py = _HL_KEYWORDS.python;
_HL_KEYWORDS.rb = _HL_KEYWORDS.ruby;
_HL_KEYWORDS.kt = _HL_KEYWORDS.kotlin;
_HL_KEYWORDS.rs = _HL_KEYWORDS.rust;
_HL_KEYWORDS.golang = _HL_KEYWORDS.go;
_HL_KEYWORDS.ex = _HL_KEYWORDS.elixir;
_HL_KEYWORDS.exs = _HL_KEYWORDS.elixir;
_HL_KEYWORDS.scala = _HL_KEYWORDS.scala; // keep explicit for look-up clarity
_HL_KEYWORDS.sc = _HL_KEYWORDS.scala;
_HL_KEYWORDS.pl = _HL_KEYWORDS.perl;
_HL_KEYWORDS.pm = _HL_KEYWORDS.perl;
_HL_KEYWORDS.ps1 = _HL_KEYWORDS.powershell;
_HL_KEYWORDS.psm1 = _HL_KEYWORDS.powershell;
_HL_KEYWORDS.psd1 = _HL_KEYWORDS.powershell;
// Shell
_HL_KEYWORDS.sh = _HL_KEYWORDS.bash;
_HL_KEYWORDS.shell = _HL_KEYWORDS.bash;
_HL_KEYWORDS.zsh = _HL_KEYWORDS.bash;
_HL_KEYWORDS.fish = _HL_KEYWORDS.bash;
// Data / config formats  (handled by dedicated highlighters; stub entries so
// _HL_KEYWORDS look-up returns a truthy value and highlightCode doesn't skip them)
_HL_KEYWORDS.yml = _HL_KEYWORDS.yaml;
_HL_KEYWORDS.json5 = _HL_KEYWORDS.yaml; // close-enough subset for now
_HL_KEYWORDS.gql = _HL_KEYWORDS.graphql;
// Markup (also handled by dedicated highlighters — stubs make aliases work)
_HL_KEYWORDS.md = null; // markdown → dedicated highlighter (no kw set)
_HL_KEYWORDS.markdown = null;

// JS/TS built-ins worth highlighting
export const _HL_BUILTINS_JS = new Set([
  "console", "Math", "Object", "Array", "String", "Number", "Boolean", "Promise", "JSON", "Date", "RegExp", "Error", "Map", "Set", "WeakMap", "WeakSet", "Symbol", "Proxy", "Reflect", "Intl", "URL", "fetch", "setTimeout", "setInterval", "clearTimeout", "clearInterval", "parseInt", "parseFloat", "isNaN", "isFinite", "encodeURIComponent", "decodeURIComponent", "document", "window", "navigator",
]);

// CSS value-position keywords (color/layout keywords like "auto", "flex",
// "solid", …), used by the CSS highlighter below to decide whether an
// identifier appearing after a ':' should render as .sh-keyword.
// PERF: hoisted to module scope — previously re-allocated as a `new Set()`
// on every single matched identifier inside the CSS tokenizer's hot loop.
export const _CSS_VALUE_KEYWORDS = new Set([
  "auto", "none", "inherit", "initial", "unset", "revert", "normal", "bold",
  "italic", "block", "inline", "flex", "grid", "inline-block", "inline-flex",
  "inline-grid", "contents", "flow-root", "table", "absolute", "relative",
  "fixed", "sticky", "static", "center", "left", "right", "top", "bottom",
  "middle", "baseline", "stretch", "start", "end", "space-between",
  "space-around", "space-evenly", "wrap", "nowrap", "row", "column",
  "row-reverse", "column-reverse", "visible", "hidden", "scroll",
  "clip", "overflow", "pointer", "default", "text", "crosshair", "grab",
  "grabbing", "transparent", "currentColor", "solid", "dashed", "dotted",
  "double", "groove", "ridge", "inset", "outset", "underline", "overline",
  "line-through", "uppercase", "lowercase", "capitalize", "ease", "linear",
  "ease-in", "ease-out", "ease-in-out", "forwards", "backwards", "both",
  "infinite", "alternate", "reverse", "paused", "running", "serif",
  "sans-serif", "monospace", "cursive", "fantasy", "system-ui",
  "max-content", "min-content", "fit-content", "contain", "cover",
  "no-repeat", "repeat", "repeat-x", "repeat-y", "round", "space",
]);

/**
 * Highlight `code` (raw, un-escaped) for the given `lang`.
 * Returns an HTML string with <span class="sh-*"> wrappers.
 * Falls back to escHtml(code) for unrecognised languages.
 */
export function highlightCode(code, lang) {
  const langKey = (lang || "").toLowerCase();

  // ── Specialised language routing ──────────────────────────────────────────
  const isHtmlLike =
    langKey === "html" || langKey === "xml" || langKey === "svg";
  const isCss = langKey === "css" || langKey === "scss" || langKey === "less";
  const isJson = langKey === "json" || langKey === "json5";
  const isMd = langKey === "markdown" || langKey === "md";
  const isYaml = langKey === "yaml" || langKey === "yml";
  const isToml = langKey === "toml";
  const isDockerfile = langKey === "dockerfile" || langKey === "docker";
  const keywords = _HL_KEYWORDS[langKey] ?? null; // may be null for md/markdown

  if (!isHtmlLike && !isCss && !isJson && !isMd && !isYaml && !isToml && !isDockerfile && !keywords) {
    return escHtml(code);
  }

  // ── HTML / XML highlighter ─────────────────────────────────────────────────
  if (isHtmlLike) {
    return (
      code
        .replace(/&/g, "&amp;")
        .replace(/</g, "\x01LT\x01") // temp placeholder
        // Comments
        .replace(
          /&lt;!--[\s\S]*?--&gt;/g,
          (m) => `<span class="sh-comment">${m}</span>`,
        )
        // Tags — do the real tokenising on the raw-ish string
        .replace(
          /\x01LT\x01(\/?)([A-Za-z][A-Za-z0-9\-:.]*)([\s\S]*?)(\/?)>/g,
          (_, slash, tag, attrs, selfClose) => {
            // Escape attrs
            const safeAttrs = attrs
              .replace(/>/g, "&gt;")
              .replace(
                /([A-Za-z][A-Za-z0-9\-:.]*)(\s*=\s*)("([^"]*?)"|'([^']*?)')/g,
                (__, aName, eq, val) =>
                  `<span class="sh-attr">${escHtml(aName)}</span>` +
                  escHtml(eq) +
                  `<span class="sh-string">${escHtml(val)}</span>`,
              );
            return (
              `&lt;` +
              escHtml(slash) +
              `<span class="sh-tag">${escHtml(tag)}</span>` +
              safeAttrs +
              escHtml(selfClose) +
              `&gt;`
            );
          },
        )
        .replace(/\x01LT\x01/g, "&lt;")
    ); // leftover < not part of a tag
  }

  // ── Markdown highlighter ───────────────────────────────────────────────────
  // Strategy: escape the whole line first, then apply span-replacements on the
  // already-escaped text so subsequent passes never double-escape the spans.
  if (isMd) {

    // Handle fenced code blocks spanning multiple lines first (stash them).
    const mdStash = [];
    const mdPush = (html) => {
      const ph = `\x02MD${mdStash.length}\x02`;
      mdStash.push(html);
      return ph;
    };
    let mdCode = code.replace(
      /```([a-zA-Z0-9_+#.-]*)\n?([\s\S]*?)```/g,
      (_, fl, body) =>
        mdPush(
          `<span class="sh-comment">\`\`\`${escHtml(fl)}\n${escHtml(body)}\`\`\`</span>`,
        ),
    );

    const lines = mdCode.split("\n").map((raw) => {
      // Restore stash placeholders on their own lines
      if (/\x02MD\d+\x02/.test(raw))
        return raw.replace(/\x02MD(\d+)\x02/g, (_, i) => mdStash[+i]);

      // Escape first — all further replacements work on safe HTML
      let line = escHtml(raw);

      // ATX headings  # … ######
      if (/^#{1,6}\s/.test(line))
        return `<span class="sh-keyword">${line}</span>`;
      // Setext underlines  ===  / ---
      if (/^={3,}\s*$/.test(line) || /^-{3,}\s*$/.test(line))
        return `<span class="sh-comment">${line}</span>`;
      // Thematic breaks  ***  ---  ___
      if (/^(\*{3,}|-{3,}|_{3,})\s*$/.test(line))
        return `<span class="sh-comment">${line}</span>`;
      // Blockquotes
      if (/^&gt;/.test(line))
        return `<span class="sh-string">${line}</span>`;
      // HTML comments  <!-- … -->
      line = line.replace(
        /(&lt;!--[\s\S]*?--&gt;)/g,
        (m) => `<span class="sh-comment">${m}</span>`,
      );
      // Unordered list bullet markers  - * +
      line = line.replace(
        /^(\s*)([-*+])( )/,
        (_, sp, mk, tr) =>
          sp + `<span class="sh-operator">${mk}</span>` + tr,
      );
      // Ordered list  1.
      line = line.replace(
        /^(\s*)(\d+\.)( )/,
        (_, sp, mk, tr) =>
          sp + `<span class="sh-number">${mk}</span>` + tr,
      );
      // Inline code  `…`  (must come before bold/italic to protect backtick content)
      const codeStash = [];
      line = line.replace(
        /`([^`]+)`/g,
        (_, inner) => {
          const ph = `\x03C${codeStash.length}\x03`;
          codeStash.push(`<span class="sh-string">\`${inner}\`</span>`);
          return ph;
        },
      );
      // Images  ![alt](url)
      line = line.replace(
        /!\[([^\]]*?)\]\(([^)]+?)\)/g,
        (_, alt, url) =>
          `!<span class="sh-function">[${alt}]</span>` +
          `<span class="sh-string">(${url})</span>`,
      );
      // Links  [text](url)
      line = line.replace(
        /\[([^\]]+?)\]\(([^)]+?)\)/g,
        (_, text, url) =>
          `<span class="sh-function">[${text}]</span>` +
          `<span class="sh-string">(${url})</span>`,
      );
      // Bold  **…**  /  __…__
      line = line.replace(
        /(\*\*|__)(.+?)\1/g,
        (_, m, inner) => `<span class="sh-type">${m}${inner}${m}</span>`,
      );
      // Italic  *…*  /  _…_  (only after bold so ** doesn't match as two *)
      line = line.replace(
        /(?<![*_])([*_])(?![*_])(.+?)(?<![*_])\1(?![*_])/g,
        (_, m, inner) => `<span class="sh-builtin">${m}${inner}${m}</span>`,
      );
      // Restore inline-code stash
      line = line.replace(/\x03C(\d+)\x03/g, (_, i) => codeStash[+i]);
      return line;
    });

    return lines.join("\n");
  }

  // ── YAML highlighter ───────────────────────────────────────────────────────
  if (isYaml) {
    return code
      .split("\n")
      .map((line) => {
        // Comments
        if (/^\s*#/.test(line))
          return `<span class="sh-comment">${escHtml(line)}</span>`;
        // Document markers --- / ...
        if (/^(---|\.\.\.)\s*$/.test(line))
          return `<span class="sh-operator">${escHtml(line)}</span>`;
        let out = "";
        // Key: value  (highlight the key)
        out = line.replace(
          /^(\s*)("[^"]+"|'[^']+'|[^:]+?)(:)(.*)/,
          (_, sp, key, colon, rest) => {
            // Value may be a string, number, boolean, or anchor/alias
            const highlightVal = (v) => {
              v = v.trimStart();
              if (/^(true|false|yes|no|on|off|null|~)$/i.test(v))
                return `<span class="sh-keyword">${escHtml(v)}</span>`;
              if (/^-?\d/.test(v))
                return `<span class="sh-number">${escHtml(v)}</span>`;
              if (/^["']/.test(v))
                return `<span class="sh-string">${escHtml(v)}</span>`;
              if (/^[&*]/.test(v))
                return `<span class="sh-builtin">${escHtml(v)}</span>`;
              return escHtml(v);
            };
            return (
              escHtml(sp) +
              `<span class="sh-attr">${escHtml(key)}</span>` +
              escHtml(colon) +
              (rest.trim() ? " " + highlightVal(rest) : escHtml(rest))
            );
          },
        );
        return out || escHtml(line);
      })
      .join("\n");
  }

  // ── TOML highlighter ───────────────────────────────────────────────────────
  if (isToml) {
    return code
      .split("\n")
      .map((line) => {
        if (/^\s*#/.test(line)) return `<span class="sh-comment">${escHtml(line)}</span>`;
        if (/^\[/.test(line.trim())) return `<span class="sh-keyword">${escHtml(line)}</span>`;
        return line.replace(
          /^(\s*)([A-Za-z_][A-Za-z0-9_.\-]*)(\s*=\s*)(.*)/,
          (_, sp, key, eq, val) => {
            let valHtml;
            if (/^(true|false)$/i.test(val.trim()))
              valHtml = `<span class="sh-keyword">${escHtml(val)}</span>`;
            else if (/^-?\d/.test(val.trim()))
              valHtml = `<span class="sh-number">${escHtml(val)}</span>`;
            else if (/^["']|^\["'\[]/.test(val.trim()))
              valHtml = `<span class="sh-string">${escHtml(val)}</span>`;
            else
              valHtml = escHtml(val);
            return escHtml(sp) + `<span class="sh-attr">${escHtml(key)}</span>` + escHtml(eq) + valHtml;
          },
        ) || escHtml(line);
      })
      .join("\n");
  }

  // ── Dockerfile highlighter ─────────────────────────────────────────────────
  if (isDockerfile) {
    const DOCKER_KW = _HL_KEYWORDS.dockerfile;
    return code
      .split("\n")
      .map((line) => {
        if (/^\s*#/.test(line)) return `<span class="sh-comment">${escHtml(line)}</span>`;
        return line.replace(
          /^(\s*)([A-Z]+)(\s|$)/,
          (_, sp, cmd, trail) =>
            DOCKER_KW.has(cmd)
              ? `${escHtml(sp)}<span class="sh-keyword">${escHtml(cmd)}</span>${escHtml(trail)}`
              : escHtml(sp) + escHtml(cmd) + escHtml(trail),
        );
      })
      .join("\n");
  }

  // ── CSS highlighter ────────────────────────────────────────────────────────
  // Full char-by-char tokeniser with:
  //  • Comments, strings, numbers-with-units, CSS variables
  //  • @at-rules (keyword)
  //  • Selectors (tag, class, id, pseudo, combinator, universal)
  //  • Property names (before ':')
  //  • Property values (after ':')
  if (isCss) {
    let out = "";
    const css = code;
    let i = 0;

    // Track context: are we inside a rule block { … }?
    // 0 = top-level (selector territory), 1 = inside rule block (property territory)
    let depth = 0;
    // After a '{' we're in property territory; after each ':' we're in value territory
    // Track whether on a line we've already emitted a property name
    let afterColon = false; // true once we've passed ':' inside a rule

    while (i < css.length) {
      // ── Comments /* … */ ────────────────────────────────────────────────
      if (css[i] === "/" && css[i + 1] === "*") {
        const end = css.indexOf("*/", i + 2);
        const chunk = end === -1 ? css.slice(i) : css.slice(i, end + 2);
        out += `<span class="sh-comment">${escHtml(chunk)}</span>`;
        i += chunk.length;
        continue;
      }
      // ── Strings ─────────────────────────────────────────────────────────
      if (css[i] === '"' || css[i] === "'") {
        const q = css[i];
        let j = i + 1;
        while (j < css.length && css[j] !== q) {
          if (css[j] === "\\") j++;
          j++;
        }
        const chunk = css.slice(i, j + 1);
        out += `<span class="sh-string">${escHtml(chunk)}</span>`;
        i = j + 1;
        continue;
      }
      // ── Opening brace — enter rule block ────────────────────────────────
      if (css[i] === "{") {
        depth++;
        afterColon = false;
        out += `<span class="sh-operator">{</span>`;
        i++;
        continue;
      }
      // ── Closing brace — exit rule block ─────────────────────────────────
      if (css[i] === "}") {
        if (depth > 0) depth--;
        afterColon = false;
        out += `<span class="sh-operator">}</span>`;
        i++;
        continue;
      }
      // ── Semicolon — end of declaration ──────────────────────────────────
      if (css[i] === ";" && depth > 0) {
        afterColon = false;
        out += `<span class="sh-operator">;</span>`;
        i++;
        continue;
      }
      // ── Colon (property separator, not pseudo-class) ─────────────────────
      if (css[i] === ":" && depth > 0 && !afterColon) {
        // Peek: pseudo-class / pseudo-element (::before, :hover) inside selector?
        // Inside a rule block a bare ':' is a property separator.
        afterColon = true;
        out += `<span class="sh-operator">:</span>`;
        i++;
        continue;
      }
      // ── @at-rules ────────────────────────────────────────────────────────
      const atMatch = css.slice(i).match(/^@[a-zA-Z\-]+/);
      if (atMatch) {
        out += `<span class="sh-keyword">${escHtml(atMatch[0])}</span>`;
        i += atMatch[0].length;
        continue;
      }
      // ── CSS custom properties  --foo ─────────────────────────────────────
      const varMatch = css.slice(i).match(/^--[a-zA-Z][a-zA-Z0-9\-_]*/);
      if (varMatch) {
        out += `<span class="sh-variable">${escHtml(varMatch[0])}</span>`;
        i += varMatch[0].length;
        continue;
      }
      // ── Numbers with optional units ──────────────────────────────────────
      const numMatch = css
        .slice(i)
        .match(
          /^-?\d+\.?\d*(%|px|em|rem|vw|vh|vmin|vmax|svh|svw|dvh|dvw|cqw|cqh|pt|pc|cm|mm|in|deg|rad|turn|grad|s|ms|fr|ch|ex|lh|cap|ic|vb|vi)?/,
        );
      if (numMatch && numMatch[0].length > 0 && /\d/.test(numMatch[0][0])) {
        out += `<span class="sh-number">${escHtml(numMatch[0])}</span>`;
        i += numMatch[0].length;
        continue;
      }
      // ── Identifiers ──────────────────────────────────────────────────────
      const identMatch = css.slice(i).match(/^-?[a-zA-Z_][a-zA-Z0-9_\-]*/);
      if (identMatch) {
        const word = identMatch[0];
        if (depth === 0) {
          // Top level: this is a tag-selector
          out += `<span class="sh-tag">${escHtml(word)}</span>`;
        } else if (!afterColon) {
          // Inside rule, before ':': this is a property name
          out += `<span class="sh-attr">${escHtml(word)}</span>`;
        } else {
          // After ':': this is a value keyword (color name, keyword, etc.)
          if (_CSS_VALUE_KEYWORDS.has(word))
            out += `<span class="sh-keyword">${escHtml(word)}</span>`;
          else
            out += escHtml(word);
        }
        i += word.length;
        continue;
      }
      // ── Selectors: class .foo  id #foo  universal *  combinators > ~ + ──
      if (css[i] === "." && depth === 0) {
        const clsMatch = css.slice(i + 1).match(/^-?[a-zA-Z_][a-zA-Z0-9_\-]*/);
        if (clsMatch) {
          out += `<span class="sh-function">.${escHtml(clsMatch[0])}</span>`;
          i += 1 + clsMatch[0].length;
          continue;
        }
      }
      if (css[i] === "#" && depth === 0) {
        const idMatch = css.slice(i + 1).match(/^[a-zA-Z_][a-zA-Z0-9_\-]*/);
        if (idMatch) {
          out += `<span class="sh-variable">#${escHtml(idMatch[0])}</span>`;
          i += 1 + idMatch[0].length;
          continue;
        }
      }
      if (css[i] === ":" && depth === 0) {
        // Pseudo-class or pseudo-element  :hover  ::before
        const extra = css[i + 1] === ":" ? 2 : 1;
        const psMatch = css.slice(i + extra).match(/^[a-zA-Z\-]+/);
        if (psMatch) {
          const prefix = css.slice(i, i + extra);
          out += `<span class="sh-operator">${escHtml(prefix)}${escHtml(psMatch[0])}</span>`;
          i += extra + psMatch[0].length;
          continue;
        }
      }
      if ((css[i] === "*" || css[i] === ">" || css[i] === "~" || css[i] === "+") && depth === 0) {
        out += `<span class="sh-operator">${escHtml(css[i])}</span>`;
        i++;
        continue;
      }
      // ── Hex colors  #rrggbb / #rgb ────────────────────────────────────────
      if (css[i] === "#" && depth > 0) {
        const hexMatch = css.slice(i + 1).match(/^[0-9a-fA-F]{3,8}\b/);
        if (hexMatch) {
          out += `<span class="sh-number">#${escHtml(hexMatch[0])}</span>`;
          i += 1 + hexMatch[0].length;
          continue;
        }
      }
      // ── Class/id selectors inside at-rule parens (depth 0 edge cases) ───
      out += escHtml(css[i]);
      i++;
    }
    return out;
  }

  // ── JSON highlighter ───────────────────────────────────────────────────────
  if (isJson) {
    return escHtml(code).replace(
      /("(\\u[a-fA-F0-9]{4}|\\[^u]|[^"\\])*"(\s*:)?|\b(true|false|null)\b|-?\d+\.?\d*([eE][+\-]?\d+)?)/g,
      (match) => {
        if (/^"/.test(match)) {
          if (/:$/.test(match)) return `<span class="sh-attr">${match}</span>`;
          return `<span class="sh-string">${match}</span>`;
        }
        if (/true|false/.test(match))
          return `<span class="sh-keyword">${match}</span>`;
        if (/null/.test(match))
          return `<span class="sh-keyword">${match}</span>`;
        return `<span class="sh-number">${match}</span>`;
      },
    );
  }

  // ── Generic keyword-based highlighter (JS/TS/Python/Java/C/Go/Rust/…) ──────
  // We iterate char-by-char via a single combined regex to keep ordering strict.
  const kw = keywords;
  const isSql = langKey === "sql";
  const isJsLike = [
    "js", "ts", "jsx", "tsx", "javascript", "typescript",
  ].includes(langKey);
  const isPowershell = [
    "powershell", "ps1", "psm1", "psd1",
  ].includes(langKey);

  // Regex alternation (order = priority):
  //  1. Line comment   //…  or  #…  or  --…
  //  2. Block comment  /* … */
  //  3. Template literal `…`       (JS/TS only)
  //  4. Double-quoted string
  //  5. Single-quoted string
  //  6. Number (int, float, hex, binary, octal)
  //  7. Word (identifier/keyword)
  //  8. Operator
  //  9. Everything else (1 char)
  // Determine the line-comment syntax for this language
  const usesHashComment = [
    "py", "python", "rb", "ruby", "bash", "sh", "shell", "zsh", "fish",
    "yaml", "yml", "toml", "r", "perl", "pl", "pm", "elixir", "ex", "exs",
    "dockerfile", "docker", "powershell", "ps1", "psm1", "psd1",
  ].includes(langKey);
  const usesDashDashComment = isSql || langKey === "lua";
  const usesPercentComment = langKey === "matlab";

  const TOKEN_RE = new RegExp(
    [
      // 1. line comment
      isJsLike
        ? "(\\/\\/[^\\n]*)"
        : usesHashComment
          ? "(#[^\\n]*)"
          : usesDashDashComment
            ? "(--[^\\n]*)"
            : usesPercentComment
              ? "(%[^\\n]*)"
              : "(\\/\\/[^\\n]*)",
      // 2. block comment
      "(\\/\\*[\\s\\S]*?\\*\\/)",
      // 3. template literal (JS/TS)
      isJsLike ? "(`(?:[^`\\\\]|\\\\.)*`)" : null,
      // 4. double-quoted string
      '("(?:[^"\\\\]|\\\\.)*")',
      // 5. single-quoted string
      "('(?:[^'\\\\]|\\\\.)*')",
      // 6. number (hex, binary, octal, float, int)
      "(\\b0[xX][0-9a-fA-F]+\\b|\\b0[bB][01]+\\b|\\b0[oO][0-7]+\\b|-?\\b\\d+\\.?\\d*(?:[eE][+\\-]?\\d+)?\\b)",
      // 7. identifier / keyword
      "([A-Za-z_$][A-Za-z0-9_$]*)",
      // 8. operator
      "([+\\-*/%&|^~<>!=?:]+)",
    ]
      .filter(Boolean)
      .join("|"),
    "g",
  );

  let result = "";
  let lastIndex = 0;

  for (const m of code.matchAll(TOKEN_RE)) {
    // Append any plain text gap before this match
    if (m.index > lastIndex) {
      result += escHtml(code.slice(lastIndex, m.index));
    }
    lastIndex = m.index + m[0].length;

    const tok = m[0];

    // Determine which group fired.
    // Groups differ by language (JS/TS adds a template-literal capture):
    //   JS/TS:  [lineComment, blockComment, templateLit, dqString, sqString, num, word, op]
    //   Others: [lineComment, blockComment,          dqString, sqString, num, word, op]
    // We use named indices based on whether isJsLike is true.
    const G = isJsLike
      ? {
        lineComment: 1,
        blockComment: 2,
        templateLit: 3,
        dqString: 4,
        sqString: 5,
        num: 6,
        word: 7,
        op: 8,
      }
      : {
        lineComment: 1,
        blockComment: 2,
        templateLit: -1,
        dqString: 3,
        sqString: 4,
        num: 5,
        word: 6,
        op: 7,
      };

    const lineComment = m[G.lineComment];
    const blockComment = m[G.blockComment];
    const templateLit = G.templateLit > 0 ? m[G.templateLit] : undefined;
    const dqString = m[G.dqString];
    const sqString = m[G.sqString];
    const num = m[G.num];
    const word = m[G.word];
    const op = m[G.op];

    if (lineComment || blockComment) {
      result += `<span class="sh-comment">${escHtml(tok)}</span>`;
    } else if (templateLit) {
      // Highlight interpolations ${…} by recursing into the JS highlighter
      const inner = tok
        .slice(1, -1)
        .replace(
          /(\$\{)([\s\S]*?)(\})/g,
          (_, open, expr, close) => {
            // Recursively highlight the interpolated expression
            const highlighted = highlightCode(expr, "js");
            return (
              `<span class="sh-interp">${escHtml(open)}</span>` +
              `<span class="sh-interp-body">${highlighted}</span>` +
              `<span class="sh-interp">${escHtml(close)}</span>`
            );
          },
        );
      result += `<span class="sh-string">\`${inner}\`</span>`;
    } else if (dqString || sqString) {
      result += `<span class="sh-string">${escHtml(tok)}</span>`;
    } else if (num) {
      result += `<span class="sh-number">${escHtml(tok)}</span>`;
    } else if (word) {
      const check = isSql ? tok.toUpperCase() : tok;
      if (kw && kw.has(check)) {
        result += `<span class="sh-keyword">${escHtml(tok)}</span>`;
      } else if (isJsLike && _HL_BUILTINS_JS.has(tok)) {
        result += `<span class="sh-builtin">${escHtml(tok)}</span>`;
      } else {
        // Lookahead and Lookbehind for object properties and function calls
        const after = code[lastIndex];
        const before = m.index > 0 ? code[m.index - 1] : "";

        if (after === "(") {
          result += `<span class="sh-function">${escHtml(tok)}</span>`;
        } else if (/[A-Z]/.test(tok[0]) && !isSql) {
          // PascalCase → type/class name
          result += `<span class="sh-type">${escHtml(tok)}</span>`;
        } else if (before === ".") {
          // Preceded by dot → object property
          result += `<span class="sh-property">${escHtml(tok)}</span>`;
        } else {
          result += escHtml(tok);
        }
      }
    } else if (op) {
      result += `<span class="sh-operator">${escHtml(tok)}</span>`;
    } else {
      result += escHtml(tok);
    }
  }

  // Remaining text after last match
  if (lastIndex < code.length) {
    result += escHtml(code.slice(lastIndex));
  }

  // PowerShell: post-process to colour $variables (token regex missed them
  // because $ is used as word-boundary anchor, not identifier start)
  if (isPowershell) {
    result = result.replace(
      /(\$(?:true|false|null|[A-Za-z_][A-Za-z0-9_]*))/g,
      `<span class="sh-variable">$1</span>`,
    );
  }

  return result;
}

// ── Language auto-detection ───────────────────────────────────────────────────
// Inspects the raw code for distinctive patterns and returns the most likely
// language key, or 'text' for unrecognised content.
export function detectLang(code) {
  if (!code || !code.trim()) return "text";
  const t = code.trim();
  // HTML
  if (/^\s*<!DOCTYPE\s+html/i.test(t) || /^\s*<(?:html|head|body|div|span|p|h[1-6])[\s>]/i.test(t)) return "html";
  // JSON
  if (/^\s*[{\[]/.test(t) && /[}\]]\s*$/.test(t)) {
    try { JSON.parse(t); return "json"; } catch {/* not json */ }
  }
  // YAML (loose check)
  if (/^---\s*$/m.test(t) || /^[a-zA-Z_][\w.\-]*\s*:/m.test(t)) return "yaml";
  // TOML
  if (/^\[\w/.test(t) && /^\w+\s*=/m.test(t)) return "toml";
  // Dockerfile
  if (/^FROM\s/m.test(t) || /^RUN\s/m.test(t)) return "dockerfile";
  // SQL
  if (/\b(?:SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|ALTER)\b/i.test(t)) return "sql";
  // Python
  if (/\bdef\s+\w+\s*\(/.test(t) || /^import\s+\w/m.test(t) || /^from\s+\w.*\simport\b/m.test(t)) return "python";
  // TypeScript (before JS)
  if (/:\s*(?:string|number|boolean|void|any|unknown|never)\b/.test(t) || /\binterface\s+\w/.test(t) || /\benum\s+\w/.test(t)) return "ts";
  // JavaScript
  if (/\b(?:const|let|var)\s+\w/.test(t) || /=>/.test(t) || /^\s*(?:function|class)\s/m.test(t)) return "js";
  // CSS
  if (/[{};]/.test(t) && /:\s*[\w#"']/.test(t)) return "css";
  // Bash
  if (/^#!\/(?:bin|usr)\/.+sh/.test(t) || /\$(?:\w+|\{\w+\})/.test(t)) return "bash";
  // Rust
  if (/\bfn\s+\w+/.test(t) || /\bimpl\s+\w/.test(t) || /\blet\s+mut\s+\w/.test(t)) return "rust";
  // Go
  if (/^package\s+\w/m.test(t) || /\bfunc\s+\w/.test(t)) return "go";
  // Java / Kotlin
  if (/\bpublic\s+(?:static\s+)?(?:void|class)\s+\w/.test(t)) return "java";
  // Kotlin
  if (/\bfun\s+\w+\s*\(/.test(t) && /\bval\b|\bvar\b/.test(t)) return "kotlin";
  // Markdown
  if (/^#{1,6}\s/m.test(t) || /\*\*.+\*\*/.test(t)) return "markdown";
  return "text";
}

// ─── 7. Core renderer ─────────────────────────────────────────────────────────
// @param {string} str
// @param {{mediaBaseUrl?: string|null}} [options] — see renderMarkdown()
export function _renderMarkdownCore(str, options = {}) {
  const { mediaBaseUrl = null } = options;
  const stash = [];
  const stashPush = (html) => {
    const idx = stash.length;
    stash.push(html);
    return `\x00ST${idx}\x00`;
  };

  // ── Step -1: Raw HTML media tags: <img>, <video>, <audio> ─────────────────
  // The editor's صورة/فيديو/صوت toolbar buttons insert real HTML tags
  // (e.g. `<img width="400" height="400" alt="x.jpg" src="...">`), not
  // bracket syntax — matching how a raw `<img>`/`<video>`/`<audio>` snippet
  // pasted from a browser's "copy image"/"copy video" action looks. Every
  // other step in this engine treats raw text as plain prose and escapes
  // it (see escapeAroundTokens / applyInline(escHtml(...)) below), which
  // would otherwise turn these tags into inert, literally-visible text —
  // so, like fenced code/passage blocks, pull them out and render them
  // FIRST, before anything else gets a chance to touch or escape them.
  //
  // `src` may legitimately be empty (`src=""`) right after the toolbar
  // inserts a blank tag for the author to fill in by hand — that's
  // rendered as a small "no source yet" placeholder rather than a broken
  // <img>/<video>/<audio> element.
  //
  // Bracket syntax (`![alt](url)`, `![audio](url)`, `![video](url)`,
  // handled later in applyInline) still works too, for any older content
  // saved before this HTML-tag support existed — both forms are accepted.
  str = str.replace(
    /<img\b([^>]*)\/?>/gi,
    (full, attrs) => {
      const src = (attrs.match(/\bsrc=["']([^"']*)["']/i) || [])[1] ?? null;
      if (src === null) return full; // not a src-bearing <img> we understand
      const alt = (attrs.match(/\balt=["']([^"']*)["']/i) || [])[1] || "";
      const width = (attrs.match(/\bwidth=["']?(\d+)["']?/i) || [])[1];
      const height = (attrs.match(/\bheight=["']?(\d+)["']?/i) || [])[1];
      return stashPush(_renderRawImageTag(src, alt, width, height, mediaBaseUrl));
    },
  );
  str = str.replace(
    /<(video|audio)\b([^>]*)>([\s\S]*?)<\/\1>|<(video|audio)\b([^>]*)\/>/gi,
    (full, tag1, attrs1, inner, tag2, attrs2) => {
      const tag = (tag1 || tag2).toLowerCase();
      const attrs = attrs1 || attrs2 || "";
      let src = (attrs.match(/\bsrc=["']([^"']*)["']/i) || [])[1];
      if (src === undefined && inner) {
        src = (inner.match(/<source\b[^>]*\bsrc=["']([^"']*)["']/i) || [])[1];
      }
      if (src === undefined) return full; // not a src-bearing tag we understand
      return stashPush(_renderRawMediaTag(tag, src, mediaBaseUrl));
    },
  );

  // ── Step 0a: Fenced passage blocks  ```passage … ``` ──────────────────────
  // A passage fence renders its body as full markdown (not a code block).
  // The wrapper gets class="reading-passage"; RTL/LTR direction is applied
  // per-element by the engine after rendering, not on the wrapper itself.
  //
  // NOTE: this — and the fenced code-block step right after it — must run
  // BEFORE the bare-LaTeX auto-wrap and block-math passes below. Those
  // passes scan raw text line-by-line for LaTeX-like patterns; if they ran
  // first they would reach inside fenced code blocks (e.g. a Python line
  // containing `\alpha` or `\theta`) and inject stray `$` characters into
  // the code itself, corrupting it. Stashing fenced content out first means
  // the LaTeX/math passes only ever see prose.
  str = str.replace(
    /```passage\n?([\s\S]*?)```/gi,
    (_, body) => {
      const innerHtml = _renderMarkdownCore(body.trim(), { mediaBaseUrl });
      return stashPush(`<div class="reading-passage">${innerHtml}</div>`);
    },
  );

  // ── Step 0b: Fenced code blocks ```lang\n…\n``` ────────────────────────
  // Wraps each block in .code-block-wrapper so the Copy button has a parent.
  // "passage" is already consumed above so it never reaches this branch.
  str = str.replace(
    /```([a-zA-Z0-9_+#.-]*)\n?([\s\S]*?)```/g,
    (_, lang, code) => {
      // If no explicit language tag, try to auto-detect from content
      const effectiveLang = lang || detectLang(code.trim());
      const highlighted = highlightCode(code.trim(), effectiveLang);
      const langClass = lang ? ` language-${lang}` : (effectiveLang !== "text" ? ` language-${effectiveLang}` : "");

      // Only show the label when the author explicitly wrote a language tag
      const langLabel = lang
        ? `<span class="code-lang-label">${escHtml(lang)}</span>`
        : "";

      return stashPush(
        `<div class="code-block-wrapper">` +
        langLabel +
        `<button class="copy-code-btn"
                 onclick="window.copyCodeBlock(this)"
                 aria-label="Copy code">` +
        ICON_COPY +
        `<span class="copy-label">${escHtml(COPY_LABEL)}</span>` +
        `</button>` +
        `<pre class="code-block ltr${langClass}"><code>${highlighted}</code></pre>` +
        `</div>`,
      );
    },
  );

  // ── Step 1: Auto-wrap bare LaTeX lines ─────────────────────────────────────
  // Some quiz data embeds LaTeX commands without $ delimiters.
  // Detect lines that contain known commands but no $ or ` and wrap them.
  // Runs after fenced-block extraction (Step 0) so code content is immune.
  const BARE_LATEX_CMD_RE =
    /\\(?:frac|sqrt|sum|int|prod|lim|pm|mp|cdot|times|div|leq|geq|neq|approx|equiv|infty|partial|alpha|beta|gamma|delta|epsilon|theta|lambda|mu|nu|pi|sigma|phi|psi|omega|vec|hat|bar|tilde|dot|binom|mathbb|mathbf|mathrm|mathit)\b/;
  if (BARE_LATEX_CMD_RE.test(str)) {
    str = str.replace(/^(?![^\n]*[$`])([^\n]+)$/gm, (line) =>
      BARE_LATEX_CMD_RE.test(line) ? `$${line.trim()}$` : line,
    );
  }

  // ── Step 2: Block math $$…$$ ───────────────────────────────────────────────
  str = str.replace(/\$\$([\s\S]*?)\$\$/g, (_, m) => {
    let rendered;
    if (typeof window.katex !== "undefined") {
      try {
        rendered = window.katex.renderToString(m.trim(), {
          displayMode: true,
          throwOnError: false,
        });
      } catch {
        rendered = `<span class="math-raw">$$${escHtml(m)}$$</span>`;
      }
    } else {
      rendered = `<span class="math-raw">$$${escHtml(m)}$$</span>`;
    }
    return stashPush(`<div class="math-block">${rendered}</div>`);
  });

  // ── Step 3: GFM Tables ────────────────────────────────────────────────────
  // Must run BEFORE the line-by-line loop — str.split("\n") would destroy
  // the multi-line table structure.
  //
  // Captures:
  //   Group 1 — header row  (| … |)
  //   Group 2 — separator   (| :---: | etc.)
  //   Group 3 — body rows   (zero or more | … | lines)
  str = str.replace(
    /^(\|.+\|)\n(\|[-| :]+\|)\n((?:\|.+\|(?:\n|$))*)/gm,
    (_, headerRow, _sepRow, bodyRows) => {
      const parseRow = (row) =>
        row
          .replace(/^\||\|$/g, "")
          .split("|")
          .map((cell) => applyInline(escHtml(cell.trim()), { mediaBaseUrl }));

      const headers = parseRow(headerRow);
      const rows = bodyRows.trim().split("\n").filter(Boolean).map(parseRow);

      const thead =
        "<thead><tr>" +
        headers.map((h) => `<th>${h}</th>`).join("") +
        "</tr></thead>";

      const tbody =
        "<tbody>" +
        rows
          .map((r) => "<tr>" + r.map((c) => `<td>${c}</td>`).join("") + "</tr>")
          .join("") +
        "</tbody>";

      return stashPush(
        `<div class="md-table-wrapper">` +
        `<table class="md-table">${thead}${tbody}</table>` +
        `</div>`,
      );
    },
  );

  // ── Step 3: Tokenize lines ─────────────────────────────────────────────────
  // Each raw line is classified into one of: stash | hr | heading | blockquote
  //   | list | blank | text

  const rawLines = str.split("\n");

  // Helper: escape HTML around stash tokens that appear on the same line as
  // other text (safety measure; in practice stash tokens are always alone).
  const escapeAroundTokens = (line) => {
    const TOKEN_RE = /(\x00ST\d+\x00)/g;
    return line
      .split(TOKEN_RE)
      .map((part, i) => (i % 2 === 1 ? part : escHtml(part)))
      .join("");
  };

  // Tokenize
  const lineTokens = rawLines.map((line) => {
    // Stash placeholder — pass through verbatim (with surrounding text escaped)
    if (/\x00ST\d+\x00/.test(line)) {
      return { type: "stash", html: escapeAroundTokens(line) };
    }
    // Horizontal rule  ---  *** ___
    if (/^(-{3,}|\*{3,}|_{3,})\s*$/.test(line)) {
      return { type: "hr" };
    }
    // Headings  # … ######
    const hMatch = line.match(/^(#{1,6})\s+(.+)$/);
    if (hMatch) {
      return { type: "heading", level: hMatch[1].length, content: hMatch[2] };
    }
    // Blockquote  >
    const bqMatch = line.match(/^>\s*(.*)$/);
    if (bqMatch) {
      return { type: "blockquote", content: bqMatch[1] };
    }
    const ulMatch = line.match(/^(\s*)[-*+]\s+(.+)$/);
    if (ulMatch) {
      return {
        type: "list",
        listType: "ul",
        indent: ulMatch[1].length,
        content: ulMatch[2],
      };
    }
    const olMatch = line.match(/^(\s*)(\d+)\.\s+(.+)$/);
    if (olMatch) {
      return {
        type: "list",
        listType: "ol",
        indent: olMatch[1].length,
        start: parseInt(olMatch[2], 10),
        content: olMatch[3],
      };
    }
    // Blank line
    if (line.trim() === "") {
      return { type: "blank" };
    }
    // Regular inline text
    return { type: "text", content: line };
  });

  // ── Step 4: Group tokens into rendering segments ───────────────────────────
  // Segments are:
  //   { type: "para",  html }        — one or more text lines → <p>
  //   { type: "list",  items }        — one or more list items (nest-aware)
  //   { type: "block", html }         — single self-contained block element

  const segments = [];
  let ti = 0;

  while (ti < lineTokens.length) {
    const tok = lineTokens[ti];

    // ── Blank lines between segments are simply dropped ──────────────────
    // Paragraph separation is achieved by the segment boundary itself
    // (each <p> or block element carries its own CSS margin).
    if (tok.type === "blank") {
      ti++;
      continue;
    }

    // ── Text lines → paragraph ───────────────────────────────────────────
    if (tok.type === "text") {
      const lines = [];
      while (ti < lineTokens.length && lineTokens[ti].type === "text") {
        lines.push(applyInline(escHtml(lineTokens[ti].content), { mediaBaseUrl }));
        ti++;
      }
      segments.push({
        type: "block",
        html: `<p class="md-p">${lines.join(" ")}</p>`,
      });
      continue;
    }

    // ── List items → list segment ─────────────────────────────────────────
    if (tok.type === "list") {
      const items = [];
      while (ti < lineTokens.length) {
        if (lineTokens[ti].type === "list") {
          items.push(lineTokens[ti]);
          ti++;
        } else if (lineTokens[ti].type === "blank") {
          // Peek ahead past all consecutive blanks
          let j = ti + 1;
          while (j < lineTokens.length && lineTokens[j].type === "blank") j++;
          if (j < lineTokens.length && lineTokens[j].type === "list") {
            // There is a list item after the blanks — absorb the blanks
            ti = j;
          } else {
            // No more list items ahead — end this list segment
            break;
          }
        } else {
          // Non-blank, non-list token — end of list
          break;
        }
      }
      segments.push({ type: "list", items });
      continue;
    }

    // ── Block tokens: stash, hr, heading, blockquote ─────────────────────
    let blockHtml = "";
    if (tok.type === "stash") {
      blockHtml = tok.html;
    } else if (tok.type === "hr") {
      blockHtml = '<hr class="md-hr">';
    } else if (tok.type === "heading") {
      const lvl = tok.level;
      blockHtml = `<h${lvl} class="md-h${lvl}">${applyInline(escHtml(tok.content), { mediaBaseUrl })}</h${lvl}>`;
    } else if (tok.type === "blockquote") {
      blockHtml = `<blockquote class="md-blockquote">${applyInline(escHtml(tok.content), { mediaBaseUrl })}</blockquote>`;
    }
    segments.push({ type: "block", html: blockHtml });
    ti++;
  }

  // ── Step 4b: Nested list renderer ─────────────────────────────────────────
  // Algorithm: renderLevel() claims items whose indent equals the indent of
  // the first item it sees.  Any item with a greater indent triggers a
  // recursive call (sub-list appended inside the current <li>).  Any item
  // with a smaller indent is left for the caller.  If the list-type changes
  // at the same indent level the current list is closed and a new one opens.
  function renderNestedList(items) {
    if (!items.length) return "";

    function renderLevel(startIdx, levelIndent) {
      if (startIdx >= items.length || items[startIdx].indent < levelIndent) {
        return { html: "", nextIdx: startIdx };
      }

      const firstIndent = items[startIdx].indent;
      const tag = items[startIdx].listType;
      const startAttr =
        tag === "ol" && items[startIdx].start && items[startIdx].start !== 1
          ? ` start="${items[startIdx].start}"`
          : "";
      let html = `<${tag} class="md-list"${startAttr}>`;
      let i = startIdx;

      while (i < items.length) {
        const item = items[i];

        // Go back up — shallower item belongs to an ancestor list
        if (item.indent < firstIndent) break;

        // Same depth but different list type (ul ↔ ol) — close and restart
        if (item.indent === firstIndent && item.listType !== tag) break;

        // Deeper item without a preceding same-level item — malformed input;
        // surface it at current level as a safety fallback
        if (item.indent > firstIndent) break;

        // ── Emit <li> for this item ────────────────────────────────────
        let liContent = applyInline(escHtml(item.content), { mediaBaseUrl });
        i++;

        // If the next item is more indented, it forms a nested sub-list
        // that is appended inside the current <li> before it is closed.
        if (i < items.length && items[i].indent > firstIndent) {
          const sub = renderLevel(i, items[i].indent);
          liContent += sub.html;
          i = sub.nextIdx;
        }

        html += `<li>${liContent}</li>`;
      }

      html += `</${tag}>`;
      return { html, nextIdx: i };
    }

    // Loop in case the top-level items alternate between ul and ol types
    let result = "";
    let i = 0;
    while (i < items.length) {
      const { html, nextIdx } = renderLevel(i, items[i].indent);
      result += html;
      if (nextIdx <= i) break; // safety guard against infinite loop
      i = nextIdx;
    }
    return result;
  }

  // ── Step 5: Assemble final HTML ────────────────────────────────────────────
  let result = "";
  for (const seg of segments) {
    if (seg.type === "list") {
      result += renderNestedList(seg.items);
    } else {
      result += seg.html;
    }
  }

  // ── Step 6: Restore stashed blocks ────────────────────────────────────────
  result = result.replace(/\x00ST(\d+)\x00/g, (_, i) => stash[parseInt(i)]);

  return result;
}

// ─── 7. Text-Direction Engine ─────────────────────────────────────────────────
// Evaluates and applies RTL/LTR direction classes on a per-line / per-block
// basis to every element produced by renderMarkdown.  Also exported so that
// special-case elements that are not rendered through renderMarkdown (e.g.
// #quizTitle) can be processed directly by the caller.
//
// Elements that are always LTR (code blocks, inline code, math) are never
// touched by the engine — the HTML they produce carries no direction class and
// CSS keeps them LTR by default.

export const _ARABIC_REGEX =
  /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;

export const _FIRST_STRONG_CHAR_REGEX =
  /[A-Za-z\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;

// Static label prefixes that must not skew direction detection of the content
// that follows them (e.g. "Explanation:" before an Arabic answer).
export const _LABEL_PREFIX_REGEX =
  /^\s*(?:Score:\s*\d+\/\d+:[^]*?)?(?:Explanation:|Formal answer)\s*/i;

// Block-level child selector — each of these gets its own direction verdict.
export const _BLOCK_CHILD_SELECTOR =
  "p, li, h1, h2, h3, h4, h5, h6, blockquote, td, th, dt, dd, div.katex-display";

// Selectors whose subtrees the engine must NEVER touch (always LTR by nature).
export const _LTR_ONLY_SELECTOR = "pre, code, .code-block, .code-block-wrapper, .math-block, .katex";

// Tag names _processElement must never modify.
// Form controls: CSS unicode-bidi:plaintext handles direction natively.
// Media elements: _processByLine sets textContent="" which destroys
// <source> children and breaks audio/video playback entirely.
// BUTTON: buttons only ever carry a short, static, developer-authored
// label (e.g. "تحقق من الإجابة" / "Show All Answers") — never
// user-generated or markdown-rendered content — so per-line direction
// detection buys nothing. Worse, _processByLine() rewrites textContent
// into `<span class="text-line" style="display:block">` and applies a
// direction class to the button itself; that in turn overrides the
// button's own `text-align: center` rule (RTL/LTR direction has no
// bearing on text-align, but the injected block-display span combined
// with the direction class was visually decentering button labels).
// Skipping BUTTON here keeps its plain textContent and CSS untouched.
export const _SKIP_TAGS = new Set(["INPUT", "TEXTAREA", "AUDIO", "VIDEO", "SOURCE", "IFRAME", "IMG", "TRACK", "BUTTON"]);

/**
 * Detects the base direction of a text string by finding its first strong
 * alphabetical character (Arabic → rtl, Latin → ltr).
 * Exported so quiz.js can reuse it for #quizTitle and similar one-off cases.
 * @param {string} text
 * @returns {'rtl' | 'ltr'}
 */
export function detectDirection(text) {
  if (!text || typeof text !== "string") return "ltr";
  const contentOnly = text.replace(_LABEL_PREFIX_REGEX, "");
  const searchText = contentOnly.trim() ? contentOnly : text;
  const match = searchText.match(_FIRST_STRONG_CHAR_REGEX);
  if (match) return _ARABIC_REGEX.test(match[0]) ? "rtl" : "ltr";
  return "ltr";
}

/**
 * Applies a direction class to a single element without redundant class churn.
 * @param {HTMLElement} node
 * @param {'rtl'|'ltr'} direction
 */
export function _applyDirectionClass(node, direction) {
  if (direction === "rtl") {
    if (!node.classList.contains("text-rtl")) {
      node.classList.remove("text-ltr");
      node.classList.add("text-rtl");
    }
  } else {
    if (!node.classList.contains("text-ltr")) {
      node.classList.remove("text-rtl");
      node.classList.add("text-ltr");
    }
  }
}

/**
 * Handles plain-text elements (no block children) by splitting on newlines
 * and wrapping each line in a direction-classed <span class="text-line">.
 * On subsequent calls it re-evaluates the existing spans without rebuilding.
 * @param {HTMLElement} element
 */
export function _processByLine(element) {
  const existingLines = element.querySelectorAll(":scope > .text-line");
  if (existingLines.length) {
    existingLines.forEach((line) => {
      _applyDirectionClass(line, detectDirection(line.textContent));
    });
    _applyDirectionClass(element, detectDirection(existingLines[0]?.textContent));
    return;
  }

  // If the element has any element children (e.g. a wrapper div around a
  // <video>, <audio>, or <img>), it is not a pure text leaf. Reading
  // textContent would concatenate all descendant text (including media
  // fallback strings), and setting textContent="" would destroy those
  // child elements entirely. Only apply a direction class on the container
  // itself and leave its children untouched.
  if (element.childElementCount > 0) {
    _applyDirectionClass(element, detectDirection(element.textContent));
    return;
  }

  const rawText = element.textContent;
  const lines = rawText.split(/\n+/).filter((l) => l.trim() !== "");

  if (lines.length <= 1) {
    _applyDirectionClass(element, detectDirection(rawText));
    return;
  }

  const frag = document.createDocumentFragment();
  lines.forEach((line) => {
    const span = document.createElement("span");
    span.className = "text-line";
    span.style.display = "block";
    span.textContent = line;
    _applyDirectionClass(span, detectDirection(line));
    frag.appendChild(span);
  });
  element.textContent = "";
  element.appendChild(frag);
  _applyDirectionClass(element, detectDirection(lines[0]));
}

/**
 * Direct-text direction for a block-level element (li, p, etc.) — i.e. the
 * element's own text, ignoring any nested block descendants (a nested
 * <ul>/<ol> inside an <li>, a nested <blockquote>, etc.). Without this, an
 * <li> whose own text is plain English but which contains a nested
 * sub-list of Arabic options would have its direction computed from the
 * concatenated text of itself PLUS every nested item — occasionally
 * flipping the outer item's direction to match its sub-list instead of
 * its own sentence.
 * @param {HTMLElement} element
 * @returns {string}
 */
export function _ownText(element) {
  let text = "";
  element.childNodes.forEach((node) => {
    if (node.nodeType === 3) {
      // Text node — always part of this element's own content.
      text += node.textContent;
    } else if (node.nodeType === 1 && !node.matches(_BLOCK_CHILD_SELECTOR)) {
      // Inline element (strong, em, a, span, ...) — its text is still
      // visually part of this element's own line, so include it. Only
      // nested block-level children (matched by _BLOCK_CHILD_SELECTOR,
      // e.g. a <ul>/<ol>'s <li>) are excluded, since those get their own
      // independent direction verdict.
      text += node.textContent;
    }
  });
  return text;
}

/**
 * Evaluates and applies direction classes to a single element — per block
 * child if the element contains block-level markdown output, or per visual
 * line for plain-text leaves.  Never touches LTR-only subtrees.
 * @param {HTMLElement} element
 */
export function _processElement(element) {
  if (!element) return;

  // INPUT / TEXTAREA: direction is handled by CSS `unicode-bidi: plaintext`.
  // No JS involvement needed or wanted — touching it fights the browser's
  // native caret placement on focused / partially-typed fields.
  if (_SKIP_TAGS.has(element.tagName)) return;

  // Pin every always-LTR zone nested inside this element first.
  element.querySelectorAll(_LTR_ONLY_SELECTOR).forEach((zone) => {
    _applyDirectionClass(zone, "ltr");
  });

  // An element that is itself a block-child type (li, p, td, ...) gets its
  // direction from its OWN text only, never from a nested block descendant
  // (e.g. a <ul> of lettered options inside an <li>). This is evaluated
  // before the "does it contain block children" branch below because such
  // an element commonly does contain further block children (a nested
  // list) — those still get their own independent direction verdicts via
  // the tree walker visiting them directly, but they must never leak back
  // up and override their own parent's direction.
  if (element.matches(_BLOCK_CHILD_SELECTOR)) {
    _applyDirectionClass(element, detectDirection(_ownText(element)));
    return;
  }

  // Containers with block-level markdown children get per-child evaluation.
  const blockChildren = element.querySelectorAll(_BLOCK_CHILD_SELECTOR);
  if (blockChildren.length) {
    // Only DIRECT block children — a nested list's items are reached (and
    // classed) independently when the tree walker visits them, and must
    // not be double-counted here as if they belonged to this container.
    const directBlockChildren = Array.from(blockChildren).filter(
      (c) => c.parentElement === element,
    );
    directBlockChildren.forEach((child) => {
      if (child.closest(_LTR_ONLY_SELECTOR)) return; // already pinned LTR
      _applyDirectionClass(child, detectDirection(_ownText(child)));
    });
    // Container itself follows its first real (non-LTR-only) block so that
    // CSS logical properties (list padding, etc.) have a sane base direction.
    const firstReal = directBlockChildren.find(
      (c) => !c.closest(_LTR_ONLY_SELECTOR),
    );
    _applyDirectionClass(element, detectDirection(firstReal ? _ownText(firstReal) : ""));
    return;
  }

  // No block children — plain text leaf.  Process per visual line.
  _processByLine(element);
}

/**
 * Scans `container` and applies direction classes to every direct child
 * element that carries rendered markdown content.  Call this after setting
 * innerHTML on any element that may contain renderMarkdown output.
 *
 * Exported so quiz.js can call it for special-case containers (e.g. #quizTitle)
 * that are populated outside the renderMarkdown pipeline.
 * @param {HTMLElement} [container=document]
 */
export function scanDirections(container = document) {
  // Walk every element inside the container and process those that are
  // themselves renderable leaf/block containers, skipping always-LTR zones.
  const walker = document.createTreeWalker(
    container,
    NodeFilter.SHOW_ELEMENT,
    {
      acceptNode(node) {
        // Never descend into LTR-only subtrees or media elements.
        if (node.matches(_LTR_ONLY_SELECTOR)) return NodeFilter.FILTER_REJECT;
        if (_SKIP_TAGS.has(node.tagName)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      },
    },
  );

  const candidates = [];
  let node;
  while ((node = walker.nextNode())) {
    candidates.push(node);
  }

  candidates.forEach(_processElement);
}

// ─── 8. Public renderMarkdown (with error boundary + direction scan) ──────────
/**
 * Render a Markdown string to an HTML string with RTL/LTR direction classes
 * already applied to every block and line.
 * Supports: KaTeX math, GFM tables, fenced code blocks with copy button,
 * reading passages (```passage … ```), headings, blockquotes, nested lists,
 * bold/italic, links, images, and inline audio/video media
 * (`![audio](url)` / `![video](url)`, including YouTube auto-embed).
 *
 * @param {string} str — Raw Markdown input.
 * @param {{mediaBaseUrl?: string|null}} [options] — Optional render options.
 *   `mediaBaseUrl` is the directory URL of the current quiz/result page
 *   (e.g. `new URL("./", window.location.href).href`), used to resolve
 *   quiz-folder-relative media paths like `./assets/quiz-media/...` found
 *   in `![audio](...)`/`![video](...)` tags. Callers rendering quiz content
 *   (quiz.js, result.js, export-to-quiz.js) should pass this; callers
 *   rendering non-quiz markdown (e.g. static pages) can omit it — relative
 *   media paths simply won't resolve, matching prior behavior.
 * @returns {string}   — Safe HTML string ready for innerHTML.
 */
export function renderMarkdown(str, options = {}) {
  if (!str) return "";
  const { mediaBaseUrl = null } = options;
  try {
    // Use the engine for alternate display delimiters too; authoring pages
    // must not need an additional KaTeX auto-render pass.
    str = str.replace(/\\\[([\s\S]*?)\\\]/g, (_, math) => `$$${math}$$`);
    // SAFETY: the engine uses \x00/\x01/\x02/\x03 control-character
    // sentinels internally (stash placeholders for math, code blocks,
    // tables, etc.). If the raw input already contains one of these bytes
    // — unlikely from normal typing, but possible from pasted binary-ish
    // or corrupted content — it could desync the later placeholder-restore
    // step and leak a stash index into the rendered output. Strip them
    // up front; they have no legitimate meaning in Markdown source.
    str = str.replace(/[\x00-\x03]/g, "");

    const html = _renderMarkdownCore(str, { mediaBaseUrl });

    // Apply direction classes to the rendered output.  We parse the HTML
    // string into a detached container, run the engine over it, then
    // serialise back — so the returned string already carries direction
    // classes and callers never need to call scanDirections themselves.
    if (typeof document !== "undefined") {
      const tmp = document.createElement("div");
      tmp.innerHTML = html;
      scanDirections(tmp);
      return tmp.innerHTML;
    }

    return html;
  } catch (err) {
    console.error("[markdown-handler] renderMarkdown error:", err);
    return escHtml(str).replace(/\n/g, "<br>");
  }
}
