// =============================================================================
// api/render-course.js
//
// Serverless function (Node.js runtime, flat file) that handles all requests
// to /course/:name and /course/:name/:sub1/:sub2/... Mirrors render-quiz.js's
// structure (Supabase lookup, HTML template read + meta-tag injection,
// caching headers) but differs in one key way: course pages are NOT a
// separate HTML file — they render inside the existing SPA
// (public/index.html), so this function injects OG tags and a data-island
// into index.html itself rather than a dedicated template, and index.html's
// own client-side router (navigation.js) takes over from there to actually
// render the course view.
//
// What it does:
//   1. Reads the course slug + any nested folder slugs from req.query.full
//      (a single "/"-joined string — see the handler below for why this
//      shape was chosen over a path-segment catch-all route file).
//   2. Looks up the course by name (+ education_type disambiguation via
//      ?education_type= if present) in the `courses` table.
//   3. Counts folders + quizzes under that course via relational count
//      queries against `folders`/`quizzes` (course_id), NOT the old
//      manifest-walk approach (see public/src/shared/quizManifest.js).
//   4. Reads the raw public/index.html template from disk.
//   5. Injects og:title, og:description, og:image (-> /api/og-course),
//      canonical URL, and a <meta name="course:*"> data-island for the
//      client SPA (navigation.js) to hydrate the correct view from.
//   6. Returns the modified HTML with edge-cache headers.
//
// URL contract:
//   /course/NAME[/SUB1/SUB2/...]  →  (vercel.json rewrite: a single
//   "/course/:full(.*)" → "/api/render-course?full=:full" rule, matching
//   any depth in one shot)  →  this file, with
//   req.query.full = "NAME[/SUB1/SUB2/...]" (one string, split below).
//   Browser URL stays /course/NAME/.... navigation.js reads the course id
//   (and folder path, when present) from the injected <meta> tags to render
//   the right view without a hash.
// =============================================================================

import { ogVersion, stampFromDate } from "./_og/version.js";
import fs from "fs";
import path from "path";
import { createClient } from "@supabase/supabase-js";
import crypto from "crypto";

let supabase = null;
let serviceSupabase = null;

function getSupabase() {
    if (supabase) return supabase;
    const url = process.env.SUPABASE_URL;
    const key = process.env.SUPABASE_ANON_KEY;
    if (!url || !key) throw new Error("Supabase environment is not configured.");
    supabase = createClient(url, key);
    return supabase;
}

function getServiceSupabase() {
    if (serviceSupabase) return serviceSupabase;
    const url = process.env.SUPABASE_URL;
    const key = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !key) throw new Error("Supabase service role is not configured.");
    serviceSupabase = createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false } });
    return serviceSupabase;
}

// index.html is the SPA shell — course pages render inside it, not a
// separate template (see quiz.html for contrast with render-quiz.js).
const TEMPLATE_PATH = path.join(process.cwd(), "public", "index.html");
const LESSON_TEMPLATE_PATH = path.join(process.cwd(), "public", "lesson.html");
const NOTEBOOK_TEMPLATE_PATH = path.join(process.cwd(), "public", "notebook.html");

// OG image versions live in api/_og/version.js (layout version + content stamp).

const SITE_ORIGIN = "https://basmagi.vercel.app";

// Mirrors public/src/features/home/slug-utils.js's toSlug() exactly (kept in
// sync manually — this is a Node serverless function and can't import an ES
// module from public/src). Converts a display name to the same URL slug the
// client builds, so /course/:name can use readable dashes (e.g.
// "Data-Structures-and-Algorithms") instead of raw percent-encoded spaces.
function toSlug(str) {
    return str.trim().replace(/-/g, "--").replace(/\s+/g, "-");
}

// =============================================================================
// Handler
// =============================================================================
// This file is a shared function now (Vercel Hobby's 12-function cap is
// already hit — see docs/plans/lessons-feature-plan.md's ground rules), so
// the course-resolution path and the lesson-resolution path are kept
// visually separate as two clearly-named internal functions called from
// one small dispatcher, rather than interleaving `if` checks through the
// existing course logic line-by-line — this is what keeps the two
// responsibilities easy to read independently instead of accumulating the
// same kind of scar tissue create-quiz.js has.
export default async function handler(req, res) {
    if (req.query.contentType === "notebook") {
        if (req.method === "GET" || req.method === "HEAD") return handleNotebookRequest(req, res);
        return res.status(405).end();
    }
    if (req.query.contentType === "lesson") {
        if (req.method === "POST") return handleLessonUnlockRequest(req, res);
        if (req.method === "GET" || req.method === "HEAD") return handleLessonRequest(req, res);
        return res.status(405).end();
    }
    if (req.method !== "GET" && req.method !== "HEAD") {
        return res.status(405).end();
    }
    return handleCourseRequest(req, res);
}

// =============================================================================
// Notebook resolution — /notebook/:id
// =============================================================================
// vercel.json: { "source": "/notebook/:id", "destination":
// "/api/render-course?contentType=notebook&id=:id" }. Reuses this function
// (Hobby's 12-function cap). Serves public/notebook.html with notebook-specific
// title / description / og:image (-> /api/og?notebook=). The browser URL stays
// /notebook/:id, which is what the client's parseNotebookRoute() reads.
async function handleNotebookRequest(req, res) {
    const rawId = typeof req.query.id === "string" ? req.query.id : "";
    if (!rawId) return res.redirect(302, "/");
    let ref;
    try { ref = decodeURIComponent(rawId); } catch { ref = rawId; }

    let html;
    try {
        html = fs.readFileSync(NOTEBOOK_TEMPLATE_PATH, "utf8");
    } catch (err) {
        console.error("[render-course] Could not read notebook.html:", err);
        return res.status(500).send("Internal Server Error");
    }

    let nb = null;
    try {
        const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(ref);
        const query = getSupabase().from("notebook_public").select("id, slug, title, description, updated_at");
        const { data, error } = isUuid
            ? await query.eq("id", ref).maybeSingle()
            : await query.eq("slug", ref).maybeSingle();
        if (error) console.error("[render-course] notebook lookup error:", error.message);
        nb = data || null;
    } catch (err) {
        console.error("[render-course] notebook lookup failed:", err);
    }

    res.setHeader("Content-Type", "text/html; charset=utf-8");
    if (!nb) {
        // Unknown/failed lookup: serve the generic shell, never cache a miss.
        res.setHeader("Cache-Control", "no-store");
        return res.status(200).send(html);
    }

    const fullTitle = `${nb.title} | منصة امتحانات بصمجي`;
    const desc = (nb.description || "").trim() || "دفتر تفاعلي بأسلوب MATLAB يعمل داخل المتصفح على منصة امتحانات بصمجي";
    const canonicalUrl = `${SITE_ORIGIN}/notebook/${encodeURIComponent(nb.slug || nb.id)}`;
    const ogImageUrl =
        `${SITE_ORIGIN}/api/og?notebook=${encodeURIComponent(nb.id)}` +
        `&v=${ogVersion("notebook", stampFromDate(nb.updated_at))}`;

    html = html.replace(/<title>[^<]*<\/title>/i, `<title>${escapeHtml(fullTitle)}</title>`);
    html = replaceLinkHref(html, "canonical", canonicalUrl);
    html = replaceMetaContent(html, "property", "og:title", fullTitle);
    html = replaceMetaContent(html, "property", "og:url", canonicalUrl);
    html = replaceMetaContent(html, "property", "og:description", desc);
    html = replaceMetaContent(html, "property", "og:image", ogImageUrl);
    html = replaceMetaContent(html, "property", "og:image:alt", nb.title);
    html = replaceMetaContent(html, "name", "twitter:title", fullTitle);
    html = replaceMetaContent(html, "name", "twitter:description", desc);
    html = replaceMetaContent(html, "name", "twitter:image", ogImageUrl);
    html = replaceMetaContent(html, "name", "twitter:image:alt", nb.title);
    html = replaceMetaContent(html, "name", "description", desc);

    res.setHeader("Cache-Control", "public, s-maxage=300, stale-while-revalidate=3600");
    return res.status(200).send(html);
}

// =============================================================================
// Lesson resolution (Phase 1 skeleton) — /lesson/:id
// =============================================================================
// vercel.json: { "source": "/lesson/:id", "destination":
// "/api/render-course?contentType=lesson&id=:id" }. Deliberately reuses this
// file rather than a new api/render-lesson.js — see the plan's ⚠️ note on
// the function-budget cap. Unlike course resolution, there is no slug-chain
// to walk: a lesson is looked up directly by id (or slug, when present),
// with no folder/course tree traversal.
//
// OG tags come straight from the lesson's title + a short plain-text
// excerpt of its first content block — no dedicated OG image variant for
// v1 (a generic site OG image is an acceptable fallback; og.js is already
// one of the 12 functions, so a new branch there isn't justified for this).

async function handleLessonUnlockRequest(req, res) {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    const rawId = typeof req.query.id === "string" ? req.query.id : "";
    if (!rawId) return res.status(400).json({ error: "معرف الدرس مطلوب." });
    let lessonId;
    try { lessonId = decodeURIComponent(rawId); } catch { lessonId = rawId; }
    const passwordHash = typeof req.body?.passwordHash === "string" ? req.body.passwordHash : "";
    try {
        const lesson = await fetchLessonMetaWithSecret(lessonId);
        if (!lesson) return res.status(404).json({ error: "الدرس غير موجود." });
        if (!lesson.password_hash) {
            return res.status(200).json({ lesson: stripPublicLesson(lesson) });
        }
        if (!/^[0-9a-f]{64}$/i.test(passwordHash)) {
            return res.status(400).json({ error: "تعذر التحقق من كلمة المرور." });
        }
        const digest = hashLessonPasswordDigest(passwordHash);
        if (!constantTimeEqual(digest, lesson.password_hash)) {
            return res.status(401).json({ error: "كلمة المرور غير صحيحة." });
        }
        return res.status(200).json({ lesson: stripPublicLesson(lesson) });
    } catch (error) {
        console.error("[render-course] Lesson unlock failed:", error);
        return res.status(500).json({ error: "تعذّر فتح الدرس." });
    }
}

function stripPublicLesson(lesson) {
    return {
        id: lesson.id,
        slug: lesson.slug || null,
        title: lesson.title || "",
        description: lesson.description || "",
        source: lesson.source || "",
        content: lesson.content || { sections: [] },
        reader_prefs_default: lesson.reader_prefs_default || null,
        created_by: lesson.created_by || null,
        created_at: lesson.created_at || null,
        updated_at: lesson.updated_at || null,
        password_protected: Boolean(lesson.password_hash),
    };
}

function hashLessonPasswordDigest(passwordHash) {
    return crypto.createHash("sha256").update(passwordHash, "utf8").digest("hex");
}

function constantTimeEqual(a, b) {
    const left = String(a || "");
    const right = String(b || "");
    if (left.length !== right.length) return false;
    let diff = 0;
    for (let i = 0; i < left.length; i += 1) diff |= left.charCodeAt(i) ^ right.charCodeAt(i);
    return diff === 0;
}

async function fetchLessonMetaWithSecret(idOrSlug) {
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(idOrSlug);
    const query = getServiceSupabase().from("lessons").select("id, slug, title, description, source, content, reader_prefs_default, created_by, created_at, updated_at, password_hash");
    const { data, error } = isUuid
        ? await query.eq("id", idOrSlug).maybeSingle()
        : await query.eq("slug", idOrSlug).maybeSingle();
    if (error) {
        console.error("[render-course] Supabase lesson secret lookup error:", error.message);
        return null;
    }
    return data || null;
}

async function handleLessonRequest(req, res) {
    const rawId = typeof req.query.id === "string" ? req.query.id : "";
    if (!rawId) {
        return res.redirect(302, "/");
    }
    let lessonId;
    try {
        lessonId = decodeURIComponent(rawId);
    } catch {
        lessonId = rawId;
    }

    // User-created lessons live in the browser workspace (`user_quizzes`)
    // and are intentionally not in the public `lessons` table. The browser
    // reader loads those rows from session/local storage, so sending their
    // short local id through this server renderer only creates an unnecessary
    // Supabase miss (and, in some deployments, a 503 fallback). Return the
    // normal lesson shell directly for browser-owned lessons; the client will hydrate it.
    if (req.query.type === "user" || /^user_lesson_/i.test(lessonId)) {
        let html;
        try {
            html = fs.readFileSync(LESSON_TEMPLATE_PATH, "utf8");
        } catch (err) {
            console.error("[render-course] Could not read lesson.html for user lesson:", err);
            return res.status(500).send("Internal Server Error");
        }
        html = html.replace(
            "</head>",
            `  <meta name="lesson:id" content="${escapeHtml(lessonId)}">\n</head>`,
        );
        res.setHeader("Content-Type", "text/html; charset=utf-8");
        res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
        return res.status(200).send(html);
    }

    let lesson = null;
    try {
        lesson = await fetchLessonMeta(lessonId);
    } catch (err) {
        console.error("[render-course] Lesson lookup failed:", err);
    }

    let html;
    try {
        html = fs.readFileSync(LESSON_TEMPLATE_PATH, "utf8");
    } catch (err) {
        console.error("[render-course] Could not read lesson.html:", err);
        return res.status(500).send("Internal Server Error");
    }

    if (!lesson) {
        // Unknown lesson id/slug — let the SPA load normally, same
        // never-cache-a-miss approach the course branch takes below.
        html = html.replace(
            "</head>",
            `  <meta name="lesson:id" content="${escapeHtml(lessonId)}">\n</head>`,
        );
        res.setHeader("Content-Type", "text/html; charset=utf-8");
        res.setHeader("Cache-Control", "no-store");
        return res.status(200).send(html);
    }

    // ── Data-island for the client SPA (navigation.js) to hydrate from ───────
    html = html.replace(
        "</head>",
        `  <meta name="lesson:id" content="${escapeHtml(lesson.id)}">\n` +
        `  <meta name="lesson:title" content="${escapeHtml(lesson.title)}">\n` +
        `</head>`,
    );

    // ── OG / title / canonical tags ───────────────────────────────────────────
    const excerpt = lesson.password_protected ? "" : (lesson.description?.trim() || buildLessonExcerpt(lesson.content));
    const canonicalUrl = `${SITE_ORIGIN}/lesson/${encodeURIComponent(lesson.slug || lesson.id)}`;

    const fullTitle = `${lesson.title} | منصة امتحانات بصمجي`;
    html = html.replace(
        /<title>[^<]*<\/title>/i,
        `<title>${escapeHtml(fullTitle)}</title>`,
    );

    html = replaceLinkHref(html, "canonical", canonicalUrl);

    html = replaceMetaContent(html, "property", "og:title", fullTitle);
    html = replaceMetaContent(html, "property", "og:url", canonicalUrl);
    // Lesson-specific OG thumbnail — rendered by /api/og?lesson= (merged into
    // the shared Edge OG function; see api/og.js renderLessonImage). The
    // updated_at stamp changes the URL whenever the lesson is edited, so
    // platforms/CDNs refetch instead of serving a year-old immutable image.
    const ogImageUrl =
        `${SITE_ORIGIN}/api/og?lesson=${encodeURIComponent(lesson.id)}` +
        `&v=${ogVersion("lesson", stampFromDate(lesson.updated_at))}`;
    html = replaceMetaContent(html, "property", "og:image", ogImageUrl);
    html = replaceMetaContent(html, "property", "og:image:alt", lesson.title);
    html = replaceMetaContent(html, "name", "twitter:image", ogImageUrl);
    html = replaceMetaContent(html, "name", "twitter:image:alt", lesson.title);
    if (excerpt) {
        html = replaceMetaContent(html, "property", "og:description", excerpt);
        html = replaceMetaContent(html, "name", "twitter:description", excerpt);
        html = replaceMetaContent(html, "name", "description", excerpt);
    }
    html = replaceMetaContent(html, "name", "twitter:title", fullTitle);

    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader(
        "Cache-Control",
        "public, s-maxage=3600, stale-while-revalidate=86400",
    );
    return res.status(200).send(html);
}

/**
 * Fetches a lesson by id (or slug, when the lookup value isn't a UUID) for
 * the /lesson/:id route. Phase 1 keeps this to a single direct lookup — no
 * folder/course tree walk, since a lesson page doesn't need the
 * folderCount/quizCount siblings a course page shows.
 *
 * @param {string} idOrSlug
 * @returns {Promise<{id:string, slug:string|null, title:string, content:unknown}|null>}
 */
async function fetchLessonMeta(idOrSlug) {
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(idOrSlug);
    const query = getSupabase().from("lesson_public").select("id, slug, title, description, source, content, password_protected, updated_at");
    const { data, error } = isUuid
        ? await query.eq("id", idOrSlug).maybeSingle()
        : await query.eq("slug", idOrSlug).maybeSingle();

    if (error) {
        console.error("[render-course] Supabase lesson lookup error:", error.message);
        return null;
    }
    if (!data) return null;

    return {
        id: data.id,
        slug: data.slug || null,
        title: data.title,
        description: data.description || "",
        source: data.source || "",
        content: data.content,
        password_protected: Boolean(data.password_protected),
        updated_at: data.updated_at || null,
    };
}

/**
 * Short plain-text excerpt of a lesson's first content block, for OG/
 * meta-description tags. Phase 1's `content` shape is just a plain
 * markdown body (see the lessons migration's comment on this column) —
 * Phase 2 introduces real sections/blocks, at which point this should read
 * the first block's text instead of assuming a single string.
 *
 * @param {unknown} content
 * @returns {string} plain text, truncated to ~160 chars, or "" if none
 */
function buildLessonExcerpt(content) {
    let raw = "";
    if (typeof content === "string") {
        raw = content;
    } else if (content && typeof content === "object") {
        if (Array.isArray(content.sections)) {
            // Real (Phase 2) shape: text lives in section.blocks[].body of
            // type "markdown". Take the first markdown block from the first
            // section that has one, skipping defaultHidden sections — those
            // are adaptive remediation, and a link preview must not show
            // content most readers are never supposed to see first.
            // (Legacy section.text / section.body is still honoured.)
            for (const section of content.sections) {
                if (!section || section.defaultHidden) continue;
                const block = Array.isArray(section.blocks)
                    ? section.blocks.find(
                        (b) => b && b.type === "markdown" && typeof b.body === "string" && b.body.trim(),
                    )
                    : null;
                raw = block?.body || section.text || section.body || "";
                if (raw) break;
            }
        } else {
            raw = content.body || "";
        }
    }
    const plain = String(raw)
        .replace(/[#*_`>[\]]/g, "")
        .replace(/\s+/g, " ")
        .trim();
    if (!plain) return "";
    return plain.length > 160 ? `${plain.slice(0, 157)}...` : plain;
}

// =============================================================================
// Course resolution — /course/:name[/:sub1/:sub2/...]
// =============================================================================
async function handleCourseRequest(req, res) {
    // This file lives at api/render-course.js (a flat file). vercel.json
    // rewrites the /course/... subtree with a single named-param capture
    // that matches ANY depth in one shot:
    //   "/course/:full(.*)" -> "/api/render-course?full=:full"
    // ":full(.*)" is a single, non-repeating custom-regex param (not a
    // repeating ":x*" token), so Vercel is happy putting it directly after
    // "?full=" in the destination -- the earlier "PATH TO REGEXP ERROR" was
    // specifically about repeating params glued after "?key=", which this
    // isn't. Because the destination is a query string (not literal path
    // segments), Vercel matches this flat file unambiguously regardless of
    // how many real segments were in the URL -- there's no dynamic-route
    // filename depth-matching involved at all, which is what made an
    // earlier "[...path].js" catch-all file version unreliable for 2+
    // segments specifically in `vercel dev` (1-segment requests worked;
    // 2+ segments 404'd, even though this handler has no code path capable
    // of producing a 404 itself -- only a 302 redirect or a 200 response --
    // meaning the catch-all route file wasn't being matched consistently at
    // that depth by this Vercel CLI version, despite the rewrite's own
    // source pattern provably matching any depth via path-to-regexp).
    //
    // req.query.full is a single string like "Website-Demo" or
    // "Website-Demo/All-Features" -- split it ourselves.
    const fullParam = typeof req.query.full === "string" ? req.query.full : "";
    const allSegments = fullParam
        .split("/")
        .filter(Boolean)
        .map((seg) => {
            try {
                return decodeURIComponent(seg);
            } catch {
                return seg;
            }
        });

    if (allSegments.length === 0) {
        return res.redirect(302, "/");
    }

    // First segment is the course slug (dashes, e.g.
    // "Data-Structures-and-Algorithms"), NOT the raw course name — resolved
    // against courses' toSlug(name) in fetchCourseMeta(), same case/slug-
    // insensitive approach the client's navigation.js uses. Any remaining
    // segments are nested-folder-name slugs, resolved level-by-level via
    // fetchFolderPath() below (parent_folder_id chain in the `folders`
    // table). This gives nested folders their own server-visible URL and
    // OG image, instead of the client-only #hash scheme (which crawlers
    // never see, so they'd otherwise always get the course-level image).
    const courseSlug = allSegments[0];
    const pathSlugs = allSegments.slice(1);
    const educationType =
        typeof req.query.education_type === "string" ? req.query.education_type : null;

    // ── 1. Fetch course metadata + counts from Supabase ───────────────────────
    let meta = null;
    try {
        meta = await fetchCourseMeta(courseSlug, educationType);
    } catch (err) {
        console.error("[render-course] Supabase lookup failed:", err);
    }

    // ── 1b. Walk the folder path (if any) under the resolved course ───────────
    // folderMeta is null when there's no path, the course itself is unknown,
    // or a segment fails to resolve (unknown/renamed folder) — in all of
    // those cases we fall back to rendering the course-level page/meta,
    // same as an unresolved hash does client-side.
    let folderMeta = null;
    if (meta && pathSlugs.length > 0) {
        try {
            folderMeta = await fetchFolderPath(meta.id, pathSlugs);
        } catch (err) {
            console.error("[render-course] Folder path lookup failed:", err);
        }
    }

    // ── 2. Read the SPA shell template ─────────────────────────────────────────
    let html;
    try {
        html = fs.readFileSync(TEMPLATE_PATH, "utf8");
    } catch (err) {
        console.error("[render-course] Could not read index.html:", err);
        return res.status(500).send("Internal Server Error");
    }

    if (!meta) {
        // Unknown course slug — let the SPA load normally (it will fall back to
        // the root view client-side once navigation.js fails to resolve it) but
        // still inject the raw slug so the client can retry after the manifest
        // loads, and never cache a miss.
        html = html.replace(
            "</head>",
            `  <meta name="course:name" content="${escapeHtml(courseSlug)}">\n</head>`,
        );
        res.setHeader("Content-Type", "text/html; charset=utf-8");
        res.setHeader("Cache-Control", "no-store");
        return res.status(200).send(html);
    }

    // ── 3. Inject data-island meta tags for the client SPA to hydrate from ────
    // course:folder-path (when present) lets navigation.js resolve straight
    // to the nested folder on load, instead of resolving the course only and
    // relying on a hash the server never sees.
    html = html.replace(
        "</head>",
        `  <meta name="course:id" content="${escapeHtml(meta.id)}">\n` +
        `  <meta name="course:name" content="${escapeHtml(meta.name)}">\n` +
        (folderMeta
            ? `  <meta name="course:folder-path" content="${escapeHtml(pathSlugs.join("/"))}">\n`
            : "") +
        `</head>`,
    );

    // ── 4. Inject OG / title / canonical tags ─────────────────────────────────
    // When a folder path resolved, every tag reflects the deepest folder
    // (title, description, canonical, OG image all show the full chain, e.g.
    // "Math / Algebra / Second") rather than the course alone.
    const pageMeta = folderMeta || meta;
    const title = buildTitle(pageMeta, meta.name);
    const description = buildDescription(pageMeta, meta.name);
    const courseSlugPath = toSlug(meta.name);
    const folderSlugPath = folderMeta
        ? "/" + folderMeta.path.map((seg) => encodeURIComponent(toSlug(seg))).join("/")
        : "";
    const canonicalUrl = `${SITE_ORIGIN}/course/${encodeURIComponent(courseSlugPath)}${folderSlugPath}`;
    // /api/og handles quizId=, course=, and course=+folder= — see that
    // file's handler() dispatch comment for why these Edge OG generators
    // share one function.
    // The counts are part of the version: the image is cached for a year per
    // URL, so when content is added/removed the URL must change or the image
    // would keep showing old counts while title/description show new ones.
    const countsStamp = [pageMeta.folderCount, pageMeta.quizCount, pageMeta.lessonCount, pageMeta.notebookCount].map((n) => n || 0);
    const ogImageUrl = folderMeta
        ? `${SITE_ORIGIN}/api/og?course=${encodeURIComponent(meta.id)}&folder=${encodeURIComponent(folderMeta.path.join("/"))}&v=${ogVersion("course", countsStamp)}`
        : `${SITE_ORIGIN}/api/og?course=${encodeURIComponent(meta.id)}&v=${ogVersion("course", countsStamp)}`;

    html = html.replace(
        /<title>[^<]*<\/title>/i,
        `<title>${escapeHtml(title)}</title>`,
    );

    html = replaceLinkHref(html, "canonical", canonicalUrl);

    html = replaceMetaContent(html, "property", "og:title", title);
    html = replaceMetaContent(html, "property", "og:url", canonicalUrl);
    html = replaceMetaContent(html, "property", "og:image", ogImageUrl);
    html = replaceMetaContent(html, "property", "og:description", description);

    html = replaceMetaContent(html, "name", "twitter:title", title);
    html = replaceMetaContent(html, "name", "twitter:image", ogImageUrl);
    html = replaceMetaContent(html, "name", "twitter:image:alt", title);
    html = replaceMetaContent(html, "name", "twitter:description", description);

    html = replaceMetaContent(html, "name", "description", description);

    // ── 4b. JSON-LD + visible spider island (plan §8.4/§8.5) ──────────────────
    // Kept as its own step, fetching real immediate children so the
    // ItemList/noscript island reflect actual content rather than just the
    // counts already computed above. Best-effort: a failure here degrades to
    // "no children listed" rather than failing the whole page render, since
    // this is supplementary discoverability, not the SPA's core content.
    let rawChildren = { folders: [], quizzes: [], lessons: [], notebooks: [] };
    try {
        rawChildren = await fetchImmediateChildren(folderMeta ? folderMeta.id : meta.id, !!folderMeta);
    } catch (err) {
        console.error("[render-course] immediate-children lookup failed (non-fatal):", err?.message || err);
    }
    // Child folder URLs need the full slug chain back to the course root,
    // which only the caller (this scope) knows at this point.
    const childFolderBase = folderMeta
        ? `${courseSlugPath}/${folderMeta.path.map((seg) => toSlug(seg)).join("/")}`
        : courseSlugPath;
    const children = {
        folders: (rawChildren.folders || []).map((f) => ({
            name: f.name,
            url: `/course/${encodeURIComponent(childFolderBase)}/${encodeURIComponent(toSlug(f.name))}`,
        })),
        quizzes: rawChildren.quizzes || [],
        lessons: rawChildren.lessons || [],
        notebooks: rawChildren.notebooks || [],
    };

    const breadcrumbItems = [{ name: "الرئيسية", url: SITE_ORIGIN }];
    breadcrumbItems.push({ name: meta.name, url: `${SITE_ORIGIN}/course/${encodeURIComponent(courseSlugPath)}` });
    if (folderMeta) {
        let acc = courseSlugPath;
        for (const seg of folderMeta.path) {
            acc += `/${toSlug(seg)}`;
            breadcrumbItems.push({ name: seg, url: `${SITE_ORIGIN}/course/${encodeURIComponent(acc)}` });
        }
    }

    const breadcrumbJsonLd = {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        itemListElement: breadcrumbItems.map((item, i) => ({
            "@type": "ListItem",
            position: i + 1,
            name: item.name,
            item: item.url,
        })),
    };

    const childItems = [
        ...children.folders.map((f) => ({ name: f.name, url: `${SITE_ORIGIN}${f.url}` })),
        ...children.quizzes.map((q) => ({ name: q.title, url: `${SITE_ORIGIN}${q.url}` })),
        ...children.lessons.map((l) => ({ name: l.title, url: `${SITE_ORIGIN}${l.url}` })),
        ...children.notebooks.map((n) => ({ name: n.title, url: `${SITE_ORIGIN}${n.url}` })),
    ];

    const collectionJsonLd = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        name: title,
        description,
        url: canonicalUrl,
        inLanguage: "ar",
        isPartOf: { "@type": "WebSite", name: "منصة امتحانات بصمجي", url: SITE_ORIGIN },
    };

    const itemListJsonLd = {
        "@context": "https://schema.org",
        "@type": "ItemList",
        itemListElement: childItems.map((item, i) => ({
            "@type": "ListItem",
            position: i + 1,
            name: item.name,
            url: item.url,
        })),
    };

    const jsonLdScripts =
        `  <script type="application/ld+json">${JSON.stringify(collectionJsonLd)}</script>\n` +
        (childItems.length
            ? `  <script type="application/ld+json">${JSON.stringify(itemListJsonLd)}</script>\n`
            : "") +
        `  <script type="application/ld+json">${JSON.stringify(breadcrumbJsonLd)}</script>\n`;
    html = html.replace("</head>", `${jsonLdScripts}</head>`);

    // Visible-but-offscreen spider island (plan §8.5): real <a> links to
    // immediate children, for HTML-only crawlers/LLM fetchers that don't
    // execute the SPA's client-side router. Wrapped in <noscript> so it
    // never affects the JS-enabled app UI, and inserted right after <body>
    // so it exists regardless of how deep index.html's own body markup is.
    if (childItems.length > 0) {
        const islandLinks = childItems
            .map((item) => `<li><a href="${escapeHtml(item.url)}">${escapeHtml(item.name)}</a></li>`)
            .join("");
        const island =
            `<noscript><div class="seo-catalog" style="position:absolute;left:-9999px" aria-hidden="true">` +
            `<h2>${escapeHtml(title)}</h2><ul>${islandLinks}</ul></div></noscript>`;
        html = html.replace(/<body[^>]*>/i, (bodyTag) => `${bodyTag}\n${island}`);
    }

    // ── 5. Respond ─────────────────────────────────────────────────────────────
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader(
        "Cache-Control",
        "public, s-maxage=300, stale-while-revalidate=3600",
    );
    return res.status(200).send(html);
}

// =============================================================================
// Data fetching
// =============================================================================

/**
 * Fetches a course by URL slug and its folder/quiz counts.
 * Courses aren't guaranteed globally unique by name (the real uniqueness key
 * is (education_type, college, year, term, name) — see
 * api/_courseFolders.js), so this fetches all courses' (id, name,
 * education_type) and matches toSlug(name) against the incoming slug,
 * exactly like the client's navigation.js does for hash-based routing.
 * ?education_type= (if present) disambiguates when multiple courses share a
 * slug; otherwise the first match wins.
 *
 * Relational count queries against `folders`/`quizzes` (course_id), NOT the
 * old manifest-walk approach (see public/src/shared/quizManifest.js).
 *
 * @param {string} courseSlug
 * @param {string|null} educationType
 * @returns {Promise<{id:string, name:string, folderCount:number, quizCount:number}|null>}
 */
async function fetchCourseMeta(courseSlug, educationType) {
    const { data: courses, error: coursesErr } = await getSupabase()
        .from("courses")
        .select("id, name, education_type");

    if (coursesErr) {
        console.error("[render-course] Supabase course lookup error:", coursesErr.message);
        return null;
    }
    if (!Array.isArray(courses) || courses.length === 0) return null;

    const candidates = courses.filter((c) => toSlug(c.name) === courseSlug);
    if (candidates.length === 0) return null;

    const course =
        (educationType && candidates.find((c) => c.education_type === educationType)) ||
        candidates[0];

    const [
        { count: folderCount, error: folderErr },
        { count: quizCount, error: quizErr },
        { count: lessonCount, error: lessonErr },
        { count: notebookCount, error: notebookErr },
    ] = await Promise.all([
        getSupabase()
            .from("folders")
            .select("id", { count: "exact", head: true })
            .eq("course_id", course.id),
        getSupabase()
            .from("quizzes")
            .select("id", { count: "exact", head: true })
            .eq("course_id", course.id),
        getSupabase()
            .from("lesson_public")
            .select("id", { count: "exact", head: true })
            .eq("course_id", course.id),
        getSupabase()
            .from("notebooks")
            .select("id", { count: "exact", head: true })
            .eq("course_id", course.id),
    ]);

    if (folderErr) console.error("[render-course] folder count error:", folderErr.message);
    if (quizErr) console.error("[render-course] quiz count error:", quizErr.message);
    if (lessonErr) console.error("[render-course] lesson count error:", lessonErr.message);
    if (notebookErr) console.error("[render-course] notebook count error:", notebookErr.message);

    return {
        id: course.id,
        name: course.name,
        folderCount: folderCount || 0,
        quizCount: quizCount || 0,
        lessonCount: lessonCount || 0,
        notebookCount: notebookCount || 0,
    };
}

/**
 * Walks a chain of folder-name slugs under a course, level by level, using
 * `folders.parent_folder_id` (null at the top level, directly under the
 * course). Each segment is matched via toSlug(name) against the slug in the
 * URL — same case/slug-insensitive approach fetchCourseMeta() and the
 * client's navigation.js use. Returns null (falls back to the course page)
 * if any segment fails to resolve, e.g. a stale/renamed folder link.
 *
 * Direct-child-only counts are used for folderCount/quizCount (not a full
 * subtree walk) to match what the course page's own counts represent
 * (immediate children), and to keep this to one query pair regardless of
 * how deep the path is.
 *
 * @param {string} courseId
 * @param {string[]} pathSlugs e.g. ["Algebra", "Second"]
 * @returns {Promise<{id:string, name:string, path:string[], folderCount:number, quizCount:number}|null>}
 */
async function fetchFolderPath(courseId, pathSlugs) {
    let parentFolderId = null;
    let folder = null;
    const resolvedNames = [];

    for (const slug of pathSlugs) {
        const query = getSupabase()
            .from("folders")
            .select("id, name")
            .eq("course_id", courseId);
        const { data: siblings, error } = parentFolderId
            ? await query.eq("parent_folder_id", parentFolderId)
            : await query.is("parent_folder_id", null);

        if (error) {
            console.error("[render-course] folder path lookup error:", error.message);
            return null;
        }
        if (!Array.isArray(siblings) || siblings.length === 0) return null;

        const match = siblings.find((f) => toSlug(f.name) === slug);
        if (!match) return null;

        folder = match;
        parentFolderId = match.id;
        resolvedNames.push(match.name);
    }

    if (!folder) return null;

    const [
        { count: folderCount, error: folderErr },
        { count: quizCount, error: quizErr },
        { count: lessonCount, error: lessonErr },
        { count: notebookCount, error: notebookErr },
    ] = await Promise.all([
        getSupabase()
            .from("folders")
            .select("id", { count: "exact", head: true })
            .eq("parent_folder_id", folder.id),
        getSupabase()
            .from("quizzes")
            .select("id", { count: "exact", head: true })
            .eq("folder_id", folder.id),
        getSupabase()
            .from("lesson_public")
            .select("id", { count: "exact", head: true })
            .eq("folder_id", folder.id),
        getSupabase()
            .from("notebooks")
            .select("id", { count: "exact", head: true })
            .eq("folder_id", folder.id),
    ]);

    if (folderErr) console.error("[render-course] folder-count error:", folderErr.message);
    if (quizErr) console.error("[render-course] folder quiz-count error:", quizErr.message);
    if (lessonErr) console.error("[render-course] folder lesson-count error:", lessonErr.message);
    if (notebookErr) console.error("[render-course] folder notebook-count error:", notebookErr.message);

    return {
        id: folder.id,
        name: folder.name,
        path: resolvedNames,
        folderCount: folderCount || 0,
        quizCount: quizCount || 0,
        lessonCount: lessonCount || 0,
        notebookCount: notebookCount || 0,
    };
}

/**
 * Fetches the real immediate children (direct-child folders + quizzes, no
 * deeper subtree walk — matching the existing folderCount/quizCount
 * semantics above) of either a course or a folder, for the CollectionPage
 * ItemList JSON-LD and the noscript spider island (plan §8.4/§8.5).
 * Excludes password-protected quizzes, same guard as api/_catalog.js's
 * sitemap/feed/llms-full query set.
 *
 * @param {string} parentId - course.id or folder.id
 * @param {boolean} isFolder - true when parentId is a folder id
 * @returns {Promise<{folders: Array<{name:string}>, quizzes: Array<{title:string,url:string}>}>}
 *   (folder URLs are resolved by the caller, which knows the full slug chain)
 */
async function fetchImmediateChildren(parentId, isFolder) {
    const folderQuery = isFolder
        ? getSupabase().from("folders").select("id, name").eq("parent_folder_id", parentId)
        : getSupabase().from("folders").select("id, name").eq("course_id", parentId).is("parent_folder_id", null);
    const quizQuery = isFolder
        ? getSupabase().from("quizzes").select("data, password").eq("folder_id", parentId)
        : getSupabase().from("quizzes").select("data, password").eq("course_id", parentId).is("folder_id", null);
    const lessonQuery = isFolder
        ? getSupabase().from("lesson_public").select("id, slug, title, password_protected").eq("folder_id", parentId)
        : getSupabase().from("lesson_public").select("id, slug, title, password_protected").eq("course_id", parentId).is("folder_id", null);
    const notebookQuery = isFolder
        ? getSupabase().from("notebooks").select("id, slug, title").eq("folder_id", parentId)
        : getSupabase().from("notebooks").select("id, slug, title").eq("course_id", parentId).is("folder_id", null);

    const [
        { data: folderRows, error: folderErr },
        { data: quizRows, error: quizErr },
        { data: lessonRows, error: lessonErr },
        { data: notebookRows, error: notebookErr },
    ] = await Promise.all([
        folderQuery,
        quizQuery,
        lessonQuery,
        notebookQuery,
    ]);

    if (folderErr) console.error("[render-course] children folder lookup error:", folderErr.message);
    if (quizErr) console.error("[render-course] children quiz lookup error:", quizErr.message);
    if (lessonErr) console.error("[render-course] children lesson lookup error:", lessonErr.message);
    if (notebookErr) console.error("[render-course] children notebook lookup error:", notebookErr.message);

    const folders = (folderRows || []).map((f) => ({ name: f.name }));

    const quizzes = [];
    for (const q of quizRows || []) {
        if (q.password) continue; // exclude password-gated quizzes
        const metaId = q.data?.meta?.id;
        const title = q.data?.meta?.title;
        if (!metaId || !title) continue;
        quizzes.push({ title, url: `/quiz/${encodeURIComponent(metaId)}` });
    }

    const lessons = [];
    for (const l of lessonRows || []) {
        if (!l.id || !l.title) continue;
        lessons.push({ title: l.title, url: `/lesson/${encodeURIComponent(l.slug || l.id)}` });
    }

    const notebooks = [];
    for (const n of notebookRows || []) {
        if (!n.id || !n.title) continue;
        notebooks.push({ title: n.title, url: `/notebook/${encodeURIComponent(n.slug || n.id)}` });
    }

    return { folders, quizzes, lessons, notebooks };
}

// =============================================================================
// Title / description formatting
// =============================================================================

function isArabicText(text) {
    const firstLetterMatch = text?.match(/\p{L}/u);
    return (
        firstLetterMatch &&
        /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/.test(firstLetterMatch[0])
    );
}

// `meta` is either the course-level object (from fetchCourseMeta) or a
// folder-level object (from fetchFolderPath, which additionally carries
// `path`: the full breadcrumb of resolved folder names under the course).
// When `courseName` + `meta.path` are both given, the displayed name/breadcrumb
// reads "Course / Sub / Sub2" instead of just the deepest folder's own name,
// so a deeply nested folder's title/OG image still shows which course it's
// under.
function displayPath(courseName, meta) {
    if (!meta.path) return meta.name; // course-level: no breadcrumb needed
    return [courseName, ...meta.path].join(" / ");
}

function formatArCount(count, one, two, few, many) {
    if (count === 1) return one;
    if (count === 2) return two;
    if (count >= 3 && count <= 10) return `${count} ${few}`;
    return `${count} ${many}`;
}

function formatEnCount(count, singular, plural) {
    return `${count} ${count === 1 ? singular : plural}`;
}

function formatConjunctionList(items, isArabic) {
    if (!items || items.length === 0) return "";
    if (items.length === 1) return items[0];
    if (isArabic) {
        return items.slice(0, -1).join(" و") + " و" + items[items.length - 1];
    }
    return items.slice(0, -1).join(", ") + " and " + items[items.length - 1];
}

function buildTitle(meta, courseName) {
    const label = displayPath(courseName, meta);
    const isArabic = isArabicText(meta.name);
    const tokens = isArabic
        ? [
            `${meta.folderCount} مجلد`,
            `${meta.quizCount} امتحان`,
            `${meta.lessonCount ?? 0} درس`,
            `${meta.notebookCount ?? 0} دفتر`,
        ]
        : [
            `${meta.folderCount} Folders`,
            `${meta.quizCount} Quizzes`,
            `${meta.lessonCount ?? 0} Lessons`,
            `${meta.notebookCount ?? 0} Notebooks`,
        ];
    return `${label}: ${tokens.join(" · ")}`;
}

function buildDescription(meta, courseName) {
    const label = displayPath(courseName, meta);
    const isArabic = isArabicText(meta.name);
    const quizC = meta.quizCount || 0;
    const lessonC = meta.lessonCount || 0;
    const notebookC = meta.notebookCount || 0;
    const folderC = meta.folderCount || 0;

    if (isArabic) {
        const contentTokens = [];
        if (quizC > 0) contentTokens.push(formatArCount(quizC, "امتحان", "امتحانان", "امتحانات", "امتحان"));
        if (lessonC > 0) contentTokens.push(formatArCount(lessonC, "درس", "درسان", "دروس", "درس"));
        if (notebookC > 0) contentTokens.push(formatArCount(notebookC, "دفتر", "دفتران", "دفاتر", "دفتر"));

        const contentClause = contentTokens.length > 0
            ? formatConjunctionList(contentTokens, true)
            : "محتوى تعليمي";

        if (folderC > 0) {
            const folderClause = formatArCount(folderC, "مجلد", "مجلدان", "مجلدات", "مجلد");
            return `تصفح ${contentClause} ضمن ${folderClause} في ${label} على منصة امتحانات بصمجي.`;
        }
        return `تصفح ${contentClause} في ${label} على منصة امتحانات بصمجي.`;
    }

    const contentTokensEn = [];
    if (quizC > 0) contentTokensEn.push(formatEnCount(quizC, "quiz", "quizzes"));
    if (lessonC > 0) contentTokensEn.push(formatEnCount(lessonC, "lesson", "lessons"));
    if (notebookC > 0) contentTokensEn.push(formatEnCount(notebookC, "notebook", "notebooks"));

    const contentClauseEn = contentTokensEn.length > 0
        ? formatConjunctionList(contentTokensEn, false)
        : "educational content";

    if (folderC > 0) {
        const folderClauseEn = formatEnCount(folderC, "folder", "folders");
        return `Browse ${contentClauseEn} across ${folderClauseEn} in ${label} on Basmagi Quiz Platform.`;
    }
    return `Browse ${contentClauseEn} in ${label} on Basmagi Quiz Platform.`;
}

// =============================================================================
// HTML helpers (identical to render-quiz.js)
// =============================================================================

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function replaceMetaContent(html, attr, value, newContent) {
    const tagRe = new RegExp(
        `<meta[^>]*\\b${attr}=["']${escapeRegex(value)}["'][^>]*>`,
        "gi",
    );
    return html.replace(tagRe, (tag) => {
        if (/content=["'][^"']*["']/i.test(tag)) {
            return tag.replace(
                /content=["'][^"']*["']/i,
                `content="${escapeHtml(newContent)}"`,
            );
        }
        return tag;
    });
}

function replaceLinkHref(html, rel, newHref) {
    const tagRe = new RegExp(
        `<link[^>]*\\brel=["']${escapeRegex(rel)}["'][^>]*>`,
        "i",
    );
    return html.replace(tagRe, (tag) => {
        if (/href=["'][^"']*["']/i.test(tag)) {
            return tag.replace(
                /href=["'][^"']*["']/i,
                `href="${escapeHtml(newHref)}"`,
            );
        }
        return tag;
    });
}

function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}