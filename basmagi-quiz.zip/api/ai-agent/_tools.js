// =============================================================================
// api/ai-agent/_tools.js
// Shared tool schema(s) the AI Helper backend can offer to providers. Kept
// provider-agnostic here; each provider adapter in _providerClients.js
// translates this into its own native tool/function-calling shape.
// =============================================================================

// Mirrors the JSON shape parseQuizJson()/buildUserQuizEntry() (in
// public/src/shared/quiz-json.js and public/src/features/home/quiz-schema.js)
// already expect — no new parsing code needed on the save side.
export const CREATE_QUIZ_TOOL = {
  name: "create_quiz",
  description:
    "Create a new quiz and save it for the user. Only call this when the user has explicitly confirmed they want the quiz created (e.g. after you've shown them a preview and they said yes/أنشئ/تمام). " +
    "For MCQ/True-False questions, `correct` MUST always be an array of 0-based option indices — use a single-element array like [2] for one correct answer, or multiple indices like [0, 2] if more than one option is correct. Omit `correct` (and `options`) entirely for essay/free-text questions and use `answer` instead. " +
    "`multiSelect` controls whether the quiz-taker sees checkboxes (true) or radio buttons (false) — it is independent of how many indices are in `correct`. Default to `false` unless the user specifically wants a \"choose one or more\" question or `correct` has more than one index (in which case set it to `true`). " +
    "Math must always be LaTeX ($...$ inline, $$...$$ display) in `q`, options, `answer` and `explanation` — never plain text like x^2, sqrt(x), 1/2, x² or ≤. " +
    "True/False options must be in the quiz's language: [\"صح\",\"خطأ\"] for Arabic, [\"True\",\"False\"] for English. " +
    "To embed an image, audio, or video in a question, do NOT use dedicated fields — embed it directly inline inside `q` (or `explanation`/`answer`) using markdown bracket syntax: `![alt text](url)` for an image, `![audio](url)` for audio, `![video](url)` for video (YouTube links auto-embed). Place the tag on its own line, typically after the question text. " +
    "`folder` is the exact title of an existing folder or course (from the folder tree listing already given to you) to place the new quiz directly inside, e.g. so the user can ask for it under \"math/algebra\" instead of always landing at the top level — omit it (or pass null) to save at the top level, alongside courses.",
  input_schema: {
    type: "object",
    properties: {
      title: { type: "string" },
      description: { type: "string" },
      folder: { type: "string" },
      questions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            q: { type: "string" },
            options: { type: "array", items: { type: "string" } },
            // NOTE: Gemini's proto-based tool schema rejects JSON-Schema union
            // types (e.g. type: ["integer","array"]) with a 400 — "Proto
            // field is not repeating, cannot start list." Always use an
            // array of 0-based indices here; the save path (buildUserQuizEntry
            // in quiz-schema.js) unwraps a single-element array to a plain
            // integer for single-answer questions, so no behavior changes.
            correct: { type: "array", items: { type: "integer" } },
            // Independent of `correct`'s length — see isMultiSelectQuestion()
            // in rate-answers.js. Omitting this falls back to the legacy
            // Array.isArray(correct) heuristic, which is always true now
            // that `correct` is always an array, so the model should set
            // this explicitly rather than rely on the fallback.
            multiSelect: { type: "boolean" },
            answer: { type: "string" },
            explanation: { type: "string" },
          },
          required: ["q"],
        },
      },
    },
    required: ["title", "questions"],
  },
};

// Same question-shape rules as CREATE_QUIZ_TOOL above. `currentTitle` is how
// the model identifies which existing quiz to modify — it's read out of the
// contextSummary list already given to it (see user-quizzes-view.js). Every
// field besides currentTitle is optional so the model can send only what
// actually changes (e.g. just `title` to rename, without resending all
// questions).
export const EDIT_QUIZ_TOOL = {
  name: "edit_quiz",
  description:
    "Edit an existing quiz's title, description, or questions. Only call this when the user has explicitly confirmed the specific change (e.g. after you've restated what will change and they said yes/عدّل/تمام). " +
    "Identify the quiz using `currentTitle`, matched exactly against one of the titles already given to you. Only include the fields that actually change — omit `questions` entirely if only the title/description changed. " +
    "If `questions` is included, it REPLACES the quiz's entire question list, so include every question that should remain, not just the changed ones. " +
    "`multiSelect` controls whether the quiz-taker sees checkboxes (true) or radio buttons (false) — it is independent of how many indices are in `correct`. Default to `false` unless the user specifically wants a \"choose one or more\" question or `correct` has more than one index. " +
    "To embed an image, audio, or video in a question, do NOT use dedicated fields — embed it directly inline inside `q` (or `explanation`/`answer`) using markdown bracket syntax: `![alt text](url)` for an image, `![audio](url)` for audio, `![video](url)` for video (YouTube links auto-embed).",
  input_schema: {
    type: "object",
    properties: {
      currentTitle: { type: "string" },
      title: { type: "string" },
      description: { type: "string" },
      questions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            q: { type: "string" },
            options: { type: "array", items: { type: "string" } },
            correct: { type: "array", items: { type: "integer" } },
            multiSelect: { type: "boolean" },
            answer: { type: "string" },
            explanation: { type: "string" },
          },
          required: ["q"],
        },
      },
    },
    required: ["currentTitle"],
  },
};

export const DELETE_QUIZ_TOOL = {
  name: "delete_quiz",
  description:
    "Permanently delete a quiz. Only call this when the user has explicitly confirmed deletion of this specific quiz by name (e.g. they asked to delete it and then replied yes/احذف/تمام to your confirmation). Never call this speculatively or as a suggestion — deletion cannot be undone.",
  input_schema: {
    type: "object",
    properties: {
      title: { type: "string" },
    },
    required: ["title"],
  },
};

// Create-quiz page only (see chat.js's TOOLS_BY_NAME / toolNames request
// field). Same edit semantics/question-shape as EDIT_QUIZ_TOOL above, but
// deliberately has NO currentTitle field at all — that page has exactly
// one quiz in scope (the one currently in the editor form), so there's
// nothing to disambiguate. A previous version reused EDIT_QUIZ_TOOL as-is
// on this page, but its schema-level `required: ["currentTitle"]` meant
// providers could still push the model to supply *something* there even
// though the page's own tool handler (create-quiz.js::handleAiEditQuizToolCall)
// always ignores it — removing the field entirely is cleaner than leaving
// it present-but-unused.
export const EDIT_CURRENT_QUIZ_TOOL = {
  name: "edit_quiz",
  description:
    "Edit the single quiz currently open in this page's editor — its title, description, and/or questions. There is only one quiz in scope on this page, so no identifier is needed. Only call this when the user has explicitly confirmed the specific change (e.g. after you've restated what will change and they said yes/عدّل/تمام). " +
    "Only include the fields that actually change — omit `questions` entirely if only the title/description changed. " +
    "If `questions` is included, it REPLACES the quiz's entire question list, so include every question that should remain (not just new/changed ones) — this is also how you fully replace the current quiz with a different one in a single call, without a separate reset step. " +
    "`multiSelect` controls whether the quiz-taker sees checkboxes (true) or radio buttons (false) — it is independent of how many indices are in `correct`. Default to `false` unless the user specifically wants a \"choose one or more\" question or `correct` has more than one index. " +
    "To embed an image, audio, or video in a question, do NOT use dedicated fields — embed it directly inline inside `q` (or `explanation`/`answer`) using markdown bracket syntax: `![alt text](url)` for an image, `![audio](url)` for audio, `![video](url)` for video (YouTube links auto-embed).",
  input_schema: {
    type: "object",
    properties: {
      title: { type: "string" },
      description: { type: "string" },
      questions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            q: { type: "string" },
            options: { type: "array", items: { type: "string" } },
            correct: { type: "array", items: { type: "integer" } },
            multiSelect: { type: "boolean" },
            answer: { type: "string" },
            explanation: { type: "string" },
          },
          required: ["q"],
        },
      },
    },
  },
};

// Create-quiz page only (see chat.js's TOOLS_BY_NAME / toolNames request
// field). Unlike delete_quiz (which removes a saved quiz from the user's
// library by title), this clears the single in-progress draft the editor
// page is currently showing — there's no title to disambiguate since
// there's only ever one quiz on that page. Input is intentionally empty:
// nothing to configure, it's an unconditional wipe.
// Home page only (see chat.js's TOOLS_BY_NAME / toolNames request field).
// Courses and folders are both plain organizational containers backed by
// the same user_quizzes records as quizzes themselves (see
// createFolderOrCourseNamed in user-quizzes-folders.js) — the model never
// sees or produces an internal id for either; every reference here is a
// title, resolved against the folder-tree text listing already included
// in this page's system prompt (buildFolderTreeContextPrompt in
// user-quizzes-view.js). That listing is the ONLY way the model can know
// what folders/courses currently exist and how they nest, so it must
// always be present in context whenever these tools are offered.
export const CREATE_FOLDER_TOOL = {
  name: "create_folder",
  description:
    "Create a new folder to organize the user's quizzes. Only call this when the user has explicitly confirmed the folder name and location (e.g. after you've restated what will be created and they said yes/أنشئ/تمام). " +
    "`parentFolder` is the exact title of an existing folder or course to nest the new folder inside, matched against the folder tree listing already given to you — omit it (or pass null) to create the new folder at the top level, alongside courses. " +
    "Unlike courses, folders CAN be nested inside other folders (or inside a course) to any depth.",
  input_schema: {
    type: "object",
    properties: {
      name: { type: "string" },
      parentFolder: { type: "string" },
    },
    required: ["name"],
  },
};

export const CREATE_COURSE_TOOL = {
  name: "create_course",
  description:
    "Create a new course — a top-level subject grouping for quizzes (e.g. \"تشريح\", \"فسيولوجيا\"). Only call this when the user has explicitly confirmed the course name (e.g. after you've restated it and they said yes/أنشئ/تمام). " +
    "Courses always live at the top level and can never be nested inside a folder or another course — there is no parent to specify, unlike create_folder.",
  input_schema: {
    type: "object",
    properties: {
      name: { type: "string" },
    },
    required: ["name"],
  },
};

export const MOVE_ITEM_TOOL = {
  name: "move_item",
  description:
    "Move an existing quiz, folder, or course to a different location in the user's folder tree. Only call this when the user has explicitly confirmed the specific move (e.g. after you've restated what will move where and they said yes/انقل/تمام). " +
    "`itemName` is the exact title of the quiz/folder/course to move, matched against the folder tree listing and quiz titles already given to you. `destinationFolder` is the exact title of the folder or course to move it into, matched the same way — omit it (or pass null) to move the item to the top level. " +
    "A course can never be moved into a folder (courses only exist at the top level) and nothing can be moved into itself or one of its own descendants — if the user asks for either, tell them it isn't possible instead of calling this tool.",
  input_schema: {
    type: "object",
    properties: {
      itemName: { type: "string" },
      destinationFolder: { type: "string" },
    },
    required: ["itemName"],
  },
};

export const RESET_QUIZ_PAGE_TOOL = {
  name: "reset_quiz_page",
  description:
    "Clear the quiz currently being edited on this page — its title, description, and every question. Only call this when the user has explicitly confirmed they want to start over from a blank quiz (e.g. after you've warned them this deletes everything currently on the page and they replied yes/امسح/ابدأ من جديد/تمام). This cannot be undone. Do NOT use this tool if the user wants to replace the current quiz with a different one — use edit_quiz for that instead (see its own description), since this page only supports one tool call per turn and a reset-then-create plan would silently only execute the reset.",
  input_schema: {
    type: "object",
    properties: {},
  },
};

export const FETCH_ATTACHED_QUIZ_TOOL = {
  name: "fetch_attached_quiz",
  description:
    "Fetch the full questions and answers for one quiz listed in an attached course or folder. Use the exact quiz ID from the attached hierarchy, and only when the user asks for details that the hierarchy does not contain.",
  input_schema: {
    type: "object",
    properties: { quizId: { type: "string" } },
    required: ["quizId"],
  },
};

export const FETCH_ATTACHED_LESSON_TOOL = {
  name: "fetch_attached_lesson",
  description:
    "Fetch the full readable content and metadata for one lesson attached to the conversation. Use the exact lesson ID from the attached lesson reference, and only when the user asks about details not already included in the attachment summary. Protected lessons cannot be unlocked by this tool; ask the user to open/unlock the lesson first.",
  input_schema: {
    type: "object",
    properties: { lessonId: { type: "string" } },
    required: ["lessonId"],
  },
};

// ── Conversational discovery tools (home page) ──────────────────────────
// All three below are read-only and resolved entirely CLIENT-SIDE (see
// ai-agent-attach-launcher.js / user-quizzes-view.js's onToolCall dispatch
// and ai-agent-library-search.js) — never on the server, unlike this
// file's own comment block up top might otherwise suggest for a "backend
// tool". Two reasons:
//   1. Half of what they search/read (user_quizzes) only ever lives in the
//      browser's localStorage; the server has no access to it and never
//      should (privacy — that data shouldn't need to transit this
//      endpoint just to be searched).
//   2. The other half (platform courses/quizzes) is ALREADY fully
//      client-resolvable without a server round-trip at all — see
//      quizManifest.js's own header comment: this project moved manifest
//      loading off a serverless function specifically because of Vercel
//      Hobby's 12-function cap, and a public RLS SELECT policy already
//      permits the exact reads these tools need directly from the client.
// So these tool schemas exist purely to tell the MODEL what it can ask
// for; chat.js's TOOLS_BY_NAME map below never executes them — the
// resulting tool_use always round-trips back to the client's onToolCall,
// same as create_quiz/edit_quiz/etc. already do.
export const SEARCH_LIBRARY_TOOL = {
  name: "search_library",
  description:
    "Search both the user's personal quiz library and the platform's main-page content by keyword. Use this when the user asks a conversational question about content that isn't already attached (e.g. \"find some quizzes about data structures\"), instead of asking them to attach something manually. " +
    "Returns up to a handful of matching quizzes/courses from each source, with id/title/kind. Call parse_item_info afterward with a specific result's id if you need its full contents rather than just its title.",
  input_schema: {
    type: "object",
    properties: {
      query: { type: "string" },
      scope: {
        type: "string",
        enum: ["mine", "platform", "both"],
        description: "\"mine\" searches only the user's own library, \"platform\" only the main-page content, \"both\" (default) searches everything.",
      },
    },
    required: ["query"],
  },
};

export const PARSE_ITEM_INFO_TOOL = {
  name: "parse_item_info",
  description:
    "Fetch full contents and metadata for one specific quiz, folder, or course by id — from either the user's own library or the platform's main-page content. Use this after search_library (or an @-mention already in the conversation) has told you the id you need, when the user asks something the id/title alone doesn't answer.",
  input_schema: {
    type: "object",
    properties: {
      id: { type: "string" },
      kind: { type: "string", enum: ["quiz", "folder", "course"] },
    },
    required: ["id"],
  },
};

export const GET_USER_ACTIVITY_TOOL = {
  name: "get_user_activity",
  description:
    "Look up the user's own recent activity on this device: their last created quiz, or the quiz they last took (including its score). Use when the user asks conversationally (e.g. \"how did I do on my last quiz?\" or \"what was the last quiz I made?\") instead of attaching it manually via @-mention. " +
    "Note: \"last taken\" and \"last result\" both come from the same stored record (this device only tracks the single most recent attempt, not a full history) — if the user asks either question, answer from whichever fields are relevant (quiz identity vs. score).",
  input_schema: {
    type: "object",
    properties: {
      which: { type: "string", enum: ["last_created", "last_taken_or_result"] },
    },
    required: ["which"],
  },
};

export const GET_CREATOR_INFO_TOOL = {
  name: "get_creator_info",
  description: "Read the full public profile and contact links of Basamgy's creator, Belal Amr Mohamed, from the site's About page. Use to answer factual questions about the creator; this is public creator information, not private information about the current chat user.",
  input_schema: { type: "object", properties: {}, required: [] },
};

export const DISPLAY_CREATOR_CARD_TOOL = {
  name: "display_creator_card",
  description: "Display an interactive in-chat card with the creator's real profile photo, portfolio thumbnail, and links. Use when the user asks to see or visit the creator's portfolio, YouTube, social profiles, or contact options.",
  input_schema: {
    type: "object",
    properties: { section: { type: "string", enum: ["all", "portfolio", "social", "contact"] } },
    required: [],
  },
};

export const CREATE_FLASHCARDS_TOOL = {
  name: "create_flashcards",
  description: "Create an interactive flashcard deck from the currently open lesson. Return concise, accurate question/answer pairs grounded only in that lesson. Aim for 6–12 cards unless the user requests another count, and include at least two useful cards. The website renders them as clickable flip cards in the current chat; do not save them as a quiz or lesson.",
  input_schema: {
    type: "object",
    properties: {
      title: { type: "string", description: "A short title for the review deck." },
      cards: {
        type: "array",
        items: {
          type: "object",
          properties: {
            question: { type: "string", description: "One concise recall prompt." },
            answer: { type: "string", description: "A clear, accurate answer grounded in the lesson." },
          },
          required: ["question", "answer"],
        },
      },
    },
    required: ["title", "cards"],
  },
};

// Create-lesson page only. One question per call is intentional: the chat
// provider executes at most one tool call per turn, and inserting one block
// is atomic, undoable, and never replaces the rest of the lesson.
export const ADD_LESSON_QUESTION_TOOL = {
  name: "add_lesson_question",
  description: "Insert one embedded question into the current lesson. Only call after the creator explicitly confirms the proposed question. Use questionKind 'essay' with a complete modelAnswer and an explanation; the reader sees an approximate 0-5 self-check rating. For MCQ, provide 2-8 options, an explanation, and a zero-based correctIndexes array; use one index for a single-answer question and set multiSelect true when there is more than one correct option. Represent true/false as two options. sectionTitle must exactly match a section supplied in the current lesson summary, or omit it to use the first section.",
  input_schema: {
    type: "object",
    properties: {
      sectionTitle: { type: "string" },
      questionKind: { type: "string", enum: ["mcq", "essay"] },
      prompt: { type: "string" },
      options: { type: "array", items: { type: "string" } },
      correctIndexes: { type: "array", items: { type: "integer" } },
      multiSelect: { type: "boolean" },
      modelAnswer: { type: "string" },
      explanation: { type: "string" },
    },
    required: ["prompt"],
  },
};

export const CREATE_LESSON_TOOL = {
  name: "create_lesson",
  description: "Create a lesson with ordered sections containing a blocks array. Use {type:'markdown',body} for lesson content and {type:'question',questionKind:'mcq'|'essay',prompt,...} for embedded questions. MCQs require 2-8 options, an explanation, a zero-based correctIndex (single answer) or correctIndexes (multiple answers), and multiSelect:true for multiple answers; represent true/false as a two-option MCQ. Essays require a complete modelAnswer and explanation; readers see an approximate 0-5 self-check rating, not an overall lesson grade. Keep title, description, section titles, Markdown, and question data in this structured JSON shape. On the home page, only call after the user confirms the proposed lesson; on the lesson editor, only call after confirmation before replacing existing lesson content. An explicit /create-lesson command is confirmation.",
  input_schema: {
    type: "object",
    properties: {
      title: { type: "string" },
      description: { type: "string" },
      sections: {
        type: "array",
        items: {
          type: "object",
          properties: {
            title: { type: "string" },
            content: { type: "string" },
            defaultHidden: { type: "boolean" },
            blocks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string", enum: ["markdown", "question"] },
                  body: { type: "string" },
                  questionKind: { type: "string", enum: ["mcq", "essay"] },
                  prompt: { type: "string" },
                  options: { type: "array", items: { type: "string" } },
                  correctIndex: { type: "integer", description: "Zero-based index of the correct option for a single-answer MCQ." },
                  correctIndexes: { type: "array", items: { type: "integer" }, description: "Zero-based indexes of all correct options for a multi-select MCQ." },
                  multiSelect: { type: "boolean" },
                  modelAnswer: { type: "string" },
                  explanation: { type: "string" },
                },
              },
            },
          },
          required: ["title", "blocks"],
        },
      },
    },
    required: ["title", "sections"],
  },
};

export const ADD_LESSON_SECTION_TOOL = {
  name: "add_lesson_section",
  description: "Append one section to the lesson currently open in the lesson editor. The section content is Markdown. Only call after the creator confirms the proposed section; an explicit /add-section command is confirmation.",
  input_schema: {
    type: "object",
    properties: {
      title: { type: "string" },
      content: { type: "string" },
    },
    required: ["title", "content"],
  },
};

// ── Notebook page tools (executed client-side by notebook-agent.js) ─────────
// Cells are addressed by their 1-based number as shown in the notebook context the
// page sends along; the page re-validates everything against the shared content rules.
const NOTEBOOK_CHALLENGE_SCHEMA = {
  type: "object",
  description: "Turns a code cell into a graded coding challenge. Grading compares what the program PRINTS (stdout) with expectedOutput, never the code text. The cell's source is the learner's starter code.",
  properties: {
    expectedOutput: { type: "string", description: "Exact text the correct program prints. For matchMode=regex: a regular expression matching the whole output." },
    matchMode: { type: "string", enum: ["trimmed", "exact", "numeric", "regex"], description: "Default trimmed (ignores CRLF, trailing spaces per line, trailing blank lines). numeric: numbers within tolerance, words exact." },
    tolerance: { type: "number", description: "numeric mode only (default 1e-6)." },
    testStdin: { type: "string", description: "C++ notebooks only: input fed to cin when graded." },
    hint: { type: "string" },
    solution: { type: "string", description: "Optional model solution CODE the learner can reveal." },
  },
  required: ["expectedOutput"],
};

export const NOTEBOOK_ADD_CELL_TOOL = {
  name: "notebook_add_cell",
  description: "Insert one cell into the notebook currently open. type 'markdown' for explanations (Markdown, math in LaTeX) or 'code' for runnable code in the notebook's language. Use position to insert before an existing cell number; omit it to append at the end. Only call after the user confirmed, unless they used an explicit slash command.",
  input_schema: {
    type: "object",
    properties: {
      type: { type: "string", enum: ["markdown", "code"] },
      source: { type: "string", description: "Cell text or code." },
      position: { type: "integer", description: "1-based cell number the new cell is inserted BEFORE. Omit to append." },
      challenge: NOTEBOOK_CHALLENGE_SCHEMA,
    },
    required: ["type", "source"],
  },
};

export const NOTEBOOK_EDIT_CELL_TOOL = {
  name: "notebook_edit_cell",
  description: "Replace the content of an existing cell (fix a bug, improve code, rewrite an explanation). Give the cell number exactly as listed in the notebook context, and the COMPLETE new source (not a diff). Optionally set or remove its challenge. Only call after the user confirmed, unless they used an explicit slash command.",
  input_schema: {
    type: "object",
    properties: {
      cell: { type: "integer", description: "1-based cell number." },
      source: { type: "string", description: "Complete new source for the cell." },
      challenge: { ...NOTEBOOK_CHALLENGE_SCHEMA, description: NOTEBOOK_CHALLENGE_SCHEMA.description + " Omit to leave the cell's challenge unchanged." },
      removeChallenge: { type: "boolean", description: "true to turn a challenge cell back into an ordinary code cell." },
    },
    required: ["cell"],
  },
};

export const NOTEBOOK_DELETE_CELL_TOOL = {
  name: "notebook_delete_cell",
  description: "Delete one cell from the open notebook by its 1-based number. ALWAYS show which cell will be deleted and get explicit confirmation first, unless the user used the explicit /delete-cell command naming the cell.",
  input_schema: {
    type: "object",
    properties: { cell: { type: "integer", description: "1-based cell number." } },
    required: ["cell"],
  },
};

export const NOTEBOOK_RUN_CELL_TOOL = {
  name: "notebook_run_cell",
  description: "Run one code cell of the open notebook (earlier cells replay automatically where the language needs it) and report what it printed. Use it to check a fix or a challenge. Safe: it only executes code already in the notebook.",
  input_schema: {
    type: "object",
    properties: { cell: { type: "integer", description: "1-based cell number of a code cell." } },
    required: ["cell"],
  },
};
