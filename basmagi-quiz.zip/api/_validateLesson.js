// =============================================================================
// api/_validateLesson.js
// Validates and sanitizes a lesson's `content` jsonb payload (the
// {sections: [{id, title, defaultHidden, blocks}]} shape defined by
// public/src/features/lesson/lesson-schema.js's normalizeLessonContent()
// — see docs/plans/lessons-feature-plan.md's Phase 2 step 1 for the shape
// and the ⚠️ on keeping onWrong/onCorrect to a single revealSection target).
//
// Mirrors _validateQuiz.js's whitelist-based approach (unknown keys are
// REJECTED, not stripped) and its overall shape (a MAX_SIZE_BYTES cap, one
// exported validate function that throws Error(message) on the first
// problem found, called from api/admin.js's create-lesson/update-lesson
// action handlers before any Supabase write).
// =============================================================================

import { LIMITS, checkLesson, formatIssueList, isBadSource } from "../scripts/lib/content-rules.js";

const MAX_SIZE_BYTES = 200_000; // lessons carry more prose than a quiz; generous but bounded
const MAX_SECTIONS = 60;
const MAX_BLOCKS_PER_SECTION = LIMITS.blocksPerSection; // shared with the editor + MCP
const MAX_TITLE_LENGTH = 200;
const MAX_MARKDOWN_LENGTH = 20_000;
const MAX_OPTIONS = 8;
const MAX_DESCRIPTION_LENGTH = 1200;
const MAX_SOURCE_LENGTH = 500;

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Notebook / folder / course link-out embeds: id field + Arabic noun per type.
const EMBED_REF_FIELDS = {
    "notebook-reference": { field: "notebookId", noun: "الدفتر" },
    "folder-reference": { field: "folderId", noun: "المجلد" },
    "course-reference": { field: "courseId", noun: "المادة" },
};

const ALLOWED_SECTION_KEYS = new Set(["id", "title", "defaultHidden", "blocks"]);
const ALLOWED_BLOCK_KEYS_BY_TYPE = {
    // `id` / `_localId` are editor bookkeeping that legitimately ride along on
    // any block (local drafts, exported lessons). They are tolerated here and
    // dropped below — each branch rebuilds a clean block from known fields only.
    markdown: new Set(["type", "body", "id", "_localId"]),
    media: new Set(["type", "url", "kind", "alt", "id", "_localId"]),
    quizRef: new Set(["type", "quizId", "title", "id", "_localId"]),
    "lesson-reference": new Set(["type", "lessonId", "title", "slug", "id", "_localId"]),
    "notebook-reference": new Set(["type", "notebookId", "title", "id", "_localId"]),
    "folder-reference": new Set(["type", "folderId", "title", "id", "_localId"]),
    "course-reference": new Set(["type", "courseId", "title", "id", "_localId"]),
    question: new Set([
        "type",
        "id",
        "prompt",
        "questionKind",
        "options",
        "correctIndex",
        "correctIndexes",
        "multiSelect",
        "modelAnswer",
        "explanation",
        "onWrong",
        "onCorrect",
        "_localId",
    ]),
};

function isPlainObject(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v);
}

function assertNoExtraKeys(obj, allowed, label) {
    for (const key of Object.keys(obj)) {
        if (!allowed.has(key)) {
            throw new Error(`حقل غير مسموح به في ${label}: "${key}".`);
        }
    }
}

function validateRevealRule(rule, sectionIds, label) {
    if (rule === undefined || rule === null) return undefined;
    if (!isPlainObject(rule)) throw new Error(`${label} يجب أن يكون كائناً.`);
    assertNoExtraKeys(rule, new Set(["revealSection"]), label);
    const target = rule.revealSection;
    if (target === undefined || target === null) return undefined;
    if (typeof target !== "string" || !target.trim()) {
        throw new Error(`${label}.revealSection يجب أن يكون نصاً.`);
    }
    // Kept to a single-step reveal rule by construction (see the plan's
    // Phase 2 step 1 ⚠️) — no chained targets, so this is just "does the
    // named section exist" rather than any graph validation.
    if (!sectionIds.has(target)) {
        throw new Error(`${label}.revealSection يشير إلى قسم غير موجود: "${target}".`);
    }
    return { revealSection: target };
}

function validateBlock(block, index, sectionIds) {
    if (!isPlainObject(block)) throw new Error(`العنصر رقم ${index + 1} يجب أن يكون كائناً.`);
    const type = block.type;
    const allowedKeys = ALLOWED_BLOCK_KEYS_BY_TYPE[type];
    if (!allowedKeys) {
        throw new Error(`نوع عنصر غير معروف في العنصر رقم ${index + 1}: "${type}".`);
    }
    assertNoExtraKeys(block, allowedKeys, `العنصر رقم ${index + 1}`);

    if (type === "markdown") {
        const body = typeof block.body === "string" ? block.body : "";
        if (body.length > MAX_MARKDOWN_LENGTH) {
            throw new Error(`نص العنصر رقم ${index + 1} طويل جداً (الحد الأقصى ${MAX_MARKDOWN_LENGTH} حرف).`);
        }
        return { type: "markdown", body };
    }

    if (type === "media") {
        const url = typeof block.url === "string" ? block.url.trim() : "";
        if (!url) throw new Error(`رابط الوسائط مفقود في العنصر رقم ${index + 1}.`);
        const kind = ["image", "audio", "video"].includes(block.kind) ? block.kind : "image";
        const clean = { type: "media", url, kind };
        if (typeof block.alt === "string" && block.alt) clean.alt = block.alt.slice(0, MAX_TITLE_LENGTH);
        return clean;
    }

    if (type === "quizRef") {
        const quizId = typeof block.quizId === "string" ? block.quizId.trim() : "";
        if (!quizId) throw new Error(`معرف الامتحان المرتبط مفقود في العنصر رقم ${index + 1}.`);
        const clean = { type: "quizRef", quizId };
        if (typeof block.title === "string" && block.title) clean.title = block.title.slice(0, MAX_TITLE_LENGTH);
        return clean;
    }

    if (type === "lesson-reference") {
        const lessonId = typeof block.lessonId === "string" ? block.lessonId.trim() : "";
        if (!lessonId) throw new Error(`معرف الدرس المرتبط مفقود في العنصر رقم ${index + 1}.`);
        if (!UUID_RE.test(lessonId)) {
            throw new Error(`معرف الدرس المرتبط يجب أن يكون UUID عند نشر الدرس (العنصر رقم ${index + 1}).`);
        }
        const clean = { type: "lesson-reference", lessonId };
        if (typeof block.title === "string" && block.title) clean.title = block.title.slice(0, MAX_TITLE_LENGTH);
        if (typeof block.slug === "string" && block.slug) clean.slug = block.slug.slice(0, MAX_TITLE_LENGTH);
        return clean;
    }

    if (EMBED_REF_FIELDS[type]) {
        const { field, noun } = EMBED_REF_FIELDS[type];
        const refId = typeof block[field] === "string" ? block[field].trim() : "";
        if (!refId) throw new Error(`معرف ${noun} المرتبط مفقود في العنصر رقم ${index + 1}.`);
        if (!UUID_RE.test(refId)) {
            throw new Error(`معرف ${noun} المرتبط يجب أن يكون UUID عند نشر الدرس (العنصر رقم ${index + 1}).`);
        }
        const clean = { type, [field]: refId };
        if (typeof block.title === "string" && block.title) clean.title = block.title.slice(0, MAX_TITLE_LENGTH);
        return clean;
    }

    // type === "question"
    const id = typeof block.id === "string" ? block.id.trim() : "";
    if (!id) throw new Error(`معرف السؤال مفقود في العنصر رقم ${index + 1}.`);
    const prompt = typeof block.prompt === "string" ? block.prompt : "";
    if (!prompt.trim()) throw new Error(`نص السؤال مطلوب في العنصر رقم ${index + 1}.`);
    if (prompt.length > MAX_MARKDOWN_LENGTH) {
        throw new Error(`نص السؤال طويل جداً في العنصر رقم ${index + 1}.`);
    }

    // `questionKind` distinguishes multiple-choice ("mcq", the historical
    // default when the field is omitted — keeps every pre-existing lesson
    // row valid without a migration) from a free-text essay question. Kept
    // as a separate discriminant rather than inferring essay-ness from
    // "options is absent" so a future third kind doesn't have to hijack an
    // absence check the way isEssayQuestion() in rate-answers.js infers it
    // for quizzes (see that file's header comment on why quizzes use a
    // sentinel answer value instead — lessons don't share that constraint
    // since this whitelist already rejects unknown shapes outright).
    const questionKind = block.questionKind === "essay" ? "essay" : "mcq";

    if (questionKind === "essay") {
        const modelAnswer = typeof block.modelAnswer === "string" ? block.modelAnswer : "";
        if (!modelAnswer.trim()) {
            throw new Error(`الإجابة النموذجية مطلوبة للسؤال المقالي في العنصر رقم ${index + 1}.`);
        }
        if (modelAnswer.length > MAX_MARKDOWN_LENGTH) {
            throw new Error(`الإجابة النموذجية طويلة جداً في العنصر رقم ${index + 1}.`);
        }
        const clean = {
            type: "question",
            id,
            questionKind: "essay",
            prompt,
            modelAnswer,
        };
        if (typeof block.explanation === "string" && block.explanation) {
            clean.explanation = block.explanation.slice(0, MAX_MARKDOWN_LENGTH);
        }
        // Essay questions are never auto-graded server-side (client-side
        // text-similarity only, same as quiz essay questions — see
        // rate-answers.js's gradeEssay()), so "wrong"/"correct" adaptive
        // reveal has no reliable signal to key off for this kind. Reject
        // rather than silently drop, so an author who tried to set one
        // finds out immediately instead of the rule quietly not firing at
        // lesson-view time.
        if (block.onWrong !== undefined || block.onCorrect !== undefined) {
            throw new Error(`لا يمكن استخدام قواعد الكشف الشرطي مع الأسئلة المقالية (العنصر رقم ${index + 1}).`);
        }
        return clean;
    }

    const options = Array.isArray(block.options) ? block.options : [];
    if (options.length < 2) throw new Error(`السؤال في العنصر رقم ${index + 1} يحتاج خيارين على الأقل.`);
    if (options.length > MAX_OPTIONS) throw new Error(`عدد كبير جداً من الخيارات في العنصر رقم ${index + 1}.`);
    const cleanOptions = options.map((opt, i) => {
        const text = typeof opt === "string" ? opt : "";
        if (!text.trim()) throw new Error(`الخيار رقم ${i + 1} فارغ في العنصر رقم ${index + 1}.`);
        return text;
    });
    const multiSelect = Boolean(block.multiSelect);
    const rawCorrectIndexes = multiSelect
        ? block.correctIndexes
        : [block.correctIndex];
    const correctIndexes = Array.isArray(rawCorrectIndexes) ? rawCorrectIndexes.map(Number) : [];
    if (!correctIndexes.length || correctIndexes.some((i) => !Number.isInteger(i) || i < 0 || i >= cleanOptions.length) || new Set(correctIndexes).size !== correctIndexes.length) {
        throw new Error(`فهرس الإجابة الصحيحة غير صالح في العنصر رقم ${index + 1}.`);
    }
    const clean = {
        type: "question",
        id,
        questionKind: "mcq",
        prompt,
        options: cleanOptions,
        correctIndex: correctIndexes[0], // compatibility with existing readers
        ...(multiSelect && { multiSelect: true, correctIndexes }),
    };
    if (typeof block.explanation === "string" && block.explanation) {
        clean.explanation = block.explanation.slice(0, MAX_MARKDOWN_LENGTH);
    }
    const onWrong = validateRevealRule(block.onWrong, sectionIds, `العنصر رقم ${index + 1}.onWrong`);
    if (onWrong) clean.onWrong = onWrong;
    const onCorrect = validateRevealRule(block.onCorrect, sectionIds, `العنصر رقم ${index + 1}.onCorrect`);
    if (onCorrect) clean.onCorrect = onCorrect;
    return clean;
}


export function validateLessonDescription(description) {
    if (description === undefined || description === null || description === "") return "";
    if (typeof description !== "string") throw new Error("وصف الدرس يجب أن يكون نصاً.");
    const clean = description.trim();
    if (clean.length > MAX_DESCRIPTION_LENGTH) {
        throw new Error(`وصف الدرس طويل جداً (الحد الأقصى ${MAX_DESCRIPTION_LENGTH} حرف).`);
    }
    return clean;
}


export function validateLessonSource(source) {
    if (source === undefined || source === null || source === "") return "";
    if (typeof source !== "string") throw new Error("مصدر الدرس يجب أن يكون نصاً.");
    const clean = source.trim();
    if (clean.length > MAX_SOURCE_LENGTH) {
        throw new Error(`مصدر الدرس طويل جداً (الحد الأقصى ${MAX_SOURCE_LENGTH} حرف).`);
    }
    if (isBadSource(clean)) {
        throw new Error("مصدر الدرس يجب أن يكون رابطاً كاملاً يبدأ بـ https:// ولا شيء غيره — أو اتركه فارغاً.");
    }
    return clean;
}

export function validateLessonPasswordHash(passwordHash) {
    if (passwordHash === undefined || passwordHash === null || passwordHash === "") return "";
    if (typeof passwordHash !== "string" || !/^[0-9a-f]{64}$/i.test(passwordHash)) {
        throw new Error("كلمة مرور الدرس غير صالحة.");
    }
    return passwordHash.toLowerCase();
}

export function collectLessonReferenceIds(content) {
    const ids = new Set();
    for (const section of content?.sections || []) {
        for (const block of section?.blocks || []) {
            if (block?.type === "lesson-reference" && block.lessonId) ids.add(String(block.lessonId));
        }
    }
    return [...ids];
}

/**
 * Validates a lesson's `content` payload, returning a cleaned/whitelisted
 * copy on success. Throws Error(message) — a user-facing Arabic string,
 * same convention as _validateQuiz.js — on the first problem found.
 *
 * @param {unknown} content - the {sections: [...]} shape from the client
 * @returns {{sections: Array}}
 */
export function validateLessonContent(content) {
    const size = Buffer.byteLength(JSON.stringify(content ?? {}), "utf8");
    if (size > MAX_SIZE_BYTES) {
        throw new Error(`حجم محتوى الدرس كبير جداً (الحد الأقصى ${Math.round(MAX_SIZE_BYTES / 1000)} كيلوبايت).`);
    }

    if (!isPlainObject(content)) throw new Error("محتوى الدرس يجب أن يكون كائناً.");
    assertNoExtraKeys(content, new Set(["sections"]), "محتوى الدرس");

    const sections = Array.isArray(content.sections) ? content.sections : [];
    if (sections.length === 0) throw new Error("الدرس يحتاج قسماً واحداً على الأقل.");
    if (sections.length > MAX_SECTIONS) throw new Error(`عدد كبير جداً من الأقسام (الحد الأقصى ${MAX_SECTIONS}).`);

    // Content rules — the SAME checks the editor page and the MCP server run
    // (scripts/lib/content-rules.js is a synced copy of public/src/shared/content-rules.js).
    // All problems are reported together instead of one at a time.
    const shared = checkLesson(
        {
            sections: sections.map((section) => ({
                ...(isPlainObject(section) ? section : {}),
                blocks: (Array.isArray(section?.blocks) ? section.blocks : []).map((block) =>
                    block?.type === "question" && block.questionKind !== "essay"
                        ? { ...block, correctIndexes: block.multiSelect ? block.correctIndexes : [block.correctIndex] }
                        : block),
            })),
        },
        { publish: true, sectionsOnly: true },
    );
    if (shared.errors.length) {
        throw new Error(`الدرس يحتوي على ${shared.errors.length} مشكلة:\n${formatIssueList(shared.errors)}`);
    }

    // Every question id and section id must be unique across the WHOLE
    // lesson (not just within one section) — adaptive-reveal rules and the
    // reader's local progress state both key off these ids flatly (see
    // lesson-schema.js's collectQuestionBlocks/resolveRevealedSections), so
    // a duplicate anywhere would let one question's answer silently affect
    // another's reveal state.
    const sectionIds = new Set();
    for (const section of sections) {
        if (!isPlainObject(section)) throw new Error("كل قسم يجب أن يكون كائناً.");
        const id = typeof section.id === "string" ? section.id.trim() : "";
        if (!id) throw new Error("كل قسم يحتاج معرفاً (id).");
        if (sectionIds.has(id)) throw new Error(`معرف قسم مكرر: "${id}".`);
        sectionIds.add(id);
    }

    const questionIds = new Set();
    const cleanSections = sections.map((section, sIndex) => {
        assertNoExtraKeys(section, ALLOWED_SECTION_KEYS, `القسم رقم ${sIndex + 1}`);
        const title = typeof section.title === "string" ? section.title.slice(0, MAX_TITLE_LENGTH) : "";
        const defaultHidden = Boolean(section.defaultHidden);
        const blocks = Array.isArray(section.blocks) ? section.blocks : [];
        if (blocks.length > MAX_BLOCKS_PER_SECTION) {
            throw new Error(`عدد كبير جداً من العناصر في القسم رقم ${sIndex + 1} (الحد الأقصى ${MAX_BLOCKS_PER_SECTION}).`);
        }
        const cleanBlocks = blocks.map((block, bIndex) => {
            const clean = validateBlock(block, bIndex, sectionIds);
            if (clean.type === "question") {
                if (questionIds.has(clean.id)) throw new Error(`معرف سؤال مكرر: "${clean.id}".`);
                questionIds.add(clean.id);
            }
            return clean;
        });
        return {
            id: section.id.trim(),
            title,
            defaultHidden,
            blocks: cleanBlocks,
        };
    });

    return { sections: cleanSections };
}
