// public/src/features/home/user-quizzes-folders.js
import { getFolderContentsCount, formatFolderAndQuizCount } from "./folder-counts.js";
import { getFromStorage, setInStorage } from "../../shared/storage-helpers.js";
import { _prompt, _confirm, _confirmTyped, showNotification } from "../../components/notifications/notifications.js";
import { isAdminAuthenticated } from "../../shared/adminAuth.js";
import { renderUserQuizzesView, updateBulkActionBar } from "./user-quizzes-view.js";
import { getSelectedUserQuizzes } from "./app-state.js";
import { toSlug } from "./slug-utils.js";
import { buildUserQuizEntry, qz } from "./quiz-schema.js";
import { getSubjectIcon } from "./subject-icons.js";
import { MORE_DOTS_ICON_SVG } from "./icons.js";
import { openMoveToDialogWithSource } from "./move-to-dialog.js";
import { getTrashItemCount } from "./user-quizzes-trash.js";
import { closeAllItemDropdownMenus } from "./item-dropdown-menu.js";

// Current navigation state
export let currentFolderId = null;
let folderPathStack = [];

/**
 * Safe read of the `user_quizzes` tree. Every caller in this file used to
 * call `JSON.parse(getFromStorage("user_quizzes", "[]"))` directly and
 * unguarded — if the stored value was ever malformed (a partially-written
 * value from an earlier failed save, or external tampering), JSON.parse
 * throws synchronously and *uncaught*, silently aborting whichever
 * delete/rename/move function was mid-call with no error shown to the user
 * and no re-render. That reads exactly like "nothing happens when I click
 * حذف/تغيير العنوان/نقل إلى" — this is one of two fixes made for that report
 * (see saveUserQuizzes below for the other). Falls back to an empty tree
 * and warns via showNotification rather than crashing the calling action.
 * @returns {Array}
 */
function readUserQuizzes() {
  try {
    const parsed = JSON.parse(getFromStorage("user_quizzes", "[]"));
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error("[user-quizzes-folders] Corrupt user_quizzes data:", err);
    showNotification(
      "خطأ في البيانات",
      "تعذّرت قراءة بيانات محتواي المحفوظة محلياً. قد تكون تالفة.",
      "warning",
    );
    return [];
  }
}

/**
 * Safe write of the `user_quizzes` tree, surfacing a failed save instead of
 * silently discarding it. setInStorage() already returns a boolean and logs
 * to console on failure, but every caller in this file used to ignore that
 * return value entirely — a full/blocked localStorage write (quota, private
 * browsing restrictions, etc.) would leave the in-memory change reflected
 * in the UI (since callers re-render right after saving) while the
 * underlying data silently never persisted, then reverted on next load.
 * Returns the same boolean so a caller that needs to bail out before
 * re-rendering can (see deleteFolder/renameItem/moveItemsToFolder below).
 * @param {Array} userQuizzes
 * @returns {boolean} true if the write succeeded
 */
function saveUserQuizzes(userQuizzes) {
  const ok = setInStorage("user_quizzes", JSON.stringify(userQuizzes));
  if (!ok) {
    showNotification(
      "تعذّر الحفظ",
      "تعذّر حفظ التغيير محلياً. قد تكون مساحة التخزين ممتلئة.",
      "warning",
    );
  }
  return ok;
}

export function getChildren(userQuizzes, parentId) {
  return userQuizzes.filter((q) =>
    (q.meta?.parentId || null) === parentId &&
    q.meta?.type !== "draft" && q.meta?.type !== "draft-lesson",
  );
}

/**
 * Walks a row's full parentId chain up to a root (parentId === null) and
 * returns true only if every ancestor along the way actually exists in
 * `userQuizzes`. A row one level below a missing parent is caught by a
 * simple "does my direct parent exist" check, but a row whose *grandparent*
 * is missing (its direct parent still exists as a row, but that parent's
 * own parent doesn't) would incorrectly pass a one-level check — this walks
 * the whole chain, the same way isDescendant() below already does for the
 * unrelated "am I inside myself" check, so both share the same notion of
 * what "reachable from root" means.
 *
 * Used by:
 *  - pruneOrphanedRows() (course-count.js) — so the "محتواي" card's
 *    counts only include genuinely reachable rows.
 *  - hasSameLevelCollision() below — so a same-name/type/level clash
 *    against a row that's technically still in storage but unreachable
 *    (a leftover from an old bug, or one being cleaned up) doesn't block a
 *    legitimate new copy/create/rename/move.
 *
 * @param {object} row - a user_quizzes entry
 * @param {Array} userQuizzes
 * @param {Map<string, object>} [byId] - optional id→row lookup to reuse
 *   across many calls in the same pass instead of re-scanning the array
 *   each time (collision checks and bulk operations call this per-row).
 * @returns {boolean}
 */
export function isRowReachable(row, userQuizzes, byId = null) {
  const lookup =
    byId ||
    new Map(
      userQuizzes.map((q) => [q.id || q.meta?.id, q]).filter(([id]) => id),
    );
  const seen = new Set();
  let current = row;
  while (current) {
    const parentId = current.meta?.parentId || null;
    if (parentId === null) return true;
    if (seen.has(parentId)) return false; // cyclic parentId — treat as unreachable, not an infinite loop
    seen.add(parentId);
    current = lookup.get(parentId);
    if (!current) return false;
  }
  return true;
}

/**
 * The one rule the whole "محتواي" section must follow, enforced
 * identically everywhere a new name can be introduced at a level: create
 * (createFolderOrCourseNamed), rename (renameItem), move
 * (moveItemsToFolder), single-quiz copy (copyQuizToUserQuizzes), and
 * tree copy (copyCategoryTreeToUserQuizzes's copyNode, every node type).
 *
 * "No two elements of the same type AND same name may share the same
 * parentId." Different levels are always allowed regardless of name reuse;
 * different types at the same level with the same name are always allowed
 * too (a folder and a course can both be named "math" side by side) — and
 * by the same rule a lesson and a quiz may share a name at one level.
 *
 * `type` is compared as an opaque string against each row's
 * `meta.type` (defaulting to "quiz" for plain quiz rows that carry none),
 * so the recognized set — "quiz" | "lesson" | "folder" | "course" — grows
 * additively: "lesson" needed no signature or logic change here. Every
 * existing call site passes its own explicit type ("quiz", or a variable
 * already carrying the row's own type), so none of them can accidentally
 * match a lesson row.
 *
 * Unreachable/orphaned rows (see isRowReachable above) never count as a
 * collision — a leftover row from an old bug shouldn't block a legitimate
 * new item from taking that name.
 *
 * @param {Array} userQuizzes - checked as given, so a caller that has
 *   already `.push()`-ed newly copied siblings earlier in the same pass
 *   (copyCategoryTreeToUserQuizzes copying two subtrees in one call) gets
 *   those included automatically — pass the same live array reference
 *   you're building, not a stale snapshot.
 * @param {{type: "quiz"|"lesson"|"folder"|"course", title: string, parentId: string|null, excludeId?: string}} candidate
 * @returns {boolean} true if placing `candidate` would collide
 */
export function hasSameLevelCollision(userQuizzes, { type, title, parentId, excludeId = null }) {
  const normalizedTitle = (title || "").trim().toLowerCase();
  const normalizedParentId = parentId || null;
  const byId = new Map(
    userQuizzes.map((q) => [q.id || q.meta?.id, q]).filter(([id]) => id),
  );
  return userQuizzes.some((q) => {
    const qId = q.id || q.meta?.id;
    if (excludeId && qId === excludeId) return false;
    const qType = q.meta?.type || "quiz"; // plain quiz rows carry no meta.type
    if (qType !== (type || "quiz")) return false;
    if ((q.meta?.parentId || null) !== normalizedParentId) return false;
    if ((q.meta?.title || "").trim().toLowerCase() !== normalizedTitle) return false;
    return isRowReachable(q, userQuizzes, byId);
  });
}

/**
 * Courses are always top-level — they never live inside another folder or
 * course, and nothing may be moved/dropped/dragged into a course except
 * directly from the root. This is the single guard every move/drop/create
 * path below funnels through, so the rule can't drift out of sync between
 * drag-and-drop, the move-to dialog, the context menu, and the breadcrumb
 * drop targets the way separate ad-hoc checks would.
 * @param {object[]} userQuizzes
 * @param {string} itemId - the item being placed somewhere
 * @param {string|null} targetFolderId - where it would be placed (null = root)
 * @returns {{allowed: boolean, reason?: string}}
 */
export function canPlaceItem(userQuizzes, itemId, targetFolderId) {
  const item = userQuizzes.find((q) => (q.id || q.meta?.id) === itemId);
  const isCourse = item?.meta?.type === "course";

  // A course may only ever sit at the root — moving it anywhere else
  // (including into another course) is never allowed.
  if (isCourse && targetFolderId !== null) {
    return { allowed: false, reason: "المواد تبقى في المستوى الرئيسي دائماً ولا يمكن نقلها داخل مجلد أو مادة أخرى." };
  }

  // Nothing may be placed *inside* a course except directly (a course can
  // hold folders/quizzes as children — that's normal); this only blocks
  // placing a course inside a course, already covered above, and moving
  // an item into itself/its own descendant (checked by the caller via
  // isDescendant since that needs the full ancestry walk).
  return { allowed: true };
}

export function getCurrentFolderPathStack() {
  return folderPathStack;
}

/** The id one level up from currentFolderId (null = root), based on
 * folderPathStack. Used by the "نقل إلى الخارج" (move out) shortcut. */
function pathStackParentId() {
  if (folderPathStack.length <= 1) return null;
  return folderPathStack[folderPathStack.length - 2].id;
}

/**
 * "نقل إلى الخارج" — moves one item up a level (out of currentFolderId).
 * Shared by the right-click menu and the ⋮ dropdown so both behave the same.
 * No-op at the root, where there is nothing to move out of.
 */
export function moveItemOutOfFolder(itemId) {
  if (currentFolderId === null) return;
  const { moved } = moveItemsToFolder([itemId], pathStackParentId());
  if (moved > 0) showNotification("تم النقل", "تم نقل العنصر خارج المجلد الحالي.", "success");
  renderUserQuizzesView();
}

export function navigateToFolder(folderId, folderTitle) {
  if (folderId === null) {
    currentFolderId = null;
    folderPathStack = [];
  } else {
    currentFolderId = folderId;
    const existingIndex = folderPathStack.findIndex((f) => f.id === folderId);
    if (existingIndex !== -1) {
      folderPathStack = folderPathStack.slice(0, existingIndex + 1);
    } else {
      folderPathStack.push({ id: folderId, title: folderTitle });
    }
  }
  renderUserQuizzesView();
}

/**
 * Build the URL hash for the current folder path stack.
 * Root level = "#my-content", nested = "#my-content/slug1/slug2"
 */
export function buildFolderPath() {
  if (folderPathStack.length === 0) return "/my-content";
  const slugs = folderPathStack.map((f) => toSlug(f.title));
  return "/my-content/" + slugs.join("/");
}

export function buildFolderHash() {
  return buildFolderPath();
}

function _legacyBuildFolderHash() {
  if (folderPathStack.length === 0) return "#my-content";
  const slugs = folderPathStack.map((f) => toSlug(f.title));
  return "#my-content/" + slugs.join("/");
}

/**
 * Restore folder state without triggering a new renderUserQuizzesView().
 * Called by restoreViewFromURL() so the URL → state sync doesn't cause
 * double renders or phantom pushState entries.
 */
export function setFolderState(stack, folderId) {
  folderPathStack = stack;
  currentFolderId = folderId;
}

export async function createNewFolderOrCourse(type = "folder") {
  const name = await _prompt(`أدخل اسم ال${type === "course" ? "مادة" : "مجلد"}:`);
  if (!name || !name.trim()) return;
  const result = createFolderOrCourseNamed(type, name.trim(), currentFolderId);
  if (!result.ok) {
    showNotification("تعذر الإنشاء", result.reason, "warning");
    return;
  }
  renderUserQuizzesView();
}

/**
 * Non-interactive counterpart to createNewFolderOrCourse — takes the name
 * and parent directly instead of prompting, so callers that already have
 * structured input (the AI agent's create_folder/create_course tools; a
 * future bulk-import path, etc.) don't need to fake a prompt() response.
 * Shares the exact same duplicate-name guard and record shape as the
 * interactive path so both stay in sync.
 * @param {"folder"|"course"} type
 * @param {string} name
 * @param {string|null} parentId
 * @returns {{ok: boolean, id?: string, reason?: string}}
 */
export function createFolderOrCourseNamed(type, name, parentId) {
  const trimmedName = (name || "").trim();
  if (!trimmedName) return { ok: false, reason: "الاسم مطلوب." };

  // Courses are top-level only (see canPlaceItem) — reject up front with a
  // clear reason rather than silently creating it at root regardless of
  // what parentId was requested, which would surprise a caller that
  // expected the folder they asked for.
  if (type === "course" && parentId !== null) {
    return { ok: false, reason: "المواد تبقى في المستوى الرئيسي دائماً ولا يمكن إنشاؤها داخل مجلد." };
  }

  const userQuizzes = readUserQuizzes();

  if (hasSameLevelCollision(userQuizzes, { type, title: trimmedName, parentId: parentId || null })) {
    return { ok: false, reason: "يوجد عنصر بنفس الاسم والنوع في هذا المستوى بالفعل." };
  }

  const newId = crypto.randomUUID();
  const newFolder = {
    id: newId,
    meta: {
      id: newId,
      type,
      title: trimmedName,
      parentId: parentId || null,
      createdAt: new Date().toLocaleString("en-US"),
    },
    stats: { questionCount: 0, questionTypes: [] },
    questions: [],
  };
  userQuizzes.push(newFolder);
  if (!saveUserQuizzes(userQuizzes)) {
    return { ok: false, reason: "تعذّر حفظ العنصر الجديد محلياً." };
  }
  return { ok: true, id: newFolder.id };
}

/**
 * Resolves a folder/course by title (case-insensitive) rather than id, so
 * callers working from human-readable names (the AI agent only ever sees
 * titles, never internal UUIDs — see the folder-tree contextPrompt built
 * in user-quizzes-view.js) can find the right target without the caller
 * needing to already know the id. When `parentTitle` is omitted, matches
 * anywhere in the tree; multiple same-named folders at different depths is
 * an accepted ambiguity here (returns the first match) since duplicate
 * names are only prevented within a single parent, not tree-wide.
 * @param {string} title
 * @param {string|null} [parentTitle] - restrict the match to children of
 *   the folder/course with this title (also resolved by name)
 * @returns {{id: string, type: string}|null}
 */
export function findFolderByName(title, parentTitle = null) {
  const userQuizzes = readUserQuizzes();
  const normalize = (s) => (s || "").trim().toLowerCase();

  let parentId = null;
  if (parentTitle) {
    const parent = userQuizzes.find(
      (q) => (q.meta?.type === "folder" || q.meta?.type === "course") &&
        normalize(q.meta?.title) === normalize(parentTitle),
    );
    if (!parent) return null;
    parentId = parent.id || parent.meta?.id;
  }

  const match = userQuizzes.find((q) => {
    if (q.meta?.type !== "folder" && q.meta?.type !== "course") return false;
    if (normalize(q.meta?.title) !== normalize(title)) return false;
    if (parentTitle && (q.meta?.parentId || null) !== parentId) return false;
    return true;
  });
  if (!match) return null;
  return { id: match.id || match.meta?.id, type: match.meta.type };
}

export async function renameItem(itemId, currentTitle) {
  const newName = await _prompt("أدخل الاسم الجديد:", currentTitle, { dismissOnBackdrop: false });
  if (!newName || !newName.trim()) return;

  const userQuizzes = readUserQuizzes();
  const item = userQuizzes.find((q) => q.id === itemId || q.meta?.id === itemId);
  if (!item || !item.meta) return;

  const trimmedName = newName.trim();
  const parentId = item.meta?.parentId || null;
  const itemType = item.meta?.type || "quiz";

  if (hasSameLevelCollision(userQuizzes, { type: itemType, title: trimmedName, parentId, excludeId: itemId })) {
    showNotification("الاسم مستخدم", "يوجد عنصر بنفس الاسم والنوع في هذا المستوى. اختر اسماً مختلفاً.", "warning");
    return;
  }

  item.meta.title = trimmedName;
  if (!saveUserQuizzes(userQuizzes)) return;
  renderUserQuizzesView();
}

/**
 * Given a set of ids the user explicitly selected, expands it to also
 * include every descendant of any folder/course among them, against a given
 * userQuizzes snapshot. Shared by deleteFolder() (single item, always a
 * folder/course) and the bulk-delete action in user-quizzes-view.js (a mixed
 * selection that may or may not include folders/courses).
 *
 * @param {Set<string>} selectedIds
 * @param {Array} userQuizzes
 * @returns {Set<string>}
 */
export function expandSelectionWithDescendants(selectedIds, userQuizzes) {
  const idsToDelete = new Set(selectedIds);
  let added = true;
  while (added) {
    added = false;
    for (const q of userQuizzes) {
      const qId = q.id || q.meta?.id;
      if (q.meta?.parentId && idsToDelete.has(q.meta.parentId) && !idsToDelete.has(qId)) {
        idsToDelete.add(qId);
        added = true;
      }
    }
  }
  return idsToDelete;
}

/* Soft-deletes an item (quiz/folder/course, called from showContextMenu's
 * "حذف" for any targetType) into the local trash instead of discarding it —
 * see user-quizzes-trash.js and plan §4. Cascades to every descendant via
 * expandSelectionWithDescendants (unchanged from the old hard-delete
 * behavior) so a folder/course and everything inside it move to the trash
 * together, as one restorable/purgeable batch. */
export async function deleteFolder(folderId) {
  const userQuizzes = readUserQuizzes();
  const target = userQuizzes.find((q) => (q.id || q.meta?.id) === folderId);
  if (!target) return;

  if (!(await _confirm("سيُنقل هذا العنصر إلى سلة المهملات. هل تريد المتابعة؟"))) return;

  const idsToDelete = expandSelectionWithDescendants(new Set([folderId]), userQuizzes);
  const itemsToTrash = userQuizzes.filter(
    (q) => idsToDelete.has(q.id) || idsToDelete.has(q.meta?.id),
  );
  const newQuizzes = userQuizzes.filter((q) => !idsToDelete.has(q.id) && !idsToDelete.has(q.meta?.id));

  const { moveToTrash } = await import("./user-quizzes-trash.js");
  moveToTrash(itemsToTrash, target.meta?.title || "عنصر بلا اسم");

  if (!saveUserQuizzes(newQuizzes)) return;
  renderUserQuizzesView();

  const { refreshUserQuizzesCard } = await import("./course-count.js");
  refreshUserQuizzesCard();
}

/**
 * "حذف الكل" — wipes the entire "امتحاناتك" collection (every quiz, folder,
 * and course) in one action, unconditionally, regardless of current folder
 * or selection state.
 *
 * This exists as a deliberate escape hatch for storage bloat/orphan buildup
 * (see A6/Part D) that no automatic cleanup heuristic should attempt to fix
 * on its own — a user staring at a phantom "5000 lines in localStorage but
 * nothing renders" situation needs a way to just start over without Claude
 * (or the app) guessing which of those rows were "real" vs leftover cruft
 * from a bygone copy-tree bug. `pruneOrphanedRows`-style automatic pruning
 * only removes rows that are provably unreachable; it deliberately does NOT
 * address rows that are technically reachable yet never rendered due to an
 * unrelated view-layer bug — this button is the deliberately blunter, fully
 * manual alternative for exactly that residual case. */
export async function deleteAllUserQuizzes() {
  const confirmed = await _confirmTyped({
    message:
      "سيتم حذف كل امتحاناتك ومجلداتك نهائياً ولا يمكن التراجع عن هذا الإجراء.\nللمتابعة، اضغط \"نعم\" ثم اكتب العبارة المطلوبة في الخطوة التالية.",
    confirmPhrase: "حذف الكل",
    confirmButtonLabel: "حذف كل شيء نهائياً",
  });
  if (!confirmed) return;

  if (!saveUserQuizzes([])) return;
  // navigateToFolder(null, ...) resets to root AND calls
  // renderUserQuizzesView() itself — no need to call it again here.
  navigateToFolder(null, null);

  const { refreshUserQuizzesCard } = await import("./course-count.js");
  refreshUserQuizzesCard();

  showNotification("تم الحذف", "تم حذف كل امتحاناتك ومجلداتك.", "success");
}

// Drag and drop logic
let draggedItemId = null;

export function handleDragStart(e, itemId) {
  draggedItemId = itemId;
  e.dataTransfer.effectAllowed = "move";
  e.dataTransfer.setData("text/plain", itemId);
  e.target.style.opacity = "0.5";
}

export function handleDragEnd(e) {
  e.target.style.opacity = "1";
  draggedItemId = null;
}

export function handleDragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = "move";
  e.currentTarget.classList.add("drag-over");
}

export function handleDragLeave(e) {
  e.currentTarget.classList.remove("drag-over");
}

export function handleDrop(e, targetFolderId) {
  e.preventDefault();
  e.currentTarget.classList.remove("drag-over");
  const itemId = e.dataTransfer.getData("text/plain");
  if (!itemId || itemId === targetFolderId) return;

  // Prevent moving a folder into itself or its children
  const userQuizzes = readUserQuizzes();
  if (isDescendant(userQuizzes, itemId, targetFolderId)) {
    showNotification("خطأ", "لا يمكن نقل المجلد إلى داخله.", "./favicon.png");
    return;
  }

  // Courses are top-level only — see canPlaceItem's doc comment.
  const placement = canPlaceItem(userQuizzes, itemId, targetFolderId);
  if (!placement.allowed) {
    showNotification("لا يمكن النقل", placement.reason, "warning");
    return;
  }

  const itemIndex = userQuizzes.findIndex((q) => q.id === itemId || q.meta?.id === itemId);
  if (itemIndex === -1) return;
  if (!userQuizzes[itemIndex].meta) userQuizzes[itemIndex].meta = {};
  if ((userQuizzes[itemIndex].meta.parentId || null) === (targetFolderId || null)) return; // already there

  const item = userQuizzes[itemIndex];
  if (
    hasSameLevelCollision(userQuizzes, {
      type: item.meta?.type || "quiz",
      title: item.meta?.title || "",
      parentId: targetFolderId || null,
      excludeId: itemId,
    })
  ) {
    showNotification(
      "تعذر النقل",
      "يوجد عنصر بنفس الاسم والنوع في هذا المستوى بالفعل.",
      "warning",
    );
    return;
  }

  item.meta.parentId = targetFolderId;
  if (!saveUserQuizzes(userQuizzes)) return;
  renderUserQuizzesView();
}

function isDescendant(quizzes, parentId, checkId) {
  if (parentId === checkId) return true;
  let current = quizzes.find((q) => q.id === checkId || q.meta?.id === checkId);
  while (current && current.meta?.parentId) {
    if (current.meta.parentId === parentId) return true;
    current = quizzes.find((q) => q.id === current.meta.parentId || q.meta?.id === current.meta.parentId);
  }
  return false;
}

/**
 * Re-parent one or more items to `targetFolderId` (null = root), with the
 * same self/descendant guard handleDrop uses. Shared by the single-item
 * "نقل إلى" menu action and the bulk-move action bar button — the only
 * difference between them is how many ids get passed in.
 * @param {string[]} itemIds
 * @param {string|null} targetFolderId
 * @returns {{moved: number, blocked: number, saveFailed?: boolean}}
 */
export function moveItemsToFolder(itemIds, targetFolderId) {
  const userQuizzes = readUserQuizzes();
  let moved = 0;
  let blocked = 0;

  itemIds.forEach((itemId) => {
    if (itemId === targetFolderId) return;
    if (isDescendant(userQuizzes, itemId, targetFolderId)) {
      blocked++;
      return;
    }
    // Courses are top-level only — see canPlaceItem's doc comment.
    if (!canPlaceItem(userQuizzes, itemId, targetFolderId).allowed) {
      blocked++;
      return;
    }
    const item = userQuizzes.find((q) => q.id === itemId || q.meta?.id === itemId);
    if (!item) return;
    if (!item.meta) item.meta = {};
    if ((item.meta.parentId || null) === (targetFolderId || null)) return; // already there
    if (
      hasSameLevelCollision(userQuizzes, {
        type: item.meta?.type || "quiz",
        title: item.meta?.title || "",
        parentId: targetFolderId || null,
        excludeId: itemId,
      })
    ) {
      blocked++;
      return;
    }
    item.meta.parentId = targetFolderId;
    moved++;
  });

  if (moved > 0 && !saveUserQuizzes(userQuizzes)) {
    // Save failed (see saveUserQuizzes, which already surfaced its own
    // notification) — don't report a successful move that never actually
    // persisted. `saveFailed` lets a caller distinguish this from an
    // ordinary placement-rule block (see resolveFolderTitleToId's caller in
    // user-quizzes-view.js, which used to always blame a "already there"
    // rule violation here regardless of the real cause).
    return { moved: 0, blocked, saveFailed: true };
  }
  return { moved, blocked };
}

/**
 * Builds the MoveSource adapter (see move-to-dialog.js's interface doc)
 * for the "محتواي" localStorage tree. Kept in this file rather than
 * move-to-dialog.js since it's the only thing here that actually reads
 * `user_quizzes` — the dialog itself stays storage-agnostic.
 * @param {string[]} itemIds
 * @returns {object|null} a MoveSource, or null if the move should be
 *   refused outright (see the lone-course guard below) before any dialog
 *   opens at all.
 */
function createLocalUserQuizzesMoveSource(itemIds) {
  const userQuizzes = readUserQuizzes();
  const folders = userQuizzes.filter(
    (q) => q.meta?.type === "folder" || q.meta?.type === "course",
  );

  // Moving a single course means there is nowhere valid to move it to at
  // all (courses are top-level only — see canPlaceItem) — the picker
  // would open with every option disabled, which is a worse experience
  // than not opening it. showContextMenu already omits "نقل إلى" for a
  // lone course for this reason; this guard covers any other caller
  // (e.g. a future bulk-select that includes a course) with the same
  // message instead of an empty-looking dialog.
  const movingCourseIds = itemIds.filter((id) => {
    const item = userQuizzes.find((q) => (q.id || q.meta?.id) === id);
    return item?.meta?.type === "course";
  });
  if (movingCourseIds.length && itemIds.length === movingCourseIds.length) {
    showNotification(
      "لا يمكن النقل",
      "المواد تبقى في المستوى الرئيسي دائماً ولا يمكن نقلها.",
      "warning",
    );
    return null;
  }

  // Current location of the item(s) being moved, so it can be excluded/
  // marked as "current" rather than offered as a no-op destination.
  const firstItem = userQuizzes.find((q) => (q.id || q.meta?.id) === itemIds[0]);
  const currentParentId = firstItem?.meta?.parentId || null;

  const itemLabel =
    itemIds.length > 1
      ? `${itemIds.length} عناصر`
      : firstItem?.meta?.title
        ? `"${firstItem.meta.title}"`
        : "العنصر";

  return {
    itemLabel,
    rootLabel: "محتواي (الرئيسية)",
    includeRoot: true,
    showNotification,

    isCurrentDestination(nodeId) {
      return (nodeId || null) === currentParentId;
    },

    getNodes() {
      return folders.map((f) => ({
        id: f.id || f.meta?.id,
        parentId: f.meta?.parentId || null,
        title: f.meta?.title || "",
        icon: f.meta?.icon || (f.meta?.type === "course" ? "📚" : "📁"),
      }));
    },

    // Each node is individually validity-checked against every item being
    // moved:
    // - a descendant of any moving item (would create a cycle)
    // - a course itself, when the payload includes a course (nowhere for a
    //   course to go but root — see canPlaceItem)
    // - a destination that already has a same-name/same-type child (would
    //   silently create a same-level duplicate)
    // - the item's current parent (a no-op, shown but marked/disabled
    //   rather than hidden, so the tree's shape stays predictable) — this
    //   one is handled by isCurrentDestination above rendering the badge
    //   instead, not by disabling the row.
    getDisabledReason(nodeId) {
      if (itemIds.includes(nodeId)) {
        return "لا يمكن نقل عنصر إلى نفسه.";
      }
      if (itemIds.some((id) => isDescendant(userQuizzes, id, nodeId))) {
        return "لا يمكن نقل مجلد إلى داخل نفسه أو أحد مجلداته الفرعية.";
      }
      if (movingCourseIds.length) {
        return "المواد تبقى في المستوى الرئيسي دائماً ولا يمكن نقلها إلى داخل مجلد.";
      }
      // Checked against EVERY item being moved (not just the first) so a
      // bulk move is flagged if it would collide for any one of them.
      const collides = itemIds.some((id) => {
        const movingItem = userQuizzes.find((q) => (q.id || q.meta?.id) === id);
        if (!movingItem) return false;
        return hasSameLevelCollision(userQuizzes, {
          type: movingItem.meta?.type || "quiz",
          title: movingItem.meta?.title || "",
          parentId: nodeId,
          excludeId: id,
        });
      });
      if (collides) {
        return "يوجد عنصر بنفس الاسم والنوع في هذا المجلد بالفعل.";
      }
      return null;
    },

    isFullyBlocked(nodeId) {
      return itemIds.every((id) => isDescendant(userQuizzes, id, nodeId) || id === nodeId);
    },

    moveTo(nodeId) {
      return moveItemsToFolder(itemIds, nodeId);
    },

    onMoved() {
      renderUserQuizzesView();
    },
  };
}

/**
 * Non-drag fallback for moving an item (used by the right-click context
 * menu and the card ⋮ overlay) — opens a small folder-tree picker modal so
 * touch/mobile users, who have no usable drag gesture, can still move items
 * in and out of folders/courses. `itemIds` supports both the single-item
 * case and the bulk-selection case with one shared implementation.
 *
 * Thin wrapper: builds the localStorage MoveSource (see
 * createLocalUserQuizzesMoveSource above) and hands it to the shared,
 * storage-agnostic dialog renderer in move-to-dialog.js. The exported
 * signature is unchanged so every existing caller (the context menu, the
 * card ⋮ overlay, the bulk-selection action bar) needs no changes.
 * @param {string[]} itemIds
 */
export function openMoveToDialog(itemIds) {
  if (!itemIds || itemIds.length === 0) return;
  const source = createLocalUserQuizzesMoveSource(itemIds);
  if (!source) return; // lone-course guard already showed its own notification
  openMoveToDialogWithSource(source);
}

// Context Menu Logic
let contextMenuEl = null;
// Track whether the last contextmenu event opened our custom menu.
// Used to implement the toggle behavior:
//   1st right-click: opens custom menu (preventDefault)
//   2nd right-click: hides custom menu, allows native menu to show
//   3rd right-click: opens custom menu again
let customMenuJustOpened = false;

// SVG icons for context menu items
const CREATE_FOLDER_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>`;
const CREATE_COURSE_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`;
const UPLOAD_FOLDER_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>`;
const SELECT_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`;
const RENAME_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`;
// Matches the ⋮ dropdown's own "تعديل الامتحان" icon (EDIT_ICON_SVG in
// icons.js), redrawn at this menu's 15x15 size instead of importing the
// 18x18 version, so every icon in this context menu shares one consistent
// scale.
const EDIT_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z"/></svg>`;
const INFO_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>`;
const DELETE_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>`;
const MOVE_TO_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 9V5c0-1.1.9-2 2-2h3.9c.7 0 1.3.3 1.7.9l.8 1.2c.4.6 1 .9 1.7.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-2"/><path d="M2 13h10"/><path d="m9 16 3-3-3-3"/></svg>`;
const ASK_AI_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="m19 16 .7 2.3L22 19l-2.3.7z"/></svg>`;
// Matches create-quiz-modal.js's own file-plus modal-header icon, redrawn
// at this menu's 15x15 scale (same "redraw rather than import a
// differently-sized version" approach EDIT_SVG above already uses).
const CREATE_QUIZ_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M9 15h6"/><path d="M12 18v-6"/></svg>`;
// Matches root-view.js's TRASH_BIN_ICON_SVG (icons.js), redrawn at 15x15 —
// see docs/plans/implementation-plan.md items 9/10.
const TRASH_CAN_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`;

// "إنشاء درس" — same book-plus glyph the sidebar's "إنشاء دروس" link uses,
// redrawn at this menu's 15x15 scale.
const CREATE_LESSON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/><path d="M9 10h6"/><path d="M12 7v6"/></svg>`;
// Trigger icon for the "إنشاء" submenu row.
const CREATE_PLUS_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/></svg>`;
// Points toward the side the submenu opens on (left in this RTL UI).
const SUBMENU_CARET_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>`;

export function initContextMenu() {
  if (contextMenuEl) return;
  contextMenuEl = document.createElement("div");
  contextMenuEl.id = "userQuizContextMenu";
  contextMenuEl.style.cssText = `
    display: none; position: absolute; z-index: 9999;
    background: var(--color-surface); border: 1px solid var(--color-border);
    border-radius: 8px; box-shadow: var(--shadow-lg); padding: 5px 0;
    min-width: 170px; flex-direction: column;
  `;
  document.body.appendChild(contextMenuEl);

  document.addEventListener("click", () => {
    contextMenuEl.style.display = "none";
    customMenuJustOpened = false;
  });
}

export function closeUserQuizContextMenu() {
  if (!contextMenuEl) return;
  contextMenuEl.style.display = "none";
  customMenuJustOpened = false;
}

export function showContextMenu(e, targetType, targetId, targetTitle) {
  initContextMenu();

  if (contextMenuEl.style.display !== "none") {
    contextMenuEl.style.display = "none";
    customMenuJustOpened = false;
    return;
  }

  closeAllItemDropdownMenus();

  e.preventDefault();
  contextMenuEl.innerHTML = "";

  // Right-click (or ⋮) on an item shows ONLY that item's own commands.
  // The global commands (create, import, trash, delete-all) are shown only
  // when right-clicking empty space; on touch devices they are reachable from
  // the امتحاناتك card ⋮ menu and the "إنشاء" button instead.
  if (targetType === "item" || targetType === "folder" || targetType === "course") {
    buildItemMenuItems(targetType, targetId, targetTitle);
  } else {
    buildGlobalMenuItems();
  }

  contextMenuEl.style.left = `${e.pageX}px`;
  contextMenuEl.style.top = `${e.pageY}px`;
  contextMenuEl.style.display = "flex";
  customMenuJustOpened = true;
  positionContextMenu(e);
}

/** Item-scoped commands: quiz / lesson / folder / course. */
function buildItemMenuItems(targetType, targetId, targetTitle) {
  contextMenuEl.appendChild(createMenuItem(SELECT_SVG, "تحديد", () => selectItem(targetId)));

  const targetRow = readUserQuizzes().find((q) => (q.id || q.meta?.id) === targetId);
  const isLesson = targetRow?.meta?.type === "lesson";
  const rename = { icon: RENAME_SVG, label: "تغيير العنوان", onClick: () => renameItem(targetId, targetTitle) };

  if (targetType === "item") {
    // "item" covers both quizzes and lessons — send each to its own editor.
    // Edit actions are grouped in one "تعديل" submenu to keep the menu short.
    contextMenuEl.appendChild(
      createSubmenuItem(EDIT_SVG, "تعديل", [
        {
          icon: EDIT_SVG,
          label: isLesson ? "تعديل الدرس" : "تعديل الامتحان",
          onClick: () => {
            window.location.href = isLesson
              ? `/create-lesson?edit=${encodeURIComponent(targetId)}`
              : `create-quiz?edit=${encodeURIComponent(targetId)}`;
          },
        },
        {
          icon: EDIT_SVG,
          label: "الوصف والمصدر",
          onClick: async () => {
            const [{ openDescriptionSourceModal }, { saveLocalItemMetadata }] = await Promise.all([
              import("./description-source-modal.js"),
              import("./user-quiz-card.js"),
            ]);
            openDescriptionSourceModal({
              title: targetRow?.meta?.title || targetTitle || "",
              description: targetRow ? (qz(targetRow, "description") || targetRow.meta?.description || "") : "",
              source: targetRow ? (qz(targetRow, "source") || targetRow.meta?.source || "") : "",
              onSave: ({ description, source }) => saveLocalItemMetadata(targetId, description, source),
            });
          },
        },
        rename,
      ]),
    );
  } else {
    contextMenuEl.appendChild(createMenuItem(rename.icon, rename.label, rename.onClick));
  }

  if (targetType !== "course") {
    const moveItems = [{ icon: MOVE_TO_SVG, label: "نقل إلى", onClick: () => openMoveToDialog([targetId]) }];
    if (currentFolderId !== null) {
      moveItems.push({ icon: MOVE_TO_SVG, label: "نقل إلى الخارج", onClick: () => moveItemOutOfFolder(targetId) });
    }
    if (moveItems.length > 1) {
      contextMenuEl.appendChild(createSubmenuItem(MOVE_TO_SVG, "نقل", moveItems));
    } else {
      contextMenuEl.appendChild(createMenuItem(moveItems[0].icon, moveItems[0].label, moveItems[0].onClick));
    }
  }

  if (targetType === "folder" || targetType === "course") {
    contextMenuEl.appendChild(
      createMenuItem(INFO_SVG, targetType === "course" ? "معلومات المادة" : "معلومات المجلد", async () => {
        const { showLocalFolderInfoModal } = await import("./folder-info-modal.js");
        showLocalFolderInfoModal(targetId);
      }),
    );
  }

  contextMenuEl.appendChild(
    createMenuItem(ASK_AI_SVG, "اسأل الباشـمبصمج", async () => {
      const { openAIAgentWithAttachment, resolveUserItemAttachment } = await import(
        "../../components/ai-agent/ai-agent-attach-launcher.js"
      );
      const attachment = resolveUserItemAttachment(targetId);
      if (attachment) openAIAgentWithAttachment(attachment);
    }),
  );

  // Per-item "upload to platform" (admin) — pushes this course/folder with
  // all nested contents to the DB. Distinct from the global "استيراد مجلد من
  // جهازك", which imports FROM the local filesystem.
  if (isAdminAuthenticated() && (targetType === "course" || targetType === "folder")) {
    const label = targetType === "course" ? "رفع المادة إلى المنصة" : "رفع المجلد إلى المنصة";
    contextMenuEl.appendChild(createMenuItem(UPLOAD_FOLDER_SVG, label, () => uploadItemToPlatform(targetType, targetId)));
  }

  const divider = document.createElement("div");
  divider.style.cssText = "border-top: 1px solid var(--color-border); margin: 4px 0;";
  contextMenuEl.appendChild(divider);
  contextMenuEl.appendChild(createMenuItem(DELETE_SVG, "حذف", () => deleteFolder(targetId), true));
}

/** Global commands: shown only when right-clicking empty space. */
function buildGlobalMenuItems() {
  // Global actions — always visible regardless of what was right-clicked
  //
  // "إنشاء امتحان" — opens the same paste-text/import-file modal
  // (create-quiz-modal.js). The standalone .user-create-quiz-card that used
  // to sit in the quiz grid was removed per docs/plans/implementation-
  // plan.md testing notes (it duplicated this entry once item 10 added it
  // here and to the create-folder-btn dropdown) — this context-menu item
  // and that dropdown's are now the only two entry points to this flow.
  // Dynamically imported to avoid a static circular import: create-quiz-
  // modal.js already imports currentFolderId from this module.
  // All four creation actions live in one "إنشاء" submenu so the root menu
  // stays short. Course creation is top-level only — inside a folder/course
  // it stays visible-but-disabled (not hidden) so the submenu's shape doesn't
  // shift depending on location.
  contextMenuEl.appendChild(
    createSubmenuItem(CREATE_PLUS_SVG, "إنشاء", [
      {
        icon: CREATE_QUIZ_SVG,
        label: "إنشاء امتحان",
        onClick: async () => {
          const { openInlineCreateQuizModal } = await import("./create-quiz-modal.js");
          openInlineCreateQuizModal();
        },
      },
      {
        // Creates a new lesson in currentFolderId (or root if at root).
        icon: CREATE_LESSON_SVG,
        label: "إنشاء درس",
        onClick: async () => {
          const { openInlineCreateLessonModal } = await import("./create-lesson-modal.js");
          openInlineCreateLessonModal();
        },
      },
      {
        icon: CREATE_LESSON_SVG,
        label: "إنشاء دفتر",
        onClick: async () => {
          const { openInlineCreateNotebookModal } = await import("./create-notebook-modal.js");
          openInlineCreateNotebookModal();
        },
      },
      {
        icon: CREATE_FOLDER_SVG,
        label: "إنشاء مجلد",
        onClick: () => createNewFolderOrCourse("folder"),
      },
      {
        icon: CREATE_COURSE_SVG,
        label: "إنشاء مادة",
        onClick: () => createNewFolderOrCourse("course"),
        disabledReason: currentFolderId !== null ? "المواد تُنشأ في المستوى الرئيسي فقط." : null,
      },
    ]),
  );

  if (isAdminAuthenticated()) {
    contextMenuEl.appendChild(createMenuItem(UPLOAD_FOLDER_SVG, "استيراد مجلد من جهازك", () => uploadFolderForAdmins()));
  }

  // "سلة المهملات" — local trash panel entry point (item 9). Mirrors the
  // exact gating root-view.js's own "امتحاناتك" card ⋮ menu already uses:
  // shown only once there's at least one trashed item, regardless of
  // whether "امتحاناتك" itself currently has any live content.
  // getTrashItemCount() is imported statically above (user-quizzes-trash.js
  // already statically imports back from this module — hasSameLevelCollision
  // — so this doesn't introduce a new cycle, just uses the existing one, and
  // it's only ever called from inside this function body, well after both
  // modules have finished their own top-level evaluation). openLocalTrashPanel
  // itself is still dynamically imported (user-quizzes-trash-panel.js pulls
  // in more of this module's exports transitively) since the click only
  // happens well after page load, so the extra async hop there is free.
  const trashCount = getTrashItemCount();
  if (trashCount > 0) {
    contextMenuEl.appendChild(
      createMenuItem(TRASH_CAN_SVG, `سلة المهملات (${trashCount})`, async () => {
        const { openLocalTrashPanel } = await import("./user-quizzes-trash-panel.js");
        openLocalTrashPanel();
      }),
    );
  }

  // Divider + "حذف الكل" below — kept visually and physically separate from
  // the item-scoped "حذف" above so a misclick can't easily wipe everything
  // instead of one folder. Hidden entirely (not just disabled) once
  // "امتحاناتك" is already empty — there's nothing left to wipe, and a
  // visible-but-inert danger button would just be confusing.
  const userQuizzesForDeleteAll = readUserQuizzes();
  if (userQuizzesForDeleteAll.length > 0) {
    const dangerDivider = document.createElement("div");
    dangerDivider.style.cssText = "border-top: 1px solid var(--color-border); margin: 4px 0;";
    contextMenuEl.appendChild(dangerDivider);
    contextMenuEl.appendChild(
      createMenuItem(DELETE_SVG, "حذف الكل", () => deleteAllUserQuizzes(), true),
    );
  }

}

/**
 * Keeps the context menu fully inside the viewport instead of letting it
 * render off-screen near an edge. The menu's real size is only known once
 * its final content is in the DOM and visible (its item count varies with
 * targetType/permissions), so this runs *after* `display: flex` is applied
 * above rather than trying to precompute a size.
 *
 * Behavior: normally the menu opens below-and-right of the cursor (this
 * page's RTL default). If there isn't enough room below, it flips to open
 * above the cursor instead; if there isn't enough room to the right (or
 * left, in an RTL context where the menu naturally grows leftward from the
 * click point), it flips to the other horizontal side too. Each axis is
 * judged independently, so a click near a corner can flip both ways at
 * once rather than only handling one edge at a time.
 */
function positionContextMenu(e) {
  const menuRect = contextMenuEl.getBoundingClientRect();
  const margin = 8; // keep a small gap from the viewport edge, not flush against it
  const viewportWidth = document.documentElement.clientWidth;
  const viewportHeight = document.documentElement.clientHeight;

  // e.clientX/Y (viewport-relative) is what actually needs to fit on
  // screen; pageX/Y (document-relative, used for the initial placement
  // above) only matches clientX/Y when the page isn't scrolled, so the
  // edge checks below are done in viewport space and converted back.
  let left = e.clientX;
  let top = e.clientY;

  const overflowsRight = left + menuRect.width > viewportWidth - margin;
  const overflowsBottom = top + menuRect.height > viewportHeight - margin;

  if (overflowsRight) left = e.clientX - menuRect.width;
  if (overflowsBottom) top = e.clientY - menuRect.height;

  // Clamp as a final safety net (e.g. a menu taller/wider than the whole
  // viewport on a very small screen) so it's never partially off either
  // opposite edge after flipping.
  left = Math.min(Math.max(left, margin), viewportWidth - menuRect.width - margin);
  top = Math.min(Math.max(top, margin), viewportHeight - menuRect.height - margin);

  contextMenuEl.style.left = `${left + window.scrollX}px`;
  contextMenuEl.style.top = `${top + window.scrollY}px`;
}

/**
 * A context-menu row that opens a nested submenu of `items`
 * (`{ icon, label, onClick, isDanger?, disabledReason? }`, same shape
 * createMenuItem takes). Opens on hover for real pointer devices and toggles
 * on click/tap/Enter/Space everywhere else. The submenu sits beside the row
 * (left of it in this RTL UI) and flips to the other side / shifts up when it
 * would run off-screen. Leaf rows are plain createMenuItem rows, so choosing
 * one closes the whole context menu exactly like any other action.
 */
function createSubmenuItem(iconSvg, label, items) {
  const wrap = document.createElement("div");
  wrap.style.cssText = "position: relative;";

  const trigger = document.createElement("div");
  trigger.setAttribute("role", "menuitem");
  trigger.setAttribute("aria-haspopup", "menu");
  trigger.setAttribute("aria-expanded", "false");
  trigger.tabIndex = 0;
  trigger.style.cssText = `
    padding: 5px 14px; cursor: pointer; color: var(--color-text-primary);
    font-size: 0.88rem; display: flex; align-items: center; gap: 10px;
  `;
  trigger.innerHTML = `<span style="flex-shrink:0;display:flex;align-items:center;opacity:0.75">${iconSvg}</span><span style="flex:1">${label}</span><span class="uqcm-submenu-caret" style="flex-shrink:0;display:flex;align-items:center;opacity:0.6;transition:transform 0.15s ease">${SUBMENU_CARET_SVG}</span>`;

  const sub = document.createElement("div");
  sub.setAttribute("role", "menu");
  sub.style.cssText = `
    display: none; position: absolute; top: -6px; right: calc(100% - 2px);
    background: var(--color-surface); border: 1px solid var(--color-border);
    border-radius: 8px; box-shadow: var(--shadow-lg); padding: 5px 0;
    min-width: 160px; flex-direction: column; z-index: 1;
  `;
  items.forEach((it) => {
    const row = createMenuItem(it.icon, it.label, it.onClick, !!it.isDanger, it.disabledReason || null);
    row.setAttribute("role", "menuitem");
    row.tabIndex = -1; // focusable from the trigger's ArrowLeft/Enter handler
    sub.appendChild(row);
  });
  // Clicks on the submenu's padding/dividers must not reach the document
  // handler that closes the whole menu.
  sub.onclick = (e) => e.stopPropagation();

  const caret = trigger.querySelector(".uqcm-submenu-caret");

  function place() {
    // Reset, then measure with the submenu visible.
    sub.style.position = "absolute";
    sub.style.boxShadow = "";
    sub.style.borderStyle = "";
    sub.style.margin = "";
    sub.style.minWidth = "160px";
    sub.style.right = "calc(100% - 2px)";
    sub.style.left = "auto";
    sub.style.top = "-6px";
    const margin = 8;
    const vw = document.documentElement.clientWidth;
    let r = sub.getBoundingClientRect();
    if (r.left < margin) {
      // No room on the left — open on the right of the row instead.
      sub.style.right = "auto";
      sub.style.left = "calc(100% - 2px)";
      r = sub.getBoundingClientRect();
    }
    if (r.left < margin || r.right > vw - margin) {
      // Neither side fits (phones) — expand inline below the trigger instead
      // of floating off-screen.
      sub.style.position = "static";
      sub.style.minWidth = "0";
      sub.style.margin = "2px 8px 4px";
      sub.style.boxShadow = "none";
      sub.style.borderStyle = "dashed";
      return;
    }
    const r2 = sub.getBoundingClientRect();
    if (r2.bottom > document.documentElement.clientHeight - margin) {
      const shift = r2.bottom - (document.documentElement.clientHeight - margin);
      sub.style.top = `${-6 - shift}px`;
    }
  }

  function setOpen(open) {
    sub.style.display = open ? "flex" : "none";
    trigger.setAttribute("aria-expanded", String(open));
    trigger.style.background = open ? "var(--color-bg-hover, rgba(0,0,0,0.05))" : "transparent";
    if (caret) caret.style.transform = open ? "rotate(-90deg)" : "";
    if (open) place();
  }
  const isOpen = () => sub.style.display !== "none";

  const hoverCapable =
    window.matchMedia && window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  if (hoverCapable) {
    wrap.addEventListener("mouseenter", () => setOpen(true));
    wrap.addEventListener("mouseleave", () => setOpen(false));
  }

  trigger.onclick = (e) => {
    e.stopPropagation(); // keep the menu open (the document handler would close it)
    setOpen(!isOpen());
  };
  trigger.onkeydown = (e) => {
    if (e.key === "Enter" || e.key === " " || e.key === "ArrowLeft") {
      e.preventDefault();
      setOpen(true);
      sub.firstElementChild?.focus?.();
    } else if (e.key === "Escape" || e.key === "ArrowRight") {
      setOpen(false);
    }
  };

  wrap.appendChild(trigger);
  wrap.appendChild(sub);
  return wrap;
}

function createMenuItem(iconSvg, label, onClick, isDanger = false, disabledReason = null) {
  const item = document.createElement("div");
  const disabled = !!disabledReason;
  item.style.cssText = `
    padding: 5px 14px; cursor: ${disabled ? "not-allowed" : "pointer"};
    color: ${disabled ? "var(--color-text-tertiary, var(--color-text-secondary))" : (isDanger ? "var(--color-danger, #dc2626)" : "var(--color-text-primary)")};
    opacity: ${disabled ? "0.55" : "1"};
    font-size: 0.88rem; display: flex; align-items: center; gap: 10px;
  `;
  item.innerHTML = `<span style="flex-shrink:0;display:flex;align-items:center;opacity:0.75">${iconSvg}</span><span>${label}</span>`;
  if (disabled) item.title = disabledReason;
  item.onmouseover = () => { if (!disabled) item.style.background = "var(--color-bg-hover, rgba(0,0,0,0.05))"; };
  item.onmouseout = () => item.style.background = "transparent";
  item.onclick = (e) => {
    e.stopPropagation();
    if (disabled) return;
    contextMenuEl.style.display = "none";
    customMenuJustOpened = false;
    onClick();
  };
  return item;
}

/**
 * Uploads a single course or folder card (with everything nested inside
 * it) to the platform, via the dedicated Course/Folder upload wizards in
 * adminUpload.js. Triggered from the card's ⋮ menu / right-click menu
 * "☁️ رفع … إلى المنصة" action — see buildCourseUploadPayload /
 * buildFolderUploadPayload for how the local tree is flattened for the API.
 * @param {"course"|"folder"} type
 * @param {string} itemId
 */
function uploadItemToPlatform(type, itemId) {
  const userQuizzes = readUserQuizzes();
  const item = userQuizzes.find((q) => (q.id || q.meta?.id) === itemId);
  if (!item) return;

  import("./adminUpload.js").then((mod) => {
    if (type === "course") {
      mod.openCourseUploadModal([item], userQuizzes);
    } else {
      mod.openFolderUploadModal({ folders: [item], quizzes: [], userQuizzes });
    }
  });
}

/**
 * "استيراد مجلد من جهازك" (admin local folder import) — lets an admin pick a whole
 * folder/Course on their machine (via the native directory picker) and
 * imports it in one shot: every subdirectory becomes a folder/course record
 * (preserving nesting) and every .json file becomes a quiz inside the right
 * folder, instead of flattening everything into the current folder the way
 * a plain multi-file JSON import would.
 *
 * Uses each File's `webkitRelativePath` (e.g. "Physics/Unit1/quiz1.json"),
 * which browsers populate automatically for `webkitdirectory` pickers, to
 * reconstruct the directory tree client-side — no server involvement, since
 * user_quizzes is a local/localStorage collection like the rest of this
 * feature.
 */
export function uploadFolderForAdmins() {
  const input = document.createElement("input");
  input.type = "file";
  input.webkitdirectory = true;
  input.directory = true;
  input.multiple = true;
  input.onchange = async (e) => {
    const allFiles = Array.from(e.target.files);
    const jsonFiles = allFiles.filter((f) => f.name.endsWith(".json"));
    const skippedCount = allFiles.length - jsonFiles.length;

    if (jsonFiles.length === 0) {
      showNotification(
        "لا توجد ملفات",
        "لم يتم العثور على أي ملفات .json داخل المجلد المحدد.",
        "warning",
      );
      return;
    }

    await importFolderTree(jsonFiles, skippedCount);
  };
  input.click();
}

/**
 * Parses a batch of File objects (already filtered to .json) that came from
 * a directory picker, rebuilds the folder tree from their
 * `webkitRelativePath`s, and — after the admin confirms a summary — writes
 * one new folder/course/quiz set into user_quizzes under `currentFolderId`,
 * in a single storage write.
 * @param {File[]} jsonFiles
 * @param {number} skippedCount - non-.json files that were silently ignored
 */
async function importFolderTree(jsonFiles, skippedCount = 0) {
  // 1. Read + parse every file first (so we can report bad JSON up front,
  //    before touching storage at all).
  const parsedFiles = [];
  const failedFiles = [];
  for (const file of jsonFiles) {
    const relPath = file.webkitRelativePath || file.name;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!parsed || !Array.isArray(parsed.questions) || parsed.questions.length === 0) {
        failedFiles.push(relPath);
        continue;
      }
      parsedFiles.push({ relPath, parsed });
    } catch (err) {
      failedFiles.push(relPath);
    }
  }

  if (parsedFiles.length === 0) {
    showNotification(
      "تعذر الرفع",
      "لم يتمكن أي من الملفات من الانضمام — تأكد أنها ملفات امتحان صالحة.",
      "warning",
    );
    return;
  }

  // 2. Build the directory tree from relative paths. Each node is keyed by
  //    its full path-so-far (so same-named folders under different parents
  //    don't collide), and carries its own quiz files + child dir keys.
  //    Root-level directory names become "course" type (matching the
  //    manual create-course affordance, which is also root-only); anything
  //    nested becomes a plain "folder".
  const dirNodes = new Map(); // pathKey -> { name, depth, parentKey, quizFiles: [], childKeys: Set }
  const rootDirKeys = new Set();

  for (const { relPath, parsed } of parsedFiles) {
    const segments = relPath.split("/").filter(Boolean);
    // Drop the filename — everything before it is the directory chain.
    const dirSegments = segments.slice(0, -1);

    if (dirSegments.length === 0) {
      // A .json file sitting directly at the picked folder's root (no
      // subdirectory) — treat the picked folder's own name as a single
      // top-level course. webkitRelativePath always includes the picked
      // folder itself as the first segment normally; this branch only
      // hits for malformed/edge-case paths, so fall back gracefully.
      continue;
    }

    let parentKey = null;
    let pathSoFar = "";
    dirSegments.forEach((seg, depth) => {
      pathSoFar = pathSoFar ? `${pathSoFar}/${seg}` : seg;
      if (!dirNodes.has(pathSoFar)) {
        dirNodes.set(pathSoFar, {
          name: seg,
          depth,
          parentKey,
          quizFiles: [],
          childKeys: new Set(),
        });
        if (depth === 0) rootDirKeys.add(pathSoFar);
        if (parentKey) dirNodes.get(parentKey).childKeys.add(pathSoFar);
      }
      parentKey = pathSoFar;
    });

    // Attach this quiz file to its immediate parent directory.
    dirNodes.get(pathSoFar).quizFiles.push(parsed);
  }

  const folderCount = dirNodes.size;
  const quizCount = parsedFiles.length;

  // 3. Confirm before writing anything — this is a bulk, hard-to-undo
  //    admin action, and the parsed tree can differ from what the admin
  //    expected (e.g. unexpected nesting depth).
  const summaryParts = [
    `سيتم إنشاء ${folderCount} مجلد/مادة`,
    `ورفع ${quizCount} امتحان`,
  ];
  if (failedFiles.length) {
    summaryParts.push(`(تم تجاهل ${failedFiles.length} ملف غير صالح)`);
  }
  if (skippedCount) {
    summaryParts.push(`(تم تجاهل ${skippedCount} ملف غير json)`);
  }
  const confirmed = await _confirm(`${summaryParts.join(" ")}. متابعة؟`);
  if (!confirmed) return;

  // 4. Materialize folder/course records + quiz entries, then write once.
  const userQuizzes = readUserQuizzes();
  const keyToId = new Map();

  // Unlike createNewFolderOrCourse (which rejects a duplicate name outright
  // via a warning), a bulk folder upload appends a "(2)", "(3)", ... suffix
  // instead — rejecting here would mean aborting or silently dropping an
  // entire subtree mid-batch just because one sibling folder name already
  // exists locally, which is a worse outcome than a renamed folder.
  function uniqueNameAtLevel(name, parentId) {
    const takenLower = new Set(
      userQuizzes
        .filter((q) => (q.meta?.parentId || null) === parentId)
        .map((q) => (q.meta?.title || "").trim().toLowerCase()),
    );
    if (!takenLower.has(name.trim().toLowerCase())) return name;
    let n = 2;
    let candidate = `${name} (${n})`;
    while (takenLower.has(candidate.toLowerCase())) {
      n += 1;
      candidate = `${name} (${n})`;
    }
    return candidate;
  }

  function ensureFolderRecord(pathKey) {
    if (keyToId.has(pathKey)) return keyToId.get(pathKey);
    const node = dirNodes.get(pathKey);
    const parentId = node.parentKey ? ensureFolderRecord(node.parentKey) : currentFolderId;
    const isRootLevel = node.depth === 0;
    const id = crypto.randomUUID();
    const title = uniqueNameAtLevel(node.name, parentId);
    userQuizzes.push({
      id,
      meta: {
        id,
        type: isRootLevel ? "course" : "folder",
        title,
        parentId,
        icon: isRootLevel ? getSubjectIcon(node.name, false) : undefined,
        createdAt: new Date().toLocaleString("en-US"),
      },
      stats: { questionCount: 0, questionTypes: [] },
      questions: [],
    });
    keyToId.set(pathKey, id);
    return id;
  }

  for (const [pathKey, node] of dirNodes.entries()) {
    const folderId = ensureFolderRecord(pathKey);
    node.quizFiles.forEach((parsed) => {
      const quizId = crypto.randomUUID();
      const entry = buildUserQuizEntry(quizId, parsed, parsed.meta?.title);
      entry.meta.parentId = folderId;
      userQuizzes.push(entry);
    });
  }

  if (!saveUserQuizzes(userQuizzes)) return;
  showNotification(
    "تم الرفع",
    `تم إنشاء ${folderCount} مجلد/مادة ورفع ${quizCount} امتحان بنجاح.`,
    "success",
  );
  renderUserQuizzesView();
}

// ─── Upload-to-platform tree builders ──────────────────────────────────────
// These turn a slice of the local `user_quizzes` tree into the flat `items`
// array api/upload-quiz.js's "folder" mode expects (see that file's header
// comment for the exact shape). Both builders share the same node shape:
//   { type: "course"|"folder"|"quiz"|"lesson", name, folderSegments, rootName, quiz?|lesson? }
// `folderSegments` is always the ordered chain of ancestor names ABOVE the
// node (never including the node's own name) — courses have none, a folder
// has its course's name (+ any ancestor folders) directly above it, and a
// quiz has whatever chain of course/folders sits above it.

function walkChildren(userQuizzes, parentId) {
  return userQuizzes.filter((q) => (q.meta?.parentId || null) === parentId);
}

// Mirrors api/_validateQuiz.js's ALLOWED_META_KEYS whitelist: the server
// rejects (not silently strips) any unrecognized meta key, so local-only
// bookkeeping fields on a user_quizzes row — parentId, type, icon,
// createdAt's raw form, etc. — must never reach the request body as-is.
// Kept in sync manually with the server list; adding a new persisted meta
// field server-side means adding it here too.
const UPLOADABLE_META_KEYS = new Set([
  "title",
  "description",
  "source",
  "createdAt",
  "password",
  "view",
  "mode",
]);

function quizToPayload(entry) {
  const rawMeta = entry.meta || {};
  const meta = {};
  for (const key of UPLOADABLE_META_KEYS) {
    const val = rawMeta[key];
    if (typeof val === "string" ? val.trim() : val != null) {
      meta[key] = typeof val === "string" ? val.trim() : val;
    }
  }
  if (!meta.title) meta.title = "امتحان";

  const questions = entry.questions || [];
  // Must mirror api/_validateQuiz.js's inferQuestionType exactly (options
  // length 0 -> Essay, 2 -> True/False, else MCQ) — the server recomputes
  // stats from `questions` and rejects the upload if this doesn't match
  // (STATS_MISMATCH), so this can never be a placeholder/empty value.
  const types = new Set();
  questions.forEach((q) => {
    if (!Array.isArray(q.options) || q.options.length === 0) types.add("Essay");
    else if (q.options.length === 2) types.add("True/False");
    else types.add("MCQ");
  });
  return {
    meta,
    stats: { questionCount: questions.length, questionTypes: Array.from(types).sort() },
    questions,
  };
}

function lessonToPayload(entry) {
  return {
    title: (entry.meta?.title || "").trim() || "درس بدون عنوان",
    description: entry.meta?.description || "",
    source: entry.meta?.source || "",
    content: { sections: entry.lesson?.sections || entry.content?.sections || [] },
    readerPrefsDefault: entry.meta?.readerPrefs || null,
    passwordHash: entry.passwordHash || "",
  };
}

/**
 * Recursively appends every descendant of `node` (folders + quizzes + lessons) into
 * `items`, tagging each with the ancestor chain above it (`ancestorNames`).
 * Shared by both buildCourseUploadPayload and buildFolderUploadPayload —
 * the only difference between the two callers is what ancestorNames starts
 * as and what rootName is stamped on each item.
 */
function notebookToPayload(nb, name) {
  return {
    title: name || (nb.meta?.title || "").trim() || "دفتر بدون عنوان",
    description: nb.meta?.description || "",
    source: nb.meta?.source || "",
    runtime: nb.notebook?.runtime || "matlab",
    content: nb.notebook?.content || { schemaVersion: 1, cells: [] },
  };
}

function appendSubtree(userQuizzes, node, ancestorNames, rootName, items) {
  const children = walkChildren(userQuizzes, node.id || node.meta?.id);
  for (const child of children) {
    const childId = child.id || child.meta?.id;
    const childName = (child.meta?.title || "").trim();
    if (child.meta?.type === "draft-lesson") continue;
    if (child.meta?.type === "lesson") {
      items.push({
        type: "lesson",
        name: childName || "درس بدون عنوان",
        folderSegments: [...ancestorNames],
        rootName,
        lesson: lessonToPayload(child),
      });
      continue;
    }
    if (child.meta?.type === "notebook") {
      items.push({
        type: "notebook",
        name: childName || "دفتر بدون عنوان",
        folderSegments: [...ancestorNames],
        rootName,
        localId: child.id, // workspace key: lets the upload step publish this notebook's images
        notebook: notebookToPayload(child, childName),
      });
      continue;
    }
    if (child.meta?.type === "folder") {
      items.push({
        type: "folder",
        name: childName,
        folderSegments: [...ancestorNames],
        rootName,
      });
      appendSubtree(userQuizzes, child, [...ancestorNames, childName], rootName, items);
    } else {
      // A plain quiz leaf.
      items.push({
        type: "quiz",
        name: childName || child.meta?.title || "امتحان",
        folderSegments: [...ancestorNames],
        rootName,
        quiz: quizToPayload(child),
      });
    }
  }
}

/**
 * Builds the flat `items` payload for uploading one or more entire courses
 * (with all of their nested folders and quizzes) to the platform in one
 * batch — the "مسار رفع المواد" workflow.
 * @param {Array} userQuizzes - full local user_quizzes collection
 * @param {Array} courseItems - the selected course rows (meta.type === "course")
 * @returns {{ items: Array, rootName: string }}
 */
export function buildCourseUploadPayload(userQuizzes, courseItems) {
  const items = [];
  for (const course of courseItems) {
    const courseName = (course.meta?.title || "").trim();
    items.push({ type: "course", name: courseName, folderSegments: [], rootName: courseName });
    appendSubtree(userQuizzes, course, [courseName], courseName, items);
  }
  return { items, rootName: courseItems.length === 1 ? (courseItems[0].meta?.title || "").trim() : "" };
}

/**
 * Builds the flat `items` payload for uploading one or more folders (with
 * their nested contents) plus any loose quizzes selected alongside them
 * into an EXISTING course already on the platform — the "مسار رفع
 * المجلدات" workflow. Unlike buildCourseUploadPayload, no "course" item is
 * emitted: the target course is chosen separately in the wizard
 * (openFolderUploadModal) and resolved server-side by name, so every
 * folderSegments chain here is seeded with `targetCourseName` as its first
 * element to match what api/upload-quiz.js's folder mode expects (the
 * course name is always folderSegments[0] when no course item is present).
 * @param {Array} userQuizzes
 * @param {Array} folderItems - selected folder rows (meta.type === "folder")
 * @param {Array} additionalQuizzes - selected plain quiz rows alongside the folders
 * @param {string} targetCourseName - name of the existing course on the platform
 * @param {string[]} [targetSubfolderPath] - optional chain of existing folder
 *   names under the course to nest everything one level deeper into
 * @returns {{ items: Array, rootName: string }}
 */
export function buildFolderUploadPayload(userQuizzes, folderItems, additionalQuizzes, targetCourseName, targetSubfolderPath = [], additionalLessons = [], additionalNotebooks = []) {
  const items = [];
  const baseChain = [targetCourseName, ...targetSubfolderPath];

  for (const folder of folderItems) {
    const folderName = (folder.meta?.title || "").trim();
    items.push({
      type: "folder",
      name: folderName,
      folderSegments: [...baseChain],
      rootName: targetCourseName,
    });
    appendSubtree(userQuizzes, folder, [...baseChain, folderName], targetCourseName, items);
  }

  for (const quiz of additionalQuizzes || []) {
    items.push({
      type: "quiz",
      name: (quiz.meta?.title || "").trim() || "امتحان",
      folderSegments: [...baseChain],
      rootName: targetCourseName,
      quiz: quizToPayload(quiz),
    });
  }

  for (const lesson of additionalLessons || []) {
    items.push({
      type: "lesson",
      name: (lesson.meta?.title || "").trim() || "درس بدون عنوان",
      folderSegments: [...baseChain],
      rootName: targetCourseName,
      lesson: lessonToPayload(lesson),
    });
  }

  for (const nb of additionalNotebooks || []) {
    const name = (nb.meta?.title || "").trim() || "دفتر بدون عنوان";
    items.push({
      type: "notebook",
      name,
      folderSegments: [...baseChain],
      rootName: targetCourseName,
      localId: nb.id || nb.meta?.id,
      notebook: notebookToPayload(nb, name),
    });
  }

  return { items, rootName: targetCourseName };
}

export function selectItem(itemId) {
  const container = document.querySelector(".user-quizzes-container");
  if (container) container.classList.add("selection-mode-active");
  const toggleBtn = document.querySelector(".selection-toggle-btn");
  if (toggleBtn) toggleBtn.classList.add("active");

  // Add itemId to the selection set
  const selectedUserQuizzes = getSelectedUserQuizzes();
  selectedUserQuizzes.add(itemId);

  // Visually check the matching checkbox
  const checkbox = document.querySelector(`.user-quiz-select-checkbox[data-quiz-id="${itemId}"]`);
  if (checkbox && !checkbox.checked) {
    checkbox.checked = true;
  }

  // Update the bulk action bar immediately
  updateBulkActionBar(true);
}

export { getFolderContentsCount, formatFolderAndQuizCount } from "./folder-counts.js";

export function createFolderOrCourseCard(item) {
  const card = document.createElement("div");
  card.className = "category-card user-quiz-card";
  card.style.cursor = "pointer";
  card.style.position = "relative";
  card.setAttribute("role", "button");
  card.setAttribute("tabindex", "0");
  const isCourse = item.meta?.type === "course";
  // Courses are always top-level (see canPlaceItem) — there is no valid
  // drop target for one, so it isn't made draggable at all rather than
  // being draggable-but-rejected-on-drop everywhere.
  card.draggable = !isCourse;

  const icon = isCourse ? "📚" : "📁";
  const itemId = item.id || item.meta?.id;

  const selectedUserQuizzes = getSelectedUserQuizzes();
  const isChecked = selectedUserQuizzes.has(itemId);

  // Checkbox: attached directly to card as an out-of-flow absolute element
  // (no in-flow wrapper div, preserving exact phone emoji alignment)
  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.className = "user-quiz-select-checkbox";
  checkbox.setAttribute("data-quiz-id", itemId);
  checkbox.setAttribute("aria-label", "تحديد");
  checkbox.checked = isChecked;
  checkbox.onclick = (e) => {
    e.stopPropagation();
    if (checkbox.checked) {
      selectedUserQuizzes.add(itemId);
    } else {
      selectedUserQuizzes.delete(itemId);
    }
    updateBulkActionBar();
  };
  card.appendChild(checkbox);

  // Category Icon: First in-flow flex child, aligned identically to user-quiz--phone-only-emoji
  const iconEl = document.createElement("div");
  iconEl.className = "category-icon";
  iconEl.setAttribute("aria-hidden", "true");
  iconEl.textContent = icon;
  card.appendChild(iconEl);

  // Text wrapper: card-text (display:contents on desktop, flex-column on mobile)
  const textWrap = document.createElement("div");
  textWrap.className = "card-text";

  const h = document.createElement("h3");
  h.textContent = item.meta?.title || "";
  h.setAttribute("data-tooltip-text", h.textContent);
  h.setAttribute("data-tooltip-clamped-only", "true");
  textWrap.appendChild(h);

  // Subtext: total number of subfolders and quizzes (recursive)
  const userQuizzes = readUserQuizzes();
  const { subfolderCount, quizCount, lessonCount, notebookCount } = getFolderContentsCount(userQuizzes, itemId);
  const subtextStr = formatFolderAndQuizCount(subfolderCount, quizCount, lessonCount, notebookCount);

  const subtextEl = document.createElement("p");
  subtextEl.className = "category-card-subtext user-quiz-count";
  subtextEl.textContent = subtextStr;
  textWrap.appendChild(subtextEl);

  card.appendChild(textWrap);


  card.setAttribute("aria-label", `${item.meta?.title || ""}, ${subtextStr}`);

  // Actions wrap with ⋮ more button for touch & quick access
  const actionsWrap = document.createElement("div");
  actionsWrap.className = "category-card-actions-wrap";
  const moreBtn = document.createElement("button");
  moreBtn.className = "exam-more-btn exam-more-btn--lg";
  moreBtn.type = "button";
  moreBtn.innerHTML = MORE_DOTS_ICON_SVG;
  moreBtn.setAttribute("aria-label", `خيارات ${item.meta?.title || ""}`);
  moreBtn.onclick = (e) => {
    e.stopPropagation();
    showContextMenu(e, item.meta?.type || "folder", itemId, item.meta?.title);
  };
  actionsWrap.appendChild(moreBtn);
  card.appendChild(actionsWrap);

  card.onclick = () => {
    // If in selection mode, toggle checkbox instead
    const container = document.querySelector(".user-quizzes-container");
    if (container?.classList.contains("selection-mode-active")) {
      checkbox.click();
      return;
    }
    navigateToFolder(itemId, item.meta?.title);
  };

  card.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      card.click();
    }
  });

  if (!isCourse) {
    card.ondragstart = (e) => handleDragStart(e, itemId);
    card.ondragend = handleDragEnd;
  }

  if (item.meta?.type === "folder" || item.meta?.type === "course") {
    card.ondragover = handleDragOver;
    card.ondragleave = handleDragLeave;
    card.ondrop = (e) => {
      e.stopPropagation();
      handleDrop(e, itemId);
    };
  }

  card.oncontextmenu = (e) => {
    e.stopPropagation();
    showContextMenu(e, item.meta?.type || "folder", itemId, item.meta?.title);
  };

  return card;
}