// ============================================================================
// public/src/features/home/user-quiz-card.js
// USER QUIZ CARD — renders a single locally-stored (user-created) quiz card,
// its ⋮ actions menu, play/delete handlers.
// ============================================================================
//
// SECURITY FIX (stored XSS): createUserQuizCard() previously interpolated
// the user-supplied quiz title into innerHTML with no escaping — a title
// like `<img src=x onerror=...>` typed into the create-quiz modal would
// execute on every render of that card. Fixed below by building the title
// with textContent instead of innerHTML, so it's never parsed as markup.
// ============================================================================

import { qz } from "./quiz-schema.js";
import { formatArabicQuestionCount, refreshUserQuizzesCard } from "./course-count.js";
import { moveToTrash } from "./user-quizzes-trash.js";
import { getSelectedUserQuizzes } from "./app-state.js";
import { getFromStorage, setInStorage } from "../../shared/storage-helpers.js";
import {
  isAdminAuthenticated,
  hasAdminSessionHint,
} from "../../shared/adminAuth.js";
import { createUploadButton, createLessonUploadButton, createNotebookUploadButton } from "./adminUpload.js";
import { showUserQuizDownloadPopup } from "./download-modal.js";
import { showUserQuizInfoModal, formatDateForInfo } from "./quiz-info-modal.js";
import { normalizeSource } from "../../components/quiz-info-modal/info-model.js";
import { showUserLessonInfoModal, collectLessonInfo } from "./lesson-info-modal.js";
import {
  createExamInfoSubmenu,
  createActionGroupSubmenu,
  openItemDropdownMenu,
} from "./item-dropdown-menu.js";
import { renderRootCategories } from "./root-view.js";
import {
  renderUserQuizzesView,
  updateBulkActionBar,
} from "./user-quizzes-view.js";
import {
  openMoveToDialog,
  renameItem,
  deleteFolder,
  selectItem,
  moveItemOutOfFolder,
  currentFolderId,
} from "./user-quizzes-folders.js";
import { userProfile } from "../../shared/userProfile.js";
import {
  LOCK_ICON_SVG,
  DOWNLOAD_ICON_SVG,
  EDIT_ICON_SVG,
  RENAME_ICON_SVG,
  TRASH_ICON_SVG,
  MORE_DOTS_ICON_SVG,
  MOVE_TO_ICON_SVG,
} from "./icons.js";
import {
  showNotification,
  _confirm,
  _alert,
} from "../../components/notifications/notifications.js";
// PHASE 2: "اسأل الباشـمبصمج" entry point — opens the AI Agent with this
// quiz pre-attached. Deliberately NOT importing from user-quizzes-view.js
// for the home-page system prompt/tools config (that file already imports
// createUserQuizCard FROM this one — importing back would be circular);
// this button opens the same "home" pageKey with a minimal, safe config
// instead (no tools — the live folder-tree context those tools need is
// built and owned by user-quizzes-view.js, not safely reconstructable
// here), which is enough for the assistant to read/discuss the attached
// quiz. See ai-agent-attach-launcher.js's own top comment for the fuller
// rationale.
import { openAIAgentWithAttachment, resolveUserItemAttachment } from "../../components/ai-agent/ai-agent-attach-launcher.js";
import { downloadLesson } from "./lesson-download.js";
import { withDownloadLoading } from "../../components/download-quiz-modal/export-card.js";
import { openDescriptionSourceModal } from "./description-source-modal.js";
import { appendNotebookMenuEntries, showNotebookDownloadModal } from "./notebook-actions.js";
import { createNotebookCardShell, createNotebookActionRow } from "./notebook-card-view.js";
import { createTypeChip, tagCardType } from "./card-type.js";
import { HOME_PAGE_SYSTEM_PROMPT } from "../../components/ai-agent/ai-agent-default-prompts.js";
import { SPARKLE_ICON_SVG } from "./icons.js";

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Create a card for a user-created quiz
 */
export function createUserQuizCard(quiz, index) {
  const card = document.createElement("div");
  card.className = "exam-card user-quiz-card";
  card.setAttribute("role", "article");
  card.setAttribute("aria-label", `امتحان: ${qz(quiz, "title")}`);
  card.style.position = "relative";

  const quizId = qz(quiz, "id") || quiz.id;

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.className = "user-quiz-select-checkbox";
  checkbox.setAttribute("data-quiz-id", quizId);
  const selectedUserQuizzes = getSelectedUserQuizzes();
  checkbox.checked = selectedUserQuizzes.has(quizId);
  checkbox.onclick = (e) => {
    e.stopPropagation();
    if (checkbox.checked) {
      selectedUserQuizzes.add(quizId);
    } else {
      selectedUserQuizzes.delete(quizId);
    }
    updateBulkActionBar();
  };
  card.appendChild(checkbox);

  // Pressing the card itself selects it while in selection mode — mirrors
  // the folder/course card's click handler in user-quizzes-folders.js
  // (`if (container?.classList.contains("selection-mode-active")) { checkbox.click(); return; }`).
  // Quiz/lesson cards previously had no whole-card click handler at all, so
  // selection only worked by hitting the tiny checkbox directly.
  card.addEventListener("click", (e) => {
    if (e.target === checkbox) return; // checkbox's own onclick already handles this
    const container = document.querySelector(".user-quizzes-container");
    if (container?.classList.contains("selection-mode-active")) {
      e.stopPropagation();
      checkbox.click();
    }
  });

  const h = document.createElement("h3");
  // SECURITY FIX (stored XSS): quiz.title is free-text the user typed into
  // the create-quiz modal's title input and is persisted to localStorage
  // verbatim. textContent (rather than innerHTML) means it's never parsed
  // as markup, so a title like `<img src=x onerror=...>` can't execute —
  // closes the same stored-XSS gap the original innerHTML interpolation
  // had, just without needing an escaping step at all.
  h.textContent = qz(quiz, "title") || quizId;
  h.setAttribute("data-tooltip-badge", "📝 امتحان");
  h.setAttribute("data-tooltip-text", h.textContent);

  // ── Phone-only leading emoji — sibling of .card-text, not nested inside
  const iconEl = document.createElement("span");
  iconEl.className = "user-quiz--phone-only-emoji";
  iconEl.textContent = "📝";

  iconEl.setAttribute("aria-hidden", "true");

  const questionCountLine = document.createElement("p");
  questionCountLine.className = "exam-question-count";
  const count = qz(quiz, "count");
  questionCountLine.textContent = formatArabicQuestionCount(count);

  // ── Play button — mirrors createExamCard's .start-btn ───────────────────
  const playBtn = document.createElement("button");
  playBtn.className = "start-btn";
  playBtn.type = "button";
  playBtn.style.flex = "1";
  playBtn.style.minWidth = "0";
  playBtn.textContent = "إبدأ";
  playBtn.setAttribute("aria-label", `بدء امتحان ${qz(quiz, "title")}`);
  playBtn.onclick = (e) => {
    e.stopPropagation();
    playUserQuiz(quiz);
  };

  // ── Download button — mirrors createExamCard's desktop-download-btn ─────
  const userQuizPassword = qz(quiz, "password");
  const downloadBtn = document.createElement("button");
  downloadBtn.className = userQuizPassword
    ? "start-btn desktop-download-btn is-password-protected"
    : "start-btn desktop-download-btn";
  downloadBtn.type = "button";
  downloadBtn.style.flex = "1";
  downloadBtn.style.minWidth = "0";
  downloadBtn.style.background =
    "linear-gradient(135deg, #dc2626 0%, #b91c1c 100%)";
  downloadBtn.style.color = "white";
  downloadBtn.style.boxShadow = "0 4px 14px rgba(220, 38, 38, 0.4)";
  downloadBtn.innerHTML = userQuizPassword
    ? `${LOCK_ICON_SVG}<span>تحميل</span>`
    : `${DOWNLOAD_ICON_SVG}<span>تحميل</span>`;
  downloadBtn.setAttribute(
    "aria-label",
    userQuizPassword
      ? `تحميل امتحان ${qz(quiz, "title")} (محمي بكلمة مرور)`
      : `تحميل امتحان ${qz(quiz, "title")}`,
  );
  if (userQuizPassword) downloadBtn.title = "هذا الامتحان محمي بكلمة مرور";
  downloadBtn.onclick = (e) => {
    e.stopPropagation();
    showUserQuizDownloadPopup(quiz, downloadBtn);
  };

  // ── More (⋮) button — opens the Action Overlay ──────────────────────────
  const moreBtn = document.createElement("button");
  moreBtn.className = "exam-more-btn";
  moreBtn.type = "button";
  moreBtn.innerHTML = MORE_DOTS_ICON_SVG;
  moreBtn.setAttribute(
    "aria-label",
    `خيارات إضافية لـ ${qz(quiz, "title") || qz(quiz, "id")}`,
  );
  moreBtn.onclick = (e) => {
    e.stopPropagation();
    showUserQuizActionsOverlay(quiz, moreBtn);
  };

  const btnWrap = document.createElement("div");
  btnWrap.className = "exam-card-actions-wrap";
  btnWrap.appendChild(moreBtn);
  btnWrap.appendChild(playBtn);
  btnWrap.appendChild(downloadBtn);

  // ── Build text wrapper (display:contents on desktop, flex-col on mobile) ──
  const textWrap = document.createElement("div");
  textWrap.className = "card-text";
  textWrap.appendChild(createTypeChip("quiz"));
  tagCardType(card, "quiz");
  textWrap.appendChild(h);
  const description = String(qz(quiz, "description") || "").trim();
  if (description) {
    const descriptionEl = document.createElement("p");
    descriptionEl.className = "lesson-card-description";
    descriptionEl.textContent = description;
    descriptionEl.setAttribute("data-tooltip-badge", "📄 وصف الامتحان");
    descriptionEl.setAttribute("data-tooltip-text", description);
    textWrap.appendChild(descriptionEl);
  }

  // Meta wrapper: holds types + count — same role as .exam-card-meta, but
  // keeps the uniquely-designed typesRow chips as a 👤 user-quiz indicator.
  const metaWrap = document.createElement("div");
  metaWrap.className = "exam-card-meta user-quiz-card-meta";

  // ── Question type badges (kept unique to user quizzes) ──────────────────
  const typeStr = qz(quiz, "type");
  if (typeStr) {
    const typesRow = document.createElement("div");
    typesRow.className = "user-quiz-types-row exam-types-subtext";
    typeStr.split(" · ").forEach((t) => {
      const chip = document.createElement("span");
      chip.textContent = t;
      const colorMap = {
        MCQ: "var(--color-primary-light)",
        Essay: "var(--color-success-light)",
        "True/False": "var(--color-warning-light)",
      };
      chip.style.cssText = `
        padding: 2px 10px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        background: ${colorMap[t] || "var(--color-border)"};
        color: var(--color-text-primary);
      `;
      typesRow.appendChild(chip);
    });
    metaWrap.appendChild(typesRow);
  }

  metaWrap.appendChild(questionCountLine);
  textWrap.appendChild(metaWrap);

  // DOM order: [icon] [textWrap] [btnWrap] — icon as a sibling of textWrap
  // (not nested in h3) matches createCategoryCard's pattern, same as
  // createExamCard. On desktop: .user-quiz--phone-only-emoji is display:none.
  card.appendChild(iconEl);
  card.appendChild(textWrap);
  card.appendChild(btnWrap);

  // Admin upload button now lives exclusively inside the ⋮ dropdown menu
  // (see showUserQuizActionsOverlay below), on all screen sizes — no
  // top-left card placement anymore.

  return card;
}

/** A local lesson is a workspace item with reading, not quiz, behavior. */
export function createUserLessonCard(lesson) {
  const lessonId = lesson.id || lesson.meta?.id;
  const title = lesson.meta?.title || "درس بدون عنوان";
  const description = lesson.meta?.description || lesson.description || "";
  const sections = lesson.stats?.sectionCount ?? lesson.lesson?.sections?.length ?? 0;
  // Reuses collectLessonInfo (same source the ⋮ menu's info rows and the
  // info modal use) instead of re-deriving the question count here, so the
  // card badge and the info modal can never disagree.
  const questionCount = lesson.stats?.questionCount ?? collectLessonInfo(lesson).questionCount;
  const card = document.createElement("div");
  card.className = "exam-card user-quiz-card user-lesson-card";
  card.setAttribute("role", "article");
  card.setAttribute("aria-label", `درس: ${title}`);

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.className = "user-quiz-select-checkbox";
  checkbox.dataset.quizId = lessonId;
  const selected = getSelectedUserQuizzes();
  checkbox.checked = selected.has(lessonId);
  checkbox.onclick = (event) => {
    event.stopPropagation();
    checkbox.checked ? selected.add(lessonId) : selected.delete(lessonId);
    updateBulkActionBar();
  };

  // Pressing the card itself selects it while in selection mode — same
  // pattern as createUserQuizCard above and the folder/course cards in
  // user-quizzes-folders.js.
  card.addEventListener("click", (e) => {
    if (e.target === checkbox) return;
    const container = document.querySelector(".user-quizzes-container");
    if (container?.classList.contains("selection-mode-active")) {
      e.stopPropagation();
      checkbox.click();
    }
  });

  const icon = document.createElement("span");
  icon.className = "user-quiz--phone-only-emoji";
  icon.textContent = "📘";

  icon.setAttribute("aria-hidden", "true");
  const text = document.createElement("div");
  text.className = "card-text";
  text.append(createTypeChip("lesson"));
  tagCardType(card, "lesson");
  const heading = document.createElement("h3");
  heading.textContent = title;
  heading.setAttribute("data-tooltip-badge", "📘 درس");
  heading.setAttribute("data-tooltip-text", title);
  const meta = document.createElement("div");
  meta.className = "exam-card-meta user-quiz-card-meta";
  const label = document.createElement("p");
  label.className = "exam-question-count";
  label.textContent = `${sections} ${sections === 1 ? "قسم" : "أقسام"}`;
  meta.appendChild(label);
  // Embedded-question count on the right — .exam-types-subtext is already
  // styled by .exam-card-meta to sit on the right side (order:2) opposite
  // .exam-question-count's left side (order:1); see index.css. Only shown
  // when the lesson actually has embedded questions, same "only if present"
  // rule the info modal's rows follow.
  if (questionCount > 0) {
    const questionsLabel = document.createElement("p");
    questionsLabel.className = "exam-types-subtext";
    questionsLabel.textContent = `الأسئلة المدمجة: ${questionCount}`;
    meta.appendChild(questionsLabel);
  }
  text.append(heading);
  if (description) {
    const desc = document.createElement("p");
    desc.className = "lesson-card-description";
    desc.textContent = description;
    desc.setAttribute("data-tooltip-badge", "📄 وصف الدرس");
    desc.setAttribute("data-tooltip-text", description);
    text.append(desc);
  }
  text.append(meta);

  const actions = document.createElement("div");
  actions.className = "exam-card-actions-wrap";
  // ⋮ button — same class/placement as the quiz card's, opening the lesson
  // equivalent of showUserQuizActionsOverlay (edit lives inside that menu now,
  // exactly like quizzes: the menu is the single entry point for editing).
  const more = document.createElement("button");
  more.className = "exam-more-btn";
  more.type = "button";
  more.innerHTML = MORE_DOTS_ICON_SVG;
  more.setAttribute("aria-label", `خيارات إضافية لـ ${title}`);
  more.onclick = (event) => {
    event.stopPropagation();
    showUserLessonActionsOverlay(lesson, more);
  };
  const start = document.createElement("button");
  start.className = "start-btn";
  start.type = "button";
  // .start-btn's base rule is `width: 100%` (built for a single full-width
  // play button on normal exam cards). The quiz card overrides this inline
  // to flex:1/min-width:0 so its play + download buttons share the row
  // instead of both claiming 100% width and stacking on top of each other
  // (see createUserQuizCard above) — the lesson card needs the same
  // override for the same two-button row.
  start.style.flex = "1";
  start.style.minWidth = "0";
  start.textContent = "ابدأ القراءة";
  start.onclick = (event) => {
    event.stopPropagation();
    playUserLesson(lesson);
  };
  const download = document.createElement("button");
  download.className = "start-btn desktop-download-btn";
  download.type = "button";
  download.style.flex = "1";
  download.style.minWidth = "0";
  download.innerHTML = `${DOWNLOAD_ICON_SVG}<span>تحميل</span>`;
  download.disabled = false;
  download.setAttribute("aria-label", `تحميل درس ${title}`);
  download.onclick = (event) => {
    event.stopPropagation();
    void withDownloadLoading(download, () => downloadLesson(lesson, download));
  };
  actions.append(more, start, download);
  card.append(checkbox, icon, text, actions);
  return card;
}

/** A local notebook: an executable MATLAB-style notebook stored in the workspace (browser only). */
export function createUserNotebookCard(nb) {
  const nbId = nb.id || nb.meta?.id;
  const title = nb.meta?.title || "دفتر بدون عنوان";
  // Same card body as the platform notebook card (notebook-card-view.js):
  // title, description, cell count, runtime label and the type chip.
  const { card, icon, text } = createNotebookCardShell({
    title,
    description: nb.meta?.description || "",
    cellCount: nb.stats?.cellCount ?? nb.notebook?.content?.cells?.length ?? 0,
    runtime: nb.notebook?.runtime || "matlab",
    cardClass: "exam-card user-quiz-card user-lesson-card user-notebook-card",
    iconClass: "user-quiz--phone-only-emoji",
  });
  card.setAttribute("aria-label", `دفتر: ${title}`);

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.className = "user-quiz-select-checkbox";
  checkbox.dataset.quizId = nbId;
  const selected = getSelectedUserQuizzes();
  checkbox.checked = selected.has(nbId);
  checkbox.onclick = (event) => {
    event.stopPropagation();
    checkbox.checked ? selected.add(nbId) : selected.delete(nbId);
    updateBulkActionBar();
  };
  card.addEventListener("click", (e) => {
    if (e.target === checkbox) return;
    const container = document.querySelector(".user-quizzes-container");
    if (container?.classList.contains("selection-mode-active")) {
      e.stopPropagation();
      checkbox.click();
    }
  });

  const actions = createNotebookActionRow({
    title,
    onMore: (trigger) => showUserNotebookActionsOverlay(nb, trigger),
    onOpen: () => playUserNotebook(nb),
    onDownload: (button) => showNotebookDownloadModal(nb, button),
  });
  card.append(checkbox, icon, text, actions);
  return card;
}

export function showUserNotebookActionsOverlay(nb, triggerBtn) {
  const nbId = nb.id || nb.meta?.id;
  const title = nb.meta?.title || "دفتر بدون عنوان";
  openItemDropdownMenu(triggerBtn, (menu, closeMenu, reposition) => {
    if (isAdminAuthenticated() || hasAdminSessionHint()) {
      const uploadBtn = createNotebookUploadButton(nb);
      uploadBtn.addEventListener("click", () => closeMenu());
      menu.appendChild(uploadBtn);
    }
    appendSelectOption(menu, closeMenu, nbId);
    appendEditGroup(menu, closeMenu, reposition, [
      {
        label: "تعديل الدفتر",
        icon: EDIT_ICON_SVG,
        onClick: () => { window.location.href = `/notebook/edit/${encodeURIComponent(nbId)}`; },
      },
      {
        label: "الوصف والمصدر",
        icon: EDIT_ICON_SVG,
        onClick: () =>
          openDescriptionSourceModal({
            title,
            description: nb.meta?.description || "",
            source: nb.meta?.source || "",
            onSave: ({ description, source }) => saveLocalItemMetadata(nbId, description, source),
          }),
      },
      { label: "تغيير العنوان", icon: RENAME_ICON_SVG, onClick: () => renameItem(nbId, title) },
    ]);
    appendMoveGroup(menu, closeMenu, reposition, nbId);
    appendNotebookMenuEntries(menu, closeMenu, reposition, nb);
    const deleteOpt = document.createElement("button");
    deleteOpt.type = "button";
    deleteOpt.className = "exam-action-btn exam-action-btn--danger";
    deleteOpt.innerHTML = `${TRASH_ICON_SVG}<span>حذف الدفتر</span>`;
    deleteOpt.onclick = (e) => {
      e.stopPropagation();
      closeMenu();
      deleteFolder(nbId);
    };
    menu.appendChild(deleteOpt);
  });
}

export function playUserNotebook(nb) {
  const nbId = nb.id || nb.meta?.id;
  try {
    window.location.href = `/notebook/${encodeURIComponent(nbId)}?type=user`;
  } catch (error) {
    console.error("Error opening user notebook:", error);
    _alert("حدث خطأ أثناء فتح الدفتر. حاول مرة أخرى.");
  }
}

/**
 * Action Overlay for workspace lessons — the lesson twin of
 * showUserQuizActionsOverlay below, built from the same .item-dropdown-menu /
 * .exam-action-btn classes so the two menus are visually identical.
 *
 * Every action reuses a type-generic helper rather than a lesson-specific
 * copy: renameItem / openMoveToDialog / deleteFolder all operate on any
 * user_quizzes row by id (deleteFolder is named for folders but its
 * confirm/trash/cascade/refresh path is fully item-generic — see its doc
 * comment). Admin uploads use the same placement wizard as folder contents,
 * while download formats stay on the lesson card's download button.
 */
export function showUserLessonActionsOverlay(lesson, triggerBtn) {
  const lessonId = lesson.id || lesson.meta?.id;
  const title = lesson.meta?.title || "درس بدون عنوان";

  openItemDropdownMenu(triggerBtn, (menu, closeMenu, reposition) => {
    if (isAdminAuthenticated() || hasAdminSessionHint()) {
      const uploadBtn = createLessonUploadButton(lesson);
      uploadBtn.addEventListener("click", () => closeMenu());
      menu.appendChild(uploadBtn);
    }

    appendSelectOption(menu, closeMenu, lessonId);

    appendEditGroup(menu, closeMenu, reposition, [
      {
        label: "تعديل الدرس",
        icon: EDIT_ICON_SVG,
        onClick: () => { window.location.href = `/create-lesson?edit=${encodeURIComponent(lessonId)}`; },
      },
      {
        label: "الوصف والمصدر",
        icon: EDIT_ICON_SVG,
        onClick: () =>
          openDescriptionSourceModal({
            title,
            description: lesson.meta?.description || lesson.description || "",
            source: lesson.meta?.source || lesson.source || "",
            onSave: ({ description, source }) => saveLocalItemMetadata(lessonId, description, source),
          }),
      },
      { label: "تغيير العنوان", icon: RENAME_ICON_SVG, onClick: () => renameItem(lessonId, title) },
    ]);

    // ── "معلومات الدرس" submenu — same quick-rows-then-"كل المعلومات"
    // pattern as the quiz menu, but the rows come from collectLessonInfo()
    // (sections/questions/dates), not quiz fields. The full dialog is the
    // lesson-specific modal, never the quiz one.
    const info = collectLessonInfo(lesson);
    const basicRows = [
      { label: "ID", val: info.id, multiline: true, copyable: true, ltr: true },
      { label: "الأقسام", val: info.sectionCount || null },
      { label: "الأسئلة المدمجة", val: info.questionCount || null },
      { label: "التاريخ", val: formatDateForInfo(info.createdAt), ltr: true },
    ].filter((r) => r.val);
    menu.appendChild(
      createExamInfoSubmenu(
        basicRows,
        () => showUserLessonInfoModal(lesson),
        closeMenu,
        reposition,
        "معلومات الدرس",
      ),
    );

    appendMoveGroup(menu, closeMenu, reposition, lessonId);

    const askAiOpt = document.createElement("button");
    askAiOpt.type = "button";
    askAiOpt.className = "exam-action-btn";
    askAiOpt.innerHTML = `${SPARKLE_ICON_SVG}<span>اسأل الباشـمبصمج</span>`;
    askAiOpt.onclick = (e) => {
      e.stopPropagation();
      closeMenu();
      const attachment = resolveUserItemAttachment(lessonId);
      if (attachment) {
        openAIAgentWithAttachment(attachment, { defaultSystemPrompt: HOME_PAGE_SYSTEM_PROMPT });
      }
    };
    menu.appendChild(askAiOpt);

    const deleteOpt = document.createElement("button");
    deleteOpt.type = "button";
    deleteOpt.className = "exam-action-btn exam-action-btn--danger";
    deleteOpt.innerHTML = `${TRASH_ICON_SVG}<span>حذف الدرس</span>`;
    deleteOpt.onclick = (e) => {
      e.stopPropagation();
      closeMenu();
      deleteFolder(lessonId);
    };
    menu.appendChild(deleteOpt);
  });
}

export function playUserLesson(lesson) {
  const lessonId = lesson.id || lesson.meta?.id;
  try {
    sessionStorage.setItem("active_user_lesson", JSON.stringify(lesson));
    window.location.href = `/lesson/${encodeURIComponent(lessonId)}?type=user`;
  } catch (error) {
    console.error("Error opening user lesson:", error);
    _alert("حدث خطأ أثناء فتح الدرس. حاول مرة أخرى.");
  }
}

/**
 * Play a user-created quiz
 */
export function playUserQuiz(quiz) {
  try {
    // Store the quiz data temporarily for the quiz page to access
    sessionStorage.setItem("active_user_quiz", JSON.stringify(quiz));

    // Navigate to quiz page with special parameter
    const mode = userProfile.getDefaultQuizMode();
    window.location.href = `/quiz/${encodeURIComponent(quiz.id)}?type=user`;
  } catch (error) {
    console.error("Error playing user quiz:", error);
    _alert("حدث خطأ أثناء بدء الامتحان. حاول مرة أخرى.");
  }
}

/**
 * Delete a user-created quiz — soft delete into the local trash (see
 * user-quizzes-trash.js and plan §4) rather than discarding it outright. */
export async function deleteUserQuiz(quizId) {
  try {
    if (!(await _confirm("سيُنقل هذا الامتحان إلى سلة المهملات. هل تريد المتابعة؟"))) {
      return;
    }

    const userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
    const target = userQuizzes.find((q) => q.id === quizId);
    if (!target) return;

    const filteredQuizzes = userQuizzes.filter((q) => q.id !== quizId);
    moveToTrash([target], qz(target, "title") || target.meta?.title || "امتحان بلا اسم");
    setInStorage("user_quizzes", JSON.stringify(filteredQuizzes));

    // Re-render the folder view
    renderRootCategories();
    renderUserQuizzesView();
    refreshUserQuizzesCard();

    showNotification("تم النقل إلى السلة", "تم نقل الامتحان إلى سلة المهملات بنجاح", "./favicon.png");
  } catch (error) {
    console.error("Error deleting quiz:", error);
    _alert("Error deleting quiz. Please try again.");
  }
}

/**
 * Action Overlay for user-made quizzes — styled identically to
 * showExamActionsOverlay (same .item-dropdown-menu/.exam-action-btn
 * classes), but with only the options that make sense for a locally-stored,
 * non-shareable quiz: edit, info, and delete. No copy-link/share here since
 * user quizzes aren't shareable (they live in localStorage, not on a
 * server), and Download already has its own dedicated button on the card.
 */
export function showUserQuizActionsOverlay(quiz, triggerBtn) {
  openItemDropdownMenu(triggerBtn, (menu, closeMenu, reposition) => {
    // Admin upload — only rendered for authenticated admins. Shown inside
    // the dropdown on ALL screen sizes (desktop and mobile) now, styled
    // identically to Edit/Delete via createUploadButton()'s own
    // .exam-action-btn class — no wrapper div needed.
    if (isAdminAuthenticated() || hasAdminSessionHint()) {
      const uploadBtn = createUploadButton(quiz);
      uploadBtn.addEventListener("click", () => closeMenu());
      menu.appendChild(uploadBtn);
    }

    // ── Mobile-only Download button ───────────────────────────────────────
    // Mirrors showExamActionsOverlay's mobile download option. Hidden on
    // desktop (≥641px) via the .mobile-only class — the card's own
    // desktop-download-btn handles that form factor.
    const userQuizPwd = qz(quiz, "password");
    const downloadOpt = document.createElement("button");
    downloadOpt.type = "button";
    downloadOpt.className = userQuizPwd
      ? "exam-action-btn mobile-only exam-action-btn--primary is-password-protected"
      : "exam-action-btn mobile-only exam-action-btn--primary";
    downloadOpt.innerHTML = userQuizPwd
      ? `${LOCK_ICON_SVG}<span>تحميل</span>`
      : `${DOWNLOAD_ICON_SVG}<span>تحميل</span>`;
    if (userQuizPwd) downloadOpt.title = "هذا الامتحان محمي بكلمة مرور";
    downloadOpt.onclick = (e) => {
      e.stopPropagation();
      closeMenu();
      showUserQuizDownloadPopup(quiz);
    };
    menu.appendChild(downloadOpt);

    appendSelectOption(menu, closeMenu, quiz.id || quiz.meta?.id);

    // ── Edit group — تعديل الامتحان / الوصف والمصدر / تغيير العنوان in one
    // submenu (this menu is the single entry-point for editing; the card has
    // no standalone edit icon).
    appendEditGroup(menu, closeMenu, reposition, [
      {
        label: "تعديل الامتحان",
        icon: EDIT_ICON_SVG,
        onClick: () => { window.location.href = `create-quiz?edit=${encodeURIComponent(quiz.id)}`; },
      },
      {
        label: "الوصف والمصدر",
        icon: EDIT_ICON_SVG,
        onClick: () =>
          openDescriptionSourceModal({
            title: qz(quiz, "title") || "الامتحان",
            description: qz(quiz, "description") || "",
            source: qz(quiz, "source") || "",
            onSave: ({ description, source }) => saveLocalItemMetadata(quiz.id || quiz.meta?.id, description, source),
          }),
      },
      { label: "تغيير العنوان", icon: RENAME_ICON_SVG, onClick: () => renameItem(quiz.id || quiz.meta?.id, qz(quiz, "title")) },
    ]);

    // ── "معلومات الامتحان" submenu — user quizzes carry everything already
    // in localStorage (quiz.meta/quiz.stats), so the preview builds
    // synchronously straight from qz(). Shows only id, description,
    // category, date, and source (المصدر is copy-to-clipboard).
    const basicRows = [
      { label: "ID", val: quiz.id, multiline: true, copyable: true, ltr: true },
      { label: "المادة", val: qz(quiz, "category") || null, multiline: true },
      { label: "الوصف", val: qz(quiz, "description") || null, multiline: true },
      { label: "التاريخ", val: formatDateForInfo(qz(quiz, "createdAt")), ltr: true },
      {
        label: "المصدر",
        val: normalizeSource(qz(quiz, "source")),
        multiline: true,
        copyable: true,
      },
    ].filter((r) => r.val);
    const infoSubmenu = createExamInfoSubmenu(
      basicRows,
      () => showUserQuizInfoModal(quiz),
      closeMenu,
      reposition,
    );
    menu.appendChild(infoSubmenu);

    // ── Move group — نقل إلى / نقل إلى الخارج (touch-friendly fallback for
    // drag-and-drop).
    appendMoveGroup(menu, closeMenu, reposition, quiz.id || quiz.meta?.id);

    // ── PHASE 2: "اسأل الباشـمبصمج" — opens the AI Agent with this
    // quiz/folder/course pre-attached (see ai-agent-attach-launcher.js's
    // own doc comment for the full rationale on why this is a minimal,
    // tool-free "home" pageKey chat rather than reusing
    // user-quizzes-view.js's own live tool config directly).
    const askAiOpt = document.createElement("button");
    askAiOpt.type = "button";
    askAiOpt.className = "exam-action-btn";
    askAiOpt.innerHTML = `${SPARKLE_ICON_SVG}<span>اسأل الباشـمبصمج</span>`;
    askAiOpt.onclick = (e) => {
      e.stopPropagation();
      closeMenu();
      const itemId = qz(quiz, "id") || quiz.id || quiz.meta?.id;
      const attachment = resolveUserItemAttachment(itemId);
      if (attachment) {
        openAIAgentWithAttachment(attachment, {
          defaultSystemPrompt: HOME_PAGE_SYSTEM_PROMPT,
        });
      }
    };
    menu.appendChild(askAiOpt);

    const deleteOpt = document.createElement("button");
    deleteOpt.type = "button";
    deleteOpt.className = "exam-action-btn exam-action-btn--danger";
    deleteOpt.innerHTML = `${TRASH_ICON_SVG}<span>حذف الامتحان</span>`;
    deleteOpt.onclick = (e) => {
      e.stopPropagation();
      closeMenu();
      deleteUserQuiz(quiz.id);
    };
    menu.appendChild(deleteOpt);
  });
}

export function saveLocalItemMetadata(itemId, description, source) {
  const items = JSON.parse(getFromStorage("user_quizzes", "[]"));
  const item = items.find((row) => (row.id || row.meta?.id) === itemId);
  if (!item) throw new Error("لم يتم العثور على العنصر في «محتواي».");
  item.meta = { ...(item.meta || {}), description, source, updatedAt: new Date().toISOString() };
  if (!setInStorage("user_quizzes", JSON.stringify(items))) {
    throw new Error("تعذّر حفظ التغييرات في التخزين المحلي.");
  }
  renderRootCategories();
  renderUserQuizzesView();
  return true;
}


// ── Shared ⋮ menu groups ────────────────────────────────────────────────────
// Related actions are collapsed into submenus so the dropdown stays short.
// Used by both the quiz and lesson menus so they can never drift apart.

function appendSelectOption(menu, closeMenu, itemId) {
  const selectOpt = document.createElement("button");
  selectOpt.type = "button";
  selectOpt.className = "exam-action-btn";
  selectOpt.innerHTML = `${CHECK_SQUARE_SVG}<span>تحديد</span>`;
  selectOpt.onclick = (e) => {
    e.stopPropagation();
    closeMenu();
    selectItem(itemId);
  };
  menu.appendChild(selectOpt);
}

function appendEditGroup(menu, closeMenu, reposition, actions) {
  menu.appendChild(createActionGroupSubmenu(actions, closeMenu, reposition, "تعديل", EDIT_ICON_SVG));
}

function appendMoveGroup(menu, closeMenu, reposition, itemId) {
  const actions = [{ label: "نقل إلى", icon: MOVE_TO_ICON_SVG, onClick: () => openMoveToDialog([itemId]) }];
  if (currentFolderId !== null) {
    actions.push({ label: "نقل إلى الخارج", icon: MOVE_TO_ICON_SVG, onClick: () => moveItemOutOfFolder(itemId) });
  }
  menu.appendChild(createActionGroupSubmenu(actions, closeMenu, reposition, "نقل", MOVE_TO_ICON_SVG));
}

const CHECK_SQUARE_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`;
