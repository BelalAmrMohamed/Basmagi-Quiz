// ============================================================================
// public/src/features/home/user-quizzes-view.js
// USER CONTENT VIEW — the "محتواي" (My Content) screen: card grid,
// admin sign-in/out bar, bulk selection + bulk action bar, and drag-and-drop
// file import.
// ============================================================================
// NOTE: this module and user-quiz-card.js import from each other
// (renderUserQuizzesView/updateBulkActionBar here, createUserQuizCard there).
// This is a real circular import, safe because neither side calls the
// other's export at module-evaluation time — only from inside event
// handlers/functions, by which point both modules have finished loading.
// ============================================================================

import { handleMyContentDrop } from "./notebook-file-import.js";
import { getFromStorage, setInStorage } from "../../shared/storage-helpers.js";
import { isAdminAuthenticated, fullSignOut } from "../../shared/adminAuth.js";
import { _prompt } from "../../components/notifications/notifications.js";
import { openItemDropdownMenu } from "./item-dropdown-menu.js";
import {
  currentFolderId,
  getChildren,
  getCurrentFolderPathStack,
  navigateToFolder,
  showContextMenu,
  handleDragStart,
  handleDragEnd,
  handleDragOver,
  handleDragLeave,
  handleDrop,
  createNewFolderOrCourse,
  createFolderOrCourseCard,
  buildFolderHash,
  openMoveToDialog,
  createFolderOrCourseNamed,
  findFolderByName,
  moveItemsToFolder,
  expandSelectionWithDescendants,
  hasSameLevelCollision,
  uploadFolderForAdmins,
} from "./user-quizzes-folders.js";
import { openSignInDialog } from "../../components/log-in/sign-in.js";
import { container, title } from "./dom-refs.js";
import { createEmptyState } from "./empty-state.js";
import {
  getNavigationStack,
  isRestoring,
  getIndexSupabaseClient,
  getSelectedUserQuizzes,
  getSearchManager,
} from "./app-state.js";
import { updateBreadcrumb } from "./breadcrumb.js";
import { renderTitleBreadcrumb } from "./title-breadcrumb.js";
import { getSubjectIcon } from "./subject-icons.js";
import { qz, saveNewUserQuiz, buildUserQuizEntry } from "./quiz-schema.js";
import { createUserQuizCard, createUserLessonCard, createUserNotebookCard } from "./user-quiz-card.js";
import { takePendingHighlight } from "./mcp-draft-import.js";
import { openInlineCreateQuizModal } from "./create-quiz-modal.js";
import { createAIAgentFab } from "../../components/ai-agent/ai-agent.js";
import { HOME_PAGE_SYSTEM_PROMPT } from "../../components/ai-agent/ai-agent-default-prompts.js";
import { HOME_PAGE_SUGGESTED_PROMPTS } from "../../components/ai-agent/ai-agent-suggested-prompts.js";
import { handleReadOnlyLibraryToolCall, READONLY_LIBRARY_TOOL_NAMES } from "../../components/ai-agent/ai-agent-readonly-tools.js";
import { CREATOR_TOOL_NAMES, handleCreatorToolCall } from "../../components/ai-agent/ai-agent-creator-tools.js";
import { createItemCardResult } from "../../components/ai-agent/ai-agent-result-cards.js";
import { toSlug } from "./slug-utils.js";
import { renderRootCategories } from "./root-view.js";
import {
  importJsonQuizFiles,
  wireJsonFileDropZone,
} from "./quiz-file-import.js";
import {
  ADMIN_SIGN_OUT_ICON_SVG,
  ADMIN_SIGN_IN_ICON_SVG,
  CHECK_SQUARE_ICON_SVG,
  TRASH_ICON_SVG,
  DOWNLOAD_ICON_SVG,
  MOVE_TO_ICON_SVG,
} from "./icons.js";
import {
  showNotification,
  _confirm,
} from "../../components/notifications/notifications.js";

function userItemRoute(item, items) {
  const kind = item.kind;
  const id = item.id || item.meta?.id;
  if (kind === "quiz") return `/quiz/${encodeURIComponent(id)}?type=user`;
  if (kind === "lesson") return `/lesson/${encodeURIComponent(id)}`;
  if (kind === "notebook") return `/notebook/${encodeURIComponent(id)}?type=user`;
  if (kind !== "folder" && kind !== "course") return "/my-content";

  const byId = new Map(items.map((entry) => [entry.id || entry.meta?.id, entry]));
  const segments = [];
  let current = item;
  const seen = new Set();
  while (current && !seen.has(current.id || current.meta?.id)) {
    const currentId = current.id || current.meta?.id;
    seen.add(currentId);
    const title = current.meta?.title;
    if (title) segments.unshift(encodeURIComponent(toSlug(title)));
    current = current.meta?.parentId ? byId.get(current.meta.parentId) : null;
  }
  return segments.length ? `/my-content/${segments.join("/")}` : "/my-content";
}

function getUserItemDestination(item, items) {
  let parentId = item.meta?.parentId || null;
  const byId = new Map(items.map((entry) => [entry.id || entry.meta?.id, entry]));
  const ancestors = [];
  const seen = new Set();
  while (parentId && !seen.has(parentId)) {
    seen.add(parentId);
    const parent = byId.get(parentId);
    if (!parent) break;
    if (parent.meta?.title) ancestors.unshift(parent.meta.title);
    parentId = parent.meta?.parentId || null;
  }
  return ancestors.length ? ancestors.join(" / ") : "محتواي الرئيسية";
}

function createdItemResult(kind, item, items, detail) {
  return createItemCardResult({
    kind,
    id: item.id || item.meta?.id,
    title: item.meta?.title || item.title || "عنصر جديد",
    detail,
    destination: getUserItemDestination(item, items),
    href: userItemRoute({ ...item, kind }, items),
  });
}
import { moveToTrash, getTrashItemCount } from "./user-quizzes-trash.js";
import { openLocalTrashPanel } from "./user-quizzes-trash-panel.js";
import { refreshUserQuizzesCard } from "./course-count.js";
import { normalizeLessonJson } from "../lesson/lesson-json.js";

/**
 * Handles the AI Helper's `create_quiz` tool call: validates the payload,
 * saves it via the same tested save path the manual paste-JSON modal uses
 * (saveNewUserQuiz, in quiz-schema.js), notifies the user, and refreshes
 * the grid. Returns the chat bubble text to show for this result.
 * @param {{name: string, input: object}} toolCall
 * @returns {string} text shown in the chat as the tool-result bubble
 */
function handleCreateQuizToolCall(toolCall) {
  const input = toolCall?.input || {};
  const questions = Array.isArray(input.questions) ? input.questions : [];

  if (!questions.length) {
    showNotification(
      "بيانات ناقصة",
      "لم يتمكن الباشــمبصمج من إنشاء الامتحان: لا توجد أسئلة صالحة.",
      "warning",
      10,
    );
    const err = new Error("create_quiz tool call had no questions");
    err.userMessage = "تعذر إنشاء الامتحان: لا توجد أسئلة صالحة.";
    throw err;
  }

  const title = input.title || "Untitled Quiz";
  const parsed = {
    questions,
    meta: { title, description: input.description || "" },
  };

  // `folder`, like create_folder's `parentFolder` / move_item's
  // `destinationFolder`, is an exact title matched against the folder-tree
  // listing already in the model's context — resolve it to an id with the
  // same shared helper those tools use, so "محتواي الرئيسية"/omitted
  // both mean top-level consistently across every placement-aware tool.
  const folderResolution = resolveFolderTitleToId(input.folder);
  if (!folderResolution.ok) {
    showNotification("لم يتم العثور على المجلد", folderResolution.reason, "warning", 10);
    const err = new Error("create_quiz tool call had an unresolvable folder");
    err.userMessage = folderResolution.reason;
    throw err;
  }

  const result = saveNewUserQuiz(parsed, title, folderResolution.id);
  if (result.ok === false) {
    showNotification("الاسم مستخدم", result.reason, "warning", 10);
    const err = new Error("create_quiz tool call hit a same-level name clash");
    err.userMessage = result.reason;
    throw err;
  }

  showNotification(
    "تم الإنشاء",
    'تم إنشاء الامتحان وإضافته إلى "محتواي"',
    "success",
  );
  renderRootCategories();
  renderUserQuizzesView();
  const items = JSON.parse(getFromStorage("user_quizzes", "[]"));
  const saved = items.find((item) => (item.id || item.meta?.id) === result.id) || result;
  return createdItemResult("quiz", saved, items, `${questions.length} سؤال${questions.length === 1 ? "" : "اً"} · جاهز للحل الآن`);
}

function handleCreateLessonToolCall(toolCall) {
  const input = toolCall?.input || {};
  const sectionsInput = Array.isArray(input.sections) ? input.sections : [];

  const fail = (message) => {
    showNotification("تعذر إنشاء الدرس", message, "warning", 10);
    const error = new Error(message);
    error.userMessage = message;
    throw error;
  };

  let lesson;
  try {
    lesson = normalizeLessonJson({ ...input, sections: sectionsInput });
  } catch (error) {
    fail(error.userMessage || error.message || "تحقق من بيانات الدرس والأقسام والأسئلة.");
  }
  const { title, description, sections, questionCount } = lesson;

  const quizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
  if (hasSameLevelCollision(quizzes, { type: "lesson", title, parentId: null })) {
    fail("يوجد درس بنفس الاسم في «محتواي». اختر عنواناً مختلفاً.");
  }

  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const entry = {
    id,
    meta: {
      id,
      type: "lesson",
      title,
      description,
      parentId: null,
      createdAt: new Date().toLocaleString("en-US"),
      updatedAt: now,
      readerPrefs: { fontId: "default" },
      passwordProtected: false,
    },
    stats: { questionCount, sectionCount: sections.length },
    lesson: { sections },
    questions: [],
  };
  const updated = [...quizzes, entry];
  if (!setInStorage("user_quizzes", JSON.stringify(updated))) {
    fail("تعذّر حفظ الدرس محلياً. تحقق من مساحة التخزين وحاول مرة أخرى.");
  }

  showNotification("تم إنشاء الدرس", 'تم إنشاء الدرس وإضافته إلى "محتواي".', "success");
  renderRootCategories();
  renderUserQuizzesView();
  const items = JSON.parse(getFromStorage("user_quizzes", "[]"));
  const saved = items.find((item) => (item.id || item.meta?.id) === id) || entry;
  return createdItemResult("lesson", saved, items, `${sections.length} ${sections.length === 1 ? "قسم" : "أقسام"} · جاهز للقراءة`);
}

/**
 * Handles the AI Helper's `edit_quiz` tool call. Finds the quiz by its
 * exact current title (matched against user_quizzes, the same source the
 * model was given via contextSummary), applies only the fields present in
 * the tool input, and persists the merged entry through buildUserQuizEntry
 * — the same normalization path saveNewUserQuiz uses — so edited quizzes
 * keep the same shape as newly-created ones.
 * @param {{name: string, input: object}} toolCall
 * @returns {string} text shown in the chat as the tool-result bubble
 */
function handleEditQuizToolCall(toolCall) {
  const input = toolCall?.input || {};
  const currentTitle = (input.currentTitle || "").trim();

  if (!currentTitle) {
    const err = new Error("edit_quiz tool call had no currentTitle");
    err.userMessage = "تعذر تعديل الامتحان: لم يتم تحديد الامتحان المطلوب تعديله.";
    throw err;
  }

  const quizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
  const index = quizzes.findIndex((q) => qz(q, "title") === currentTitle);

  if (index === -1) {
    const err = new Error(`edit_quiz: no quiz titled "${currentTitle}" found`);
    err.userMessage = `تعذر العثور على امتحان بعنوان "${currentTitle}".`;
    throw err;
  }

  const existing = quizzes[index];
  const newTitle = input.title || qz(existing, "title");

  const existingId = qz(existing, "id") || existing.id;
  if (
    newTitle !== qz(existing, "title") &&
    hasSameLevelCollision(quizzes, {
      type: "quiz",
      title: newTitle,
      parentId: existing.meta?.parentId || null,
      excludeId: existingId,
    })
  ) {
    const err = new Error(`edit_quiz: renaming to "${newTitle}" collides with an existing quiz`);
    err.userMessage = `يوجد امتحان بنفس الاسم "${newTitle}" في هذا المستوى بالفعل.`;
    throw err;
  }

  const parsed = {
    // Only overwrite questions if the model actually sent a replacement
    // list — omitting `questions` in the tool call means "keep as-is",
    // per EDIT_QUIZ_TOOL's description (see api/ai-agent/_tools.js).
    questions: Array.isArray(input.questions) && input.questions.length
      ? input.questions
      : existing.questions,
    meta: {
      ...existing.meta,
      title: newTitle,
      description: input.description ?? existing.meta?.description ?? "",
    },
  };

  const entry = buildUserQuizEntry(existingId, parsed, newTitle);
  quizzes[index] = entry;
  setInStorage("user_quizzes", JSON.stringify(quizzes));

  showNotification("تم التعديل", `تم تعديل الامتحان "${newTitle}"`, "success");
  renderRootCategories();
  renderUserQuizzesView();
  return `✅ تم تعديل الامتحان: ${newTitle}`;
}

/**
 * Handles the AI Helper's `delete_quiz` tool call. The system prompt
 * already instructs the model to only call this after the user explicitly
 * confirmed the exact quiz name in chat (see HOME_PAGE_SYSTEM_PROMPT) —
 * that confirmation, already given once in the conversation, is the single
 * source of truth. This intentionally does NOT add a second native/in-app
 * confirmation dialog on top: a prior version did, and the result was the
 * user confirming once in chat only to be asked again by a popup — a
 * redundant, confusing second gate on the exact same decision. create_quiz
 * and edit_quiz never had this second gate either; delete_quiz shouldn't
 * be the odd one out just because it's destructive — the chat confirmation
 * already carries that weight.
 * @param {{name: string, input: object}} toolCall
 * @returns {string} text shown in the chat as the tool-result bubble
 */
function handleDeleteQuizToolCall(toolCall) {
  const input = toolCall?.input || {};
  const title = (input.title || "").trim();

  if (!title) {
    const err = new Error("delete_quiz tool call had no title");
    err.userMessage = "تعذر حذف الامتحان: لم يتم تحديد اسم الامتحان.";
    throw err;
  }

  const quizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
  const match = quizzes.find((q) => qz(q, "title") === title);

  if (!match) {
    const err = new Error(`delete_quiz: no quiz titled "${title}" found`);
    err.userMessage = `تعذر العثور على امتحان بعنوان "${title}".`;
    throw err;
  }

  const remaining = quizzes.filter((q) => q !== match);
  setInStorage("user_quizzes", JSON.stringify(remaining));

  showNotification("تم الحذف", `تم حذف الامتحان "${title}"`, "success");
  renderRootCategories();
  renderUserQuizzesView();
  return `🗑️ تم حذف الامتحان: ${title}`;
}

/**
 * "محتواي الرئيسية" (root) is how the folder-tree context prompt and
 * move_item's destinationFolder both refer to the top level — resolve that
 * literal label the same way for both create_folder's parentFolder and
 * move_item's destinationFolder so the model can use the exact string it
 * was given back in context, instead of having to know to omit the field
 * (which it won't reliably infer purely from the schema description).
 */
function resolveFolderTitleToId(folderTitle) {
  if (!folderTitle || folderTitle === "محتواي الرئيسية" || folderTitle === "امتحاناتك الرئيسية" || folderTitle === "الرئيسية") {
    return { ok: true, id: null };
  }
  const found = findFolderByName(folderTitle);
  if (!found) {
    return { ok: false, reason: `لم يتم العثور على "${folderTitle}".` };
  }
  return { ok: true, id: found.id };
}

function handleCreateFolderToolCall(toolCall) {
  const { name, parentFolder } = toolCall?.input || {};
  if (!name || !name.trim()) {
    const err = new Error("create_folder called without a name");
    err.userMessage = "اسم المجلد مطلوب.";
    throw err;
  }

  const parentResolution = resolveFolderTitleToId(parentFolder);
  if (!parentResolution.ok) {
    const err = new Error(parentResolution.reason);
    err.userMessage = parentResolution.reason;
    throw err;
  }

  const result = createFolderOrCourseNamed("folder", name.trim(), parentResolution.id);
  if (!result.ok) {
    const err = new Error(result.reason);
    err.userMessage = result.reason;
    throw err;
  }

  renderUserQuizzesView();
  const items = JSON.parse(getFromStorage("user_quizzes", "[]"));
  const saved = items.find((item) => (item.id || item.meta?.id) === result.id);
  return createdItemResult("folder", saved || { id: result.id, meta: { title: name.trim(), parentId: parentResolution.id } }, items, "مجلد جديد · جاهز لتنظيم محتواك");
}

function handleCreateCourseToolCall(toolCall) {
  const { name } = toolCall?.input || {};
  if (!name || !name.trim()) {
    const err = new Error("create_course called without a name");
    err.userMessage = "اسم المادة مطلوب.";
    throw err;
  }

  // Courses are always top-level — see createFolderOrCourseNamed's own
  // guard, which this relies on rather than duplicating the check here.
  const result = createFolderOrCourseNamed("course", name.trim(), null);
  if (!result.ok) {
    const err = new Error(result.reason);
    err.userMessage = result.reason;
    throw err;
  }

  renderUserQuizzesView();
  const items = JSON.parse(getFromStorage("user_quizzes", "[]"));
  const saved = items.find((item) => (item.id || item.meta?.id) === result.id);
  return createdItemResult("course", saved || { id: result.id, meta: { title: name.trim(), parentId: null } }, items, "مادة جديدة · مساحة مرتبة لمحتواك");
}

function handleMoveItemToolCall(toolCall) {
  const { itemName, destinationFolder } = toolCall?.input || {};
  if (!itemName || !itemName.trim()) {
    const err = new Error("move_item called without an itemName");
    err.userMessage = "اسم العنصر المراد نقله مطلوب.";
    throw err;
  }

  // The item being moved can be a quiz, a folder, or a course — quizzes
  // aren't findable via findFolderByName (folders/courses only), so quiz
  // titles are matched directly against user_quizzes here.
  const userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
  const normalize = (s) => (s || "").trim().toLowerCase();
  const item = userQuizzes.find((q) => normalize(q.meta?.title) === normalize(itemName));
  if (!item) {
    const err = new Error(`Item not found: ${itemName}`);
    err.userMessage = `لم يتم العثور على "${itemName}".`;
    throw err;
  }
  const itemId = item.id || item.meta?.id;

  const destResolution = resolveFolderTitleToId(destinationFolder);
  if (!destResolution.ok) {
    const err = new Error(destResolution.reason);
    err.userMessage = destResolution.reason;
    throw err;
  }

  const { moved, blocked, saveFailed } = moveItemsToFolder([itemId], destResolution.id);
  renderUserQuizzesView();

  if (moved > 0) {
    return `✅ تم نقل "${itemName}" إلى ${destinationFolder || "محتواي الرئيسية"}.`;
  }
  const err = new Error(`Move blocked/no-op for ${itemName}`);
  err.userMessage = saveFailed
    ? "تعذّر حفظ النقل محلياً. قد تكون مساحة التخزين ممتلئة."
    : blocked > 0
      ? "لا يمكن نقل مجلد إلى داخل نفسه أو أحد مجلداته الفرعية، ولا يمكن نقل مادة إلى داخل مجلد آخر."
      : `"${itemName}" موجود بالفعل في هذا الموقع.`;
  throw err;
}

/**
 * Renders the user's folder/course tree as an indented plain-text list by
 * title (root "محتواي الرئيسية" first, then each folder/course nested
 * under its parent) for the AI agent's system-context — this is the only
 * way the model can resolve create_folder's parentFolder or move_item's
 * itemName/destinationFolder to a real location, since (like every other
 * tool on this page) it only ever sees titles, never internal ids.
 * @param {object[]} userQuizzes
 * @returns {string}
 */
function buildFolderTreeContextPrompt(userQuizzes) {
  const nodes = userQuizzes.filter(
    (q) => q.meta?.type === "folder" || q.meta?.type === "course",
  );
  const lines = ["هيكل المجلدات والمواد الحالي للمستخدم:", "- محتواي الرئيسية (المستوى الرئيسي)"];

  function appendChildren(parentId, depth) {
    nodes
      .filter((n) => (n.meta?.parentId || null) === parentId)
      .forEach((n) => {
        const nid = n.id || n.meta?.id;
        const kind = n.meta?.type === "course" ? "مادة" : "مجلد";
        lines.push(`${"  ".repeat(depth)}- ${n.meta?.title || ""} (${kind})`);
        appendChildren(nid, depth + 1);
      });
  }
  appendChildren(null, 1);

  return lines.join("\n");
}

/**
 * Single entry point passed as onToolCall to createAIAgentFab — dispatches
 * to the right handler by tool name. Keeps ai-agent-chat.js generic (it
 * just calls whatever onToolCall it was given) while each page decides
 * which tool names it actually supports.
 *
 * async because search_library/parse_item_info/get_user_activity resolve
 * platform-side results via the client-side Supabase-backed manifest
 * (ai-agent-library-search.js) — ai-agent-chat.js's call site already
 * `await`s this handler unconditionally, so the existing synchronous
 * handlers below are unaffected by this becoming async.
 * @param {{name: string, input: object}} toolCall
 * @returns {Promise<string>} text shown in the chat as the tool-result bubble
 */
async function handleQuizToolCall(toolCall) {
  switch (toolCall?.name) {
    case "create_lesson":
      return handleCreateLessonToolCall(toolCall);
    case "create_quiz":
      return handleCreateQuizToolCall(toolCall);
    case "edit_quiz":
      return handleEditQuizToolCall(toolCall);
    case "delete_quiz":
      return handleDeleteQuizToolCall(toolCall);
    case "create_folder":
      return handleCreateFolderToolCall(toolCall);
    case "create_course":
      return handleCreateCourseToolCall(toolCall);
    case "move_item":
      return handleMoveItemToolCall(toolCall);
    case "search_library":
    case "parse_item_info":
    case "get_user_activity":
      // These three read-only tools are shared with the attach-launcher
      // panel (see ai-agent-attach-launcher.js) — handled by one common
      // module rather than duplicated here. See
      // ai-agent-readonly-tools.js's own header comment.
      return handleReadOnlyLibraryToolCall(toolCall);
    case "get_creator_info":
    case "display_creator_card":
      return handleCreatorToolCall(toolCall);
    default: {
      const err = new Error(`Unknown tool call: ${toolCall?.name}`);
      err.userMessage = "أداة غير معروفة.";
      throw err;
    }
  }
}

/**
 * Render user-created quizzes VIEW (Folder Content)
 */
/** Marks the card of a freshly created item (looked up by data-item-id). No-op if it is not on this level. */
function highlightNewItem(container, itemId) {
  if (!itemId) return;
  const card = Array.from(container.querySelectorAll("[data-item-id]")).find((el) => el.dataset.itemId === itemId);
  if (!card) return;
  card.classList.add("mcp-new-item");
  const badge = document.createElement("span");
  badge.className = "mcp-new-badge";
  badge.textContent = "جديد";
  card.appendChild(badge);
  const clear = () => {
    card.classList.remove("mcp-new-item");
    badge.remove();
  };
  // the glow + badge stay until the user clicks the card (or ~30 s).
  card.addEventListener("click", clear, { once: true });
  setTimeout(clear, 30000);
  requestAnimationFrame(() => card.scrollIntoView({ behavior: "smooth", block: "center" }));
}

export function renderUserQuizzesView() {
  try {
    const selectedUserQuizzes = getSelectedUserQuizzes();
    selectedUserQuizzes.clear();

    // Update Navigation Stack — only push if we're not already sitting on
    // this same view. Without this guard, any re-render of this view while
    // already inside it (e.g. renderUserQuizzesView() called again after a
    // bulk delete) pushes a second "محتواي" frame, making the breadcrumb
    // read navigationStack[length - 2] (undefined) instead of the actual
    // parent, which broke both its label and its onclick handler.
    const navigationStack = getNavigationStack();
    const topOfStack = navigationStack[navigationStack.length - 1];
    if (!topOfStack || topOfStack.name !== "محتواي") {
      navigationStack.push({ name: "محتواي" });
    }
    updateBreadcrumb();

    // Build the correct URL hash for the current folder depth
    const folderHash = buildFolderHash();
    if (!isRestoring()) {
      history.pushState({ view: "my-content" }, "", folderHash);
      if (typeof window.syncActiveNavState === "function") window.syncActiveNavState();
    } else {
      history.replaceState({ view: "my-content" }, "", folderHash);
      if (typeof window.syncActiveNavState === "function") window.syncActiveNavState();
    }

    // Fix the #breadcrumb back-button for nested user-quiz folders.
    // updateBreadcrumb() only knows about the navigationStack which holds
    // a single "محتواي" entry — it always renders "الرجوع إلى المواد ←"
    // regardless of how deep we are in the folder tree. Override it directly
    // based on the real folderPathStack.
    const pathStack = getCurrentFolderPathStack();
    const breadcrumbEl = document.getElementById("breadcrumb");
    if (breadcrumbEl && pathStack.length > 0) {
      breadcrumbEl.classList.add("show");
      breadcrumbEl.setAttribute("aria-hidden", "false");
      const breadcrumbText = breadcrumbEl.querySelector(".breadcrumb-text");
      if (breadcrumbText) {
        if (pathStack.length === 1) {
          // Parent is the root of user-quizzes
          breadcrumbText.textContent = "الرجوع إلى محتواي ←";
          breadcrumbEl.onclick = () => navigateToFolder(null, null);
          breadcrumbEl.setAttribute("aria-label", "الرجوع إلى محتواي ←");
        } else {
          // Parent is the previous folder in the path stack
          const parentFolder = pathStack[pathStack.length - 2];
          breadcrumbText.textContent = `الرجوع إلى ${parentFolder.title} ←`;
          breadcrumbEl.onclick = () => navigateToFolder(parentFolder.id, parentFolder.title);
          breadcrumbEl.setAttribute("aria-label", `الرجوع إلى ${parentFolder.title} ←`);
        }
      }

      // MOVE OUT OF FOLDER — make the back-breadcrumb itself a valid drop
      // target. Previously the only background drop target was
      // quizzesContainer, which resolves to `currentFolderId` — a no-op
      // when you're already inside a folder, since it just re-parents the
      // item to the folder it's already in. Dropping on the "الرجوع إلى
      // ..." breadcrumb instead moves the item to the parent one level up,
      // which is the actual "move out" gesture this view was missing.
      const targetParentId = pathStack.length === 1 ? null : pathStack[pathStack.length - 2].id;
      breadcrumbEl.ondragover = handleDragOver;
      breadcrumbEl.ondragleave = handleDragLeave;
      breadcrumbEl.ondrop = (e) => handleDrop(e, targetParentId);
    } else if (breadcrumbEl) {
      breadcrumbEl.ondragover = null;
      breadcrumbEl.ondragleave = null;
      breadcrumbEl.ondrop = null;
    }

    // Update Title: use the smart collapsible breadcrumb in #Subjects-text.
    // Build items from folderPathStack: root = "محتواي", then each folder.
    if (title) {
      let userQuizzes = [];
      try {
        userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
      } catch (e) {
        userQuizzes = [];
      }

      // dropTargetId is carried separately from onClick: every ancestor
      // crumb (including the current/last one, which has no onClick) is a
      // valid "move item here" drop target, not just the clickable ones.
      const bcItems = [
        {
          label: "محتواي",
          icon: "🗂️",
          onClick: pathStack.length > 0 ? () => navigateToFolder(null, null) : undefined,
          dropTargetId: null,
        },
        ...pathStack.map((f, idx) => {
          const item = userQuizzes.find((q) => (q.id || q.meta?.id) === f.id);
          const isCourse = item?.meta?.type === "course" || (!item?.meta?.type && idx === 0);
          const icon = item?.meta?.icon || (isCourse ? getSubjectIcon(f.title, false) : "📁");
          return {
            label: f.title,
            icon: icon,
            onClick:
              idx < pathStack.length - 1
                ? () => navigateToFolder(f.id, f.title)
                : undefined, // last = current, non-clickable
            dropTargetId: f.id,
          };
        }),
      ];
      renderTitleBreadcrumb(title, bcItems);

      // MOVE INTO ANY ANCESTOR — wire drag/drop onto the rendered crumb
      // elements too (renderTitleBreadcrumb doesn't take drop handlers
      // itself), so dropping a quiz/folder on ANY ancestor in the path —
      // not just the immediate parent — moves it there directly, including
      // the current (non-clickable) crumb which represents "stay here".
      // Matched by index since renderTitleBreadcrumb renders one
      // .title-breadcrumb-item per bcItems entry, in the same order
      // (it may collapse the middle into a "…" dropdown, but the first and
      // last items — the ones most useful as drop targets — always render).
      requestAnimationFrame(() => {
        const crumbEls = title.querySelectorAll(".title-breadcrumb-item");
        crumbEls.forEach((el) => {
          const label = el.getAttribute("title");
          const match = bcItems.find((it) => it.label === label);
          if (!match) return;
          el.ondragover = handleDragOver;
          el.ondragleave = handleDragLeave;
          el.ondrop = (e) => {
            e.stopPropagation();
            handleDrop(e, match.dropTargetId);
          };
        });
      });
    }

    if (!container) return;

    container.innerHTML = "";
    container.className = "grid-container user-quizzes-drop-zone";

    const userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));

    // Update search context for user quizzes
    const searchManager = getSearchManager();
    if (searchManager) {
      searchManager.container.style.display = ""; // Reset inline hide
      searchManager.setUserQuizzesContext(userQuizzes);
    }

    // 1. Create 'Create New Quiz' Button (Always visible at top)
    const actionsBar = document.createElement("div");
    actionsBar.className = "user-quiz-search-actions";

    // Mobile "مجلد جديد" button — a dropdown with both "مجلد جديد" and
    // "مادة جديدة" (previously hardcoded to always create a folder, so
    // phone users had no way to create a course at all — that was only
    // reachable via the desktop right-click context menu). Course creation
    // stays root-only, matching the same rule the desktop context menu
    // already enforces (see showContextMenu in user-quizzes-folders.js).
    const createFolderBtn = document.createElement("button");
    createFolderBtn.type = "button";
    createFolderBtn.innerHTML = `<span>إنشاء</span> <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>`;
    createFolderBtn.className = "btn create-folder-btn mobile-only-flex";
    // Broadened from "مجلد أو مادة جديدة" now that this dropdown also
    // covers quiz creation and the trash link (see docs/plans/
    // implementation-plan.md items 9/10) — the button's own visible label
    // ("إنشاء") already covered this; only the a11y label needed updating.
    createFolderBtn.setAttribute("aria-label", "إنشاء أو الوصول إلى سلة المهملات");
    createFolderBtn.setAttribute("aria-haspopup", "menu");
    createFolderBtn.onclick = (e) => {
      e.stopPropagation();
      openItemDropdownMenu(createFolderBtn, (menu, closeMenu) => {
        menu.dataset.unordered = "1"; // create menu, not an item menu
        // "امتحان جديد" — opens the same modal previously reachable
        // via the standalone .user-create-quiz-card in the quiz grid
        // (createInlineCreateQuizCard(), removed per docs/plans/
        // implementation-plan.md testing notes: it duplicated this menu
        // entry once item 10 added it here and to #userQuizContextMenu).
        const quizOpt = document.createElement("button");
        quizOpt.type = "button";
        quizOpt.className = "exam-action-btn";
        quizOpt.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M9 15h6"/><path d="M12 18v-6"/></svg><span>امتحان جديد</span>`;
        quizOpt.onclick = (e) => {
          e.stopPropagation();
          closeMenu();
          openInlineCreateQuizModal();
        };
        menu.appendChild(quizOpt);

        // "درس جديد" — opens the inline create lesson modal, which creates the
        // lesson directly in currentFolderId (or root if at root).
        const lessonOpt = document.createElement("button");
        lessonOpt.type = "button";
        lessonOpt.className = "exam-action-btn";
        lessonOpt.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/><path d="M9 10h6"/><path d="M12 7v6"/></svg><span>درس جديد</span>`;
        lessonOpt.onclick = (e) => {
          e.stopPropagation();
          closeMenu();
          import("./create-lesson-modal.js").then(({ openInlineCreateLessonModal }) => {
            openInlineCreateLessonModal();
          });
        };
        menu.appendChild(lessonOpt);

        // "دفتر جديد" — local executable MATLAB-style notebook (.ipynb / .m / JSON).
        const notebookOpt = document.createElement("button");
        notebookOpt.type = "button";
        notebookOpt.className = "exam-action-btn";
        notebookOpt.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="m8 10 3 2-3 2"/><path d="M13 15h3"/></svg><span>دفتر جديد</span>`;
        notebookOpt.onclick = (e) => {
          e.stopPropagation();
          closeMenu();
          import("./create-notebook-modal.js").then(({ openInlineCreateNotebookModal }) => {
            openInlineCreateNotebookModal();
          });
        };
        menu.appendChild(notebookOpt);

        const folderOpt = document.createElement("button");
        folderOpt.type = "button";
        folderOpt.className = "exam-action-btn";
        folderOpt.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg><span>مجلد جديد</span>`;
        folderOpt.onclick = (e) => {
          e.stopPropagation();
          closeMenu();
          createNewFolderOrCourse("folder");
        };
        menu.appendChild(folderOpt);

        const courseOpt = document.createElement("button");
        courseOpt.type = "button";
        courseOpt.className = "exam-action-btn";
        courseOpt.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg><span>مادة جديدة</span>`;
        if (currentFolderId === null) {
          courseOpt.onclick = (e) => {
            e.stopPropagation();
            closeMenu();
            createNewFolderOrCourse("course");
          };
        } else {
          // Shown-disabled with an explanation, rather than hidden — a
          // silently-missing option here would look like a bug, the same
          // inconsistency Part 3 flags for the desktop context menu.
          courseOpt.disabled = true;
          courseOpt.title = "يمكن إنشاء المواد في الصفحة الرئيسية لـ«محتواي» فقط";
          courseOpt.style.opacity = "0.5";
          courseOpt.style.cursor = "not-allowed";
        }
        menu.appendChild(courseOpt);

        // "استيراد مجلد من جهازك" (admin only) — phones have no right-click,
        // so this global action lives in the mobile "إنشاء" dropdown.
        if (isAdminAuthenticated()) {
          const importOpt = document.createElement("button");
          importOpt.type = "button";
          importOpt.className = "exam-action-btn";
          importOpt.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg><span>استيراد مجلد من جهازك</span>`;
          importOpt.onclick = (e) => {
            e.stopPropagation();
            closeMenu();
            uploadFolderForAdmins();
          };
          menu.appendChild(importOpt);
        }

        // "سلة المهملات" — same gating as root-view.js's "محتواي" card
        // ⋮ menu and the #userQuizContextMenu global actions (see
        // user-quizzes-folders.js's showContextMenu): only shown once
        // there's at least one trashed item.
        const trashCount = getTrashItemCount();
        if (trashCount > 0) {
          const trashOpt = document.createElement("button");
          trashOpt.type = "button";
          trashOpt.className = "exam-action-btn";
          trashOpt.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg><span>سلة المهملات (${trashCount})</span>`;
          trashOpt.onclick = (e) => {
            e.stopPropagation();
            closeMenu();
            openLocalTrashPanel();
          };
          menu.appendChild(trashOpt);
        }
      });
    };
    actionsBar.appendChild(createFolderBtn);

    // Selection mode only makes sense when there's actually something to
    // select — hide the toggle entirely for an empty quiz list.
    if (userQuizzes.length > 0) {
      const toggleSelectionBtn = document.createElement("button");
      toggleSelectionBtn.type = "button";
      toggleSelectionBtn.className = "btn selection-toggle-btn mobile-only-flex";
      toggleSelectionBtn.innerHTML = `<span>تحديد الامتحانات</span> ${CHECK_SQUARE_ICON_SVG}`;
      toggleSelectionBtn.onclick = () => {
        const qzContainer = container.querySelector(".user-quizzes-container");
        if (qzContainer) {
          qzContainer.classList.toggle("selection-mode-active");
          const isActive = qzContainer.classList.contains(
            "selection-mode-active",
          );
          toggleSelectionBtn.classList.toggle("active", isActive);
          if (!isActive) {
            selectedUserQuizzes.clear();
            document
              .querySelectorAll(".user-quiz-select-checkbox")
              .forEach((cb) => (cb.checked = false));
          }
          // Show the bar as soon as selection mode turns on (even with
          // nothing selected yet, so "تحديد الكل" is reachable), and hide
          // it the moment selection mode turns off.
          updateBulkActionBar(isActive);
        }
      };
      actionsBar.appendChild(toggleSelectionBtn);
    }

    container.appendChild(actionsBar);

    // Drag-and-drop import on the whole user-content section: .json (quiz), .ipynb / .m / .zip (notebooks)
    wireJsonFileDropZone(container, (files) => handleMyContentDrop(files), {
      isEnabled: () => container.classList.contains("user-quizzes-drop-zone"),
    });

    // 2. Dedicated container for quiz cards — gets its own border/border-radius
    //    so the sign-in button and create card sit outside the bordered list.
    const quizzesContainer = document.createElement("div");
    quizzesContainer.className = "user-quizzes-container";

    // (Breadcrumbs are now shown in the #Subjects-text header above, not here)

    // Attach Context Menu & Drop events to the container
    quizzesContainer.addEventListener("contextmenu", (e) => {
      if (e.target === quizzesContainer || e.target.closest(".user-quizzes-drop-zone")) {
        showContextMenu(e, "background", null, null);
      }
    });

    quizzesContainer.addEventListener("dragover", handleDragOver);
    quizzesContainer.addEventListener("dragleave", handleDragLeave);
    quizzesContainer.addEventListener("drop", (e) => handleDrop(e, currentFolderId));

    // Filter userQuizzes based on current folder
    const currentChildren = getChildren(userQuizzes, currentFolderId);

    // 3. Quiz cards (or empty state) go into quizzesContainer, not container
    if (currentChildren.length === 0) {
      // Empty state
      const emptyState = createEmptyState({
        variant: "panel",
        icon: "folder",
        title: currentFolderId
          ? "هذا المجلد فارغ"
          : "لم تقم بإنشاء أي محتوى بعد",
        subtitle: "قم بإنشاء مادة ، أو مجلد ، أو امتحان ، أو درس ، أو دفتر",
      });
      quizzesContainer.appendChild(emptyState);
    } else {
      currentChildren.forEach((item, index) => {
        if (item.meta?.type === "folder" || item.meta?.type === "course") {
          const folderCard = createFolderOrCourseCard(item);
          quizzesContainer.appendChild(folderCard);
        } else {
          const quizCard = item.meta?.type === "lesson"
            ? createUserLessonCard(item)
            : item.meta?.type === "notebook"
              ? createUserNotebookCard(item)
              : createUserQuizCard(item, index);
          // Attach drag and context menu to quiz card
          quizCard.draggable = true;
          quizCard.addEventListener("dragstart", (e) => handleDragStart(e, item.id || item.meta?.id));
          quizCard.addEventListener("dragend", handleDragEnd);
          quizCard.addEventListener("contextmenu", (e) => {
            e.stopPropagation();
            showContextMenu(e, "item", item.id || item.meta?.id, item.meta?.title);
          });
          quizCard.dataset.itemId = item.id || item.meta?.id || "";
          quizzesContainer.appendChild(quizCard);
        }
      });
    }

    // Prepend removed (docs/plans/implementation-plan.md testing notes):
    // the standalone create-quiz card used to be prepended here, but is
    // now redundant with the "امتحان جديد" entry in the
    // create-folder-btn dropdown above and #userQuizContextMenu — both
    // call openInlineCreateQuizModal() directly, so no in-grid card is
    // needed to reach the same modal.

    container.appendChild(quizzesContainer);

    // An item that was just created from an MCP link gets a «جديد» badge +
    // glow and is scrolled into view (see .mcp-new-item in index.css).
    highlightNewItem(quizzesContainer, takePendingHighlight());

    // ── AI Helper — floating action button that opens the modal widget on
    // click (see public/src/components/ai-agent/ai-agent.js). Mounted once
    // per render; harmless to recreate since the old one is discarded with
    // container.innerHTML = "" at the top of this function, and a FAB
    // fixed-positioned outside the render flow doesn't need special
    // placement here beyond being present in the DOM.
    //
    // contextSummary: a lightweight { title, questionCount, types } per
    // quiz — NOT the full quiz JSON, which could blow the context window.
    // Read access lets the assistant answer "what quizzes do I have"
    // without a tool round-trip; create access (enableTools +
    // onToolCall) lets it save a new quiz once the user confirms one.
    const getLiveContextSummary = () => {
      const liveQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
      return liveQuizzes.map((quiz) => ({
        title: qz(quiz, "title"),
        itemType: quiz.meta?.type || "quiz",
        questionCount: qz(quiz, "count"),
        sectionCount: quiz.stats?.sectionCount || quiz.lesson?.sections?.length || 0,
        types: qz(quiz, "type"),
      }));
    };

    const getLiveFolderTreePrompt = () => {
      const liveQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
      return buildFolderTreeContextPrompt(liveQuizzes);
    };

    container.appendChild(
      createAIAgentFab({
        placeholder: "اسأل الباشــمبصمج",
        pageKey: "home",
        defaultSystemPrompt: HOME_PAGE_SYSTEM_PROMPT,
        suggestedPrompts: HOME_PAGE_SUGGESTED_PROMPTS,
        enableFileUpload: true,
        contextSummary: getLiveContextSummary,
        contextPrompt: getLiveFolderTreePrompt,
        enableTools: true,
        toolNames: ["create_lesson", "create_quiz", "edit_quiz", "delete_quiz", "create_folder", "create_course", "move_item", "fetch_attached_quiz", ...READONLY_LIBRARY_TOOL_NAMES, ...CREATOR_TOOL_NAMES],
        onToolCall: handleQuizToolCall,
      }),
    );

    renderBulkActionBar();
  } catch (error) {
    console.error("Error rendering user quizzes view:", error);
    if (container) {
      container.innerHTML = `
  <div class="error-state" role="alert">
    <p>حدث خطأ أثناء تحميل الإختبارات. يرجى تحديث الصفحة.</p>
    <button onclick="renderRootCategories()" type="button">الرجوع للرئيسية</button>
  </div>
`;
    }
  }
}

// ─── Bulk Action Helpers ────────────────────────────────────────────────────────

function downloadQuizAsJson(quiz) {
  const dataStr =
    "data:text/json;charset=utf-8," +
    encodeURIComponent(JSON.stringify(quiz, null, 2));
  const dlAnchorElem = document.createElement("a");
  dlAnchorElem.setAttribute("href", dataStr);
  const safeTitle = (quiz.meta?.title || quiz.title || "quiz")
    .replace(/[^a-zA-Z0-9\u0600-\u06FF\s-_]/g, "")
    .trim();
  dlAnchorElem.setAttribute("download", safeTitle + ".json");
  dlAnchorElem.click();
}

/**
 * Classifies a bulk selection (raw user_quizzes rows) by item type and
 * decides which upload wizard (if any) the selection should open, per the
 * routing rules in admin-upload-update.md:
 *   - courses only (one or more)              -> "course" wizard
 *   - courses mixed with folders/quizzes       -> "mixed" (blocked; courses
 *                                                 must be uploaded alone
 *                                                 with their own contents)
 *   - folders (+ optionally loose quizzes/lessons),
 *     no courses                               -> "folder" wizard
 *   - lessons (with optional quizzes),
 *     no courses/folders                       -> "folder" wizard (choose a
 *                                                 destination course)
 *   - quizzes only, no courses/folders          -> "quiz" wizard (existing
 *                                                 single/batch flow)
 * @param {Array} rows - raw user_quizzes rows matching the selection
 * @returns {{
 *   mode: "course"|"folder"|"quiz"|"mixed"|"empty",
 *   courses: Array, folders: Array, quizzes: Array, lessons: Array
 * }}
 */
function classifyBulkSelection(rows) {
  const courses = [];
  const folders = [];
  const quizzes = [];
  const lessons = [];
  const notebooks = [];
  for (const row of rows) {
    if (row?.meta?.type === "course") courses.push(row);
    else if (row?.meta?.type === "folder") folders.push(row);
    else if (row?.meta?.type === "lesson") lessons.push(row);
    else if (row?.meta?.type === "notebook") notebooks.push(row);
    else quizzes.push(row);
  }

  let mode;
  if (courses.length === 0 && folders.length === 0 && quizzes.length === 0 && lessons.length === 0 && notebooks.length === 0) {
    mode = "empty";
  } else if (courses.length > 0 && (folders.length > 0 || quizzes.length > 0 || lessons.length > 0 || notebooks.length > 0)) {
    mode = "mixed";
  } else if (courses.length > 0) {
    mode = "course";
  } else if (folders.length > 0 || lessons.length > 0 || notebooks.length > 0) {
    mode = "folder";
  } else {
    mode = "quiz";
  }

  return { mode, courses, folders, quizzes, lessons, notebooks };
}

/**
 * Routes a bulk selection to the right upload wizard (adminUpload.js),
 * per classifyBulkSelection's mode. Shared by both bulk-upload-button
 * wiring sites (renderBulkActionBar's inline build + ensureBulkUploadButton's
 * lazy-attach path) so the routing logic can't drift out of sync between
 * the two.
 * @param {Array} selected - raw user_quizzes rows matching the selection
 */
function routeBulkUpload(selected) {
  const { mode, courses, folders, quizzes, lessons, notebooks } = classifyBulkSelection(selected);

  if (mode === "empty") return;

  if (mode === "mixed") {
    showNotification(
      "لا يمكن رفع هذا التحديد معاً",
      `المواد ترفع وحدها مع محتوياتها الكاملة. تم تحديد ${courses.length} مادة مع ${folders.length + quizzes.length + lessons.length + notebooks.length} عنصر آخر — ألغِ تحديد المواد أو حددها بمفردها.`,
      "warning",
    );
    return;
  }

  const userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
  const selectedFolderIds = new Set(folders.map((item) => item.id || item.meta?.id));
  const notStandalone = (lesson) => {
    let parentId = lesson.meta?.parentId || null;
    const visited = new Set();
    while (parentId && !visited.has(parentId)) {
      if (selectedFolderIds.has(parentId)) return false;
      visited.add(parentId);
      const parent = userQuizzes.find((item) => (item.id || item.meta?.id) === parentId);
      parentId = parent?.meta?.parentId || null;
    }
    return true;
  };
  const standaloneLessons = lessons.filter(notStandalone);
  const standaloneNotebooks = notebooks.filter(notStandalone);

  if (mode === "course") {
    import("./adminUpload.js").then((mod) => {
      mod.openCourseUploadModal(courses, userQuizzes);
    });
    return;
  }

  if (mode === "folder") {
    import("./adminUpload.js").then((mod) => {
      mod.openFolderUploadModal({ folders, quizzes, lessons: standaloneLessons, notebooks: standaloneNotebooks, userQuizzes });
    });
    return;
  }

  // mode === "quiz"
  import("./adminUpload.js").then((mod) => {
    mod.openAdminUploadModal(quizzes);
  });
}

/**
 * Lazily creates and wires the admin-only upload button inside an existing
 * bulk action bar if it's missing and the admin is (now) authenticated.
 *
 * This exists because renderBulkActionBar() below only builds the bar's
 * DOM once per page load and caches it — the upload button's presence was
 * previously decided a single time, at first-build, from whatever
 * isAdminAuthenticated() returned in that instant. If the bar happened to
 * get built before an admin signed in (the totally normal case of
 * browsing anonymously, then logging in as admin mid-session via the
 * sidebar — session-sync.js's onRecovered path — without a full reload),
 * the button was simply never created, and nothing afterward ever
 * re-checked: it stayed permanently absent for the rest of the session.
 * Calling this from updateBulkActionBar() (already invoked on every
 * selection/auth-relevant UI refresh) means the button appears as soon as
 * the admin session is recognized, without needing a reload.
 */
function ensureBulkUploadButton(bar, selectedUserQuizzes) {
  if (bar.querySelector(".bulk-upload-btn") || !isAdminAuthenticated()) return;

  const btn = document.createElement("button");
  btn.className = "btn bulk-upload-btn";
  btn.title = "رفع الامتحان (للمشرفين)";
  btn.style.display = "none";
  btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg>`;

  // Placed right before the "clear selection" (✕) button, matching where
  // it's positioned when built inline at bar-creation time.
  const clearBtn = bar.querySelector(".bulk-clear-btn");
  if (clearBtn) clearBtn.before(btn);
  else bar.querySelector(".bulk-actions")?.appendChild(btn);

  btn.onclick = () => {
    if (selectedUserQuizzes.size === 0) return;
    const userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
    const selected = userQuizzes.filter((q) =>
      selectedUserQuizzes.has(q.id || q.meta?.id),
    );
    routeBulkUpload(selected);
  };
}

/**
 * Refresh the bulk action bar's visibility, selected-count label, and the
 * "select all" button's state.
 *
 * @param {boolean|undefined} forceActive - when provided, this overrides the
 *   visibility decision (used right when selection mode is toggled on/off,
 *   before any card has necessarily been selected). When omitted, visibility
 *   is inferred from whether the quiz grid is currently in selection mode.
 */
export function updateBulkActionBar(forceActive) {
  const selectedUserQuizzes = getSelectedUserQuizzes();
  const bar = document.getElementById("bulk-action-bar");
  if (!bar) return;

  ensureBulkUploadButton(bar, selectedUserQuizzes);

  const qzContainer = document.querySelector(".user-quizzes-container");
  const selectionModeActive =
    typeof forceActive === "boolean"
      ? forceActive
      : !!qzContainer?.classList.contains("selection-mode-active");

  if (!selectionModeActive) {
    bar.style.display = "none";
    return;
  }

  bar.style.display = "flex";

  const count = selectedUserQuizzes.size;
  bar.querySelector(".bulk-count").textContent =
    count > 0 ? `تم تحديد ${count}` : "لم يتم تحديد أي شيء";

  // Hide the destructive/export actions when nothing is selected (not just
  // disabled — fully hidden so the bar looks clean with only count + select-all
  // when zero items are selected).
  const hasSelection = count > 0;
  bar
    .querySelectorAll(".bulk-delete-btn, .bulk-extract-btn, .bulk-upload-btn, .bulk-move-btn")
    .forEach((btn) => {
      btn.style.display = hasSelection ? "" : "none";
    });

  // Keep the "تحديد الكل" button in sync with whether everything visible
  // is currently selected.
  const selectAllBtn = bar.querySelector(".bulk-select-all-btn");
  if (selectAllBtn) {
    const totalCheckboxes = document.querySelectorAll(
      ".user-quiz-select-checkbox",
    ).length;
    const allSelected = totalCheckboxes > 0 && count >= totalCheckboxes;
    selectAllBtn.textContent = allSelected ? "إلغاء التحديد" : "الكل";
    selectAllBtn.classList.toggle("all-selected", allSelected);
  }
}

function renderBulkActionBar() {
  const selectedUserQuizzes = getSelectedUserQuizzes();
  let bar = document.getElementById("bulk-action-bar");
  if (!bar) {
    bar = document.createElement("div");
    bar.id = "bulk-action-bar";
    bar.className = "bulk-action-bar";
    bar.style.display = "none";

    let uploadBtnHtml = "";
    if (isAdminAuthenticated()) {
      uploadBtnHtml = `<button class="btn bulk-upload-btn" title="رفع الامتحان (للمشرفين)" style="display:none"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg></button>`;
    }

    bar.innerHTML = `
      <div class="bulk-count">لم يتم تحديد أي شيء</div>
      <div class="bulk-actions">
        <button class="btn bulk-select-all-btn">الكل</button>
        <button class="btn bulk-move-btn" style="display:none" title="نقل إلى" aria-label="نقل إلى">${MOVE_TO_ICON_SVG}</button>
        <button class="btn bulk-extract-btn" style="display:none" title="استخراج" aria-label="استخراج">${DOWNLOAD_ICON_SVG}</button>
        <button class="btn bulk-delete-btn" style="display:none" title="حذف" aria-label="حذف">${TRASH_ICON_SVG}</button>
        ${uploadBtnHtml}
        <button class="btn bulk-clear-btn" title="إلغاء التحديد" aria-label="إلغاء التحديد">✕</button>
      </div>
    `;
    document.body.appendChild(bar);

    bar.querySelector(".bulk-clear-btn").onclick = () => {
      selectedUserQuizzes.clear();
      const qzContainer = document.querySelector(".user-quizzes-container");
      if (qzContainer) qzContainer.classList.remove("selection-mode-active");
      const toggleBtn = document.querySelector(".selection-toggle-btn");
      if (toggleBtn) toggleBtn.classList.remove("active");
      document.querySelectorAll(".user-quiz-select-checkbox").forEach((cb) => (cb.checked = false));
      bar.style.display = "none";
    };
    bar.querySelector(".bulk-select-all-btn").onclick = () => {
      const userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
      const allIds = userQuizzes.map((q) => qz(q, "id") || q.id);
      const allCurrentlySelected =
        allIds.length > 0 && allIds.every((id) => selectedUserQuizzes.has(id));

      if (allCurrentlySelected) {
        selectedUserQuizzes.clear();
      } else {
        allIds.forEach((id) => selectedUserQuizzes.add(id));
      }

      document.querySelectorAll(".user-quiz-select-checkbox").forEach((cb) => {
        cb.checked = !allCurrentlySelected;
      });

      updateBulkActionBar();
    };

    bar.querySelector(".bulk-delete-btn").onclick = async () => {
      if (selectedUserQuizzes.size === 0) return;
      if (await _confirm("سيُنقل العناصر المحددة إلى سلة المهملات. هل تريد المتابعة؟")) {
        let userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
        const idsToDelete = expandSelectionWithDescendants(
          selectedUserQuizzes,
          userQuizzes,
        );
        const itemsToTrash = userQuizzes.filter((q) => {
          const qId = qz(q, "id") || q.id;
          return idsToDelete.has(qId);
        });
        userQuizzes = userQuizzes.filter((q) => {
          const qId = qz(q, "id") || q.id;
          return !idsToDelete.has(qId);
        });
        const label =
          itemsToTrash.length > 1
            ? `${itemsToTrash.length} عناصر محددة`
            : itemsToTrash[0]?.meta?.title || qz(itemsToTrash[0], "title") || "عنصر بلا اسم";
        moveToTrash(itemsToTrash, label);
        setInStorage("user_quizzes", JSON.stringify(userQuizzes));
        selectedUserQuizzes.clear();
        renderUserQuizzesView();
        refreshUserQuizzesCard();
      }
    };

    // ── Bulk move — the folder-tree picker (openMoveToDialog) already
    // accepts an array of ids and moves all of them in one storage write
    // (see moveItemsToFolder in user-quizzes-folders.js), so the only work
    // here is collecting the current selection and handing it off. One
    // gap: openMoveToDialog doesn't clear the shared selectedUserQuizzes
    // Set itself (it's also used by the single-item "نقل إلى" menu action,
    // which never touches that Set at all), so without clearing it here the
    // moved ids would stay marked "selected" — stale entries that would
    // silently resurface the next time the bulk bar is used. Delete already
    // clears the same Set for the same reason; move needs to as well.
    bar.querySelector(".bulk-move-btn").onclick = () => {
      if (selectedUserQuizzes.size === 0) return;
      openMoveToDialog([...selectedUserQuizzes]);
      selectedUserQuizzes.clear();
    };

    bar.querySelector(".bulk-extract-btn").onclick = async () => {
      if (selectedUserQuizzes.size === 0) return;
      const userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
      const selected = userQuizzes.filter((q) => {
        const qId = qz(q, "id") || q.id;
        return selectedUserQuizzes.has(qId) && q.meta?.type !== "lesson";
      });
      if (selected.length === 0) {
        showNotification("التصدير غير متاح", "تصدير الدروس سيُضاف في مرحلة لاحقة.", "warning");
        return;
      }
      if (selected.length === 0) return;
      const dataStr =
        "data:text/json;charset=utf-8," +
        encodeURIComponent(JSON.stringify(selected, null, 2));
      const dlAnchorElem = document.createElement("a");
      dlAnchorElem.setAttribute("href", dataStr);
      dlAnchorElem.setAttribute(
        "download",
        `my-personal-quizzes__${selected.length}.json`,
      );
      dlAnchorElem.click();
    };

    if (isAdminAuthenticated()) {
      bar.querySelector(".bulk-upload-btn").onclick = () => {
        if (selectedUserQuizzes.size === 0) return;
        const userQuizzes = JSON.parse(getFromStorage("user_quizzes", "[]"));
        const selected = userQuizzes.filter((q) =>
          selectedUserQuizzes.has(q.id || q.meta?.id),
        );
        routeBulkUpload(selected);
      };
    }
  }
  updateBulkActionBar(false);
}